İlk Direğin Minimum Hacmi
====
Bu, ekstruderler arasında geçiş yaparken her seferinde boşaltılması gereken malzemenin miktarını belirtir. Fikir, ekstruder beklerken nozuldan belirli bir hacmin sızmasının olduğudur. Bu ayar tarafından belirtilen primlenen hacim, bunu telafi etmek içindir.

![Ekstrüde edilen hacim yeşil renkte vurgulanmıştır](../images/prime_tower.svg)

Bu ayar, temizlenmesi gereken minimum malzeme miktarını gösterir. Bununla birlikte, prime kulesinin konturları tamamen bitirilir, bu yüzden bir konturun hacmiyle ne kadar uyduğuna bağlı olarak daha fazla malzeme temizlenmiş olabilir.

Bazı yazıcılar birden fazla ayrı nozul içerirken, diğerleri birden fazla malzemeyi tek bir nozula besler. Bu ayar için iyi bir değer, iki durum arasında çok farklıdır.
* Yazıcınızın birden fazla nozulu olması durumunda, temel ihtiyaç, diğer nozul aktifken kaybolan malzemeyi telafi etmektir. Diğer nozul bir miktar malzeme sızdıracak ve nozul odasındaki basınç kaybolacaktır. Nozul odasını tekrar basınca sokmak için bir miktar malzeme yeterlidir. Daha akışkan malzemeler, PETG gibi, genellikle daha büyük bir primleme hacmine ihtiyaç duyar. Prime Kule Minimum Hacim çok düşükse, ekstruder değişiminden sonra ekstrüzyon yolunun başlangıcında [underextrusion](../troubleshooting/underextrusion.md) yaşarsınız.
* Yazıcınız birden fazla filamenti aynı nozula iterse, prime kulesi ayrıca nozuldan kalan malzemeyi de temizlemelidir. Önceki filamenti geri çekerken, nozulda her zaman küçük bir yumak kalır çünkü malzeme ısı bölgesinin altında sıvıydı ve geri kalan filamentle birlikte çekilmez. Bu nedenle, minimum prime kulesi hacmi en azından nozulun tam ısıtma bölgesinin hacmi olmalıdır. Uygulamada, bu, eski filamentin tamamını dışarı çıkarmak için çok daha fazla olmalıdır, çünkü yeni filament itildiğinde, eski filamentle karışır ve eski filamenti kenara ittirir. Tüm eski malzemeyi dışarı çıkarmak için daha fazla tampon malzeme gereklidir, böylece kirlenmeyi önler. Bütün bunlar, sızma endişesi artık bir endişe olmadığından çok daha fazla malzeme gerektirir. Prime Kule Minimum Hacim çok düşükse, malzemeler bu durumda karışır, bu nedenle renkler daha fazla kanar veya çözünebilir destek malzemesinden sonra baskınızda çukurlar oluşabilir.

Prime Kule Minimum Hacim'i çok yüksek ayarlamak nispeten zararsızdır, ancak baskının daha uzun sürmesine ve daha fazla malzeme harcamasına neden olur. Hacim, [İlk Direk Boyutu](prime_tower_size.md) tarafından sınırlı olacaktır. Hacim, o katman için prime kulesinin toplam hacminden daha yüksek ayarlanabilir, ancak prime kulesi dolu planlanırsa, baskı üzerinde hiçbir etkisi olmayacaktır.

Her ekstruder için hacim farklı olabilir, bu nedenle son kulede her bir ekstruder için farklı sayıda kontur olabilir.