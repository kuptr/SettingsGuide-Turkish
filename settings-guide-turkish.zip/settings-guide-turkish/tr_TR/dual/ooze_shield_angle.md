Sızdırma Kalkanı Açısı
====
Ooze kalkanı, modelin şeklini takip eder. Kalkan modelden yakın olmalıdır, aksi takdirde kalkandan modele olan seyahat yeni malzeme sızdırır. Ancak model yatay yüzeylere sahip olabilir, bu da ooze kalkanında dik yamaçlar oluşturur. Bu ayar, kalkanın dik yamaçlara çökmemesi için eğimi sınırlar.

![Modelin kontürlerini tam olarak takip etmek yerine, püskürtme kalkanının açısı belirtilen değeri aşmayacaktır](../images/ooze_shield.svg)

* 0 değeri, ooze kalkanını şeklin etrafında tamamen dikey hale getirir. Açı ne kadar düşük olursa, kalkan o kadar stabil olur.
* 90 değeri, ooze kalkanını modeli tam olarak takip ettirir. Açı ne kadar yüksek olursa, kalkan modelde sızmayı daha iyi önler.

Teoride [Destek Çıkıntı Açısı](../support/support_angle.md) için burada benzer bir değer kullanmak mantıklı olabilir, ancak ooze kalkanı sadece tek bir çizgidir. Bu tek çizgi, modelinizden daha zayıftır ve şekil değiştirmeye daha yatkındır. Ooze kalkanının bölünmesini önlemek için normalde modelinizde iyi basılacak bir açıdan biraz daha sığ bir açı kullanmak iyidir.