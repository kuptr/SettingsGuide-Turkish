İlk Direkteki Sürme İnaktif Nozülü
====
Eğer bu seçenek aktif edilirse, yazıcı bir sonraki nozzle'i prime kulesinde primledikten sonra önceki nozzle'i temizleyecektir.

Bu etkinleştirildiğinde olaylar şu sırayla gerçekleşir:
1. Yazıcı yeni nozzleye geçer.
2. Yeni nozzle, prime kulesi üzerinde bir prime işlemiyle primlenir.
3. Nozzle değişimi öncesinde etkin olan nozzle, prime kulesi üzerinde temizlenir.
4. Yazıcı, yeni nozzle ile parçayı devam ettirir.

Dikkat edilmesi gereken nokta, bu ayarın, nozzle değişiminden önce etkin olan nozzle'in temizlenmesine neden olmasıdır, şu anda etkin olan nozzle'in değil. Eğer yazıcınızda belirli bir mesafe ile birbirinden farklı birden fazla nozzle bulunuyorsa, katman görünümünde gereksiz gibi görünen bir hareket seyahat hareketi görebilirsiniz. Bu, önceki nozlinin prime kulesinin üzerinden geçmesine neden olan harekettir (bu, katman görünümünde resmedilmez).

Bir nozzle stand-by moda geçtikten sonra bir süre oldukça sıcak kalacaktır. Sıcakken, bazı malzemenin sızma eğilimi vardır. Prime kulesinde bir sonraki nozzle'i prime yaparken, bir miktar sızma yavaşlamış olacağından biraz soğuma şansı olacaktır. Bu ayar, dışarı sızan malzemenin, basılı modelinizin yanına gelmesini engellemek için prime kulesinin ortasında silinmesine neden olur.