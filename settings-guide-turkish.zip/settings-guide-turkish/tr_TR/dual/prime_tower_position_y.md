İlk Direk Y Konumu
====
Bu ayar, prime kulesini yeniden konumlandırmanıza olanak tanır. Bir köşesi olan prime kulesinin Y koordinatını belirtir.

![Prime kule Y koordinatı](../images/prime_tower.svg)

Bu koordinatlar, prime kulesinin merkezini değil, en düşük X ve Y koordinatlarına sahip köşesini gösterir. Prime kulesinin koordinatları, Cura'nın model konumlarını gösterdiği koordinatlardan farklıdır. Prime kulesinin nerede olacağı, diğer nesnelerin oraya yerleştirilemeyeceğini gösteren dairesel bir gölge ile baskı tablasında belirtilir.