Nozül Anahtarı Geri Çekme Hızı
====
Bir nozül bekleme konumundayken, malzeme ısı bölgesinden uzak tutulur ve bozulmasını önlemek için. Bu ayar, farklı bir ekstrüdere geçiş yapıldığında malzemenin nozul odasından ne kadar hızlı geri çekileceğini ve bu ekstrüdere geri geçildiğinde ne kadar hızlı itileceğini yapılandırır.

Ekstrüder değişimi için gerçekleştirilen geri çekme daha uzun olduğundan, bu ayar [Geri Çekme Sırasındaki Çekim Hızı](../travel/retraction_retract_speed.md) ayrı olarak yapılandırılabilir. Ayarı artırmak sızıntıyı azaltabilir, ancak filamentin ezilme olasılığı vardır, bu da besleyicinin filamenti tutma gücünü kaybetmesine neden olabilir.