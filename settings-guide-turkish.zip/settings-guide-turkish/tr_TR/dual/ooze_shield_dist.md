Sızdırma Kalkanı Mesafesi
====
Bu ayar, püskürtme kalkanının nesnenizden ne kadar uzakta olması gerektiğini (minimumda) belirler. Püskürtme kalkanının veya üzerindeki damlacıkların modelinize yapışmasını önlemek için bir miktar boşluk bırakılmalıdır.

![Kalkan ve model arasında yatay bir mesafe korunur.](../images/ooze_shield.svg)

Püskürtme kalkanını, modelinize çarpmadan mümkün olduğunca yakın bir yere yerleştirin. Kalkan ne kadar yakınsa, püskürtme ucu tarafından daha fazla oozing yapılması için kalkan ile model arasında geçen süre o kadar az olur.

Bazen kalkan, çökmemesi için belirli bir [Sızdırma Kalkanı Açısı](ooze_shield_angle.md) koruması gerektiği için modele daha fazla uzaklıkta olabilir.