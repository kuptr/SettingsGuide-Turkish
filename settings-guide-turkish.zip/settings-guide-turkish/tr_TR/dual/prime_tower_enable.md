İlk Direği Etkinleştir
====
Prime Tower Etkinleştirildiğinde, baskı platformunuzda farklı materyallerle bir kule basılır. Kule atılması amaçlanmıştır, ancak her ekstruder değişiminden sonra malzemeyi hazırlamak için hizmet eder.

![Bir prime kule nasıl görünür ve boyutları..](../images/prime_tower.svg)

Diğer ekstrüderler baskı yaparken, nozul bazen bir miktar malzeme akıtabilir ve nozul odasını malzeme boşluğu ile bırakabilir. Sonraki ekstruder değişimlerinde malzemeyi hazırlamak esastır, aksi takdirde malzeme başlangıçta düzgün bir şekilde akıtmaz.

Prime kulesi, tamamen tek bir ekstruderle her katmanı tamamen baskılanan bir dış kabuktan oluşur. Bu, kulenin istikrarını garanti etmek için gereklidir, ancak bazı baskılarda bazı ekstruder değişimleri için ekstra ekstruder değişiklikleri gerektirebilir. Diğer tüm ekstruderler, bu kabuğun içinde döngüler basar ve malzemelerini tercihen iç duvarlara bırakır. Bu ekstruderler eğer katmanı başlatmak durumundaysa prime yapmaya ihtiyaç duymazlar, çünkü bu durumda beklemeye geçmezler.

Dış kabuk için seçilen malzeme, katmanlar arasında ne kadar iyi yapıştığını gösteren [Yapışma Eğilimi](../material/material_adhesion_tendency.md) en büyük olan malzemedir. Bu, prime kulesinin kırılma riskini en aza indirmek için yapılır. Birden fazla malzemenin aynı yapışma eğilimine sahip olması durumunda (örneğin, aynı malzeme türünü kullanan çift renkli baskılar için), en düşük ekstruder numarası seçilir.

Prime kulesinin bir başka avantajı, nozulun stand-by sırasında biriken malzemeyi temizlemek için kulenin içinde bir hareket yapmasıdır. Bu, ooz'un baskıya yapışmasını engeller. Bu nedenle, prime kulesine bazen süpürme kulesi de denir.

Prime kulesinin dezavantajları, bir miktar ekstra baskı zamanı alması ve baskı platformunda bir miktar alan almasıdır.

Bir prime kulesi, baskı sırasında materyal değişikliklerini sağlamak için kullanılan bir yapıdır. Genellikle bir dış kabuk ve iç dolgudan oluşur. Dış kabuk, prime kulesini stabilize etmek için tek bir ekstruder ile tamamlanan bir dış duvarı ifade ederken, iç dolgu, diğer ekstrüzyonlar sırasında malzeme atılmasını sağlayan iç kısımları ifade eder.

Prime kulelerin boyutları, baskının gereksinimlerine ve malzeme akışını iyileştirmeye yönelik hedeflere bağlı olarak değişebilir. Tipik olarak, prime kuleler küçük yapılar olsa da, çoğu zaman baskı platformunun bir kısmını kaplarlar ve baskı süresini artırabilirler.

Prime kulelerin boyutu ve şekli, kullanılan yazılıma, malzemelere ve baskı ayarlarına bağlı olarak değişebilir. Özellikle, prime kulelerin genellikle 1 ila 3 katman yüksekliğinde olduğu ve dış kabuk kalınlığının ve iç dolgu deseninin ayarlanabileceği birkaç parametre vardır.

Bu nedenle, bir prime kulesinin belirli boyutlarını belirtmek zordur. Ancak, genel olarak, prime kulelerin çoğu baskıda ortaya çıkan nesnelerden daha küçük olduğunu söyleyebiliriz.