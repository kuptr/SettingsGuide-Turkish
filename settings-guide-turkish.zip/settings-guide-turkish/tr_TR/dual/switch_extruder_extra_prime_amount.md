Nozül Değişimiyle Çalışmaya Hazırlanacak Ek Miktar
====
Bu ayar, yazıcının, her nozul değişiminden sonra bir miktar ekstra malzeme dışarı atmasını yapılandırmanıza olanak tanır. Bu, diğer nozulların baskı yaparken veya nozul değişimi sırasında sızıntı yaparken nozul üzerindeki basıncı yenilemek için tasarlanmıştır.

Diğer nozullar baskı yaparken, bu nozul stand-by'da beklemiş olacak. Ancak bu süre zarfında, malzeme sızabilir. Bu malzeme kaybı, bir miktar ekstra malzemenin itilmesiyle telafi edilebilir. Bu, nozul odasındaki basıncı geri getirir. Ancak sızan malzeme hala nozul ucunda olacak, bu yüzden bir [İlk Direği Etkinleştir](prime_tower_enable.md) veya [Sızdırma Kalkanını Etkinleştir](ooze_shield_enabled.md) kullanılmadığı sürece, baskınızın yanına gelecektir. 

**Bu ayar, nozul başına yapılandırılabilir. Yapılandırılan malzeme miktarı, malzeme ile baskı yapmadan önce o nozulun planının başında dışarı atılır.**