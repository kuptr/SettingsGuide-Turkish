Nozül Anahtarı Geri Çekme Mesafesi
====
Birden fazla ekstruderle baskı yaparken, şu anda baskı yapmayan ekstruderler bekleme konumunda tutulur. Stand-by'dayken malzemenin ısı bölgesinden tamamen geri çekilmesi gerekir, aksi takdirde aşırı sızıntı oluşabilir.

Bu ayar, ekstruder değişimi sırasında ekstruder stand-by konumuna geçtiğinde bu ekstruder için malzemenin ne kadar geri çekileceğini belirler. Bu genellikle, diğer ekstruderler baskı yaparken malzemenin nozul odasında sürekli sızmasını ve bozulmasını önlemek için büyük ölçüde geri çekilmesi gerektiği için [Geri Çekme Mesafesi](../travel/retraction_amount.md) ayrı olarak yapılandırılabilir.