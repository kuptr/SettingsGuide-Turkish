Nozül Değişiminin İlk Hızı
====
Bir nozul stand-by konumunda olduğunda, malzeme ısı bölgesinden uzak tutularak bozulmasını önlenir. Bu ayar, extruder'ları değiştirdikten sonra malzemenin nozul odasına geri itilme hızını yapılandırır.

Extruder değişimi için gerçekleştirilen geri çekme daha uzun olduğundan, bu ayar [Geri Çekme Sırasındaki Astar Hızı](../travel/retraction_prime_speed.md) ayrı olarak yapılandırılabilir. Ayarın artırılması, sızıntıyı azaltabilir, ancak filamenti ezme ve besleyicinin filamenti kavrama gücünü kaybetmesine neden olabilecek bir kayma olasılığı bulunmaktadır.