Dairesel Primer Kule
====
Eğer bu ayar etkinleştirilirse, primer kule silindir şeklinde olacaktır. Devre dışı bırakılırsa, primer kule kare olacaktır.

<!--screenshot {
"image_path": "prime_tower_circular_enabled.png",
"models": [
    {
        "script": "cube.scad",
        "object_settings": {
            "extruder_nr": 0
        }
    },
    {
        "script": "cube.scad",
        "object_settings": {
            "extruder_nr": 1
        },
        "transformation": ["translateX(40)"]
    }
],
"camera_position": [470, -384, 150],
"camera_lookat": [470, -470, 5],
"settings": {
    "prime_tower_enable": true,
    "prime_tower_min_volume": 3
},
"colours": 16
}-->
![Kare primer kule](../images/prime_tower_circular_disabled.png)
![Dairesel primer kule](../images/prime_tower_circular_enabled.png)

Her iki durumda da, primer kule hala boştur. Silindirik primer kule, kare primer kuleden (köşeler kesildiğinden) kesinlikle daha küçüktür. [İlk Direğin Minimum Hacmi](prime_tower_min_volume.md) hala doğru olacaktır.

Malzeme çarpma eğilimindeyse, kare primer kule inşa tablasından gevşeyebilecek dört köşesi vardır. Bu, silindirik primer kuleye göre daha kolay devrilebilir olmasını sağlar. Kare primer kuleyi yazdırmak için daha büyük ivmeler de vardır. Bu ivmeler, akış oranını tutarsız hale getirir ve malzemeyi işlemek için istediğiniz şey değildir.

Silindirik primer kule neredeyse her açıdan daha iyidir. Bu nedenle, bu ayar daha yeni Cura sürümlerinde kaldırılmıştır. Bu sürümler her zaman silindirik bir primer kuleye sahip olacaktır.