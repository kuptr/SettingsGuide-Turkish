Sızdırma Kalkanını Etkinleştir
====
Çoklu ekstrüderlerle baskı yaparken, pasif ekstrüderlerde bazen hala bir miktar malzeme kalabilir. Nozullar hala sıcakken, bu malzeme sızmaya eğilimlidir. İşte bu nedenle, ooze kalkanı sorunu önlemek için tasarlanmıştır. Ooze kalkanı, nozulun altında herhangi bir sızıntıyı yakalayan nesnenin etrafında bir sınır oluşturur.

<!--screenshot {
"image_path": "ooze_shield.png",
"models": [
    {
        "script": "rocket_dual.scad",
        "scad_params": ["extruder=0"],
        "object_settings": {
            "extruder_nr": 0
        },
        "transformation": ["scale(0.5)"]
    },
    {
        "script": "rocket_dual.scad",
        "scad_params": ["extruder=1"],
        "object_settings": {
            "extruder_nr": 1
        },
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [-62, 102, 87],
"settings": {
    "ooze_shield_enabled": true,
    "layer_height": 0.2,
    "line_width": 0.6
},
"colour_scheme": "material_colour",
"colours": 64
}-->
![Ooze kalkanı, iki ekstrüderle baskı yapılıyorsa, bir katmanın ilk ekstrüderi ile yazdırılır ve böylece birbirini takip eden katmanlarda birbirini izleyen bir desen oluşturur](../images/ooze_shield.png)
![Ooze kalkanı için bazı parametreler ayarlanabilir](../images/ooze_shield.svg)

Ooze kalkanı, en yüksek ekstrüder değişim yüksekliğine kadar yükselecek şekilde yazdırılır. Bu yüksekliğin üzerinde, stand-by modunda olan bir nozul yazdırılmayacağı için, bir sıvı kalkanı yazdırmak gereksizdir. Ooze kalkanı, bir katmanda başlayan ekstrüderle yazdırılır. Bu ekstrüder her katmanda sırayla değişir, bu iki farklı malzemenin birbirine iyi yapışmadığı durumlarda bir tehlikedir. Ancak diğer ekstrüder etkinleştirildiğinde kalkanı yazdırmak, kalkanın etkisini büyük ölçüde yok eder.

Ooze kalkanı oldukça ince olduğundan kolayca kırılabilir veya kesilebilir ve modelinizden uzak tutulur, böylece yüzeyi çizmeden çıkarılabilir.