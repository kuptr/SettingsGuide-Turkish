İlk Direk Boyutu
====
Bu ayar, prime kulesinin genişliğini ayarlar.

![Prime kulesinin genişliği](../images/prime_tower.svg)

Prime kulesini daha geniş yapmak, daha stabil olmasına neden olur. Bu, baskınızın güvenilirliğini artırır.

Ancak, daha geniş bir prime kulesi aynı zamanda baskı tablanızda daha fazla yer kaplar. Ayrıca, purged edilen hacmin [İlk Direğin Minimum Hacmi](prime_tower_min_volume.md) üzerine daha fazla malzeme ekler, çünkü purged edilen hacim, kule etrafında tam konturlar oluşturmak için yuvarlanır.