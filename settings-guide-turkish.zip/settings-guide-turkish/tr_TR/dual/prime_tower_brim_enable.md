Başlangıç Kulesi Tabanı
====
Prime kulesi etek, [Yapı Levhası Türü](../platform_adhesion/adhesion_type.md) seçeneğindeki etek seçeneğine benzer bir ek etekleme işlemidir. Bu etek, normal yapışmadan ayrı olarak etkinleştirilebilir veya devre dışı bırakılabilir. Aktive edildiğinde, bir ek etek, prime kulesinin etrafında yazdırılacaktır. Bu etek, prime kulesinin yapı platformuna yapışmasını iyileştiren tek katmanlı düz bir disk olarak tasarlanmıştır.

<!--screenshot {
"image_path": "prime_tower_brim_enable.png",
"models": [
    {
        "script": "cube.scad",
        "object_settings": {
            "extruder_nr": 0
        }
    },
    {
        "script": "cube.scad",
        "object_settings": {
            "extruder_nr": 1
        },
        "transformation": ["translateX(40)"]
    }
],
"camera_position": [50, -32, 133],
"camera_lookat": [93, -122, 5],
"settings": {
    "prime_tower_enable": true,
    "prime_tower_brim_enable": true,
    "prime_tower_position_x": 600,
    "prime_tower_position_y": 600,
    "adhesion_type": "skirt"
},
"colours": 16
}-->
![Yapışma etek olarak ayarlanmış, ancak prime kulesinin etrafında hala bir etek var](../images/prime_tower_brim_enable.png)

Prime kulesi eteğinin etkinleştirilmesi, prime kulesinin yapı platformuna daha fazla bağlanma yüzeyi sağlar. Prime kulesi oldukça uzun ve ince olabilir, bu nedenle çok uzun baskılarda devrilebilir. Bu prime kulesi eteği, bu durumu önlemek için bir maliyet karşılığında yapı platformunda alan ve malzeme kullanarak basit bir çözüm sunar.

Prime kulesi eteği, [Kenar Genişliği](../platform_adhesion/brim_width.md) ayarında belirtilen genişliği alır. Yapışma Türü Etek olarak ayarlandığında, bu ayar, prime kulesinin etrafındaki eteğin genişliğini etkili olarak iki katına çıkarır.

Prime kulesi eteği, bir iskeleye kombin edilemez.