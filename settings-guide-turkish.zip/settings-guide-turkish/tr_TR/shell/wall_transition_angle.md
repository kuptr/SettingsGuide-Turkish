Duvar Geçişi Eşik Açısı
====
Bu açı, Cura'nın alanı uygun şekilde doldurmak için geçişler oluşturmaya başladığı açıyı belirtir. Bu açıdan daha keskin olan köşeler, değişken genişlikte çizgilerle doldurulur.

<!--screenshot {
"image_path": "wall_transition_angle.png",
"models": [{"script": "sharpening_corners.scad"}],
"camera_position": [0, 11, 106],
"settings": {
	"wall_transition_angle": 11,
	"wall_line_count": 4
},
"colours": 64
}-->
![10°'den geniş, artık geçiş oluşturmuyor](../images/wall_transition_angle.png)

Bu, aslında belirli köşeler için değişken çizgi genişliklerini açıp kapatan bir işlevdir. İki karşıt duvar neredeyse paralel ise, bu ayarın belirttiği açıdan daha küçükse, aralarındaki alan genişlikleri değişebilen çizgilerle doldurulur. Birbirlerinden daha büyük bir açıda ise, aralarındaki alan sabit genişlikte duvarlarla doldurulur.

Her zamanki gibi, bu bir takas. Değişken genişliğin bazı avantajları vardır, örneğin:
* Çizgiler arasında boşluk bırakmaz.
* Aynı alanı birden çok kez doldurmaz.
* Baskının boyutları orada daha doğru olacaktır.

Ancak bazı dezavantajları da vardır:
* İnce parçalarda köşeler oluşturarak yüzeyde dalgalanmalar olarak görünebilir.
* Ek seyahat hareketleri oluşturur.
* Yazıcı, çizgi genişliğini hızla ve doğru bir şekilde değiştiremeyebilir.

Uygulamada, bu açıyı, katman görünümünde görülebileceği gibi, keskin köşelerdeki boşlukların boyutunu azaltmak için yeterince büyük yapmak iyi bir fikirdir, ancak aksi takdirde mümkün olduğunca küçük yapmak iyidir. Daha küçük bir açı genellikle yüzeyin daha düzgün görünmesini sağlar.

Değişken çizgi genişliklerini tamamen ortadan kaldırmak için açıyı 0°'ye indirmek mümkün değildir. Paralel karşıt duvarlar her zaman genişliklerini alana uyacak şekilde ayarlanır.

**Bu ayar sadece normal duvarlara değil, aynı zamanda ek cilt duvarlarına, destek duvarlarına, doldurma duvarlarına ve konsantrik desenlere de uygulanır.**