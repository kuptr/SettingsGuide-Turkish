Minimum Tek Duvar Hattı Genişliği
====
İnce parçaları yazdırırken, Cura duvar hatlarının genişliğini modelin tam genişliğine uyacak şekilde ayarlar. Cura, bunun yerine daha az duvar hattı kullanmayı da tercih edebilir. Bu ayar, Cura'nın merkezdeki bir hattı çıkarmaya karar vereceği eşiği belirler. [Minimum Çift Duvar Hattı Genişliği](min_even_wall_line_width.md) ayrı olarak ayarlanabilir.

<!--screenshot {
"image_path": "min_wall_line_width_0_34.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
<!--screenshot {
"image_path": "min_wall_line_width_odd_0_1.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_odd_wall_line_width": 0.1,
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
![Merkez hattı çok küçük olduğunda, etrafındaki iki hat genişletilir](../images/min_wall_line_width_0_34.png)
![Bu ayar azaltıldığında, merkez hattı çok daha küçük başlar ve biter](../images/min_wall_line_width_odd_0_1.png)

Çift vs. Tek Hatlar
----
Bu ayar, özellikle tek sayıda hat olduğunda hatların kaldırılması için eşik değerini ayarlamanıza olanak tanır. Bu, merkezde iki hat yerine tek bir hat olduğunda olur. Bu tek hatın, iki etrafındaki hattın biraz daha geniş olması lehine kaldırılacağını belirler.

Minimum tek duvar hat genişliği, geçiş şekillerinden dolayı minimum çift duvar hat genişliğinden farklı olabilir. Bir tek hat kaldırıldığında, geçişten önce durur ve çevredeki duvarların kapanmasına izin verir. Geçiş sırasında, çevredeki hatların tam olarak bir araya gelmediği bir boşluk vardır. Bu, çift duvar sayısının olduğu durumlardan farklıdır: Orta iki hat o zaman birlikte çöker, hafifçe üst üste binerler. Minimum tek duvar hat genişliğinin azaltılması, tek duvarlardan çift duvarlara geçişlerdeki boşluğun boyutunu azaltır. Minimum çift duvar hat genişliğinin azaltılması, çift duvarlardan tek duvarlara geçişlerdeki fazla ekstrüzyonu azaltır.

Tek bir hattın sona erdiğinde kalan boşluklar, birleşim noktasındaki biraz fazla ekstrüzyondan daha belirgindir, bu yüzden Minimum Tek Duvar Hat Genişliği'ni Minimum Çift Duvar Hat Genişliği'nden biraz daha düşük ayarlamak faydalı olabilir.

Bu ayarı azaltmak şunlara yol açar:
* Merkez hattın sona erdiğinde daha küçük boşluklar.
* Bir çift merkez hattının maksimum genişliğinin azaltılması.
* İyi ekstrüzyon yapmayan daha ince hatlar.
* Daha uzun hatlar, bu da daha uzun süre yazdırılmasına neden olur.

**Bu ayar sadece normal duvarlar için değil, aynı zamanda ekstra deri duvarları, destek duvarları, dolgu duvarları ve konsantrik desenler için de geçerlidir.**