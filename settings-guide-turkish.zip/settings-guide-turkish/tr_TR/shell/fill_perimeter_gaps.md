Duvarlar arasındaki Boşlukları Doldurma
====
Birçok baskı, istenen duvar kalınlığından daha ince parçalar içerir. Çoğu durumda bu sorun değildir, ancak bazı baskılar için bu, duvarlar arasında bir boşluk bırakır. Bu ayar etkinleştirildiğinde, duvarlar arasındaki boşluklar ekstra malzeme ile doldurulacaktır.

![Karşılıklı duvarlar arasındaki uzun, ince bir boşluk sol ve sağ tarafta gösterilmiştir](../images/fill_perimeter_gaps_disabled.png)
![Duvarlar arasındaki boşluklar malzeme ile doldurulmuştur](../images/fill_perimeter_gaps_enabled.png)

Boşlukların doldurulmasının faydalı olduğu iki yaygın durum vardır:
* İnce baskılarda karşılıklı iki duvar arasında (yukarıdaki resimlerde gösterildiği gibi). Bu boşlukları doldurmak, o bölgelerdeki parçanın dayanıklılığını artırır çünkü karşılıklı iki duvar artık birbirinden bağımsız hareket edemez.
* Çok keskin köşelerde, iç duvar köşeye ulaşamayacak kadar kalın olduğunda dış duvar içinde bir boşluk olacaktır. Bu boşlukları doldurmak, dayanıklılığı artırır ve aynı zamanda dış duvarın daha tutarlı görünmesini sağlar.

**Bu ayar etkinleştirildiğinde, hangi hareketlerin gerekli olduğunu dikkatlice incelemek tavsiye edilir. Boşluk doldurma, duvarların baskısı tamamlandıktan sonra yapılır**