Alternatif Ek Duvar
====
Bu ayar, her iki katmanda bir ekstra duvar ekler. Bu şekilde dolgu, duvarlar arasında dikey olarak sıkışarak daha güçlü baskılar elde edilir.

Örneğin, duvar hattı sayısını iki duvar olarak ayarlarsanız ve alternatif ekstra duvarı etkinleştirirseniz, çift numaralı katmanlarda iki duvar ve tek numaralı katmanlarda üç duvar basılacaktır.

<!--screenshot {
"image_path": "alternate_extra_perimeter.gif",
"models": [
    {
        "script": "gear.scad",
        "transformation": ["scale(0.7)"]
    }
],
"camera_position": [0, 30, 123],
"settings": {
    "zig_zaggify_infill": true,
    "alternate_extra_perimeter": true
},
"layer": [15, 16, 17, 18],
"minimum_layer": [15, 16, 17, 18],
"colours": 32
}-->
![Bu resim, bu ayarı değiştirirken etkilenen duvarları göstermektedir.](../images/alternate_extra_perimeter.gif)

Bu ayarı etkinleştirmek ekstra zaman alır, ancak bir ekstra duvar eklemekten yaklaşık yarısı kadar. Bazı yönlerden, bu alternatif ekstra duvar neredeyse tam bir ekstra duvar kadar iyidir ve bazı yönlerden değildir:
* Dolgu ile duvarlar arasındaki bağlanmayı büyük ölçüde artırır, çünkü dolgu hatları da dikey olarak üst ve altlarındaki ekstra duvara yapışabilir. Bu açıdan, ekstra duvar beklenenden daha fazla etki sağlar. Oldukça verimlidir. 
* Baskının sertliğine, ekstra bir duvarın yaklaşık yarısı kadar katkıda bulunur. Bitişik duvara yapışarak stresi daha fazla tel üzerine dağıtır ve yatay yöndeki kuvvetlere karşı daha büyük bir direnek sağlar. Alternatif ekstra duvarın bu konuda ne özel bir avantajı ne de dezavantajı vardır.
* Gerçek bir ekstra duvar aynı zamanda katman bağlanma dayanıklılığına da katkıda bulunur. Duvarlar yavaşça basıldığından, katman bağlanma dayanıklılığının ana kaynaklarından biridir. Ancak, alternatif ekstra duvar, yalnızca her iki katmanda bir meydana geldiği için bitişik katmanlara bağlanmaz.

Sonuç olarak, alternatif ekstra duvar, yatay sertliği artırmanın verimli bir yoludur, ancak dikey dayanıklılığı artırmanın verimli bir yolu değildir.