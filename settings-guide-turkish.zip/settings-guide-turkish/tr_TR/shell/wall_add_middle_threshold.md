Add Middle Line Threshold
====
İnce parçaları basarken, Cura duvar çizgilerinin genişliğini modelin tam genişliğine uydurur. Cura ayrıca daha az duvar çizgisi kullanmaya da karar verebilir. Bu ayar, Cura'nın merkeze bir çizgi ekleyeceği eşiği belirler. Bu, [ortadaki iki çizginin birleştiği eşiği](wall_split_middle_threshold.md) ayrı olarak ayarlanabilmesini sağlar.

Bu ayar, [Minimum Tek Duvar Hattı Genişliği](min_odd_wall_line_width.md) ile aynıdır, ancak farklı bir birim kullanır. Bu ayarın birimi, bir parçanın genişliğinin bir yeni orta çizgi eklemek için çizgi genişliği fraksiyonlarında ne kadar artması gerektiğidir.

<!--screenshot {
"image_path": "min_wall_line_width_0_34.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
<!--screenshot {
"image_path": "min_wall_line_width_odd_0_1.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_odd_wall_line_width": 0.1,
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
![Orta çizgi çok küçük olduğunda, etrafındaki iki çizgi daha geniş hale getirilir](../images/min_wall_line_width_0_34.png)
![Bu ayarı azaltmak, merkez çizgi çok daha küçük başlar ve biter](../images/min_wall_line_width_odd_0_1.png)

Tek ve Çift Çizgiler
----
Bu ayar, özellikle tek sayıda çizgi olduğunda çizgi eklemek için eşiği ayarlamayı sağlar. Bu, iki çizginin ortasında tek bir çizginin olduğu durumları içerir. İki merkez çizginin arasına yeni bir çizgi eklenmesinin ne zaman gerçekleşeceğini belirler.

Merkez çizgi eklemek için eşiğin, iki orta çizgiyi ikiye ayırmak için olan eşikten farklı olabilir, çünkü bunların geçiş şekli farklıdır. Tek bir çizgi eklediğinde, çevresindeki iki çizgi ona yol açtığında başlar. Geçiş sırasında, çevre çizgiler henüz yeterince yer açmamıştır. Bu, çift sayıda duvar olduğunda farklıdır: Orta çizgi o zaman ikiye ayrılır ve bu iki çizgi birbirleriyle biraz örtüşürler, ta ki yeterince uzak olana kadar. Orta Çizgi Ekle Eşiğini azaltmak, çiftten tek çizgilere geçişlerdeki boşlukların boyutunu azaltır. Orta Çizgi Bölme Eşiğini azaltmak, tekten çifte çizgilere geçişlerdeki fazla ekstrüzyonu azaltır.

Tek bir çizgi başladığında bırakılan boşluklar, birleşme yerinde biraz fazla ekstrüzyondan daha belirgin olduğundan, Orta Çizgi Ekle Eşiğini Orta Çizgi Bölme Eşiğinden biraz daha düşük ayarlamak faydalı olabilir.

Bu ayarı azaltmak, şu sonuçlara yol açar:
* Merkezi bir çizgi bittiğinde daha küçük boşluklar.
* Çift merkez çizgi çiftlerinin maksimum genişliğinin azalması.
* Daha ince çizgiler, iyi ekstrüde olmayabilir.
* Daha uzun çizgiler, daha uzun sürede basılır.

**Bu ayar sadece normal duvarlara değil, aynı zamanda ek cilt duvarlarına, destek duvarlarına, doldurma duvarlarına ve konsantrik desenlere de uygulanır.**