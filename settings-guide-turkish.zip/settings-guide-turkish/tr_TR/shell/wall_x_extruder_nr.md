İç Duvar Ekstrüderi
====
Eğer yazıcınızın birden fazla nozülü varsa, iç duvarları farklı bir nozülle basmayı seçebilirsiniz.

<!--screenshot {
"image_path": "wall_x_extruder_nr.png",
"models": [{"script": "headphone_hook.scad"}],
"camera_position": [140, 140, 206],
"settings": {"wall_x_extruder_nr": 1},
"colour_scheme": "material_colour",
"colours": 32
}-->
![İç duvarlar mavi renkte basılır, ancak geri kalanı sarı renktedir](../images/wall_x_extruder_nr.png)

İç duvarları, doldurma, cilt veya dış duvarlar ile aynı nozülle basmak akıllıcadır. İç duvarları geri kalanından farklı bir nozülle basmanın gerçek bir kullanım durumu yoktur, belki ilginç bir görsel etkiden başka. İç duvarın rengi genellikle dış duvarın hafifçe içinden parlar.

İç duvarları doldurma, cilt veya dış duvarla aynı nozülle basmak, bu yapılarla daha iyi bağlanmasını sağlar. Bu daha güçlü bir parça oluşturur. Diğer yapıların nozülünü ayarlarken, iç duvarları neyle bağlamak istediğinizi aklınızda bulundurun.