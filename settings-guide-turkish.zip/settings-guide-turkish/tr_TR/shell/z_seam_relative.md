Z Dikişi Göreliliği
====
Dikiş, [Z Dikiş Hizalama](z_seam_type.md) ayarına göre kullanıcı tarafından belirlenen bir konuma yerleştirildiğinde, dikişin nerede olması gerektiğini belirlemek için koordinatlar girebilirsiniz. Normalde bu koordinatlar, baskı tablasının arkası gibi baskı tablasındaki belirli bir konumu belirtir. Bu ayar etkinleştirildiğinde, bu koordinatlar modelin konumuna göre alınır.

<!--screenshot {
"image_path": "z_seam_relative_disabled.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["translateX(-30)", "translateY(-20)"]
    },
    {
        "script": "rod_holder.scad",
        "transformation": ["translateX(30)", "translateY(-20)"]
    },
    {
        "script": "rod_holder.scad",
        "transformation": ["translateX(30)", "translateY(20)"]
    },
    {
        "script": "rod_holder.scad",
        "transformation": ["translateX(-30)", "translateY(20)"]
    },
    {
        "script": "cylinder.scad",
        "transformation": ["scale(0.25)"]
    }
],
"camera_position": [0, 0, 250],
"settings": {
    "z_seam_type": "back",
    "z_seam_x": 500,
    "z_seam_y": 500,
    "z_seam_relative": false
},
"colours": 64
}-->
<!--screenshot {
"image_path": "z_seam_relative_enabled.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["translateX(-30)", "translateY(-20)"]
    },
    {
        "script": "rod_holder.scad",
        "transformation": ["translateX(30)", "translateY(-20)"]
    },
    {
        "script": "rod_holder.scad",
        "transformation": ["translateX(30)", "translateY(20)"]
    },
    {
        "script": "rod_holder.scad",
        "transformation": ["translateX(-30)", "translateY(20)"]
    },
    {
        "script": "cylinder.scad",
        "transformation": ["scale(0.25)"]
    }
],
"camera_position": [0, 0, 250],
"settings": {
    "z_seam_type": "back",
    "z_seam_x": 500,
    "z_seam_y": 500,
    "z_seam_relative": true
},
"colours": 64
}-->
![Devre dışı: Koordinatlar, baskı tablasının ortasında mutlak bir konumu gösterir, bu nedenle tüm beyaz çizgiler ortaya doğru yönlendirilir](../images/z_seam_relative_disabled.png)
![Etkin: Koordinatlar modele göre belirlenir, bu nedenle her modelin beyaz çizgileri aynı köşede olur](../images/z_seam_relative_enabled.png)

Bir ağ, baskı tablasında tekrarlandığında, bu ayar, kopyaların her biri için dikişin baskı tablasındaki aynı noktaya doğru yönlendirilmesi yerine tam olarak aynı konumda yerleştirilmesini sağlar. Bu, her kopyayı baskı tablasındaki konumlarından bağımsız olarak tam olarak aynı şekilde yazdırmanıza olanak tanır.