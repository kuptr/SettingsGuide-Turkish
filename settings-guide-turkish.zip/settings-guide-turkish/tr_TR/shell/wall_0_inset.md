Dış Duvar İlavesi
====
Bu ayar, dış duvarın biraz daha içeri doğru hareket etmesine neden olur.

Bu ayarın amacı, meme çapından daha küçük bir çizgi genişliği kullanırken boyutsal doğruluğu artırmaktır. Dış duvar, meme çapından daha küçük bir çizgiyle basıldığında, malzeme istenenden daha geniş bir çizgi genişliğinde dışarı doğru akabilir, baskı istenenden daha geniş olur. Dış duvarı biraz içeriye hareket ettirmek, memenin iç duvarlarla örtüşmesine ve malzemenin iç duvarlara bitişik konumdaki alana zorla gelmesine neden olur. Bu sadece iç duvarlardan sonra dış duvarı basarken çalışır.

Dış duvarı daha içeriye doğru basmak, dış duvar ile iç duvarlar arasındaki yapışmayı artırabilir. Bu yapışma, parçanın dayanıklılığı için çok önemlidir.