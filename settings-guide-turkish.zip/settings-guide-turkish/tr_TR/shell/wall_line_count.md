Duvar Hattı Sayısı
====
Bu ayar, her katmanın etrafında kaç kontur çizileceğini belirler.

<!--screenshot {
"image_path": "wall_thickness_0.8.png",
"models": [
    {
        "script": "rotary_tumbler_lid.scad",
        "transformation": ["scale(0.4)"]
    }
],
"camera_position": [50, 50, 124],
"settings": {
    "skin_outline_count": 0,
    "wall_line_count": 2
},
"colours": 32
}-->
<!--screenshot {
"image_path": "wall_thickness_1.6.png",
"models": [
    {
        "script": "rotary_tumbler_lid.scad",
        "transformation": ["scale(0.4)"]
    }
],
"camera_position": [50, 50, 124],
"settings": {
    "skin_outline_count": 0,
    "wall_line_count": 4
},
"colours": 32
}-->
![İki Duvar](../images/wall_thickness_0.8.png)
![Dört duvar](../images/wall_thickness_1.6.png)

Duvarların sadece biri dış duvar olacak şekilde, dış duvar ayarlarıyla basılacak. Geri kalan duvarlar iç duvar ayarlarıyla basılacaktır.

Duvar sayısı, baskının ne kadar güçlü olacağında önemli bir faktördür. Duvarlar bitişik olduklarından, birbirlerini güçlendirebilirler ve daha sağlam bir parça elde edilir. Daha büyük baskılarda, şekle bağlı olarak, bu, sağlam bir nesne elde etmenin doldurmayı ayarlamaktan çok daha etkili bir yoludur.

Duvar sayısını arttırmak şunları sağlayacaktır:
* Baskının dayanıklılığını büyük ölçüde artırır.
* İç doldurmanın dışarıdan görülebilen etkisini azaltır.
* Overhangları iyileştirir, çünkü duvar çizgileri genellikle en yakın dayanma noktasına daha fazla yöneliktir.
* Modelin su geçirmezliğini daha kolay sağlar.
* Baskının basılma süresini ve malzeme kullanımını büyük ölçüde artırır.