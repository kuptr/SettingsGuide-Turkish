Duvar Geçişi Filtresi Mesafesi
====
Bazı modeller, farklı duvar sayılarının kullanıldığı eşikte ince parçalar içerebilir. Bu durum, parçanın gerçek genişliği çok fazla değişmese bile duvar sayısının sürekli olarak değişmesine neden olabilir. Bu değişim, baskı kalitesini bozar, çok sayıda akış değişikliği gerektirir ve daha fazla seyahat hareketi ekler. Bu özellik kullanılarak, geçişler belirli bir mesafe içinde ileri geri geçiş yapacaksa kaldırılır.

<!--screenshot {
"image_path": "wall_transition_filter_off.png",
"models": [{"script": "signet.scad"}],
"camera_position": [0, 11, 106],
"settings": {
	"wall_transition_filter_distance": 0,
	"wall_transition_filter_margin": 0,
	"wall_line_count": 3
},
"colours": 64
}-->
<!--screenshot {
"image_path": "wall_transition_filter_on.png",
"models": [{"script": "signet.scad"}],
"camera_position": [0, 11, 106],
"settings": {
	"wall_transition_filter_distance": 100,
	"wall_transition_filter_margin": 0.2,
	"wall_line_count": 3
},
"colours": 64
}-->
![Filtresiz durumda, sürekli olarak 2 ve 3 duvar arasında değişir](../images/wall_transition_filter_off.png)
![Filtre kullanıldığında, artık sürekli olarak değişmez](../images/wall_transition_filter_on.png)

Bir geçiş kaldırıldığında, geçici olarak bazı çizgiler çok geniş veya çok ince olabilir, [Minimum Duvar Hattı Genişliği](min_wall_line_width.md) sınırını aşar. Sonuçta, parçanın genişliğine daha iyi uyacak şekilde bir geçiş yapıldı. Bu geçiş olmadan, ideal olanın altında veya üstünde bir duvar miktarı kullanılacak ve bu duvarların genişlikleri buna göre ayarlanacaktır. Bu, [Duvar Geçişi Filtresi Kenar Boşluğu](wall_transition_filter_deviation.md)'na kadar izin verilir. Duvarların genişliği çok fazla değişirse, geçiş kaldırılmaz.

Bu filtre, düşük çözünürlüklü 3B kafesler kullanan ince parçaların yaygın bir sorununu çözmeyi amaçlar. Düz üçgenlerden oluşan 3B model, bir eğriyi tam olarak temsil edemez, sadece onu yaklaşık olarak temsil eder. Eğri, kenarlara sahip olacaktır ve aralarında düz yüzeyler olacaktır. Sabit bir genişlikte kavisli bir parçayı modelleme yaparken, dıştaki kenarların içteki kenarlarla hizalanması önemlidir. Eğer hizalanmazlarsa, halkanın genişliği hafifçe değişir, bu da yukarıda gösterilen etkiye neden olabilir. Eğer hizalanırlarsa, geçiş filtresi, etkinin fazla olmasını engellemelidir.

Mesafe arttıkça, bazı durumlarda küçük çizgi segmentleri oluşturulması önlenir. Bu, daha hızlı baskı alır ve yüzeyin daha düzgün görünmesini sağlayabilir. Ancak aynı zamanda, nozülünüzden iyi çıkmayabilecek daha aşırı çizgi genişliklerine neden olur. Düşük çözünürlüklü modellerde ince parçalar basarken, mesafeyi artırmak kaliteyi artırmaya yardımcı olabilir. Zorlu malzemelerle çalışırken, güvenli tarafta kalmak daha iyidir.

**Bu ayar şu anda kullanıcıya görünmez durumdadır. Filtre, yalnızca [Duvar Geçişi Filtresi Kenar Boşluğu](wall_transition_filter_deviation.md) kullanılarak ayarlanabilir. Bu ayar, sadece normal duvarlara değil, aynı zamanda ek cilt duvarlarına, destek duvarlarına, doldurma duvarlarına ve konsantrik desenlere de etki eder.**