Z Dikişi Konumu
====
Eğer [Z Dikiş Hizalama](z_seam_type.md) ayarında dikişin konumu "Kullanıcı Tarafından Belirlenmiş" olarak ayarlanmışsa, dikiş bu ayar tarafından belirtilen yönde yerleştirilir.

<!--screenshot {
"image_path": "z_seam_x_left.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["rotateZ(-90)"]
    }
],
"camera_position": [-55, 128, 40],
"settings": {
    "z_seam_type": "back",
    "z_seam_position": "left"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "z_seam_y_back.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["rotateZ(-90)"]
    }
],
"camera_position": [0, -77, 130],
"settings": {
    "z_seam_type": "back",
    "z_seam_position": "back"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "z_seam_x_right.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["rotateZ(-90)"]
    }
],
"camera_position": [55, 128, 40],
"settings": {
    "z_seam_type": "back",
    "z_seam_position": "right"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "z_seam_y_front.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["rotateZ(-90)"]
    }
],
"camera_position": [0, 77, 130],
"settings": {
    "z_seam_type": "back",
    "z_seam_position": "front"
},
"colours": 64
}-->
![Dikiş sol tarafta bulunuyor](../images/z_seam_x_left.png)
![Dikiş arka bölümde bulunuyor](../images/z_seam_y_back.png)
![Dikiş sağ tarafta bulunuyor](../images/z_seam_x_right.png)
![Dikiş ön bölümde bulunuyor](../images/z_seam_y_front.png)

Dikişin konumu için sekiz yön belirlenebilir. Dikişin konumu, nihai nesnede zor görülebilecek bir konumu seçmek en iyisidir, bu nedenle modelinizin tasarımına büyük ölçüde bağlıdır. Genellikle, dikişin, iç köşede olduğu bir konumu seçmek en iyisidir, ancak böyle bir köşe mevcut değilse, baskı işleminden sonra bir bıçakla kolayca kesilebilecek bir konumu da seçebilirsiniz.

**Dikiş aslında [Z Dikişi X](z_seam_x.md) ve [Z Dikişi Y](z_seam_y.md) ayarları tarafından belirtilen konuma mümkün olduğunca yakın yerleştirilir. Bu, bu koordinatları daha sezgisel bir şekilde ayarlayan bir kolaylık ayarıdır.**