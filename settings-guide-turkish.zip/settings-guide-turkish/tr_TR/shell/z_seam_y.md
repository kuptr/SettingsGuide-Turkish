Z Dikişi Y
====
[Z Dikiş Hizalama](z_seam_type.md) ayarlarında dikiş konumu "Kullanıcı Belirledi" olarak ayarlandığında, dikiş [Z Dikişi X](z_seam_x.md) ve Z Dikişi Y ayarları ile belirtilen konuma yakın bir yerde yerleştirilir.

<!--screenshot {
"image_path": "z_seam_y_back.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["rotateZ(-90)"]
    }
],
"camera_position": [0, -77, 130],
"settings": {
    "z_seam_type": "back",
    "z_seam_position": "back"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "z_seam_y_front.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["rotateZ(-90)"]
    }
],
"camera_position": [0, 77, 130],
"settings": {
    "z_seam_type": "back",
    "z_seam_position": "front"
},
"colours": 64
}-->
![Dikiş, ön tarafta yer alır](../images/z_seam_y_front.png)
![Dikiş, arka tarafta yer alır.](../images/z_seam_y_back.png)

Bu ayar, [Z Dikişi Göreliliği](z_seam_relative.md) devre dışı bırakıldığında, baskı tablası üzerindeki mutlak bir konumu veya Z Dikişi Göreceli etkinleştirildiğinde modelin merkezine göre göreceli bir konumu belirtir. Konum mutlak olduğunda, koordinat g-code koordinat sistemindedir, bu da Cura'nın nesnelerin yerleştirilmesi için gösterdiği koordinatlardan farklıdır.

Dikişi, baskınızın uygulamasında gözle görülmesi zor bir konumda seçmek faydalıdır. Eğer böyle bir konum yoksa veya baskıdan sonra biraz işlem yapılabilecekse, dikişi kolayca bıçakla kesilebilecek veya zımparalanabilecek bir konuma yerleştirmeyi tercih edebilirsiniz.