Delik Yatay Büyüme
====
Bu ayar, deliklerin baskıda beklenenden daha küçük olma eğilimine karşı bir telafi önlemidir. Bu ayarla, baskınızdaki dikey deliklerin boyutunu genişletebilirsiniz. Normal [Yatay Büyüme](xy_offset.md) ayarına benzer şekilde, baskınızdaki delikler tüm yönlerde genişletilecektir.

Delik her yönde genişletildiğinden, bu ayarın değeri deliklerin çapı değil, yarıçapı üzerinde etkili olur.

<!--screenshot {
"image_path": "hole_xy_offset_0.png",
"models": [{"script": "rotary_tumbler_motor_lid.scad"}],
"camera_position": [-30, 30, 111],
"settings": {"hole_xy_offset": 0},
"colours": 64
}-->
<!--screenshot {
"image_path": "hole_xy_offset.png",
"models": [{"script": "rotary_tumbler_motor_lid.scad"}],
"camera_position": [-30, 30, 111],
"settings": {"hole_xy_offset": 0.8},
"colours": 64
}-->
![Bu baskıdaki deliklerin vida ve millere uyacak şekilde olması gerekiyor, ancak baskı sırasında çok küçük oluyorlar](../images/hole_xy_offset_0.png)
![Delikler daha büyük yapılmış, ancak şeklin geri kalanı değişmemiş](../images/hole_xy_offset.png)

Malzemenin viskozitesi nedeniyle, plastik bir hattı eğrili bir şekilde baskılarken, plastik eğride nozülle birlikte sürüklenme eğilimindedir. Bu, eğriyi planlanandan biraz daha küçük yapar çünkü iplik eğrinin içine çekilir. Normalde bu pek fark edilmez, ancak çok hassas bir şekilde uyması gereken parçaları veya çok küçük dikey delikleri yazdırırken bu durum baskınızın doğruluğunu bozabilir. Vidalar artık sığmaz, parçalar düzgün bir şekilde birbirine geçmez, vb.

Bu ayar, tüm delikleri biraz daha büyük yaparak bunu telafi eder. Ancak [Yatay Büyüme](xy_offset.md)'den farklı olarak bu sadece kapalı delikleri etkiler. Eğer bir tarafında (aynı katmanda yatay olarak) küçük bir açıklık varsa, bu kısım delik olarak kabul edilmez ve bu ayardan etkilenmez.

Pozitif bir değer delikleri büyütür. Negatif bir değer delikleri küçültür. Yatay Genişletme ile birleştirildiğinde, delikler önce genişletilir, ardından normal yatay genişletme uygulanır. Bu, ince parçaların tamamen kaybolmasına ve ardından normal yatay genişletme ile genişletilmesine neden olabilir.

Bu ayarın yalnızca katmanların düzlemindeki deliklere baktığını unutmayın. Yalnızca baskının üst veya altındaki deliklerin boyutunu ayarlar. Baskının yanındaki delikler ayarlanmaz. Ayrıca, deliğin boyutu veya şekli üzerinde herhangi bir kısıtlama yoktur. O katmanda tamamen malzeme ile çevrili olan herhangi bir boşluk genişletilecektir, hatta bir kabın içi bile. Dahası, bu, yan tarafında bir açıklık olduğu anda, içerinin artık o katmanlarda tamamen kapalı olmadığı ve bu nedenle genişletilmeyeceği anlamına gelir. Bu genellikle bir kabın içinde, yan tarafında bir açıklık yüksekliğinde görülebilir bir çıkıntı oluşmasına neden olur, burada içerisi o açıklık nedeniyle geçici olarak genişletilmez.