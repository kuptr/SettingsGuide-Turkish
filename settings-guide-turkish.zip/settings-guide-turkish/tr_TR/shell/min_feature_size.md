Minimum Yüz Hattı Boyutu
====
Bu ayar, modelin yazdırılacak detaylarının minimum genişliğini kontrol eder. Bu değerden daha ince olan herhangi bir şey yazdırılmaz.

Nozül boyutundan daha küçük detaylar genellikle iyi yazdırılmaz. Bu, yazıcının bir sınırlamasıdır. Ancak Cura, bunları yazdırmayı yine de deneyebilir; bu durumda, düzgün bir ekstrüzyon oranı olmayacağını veya detayların modelden daha kalın çıkacağını kabul eder.

Minimum Özellik Boyutunu azaltmak, yazıcının baskının daha küçük detaylarını yazdırmasını sağlar. [Minimum İnce Duvar Hattı Genişliği](min_bead_width.md)'ne bağlı olarak, bu küçük detaylar çok az ekstrüzyon yapılarak (bu da az [ekstrüdere](../troubleshooting/underextrusion.md) yol açar) veya daha makul hat genişlikleri ekstrüde edilerek ancak fazla büyük yazdırılarak yazdırılabilir. Bu değeri 0 olarak ayarlamak, yazıcının her keskin köşenin en uç noktasına kadar gitmesini sağlar.

Minimum Özellik Boyutunu artırmak, yazıcının zaten düzgün çıkmayacak küçük detaylarla uğraşmamasını sağlar. Bu, biraz zaman kazandırır ve baskının daha temiz çıkmasını sağlayabilir.