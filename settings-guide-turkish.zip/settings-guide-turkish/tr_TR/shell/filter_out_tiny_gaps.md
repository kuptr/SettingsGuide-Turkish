Küçük Boşlukları Filtreleyin
====
Duvarlar arasındaki boşlukları doldurmak ekstra hareketler gerektirir. Eğer boşluklar çok küçükse, malzeme genellikle nozülün dışına yeterince akamaz. Bu ayar etkinleştirildiğinde, yazıcı bazı en küçük boşlukları doldurmaya çalışmaz.

![Dişlerin uçlarındaki küçük boşluklar dolduruluyor](../images/filter_out_tiny_gaps_disabled.png)
![Küçük boşluklar filtrelenir ve doldurulmadan bırakılır](../images/filter_out_tiny_gaps_enabled.png)

2 kare dış duvar hat genişliğinden daha küçük boşluklar "küçük" boşluk olarak kabul edilir. Örneğin, [Outer Wall Line Width](../resolution/wall_line_width_0.md) ayarınız 0.4mm olarak ayarlanmışsa, 0.4mm * 0.4mm * 2 = 0.32mm² alanındaki boşluklar artık doldurulmaz.