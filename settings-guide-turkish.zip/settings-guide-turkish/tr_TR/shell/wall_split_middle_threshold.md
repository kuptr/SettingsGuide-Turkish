Split Middle Line Threshold
====
İnce parçalar basılırken, Cura duvar çizgilerinin genişliğini modelin tam genişliğine uydurur. Cura ayrıca daha az duvar çizgisi kullanmaya da karar verebilir. Bu ayar, Cura'nın bir parçanın genişliği arttığında merkezdeki tek bir çizgiyi ikiye böleceği eşiği belirler. Bu, [yeni bir merkez çizgisinin eklendiği eşiği](wall_add_middle_threshold.md) ayrı olarak ayarlanabilmesini sağlar.

Bu ayar, [Minimum Çift Duvar Hattı Genişliği](min_even_wall_line_width.md) ile aynıdır, ancak farklı bir birim kullanır. Bu ayarın birimi, bir parçanın genişliğinin merkez çizgiyi ikiye bölmek için ne kadar artması gerektiğini çizgi genişliği fraksiyonları olarak ifade eder. Çünkü genişlik farkı, bölündükten sonra ortaya çıkan iki çizgiye eşit olarak dağıtılmıştır, daha küçük bir Minimum Çift Duvar Çizgisi Genişliği, tek bir duvarın bölünmesi durumunda Split Middle Line Threshold'in çok daha küçük olmasına eşittir.

<!--screenshot {
"image_path": "min_wall_line_width_0_34.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
<!--screenshot {
"image_path": "min_wall_line_width_even_0_1.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_even_wall_line_width": 0.1,
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
![Merkezi çizgi, uyması için genişletilir](../images/min_wall_line_width_0_34.png)
![Bu ayar azaltılırsa, iki çizgi kullanılır](../images/min_wall_line_width_even_0_1.png)

Tek ve Çift Çizgiler
----
Bu ayar, özellikle çift çizgi haline geldiğinde çizgi eklenmesi için eşiği ayarlamayı sağlar. Bu, tek bir çizgi yerine iki çizginin olduğu durumları içerir. Merkezdeki bir çizginin iki çizgiye bölünmesinin ne zaman gerçekleşeceğini belirler.

Orta çizginin bölünmesi için eşik, merkez çizginin eklenmesi için eşikten farklı olabilir, çünkü nasıl birleştiklerine bağlıdır. Çift çizgiler uçları daha yakın hale getirilerek uç uca birleştirilir. Bu çizgilerde biraz örtüşme vardır ve bu da aşırı ekstrüzyona neden olur. Bu, tek sayıda duvar olduğunda farklıdır: Orta çizgi o zaman sadece durur, baskıda bir boşluk bırakır. Split Middle Line Threshold, çiftten tek çizgilere geçişlerdeki aşırı ekstrüzyonu azaltır. Add Middle Line Threshold, tekten çifte çizgilere geçişlerdeki boşluğun boyutunu azaltır.

Merkez çizgi eklenirken bırakılan boşluklar, birleşme yerindeki biraz aşırı ekstrüzyondan daha belirgin sonuçlar ortaya koyar, bu nedenle Split Middle Line Threshold'in Add Middle Line Threshold'ten biraz daha yüksek ayarlanması yardımcı olabilir.

Bu ayarın azaltılması şu sonuçlara yol açar:
* Birleşmek için iki çizginin bir araya geldiği örtüşme alanının azalması.
* Tek merkez çizgilerin maksimum genişliğinin azalması.
* Daha ince çizgiler, iyi ekstrüde olmayabilir.
* Daha fazla çizgi, daha uzun süre baskı yapılmasını gerektirir.

**Bu ayar sadece normal duvarlara değil, aynı zamanda ek cilt duvarlarına, destek duvarlarına, doldurma duvarlarına ve konsantrik desenlere de uygulanır.**