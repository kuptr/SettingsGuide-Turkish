Prefer Retract
====
Duvar çizgilerindeki örtüşmeleri telafi etmek, bazı duvarların akış hızını azaltacaktır. Bu akış hızı, [Minimum Duvar Akışı](wall_min_flow.md) ayarının değerinin altına düşerse, bir duvar çizgisi yerine bir seyahat hareketi yapılır.

Bu ayar etkinleştirilmişse, bu seyahat hareketi sırasında filament geri çekilir.

Bu ayarın amaçlanan etkisi, duvarlardaki sızıntıyı azaltmaktır. Minimum Duvar Akışı ayarının amacı, son derece ince duvarlardan kaynaklanan sızıntıyı azaltmaktır ki bu da hoş görünmez. Bu, bu ayarın etkinleştirilmesiyle daha da iyileştirilebilir.

Ancak, dış duvarlarda geri çekilme, filament geri çekilirken meme anlık olarak durur, bu da geri çekilmenin yapıldığı yerde bir topak bırakır. Ayrıca, baskı süresini artırır ve filamentin daha hızlı tükenmesine neden olur.