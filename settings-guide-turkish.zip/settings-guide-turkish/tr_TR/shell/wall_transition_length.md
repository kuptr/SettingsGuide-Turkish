Duvar Geçişi Uzunluğu
====
İnce parçalarda, duvarların tamamı şeklin içine sığmaz. Parça bazı yerlerde diğerlerinden daha ince olduğunda, Cura'nın bazı yerlerde farklı duvar sayıları kullanması gerekir. Bu ayar, duvarlardan birini ekleyip veya kaldırdığı geçiş alanının ne kadar geniş olacağını kontrol eder.

<!--screenshot {
"image_path": "wall_transition_length_0_2.png",
"models": [{"script": "wedge.scad"}],
"camera_position": [-7, 0, 75],
"settings": {"wall_transition_length": 0.2},
"colours": 64
}-->
<!--screenshot {
"image_path": "wall_transition_length_1_5.png",
"models": [{"script": "wedge.scad"}],
"camera_position": [-7, 0, 75],
"settings": {"wall_transition_length": 1.5},
"colours": 64
}-->
![Çok kısa bir geçiş](../images/wall_transition_length_0_2.png)
![Daha uzun bir geçiş](../images/wall_transition_length_1_5.png)

Farklı duvar sayıları arasındaki geçiş alanının her zaman bazı hafif sorunları vardır. Bu en belirgin şekilde, merkezdeki tek bir çizginin sona ermesi ve iki çevreleyen duvarın boşluğu doldurması gerektiğinde görülür. Çevreleyen duvarlar hemen boşluğu doldurmaz ve bir boşluk kalır. Bu, baskının üstünde ve altında küçük deliklerin oluşmasına neden olur. İki duvarın birleştiği durumda ise tam tersi olur, bunun sonucunda bir araya gelene kadar bir an için birbirlerinin üzerine binerler. Aşırı çıkıntı, özellikle bu durumun dış duvarda gerçekleştiği yerde boyutsal bir sapmaya yol açabilir. Tüm bunlar, geçişi mümkün olduğunca kısa tutarak önlenebilir.

Ancak, kısa bir geçiş aynı zamanda nozülünün boşluğu hızlı bir şekilde doldurmak için çok keskin dönüşler yapmasına neden olur. Bu, özellikle dış duvarın basımı sırasında gerçekleşirse daha fazla titremeyle sonuçlanır. Geçişi daha uzun yapmak, özellikle bunu [Yazdırma İvmesi Değişimi](../speed/jerk_print.md) sınırının altına düşürerek nozüldeki hızlanmaları azaltır.

Bu uzunluğu bir veya iki kez çizgi genişliğine ayarlamak makul bir başlangıç ​​noktasıdır. Daha zayıf çerçevelere veya daha ağır baskı kafalarına sahip yazıcılar bunu artırması gerekebilir, ancak hızlanma yapmadan titreme olmadan kısaltarak geçişi iyileştirmek isteyen yazıcılar uzunluğu kısaltabilir.

**Bu ayar yalnızca normal duvarlar için değil, aynı zamanda ek cilt duvarları, destek duvarları, doldurma duvarları ve konsantrik desenler için de geçerlidir.**