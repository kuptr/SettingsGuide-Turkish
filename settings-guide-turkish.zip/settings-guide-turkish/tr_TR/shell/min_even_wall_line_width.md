Minimum Çift Duvar Hattı Genişliği
====
İnce parçaları yazdırırken, Cura duvar hatlarının genişliğini modelin tam genişliğine uyacak şekilde ayarlar. Cura, bunun yerine daha az duvar hattı kullanmayı da tercih edebilir. Bu ayar, Cura'nın iki hattı birleştirip tek bir hat yapacağı eşik değeridir. Bu, [Minimum Tek Duvar Hattı Genişliği](min_odd_wall_line_width.md) ayrı olarak ayarlanabilir.

<!--screenshot {
"image_path": "min_wall_line_width_0_34.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
<!--screenshot {
"image_path": "min_wall_line_width_even_0_1.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_even_wall_line_width": 0.1,
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
![Merkez hattı sığacak şekilde genişletilir](../images/min_wall_line_width_0_34.png)
![Bu ayar azaltıldığında, iki hat kullanılır](../images/min_wall_line_width_even_0_1.png)

Çift vs. Tek Hatlar
----
Bu ayar, özellikle çift sayıda hat olduğunda hatların kaldırılması için eşik değerini ayarlamanıza olanak tanır. Bu, merkezde iki hat olduğunda ve bunların tek bir hat olarak birleştiği durumlardır. Ortadaki bu iki hattın ne zaman tek bir hat olarak birleşeceğini belirler.

Çift duvar hat genişliği, ortadaki hatların birleşme şeklinden dolayı tek duvar hat genişliğinden farklı olabilir. Çift hatlar uçlarında birleşir, uçlar birbirine yaklaşır. Bu hatların uçlarında biraz örtüşme olur, bu da fazla ekstrüzyona yol açar. Bu, tek sayıda duvar olduğunda farklıdır: Ortadaki hat durur ve baskıda bir boşluk bırakır. Minimum çift duvar hat genişliğini azaltmak, çift hatlardan tek hatlara geçişlerdeki fazla ekstrüzyonu azaltır. Minimum tek duvar hat genişliğini azaltmak ise tek hatlardan çift hatlara geçişlerdeki boşluğun boyutunu azaltır.

Tek bir hattın sona erdiğinde kalan boşluklar, birleşim noktasındaki biraz fazla ekstrüzyondan daha belirgin olduğu için, Minimum Çift Duvar Hat Genişliğini Minimum Tek Duvar Hat Genişliğinden biraz daha yüksek ayarlamak faydalı olabilir.

Bu ayarı azaltmak şunlara yol açar:
* İki hattın birleşip tek bir hat haline geldiği yerdeki örtüşme alanının azalması.
* Tek merkez hatlarının maksimum genişliğinin azaltılması.
* İyi ekstrüzyon yapmayan daha ince hatlar.
* Yazdırılması daha uzun süren daha fazla hat.

**Bu ayar, normal duvarlar dışında, ekstra yüzey duvarları, destek duvarları, dolgu duvarları ve konsantrik desenler için de geçerlidir.**