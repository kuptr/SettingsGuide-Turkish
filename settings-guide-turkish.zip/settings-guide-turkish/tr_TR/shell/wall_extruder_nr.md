Duvar Ekstruderi
====
Eğer yazıcınız birden fazla ekstrüzyona sahipse, sadece duvarları farklı bir ekstrüzyon ile basmayı seçebilirsiniz.

<!--screenshot {
"image_path": "wall_extruder_nr.png",
"models": [{"script": "headphone_hook.scad"}],
"camera_position": [140, 140, 206],
"settings": {"wall_extruder_nr": 1},
"colour_scheme": "material_colour",
"colours": 32
}-->
![Duvarlar mavi renkte basılır, ancak geri kalan kısım sarıdır](../images/wall_extruder_nr.png)

Duvarları farklı bir ekstrüzyon ile basmak çeşitli amaçlar taşıyabilir:
* Sadece dış duvarı farklı bir renkte basarak görsel bir etki elde etmek.
* Duvarlar, detayları daha iyi yakalayan ancak doldurma için istenmeyen mukavemet özelliklerine sahip bir malzeme ile basılabilir.
* Duvarlar, baskınızda daha yumuşak bir dokuya ve daha fazla sürtünme/kavrama elde etmek için esnek bir malzeme ile basılabilir.
* Duvar, yüzeydeki hareketli parçaların daha kolay kaymasına izin vermek için sürtünme katsayısı daha düşük bir malzeme ile basılabilir.