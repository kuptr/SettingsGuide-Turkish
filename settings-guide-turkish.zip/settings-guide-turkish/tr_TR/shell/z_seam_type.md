Z Dikiş Hizalama
====
Bu ayar, her konturun dikişinin nereye yerleştirileceğini seçmenize olanak tanır. Dikişin etkisini en aza indirmek veya dikişi sonradan daha kolay çıkarmanıza izin vermek için dikişin yerini kontrol etmenize olanak sağlayan birkaç seçenek bulunmaktadır.

Dikiş, konturun yazdırmanın başladığı ve bittiği yerdir. Nozülün yolunun kapalı bir daire olduğu durumda bile, dikiş, ekstrüzyonun başladığı ve bittiği yerde her zaman bir dikiş bırakılır çünkü yazdırma işlemi asla tam olarak doğru değildir. Bu ayarla dikişin görünürlüğü en aza indirilebilir veya etrafına yayılabilir.

<!--screenshot {
"image_path": "z_seam_type_user.png",
"models": [{"script": "seams_on_curves.scad"}],
"camera_position": [51, -36, 132],
"settings": {
    "z_seam_corner": "z_seam_corner_outer",
    "z_seam_position": "left",
    "z_seam_type": "back"
},
"colours": 32
}-->
Kullanıcı Tarafından Belirtilen
----
![Kullanıcı Tarafından Belirtilen](../images/z_seam_type_user.png)

Bu seçenek size manuel olarak bir konum seçme olanağı sağlar. Dikiş, seçilen konuma en yakın köşeye yerleştirilir. Bu genellikle köşeleri birbirine çok yakın hizalamayı sağlar, böylece dikişi kolayca kesmenizi sağlar. Ayrıca dikişin nerede olması gerektiği konusunda ince bir kontrol sağlar.

Varsayılan olarak, baskı tablasının arkasında bir konum seçilir. Kullanıcıların çoğu modelin ön kısmını yazıcıyı ön tarafına bakacak şekilde bırakır, bu nedenle arkada bir konum dikişi daha iyi gizler.

<!--screenshot {
"image_path": "z_seam_type_shortest.png",
"models": [{"script": "seams_on_curves.scad"}],
"camera_position": [51, -36, 132],
"settings": {
    "z_seam_corner": "z_seam_corner_outer",
    "z_seam_type": "shortest"
},
"colours": 32
}-->
En Kısa
----
![En Kısa](../images/z_seam_type_shortest.png)

Bu seçenek, dikişe doğru yolculuk hareketlerinin uzunluğunu en aza indirir ve dikişi belirli bir yere yerleştirmeye çalışmaz. Seyahat yolu daha kısadır, bu nedenle seyahat hareketlerinde küçük bir zaman tasarrufu sağlanır. Dikiş de biraz daha küçük olacaktır, çünkü nozülün kontura indiği yerde daha az ooz olacaktır.

Arzu edilen köşe tercihi hala nozülün nerede olduğuna yakın bir köşe seçilerek tutulur. En yakın köşe değil, seyahat hareketlerini bir miktar en aza indirmek için bir tercih kullanılır, ancak [Dikiş Köşesi Tercihi](z_seam_corner.md) ayarı için uygun bir köşe de kullanılır.

<!--screenshot {
"image_path": "z_seam_type_random.png",
"models": [{"script": "seams_on_curves.scad"}],
"camera_position": [51, -36, 132],
"settings": {
    "z_seam_corner": "z_seam_corner_outer",
    "z_seam_type": "random"
},
"colours": 32
}-->
Gelişigüzel
----
![Gelişigüzel](../images/z_seam_type_random.png)

Dikiş için çevrenin etrafında rastgele bir konum seçilir. Bu rastgele konum, her katmanında değiştirilir, bu nedenle dikiş neredeyse eşit bir şekilde modele yayılır. Farklı katmanların dikişleri hizalanmadığı için dikiş neredeyse görünmez olacaktır. Ancak, yüzey genel olarak biraz daha karışık görünecektir.

<!--screenshot {
"image_path": "z_seam_type_sharpest.png",
"models": [{"script": "seams_on_curves.scad"}],
"camera_position": [51, -36, 132],
"settings": {
    "z_seam_corner": "z_seam_corner_outer",
    "z_seam_type": "sharpest_corner"
},
"colours": 32
}-->
En Keskin Köşe
----
![En Keskin Köşe](../images/z_seam_type_sharpest.png)

Dikiş, konturun tamamen en sivri köşesine yerleştirilecektir ve bu, köşeler için belirlenen tercihe göre dikişin maksimum derecede gizlenmesini veya ortaya çıkarılmasını sağlar [Dikiş Köşesi Tercihi](z_seam_corner.md). Bu, daha uzun seyahat hareketlerine neden olabilir, ancak dikişin köşeler için belirlenen tercihe göre maksimum derecede gizlenmesini veya ortaya çıkarılmasını sağlar.