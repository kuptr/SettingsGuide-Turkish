Dış Duvar Ekstruderi
====
Eğer yazıcınızda birden fazla ekstrüzyon noktası varsa, dış duvarı farklı bir ekstrüzyon noktasıyla basabilirsiniz.

<!--screenshot {
"image_path": "wall_0_extruder_nr.png",
"models": [{"script": "headphone_hook.scad"}],
"camera_position": [140, 140, 206],
"settings": {"wall_0_extruder_nr": 1},
"colour_scheme": "material_colour",
"colours": 32
}-->
![Dış duvar mavi renkte basılır, ancak geri kalan kısmı sarıdır](../images/wall_0_extruder_nr.png)

Dış duvarı farklı bir ekstrüzyon noktasıyla basmak çeşitli amaçlar taşıyabilir:
* Dış duvarı farklı bir renkte basarak sadece görsel bir etki elde etmek.
* Dış duvar, detayı daha iyi yakalayan ancak doldurmayı olumsuz etkileyen mukavemet özelliklerine sahip bir malzeme ile basılabilir.
* Dış duvar, baskınıza daha yumuşak bir dokunun elde edilmesi ve daha fazla sürtünme veya kavrama sağlanması için esnek bir malzeme ile basılabilir.
* Dış duvar, yüzeydeki hareketli parçaların daha kolay kaymasına izin vermek için sürtünme katsayısı daha düşük bir malzeme ile basılabilir.

**Bir duvar genellikle büyük renk değişikliğini tamamen kapatmak için yeterli değildir. İç duvarın renginin biraz görünmesini bekleyebilirsiniz.**