Minimum İnce Duvar Hattı Genişliği
====
Bu ayar, aslında çok büyük olan bir hat genişliği ile çok küçük detayları yazdırmayı sağlar. Çok ince çizgiler yazdırmak yerine, daha makul bir hat genişliği ile yazdırır.

Eğer [Minimum Yüz Hattı Boyutu](min_feature_size.md) çok düşükse, bazı çok ince parçalar yazdırılabilir. Bu iyi çalışmaz. Nozül boyutundan daha küçük çizgiler yazdırmak mümkündür, ancak çok fazla değil. Çok ince çizgiler yazdırmak, tutarsız ekstrüzyona yol açar.

Bunun yerine, bu çok ince çizgiler daha tutarlı bir şekilde ekstrüde edilmeleri için genişletilir. Modelin Minimum İnce Duvar Hat Genişliğinden daha ince olan herhangi bir parçası, Minimum İnce Duvar Hat Genişliği kullanılarak tek bir hat olarak yazdırılacaktır. Bu hatlar, modelin orijinal genişliğinden daha geniş hale gelir. Bu, boyutsal doğruluğu azaltır, ancak en azından güvenilir bir şekilde yazdırılacaktır.

Bu ayarın değeri, yazıcının güvenilir bir şekilde ulaşabileceği en ince hat genişliği olmalıdır, aksi takdirde pürüzlü yüzeyler ve tutarsız ekstrüzyon oluşur. Bu genellikle nozül boyutu ile nozül boyutunun yarısı arasında bir yerdedir. Bunu artırmak, ince parçaların fazla kalın yazdırılmasına neden olur, ancak çok ince çizgiler yazdırmaya çalışırken alt ekstrüzyon olasılığını azaltır.