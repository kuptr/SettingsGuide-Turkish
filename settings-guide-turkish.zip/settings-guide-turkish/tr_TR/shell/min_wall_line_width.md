Minimum Duvar Hattı Genişliği
====
İnce parçaları yazdırırken, Cura duvar hatlarının genişliğini modelin tam genişliğine uyacak şekilde ayarlar. Cura, bunun yerine daha az duvar hattı kullanmayı da tercih edebilir. Bu ayar, mevcut duvarları daha ince hale getirmek yerine bir duvarı kaldırma kararı verme eşiğini belirler.

<!--screenshot {
"image_path": "min_wall_line_width_0_34.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_wall_line_width": 0.34,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
<!--screenshot {
"image_path": "min_wall_line_width_0_1.png",
"models": [{"script": "moon_sickle.scad"}],
"camera_position": [0, 0, 63],
"settings": {
	"min_wall_line_width": 0.1,
	"wall_line_count": 3,
	"wall_transition_angle": 20
},
"layer": 14,
"colours": 32
}-->
![Normalde hatlar daha geniş hale getirilir](../images/min_wall_line_width_0_34.png)
![Minimum hat genişliği azaltıldığında, daha fazla hat kullanılması tercih edilir](../images/min_wall_line_width_0_1.png)

Farklı sayılarda duvarlar
----
Eğer tek bir merkezi hat varsa ve [Duvar Dağılım Sayısı](wall_distribution_count.md) 1 olarak ayarlanmışsa, bu ayar tam olarak söylendiği gibi çalışır. Orta hat belirli bir genişlikten daha ince hale geldiğinde, diğer hatları genişletmek yerine kaldırılır. Diğer durumlarda, hesaplama daha karmaşıktır.

Bu hesaplamanın kesin hesaplanması karmaşıktır, ancak sezgisel bir anlayış faydalı olabilir. Esasen, modelin toplam genişliğini [Duvar Hattı Genişliği](../resolution/wall_line_width.md)'ne bölersiniz ve belirli bir duvar sayısına ulaşırsınız. Bu bir kesir olabilir (örneğin 5.3 duvar hat genişliği). Minimum Duvar Hat Genişliği sadece bu kesir kısmını (0.3 duvar hat genişliği) alır ve Minimum Duvar Hat Genişliği'ni aşarsa ek bir duvar ekler. Duvar sayısı bilindiğinde, her bir hattın genişliği Duvar Dağıtım Sayısına göre belirlenir.

![Minimum Duvar Hat Genişliği, yeni bir hat ekleme eşiğini sola veya sağa kaydırır](../images/min_wall_line_width.svg)

Bu aslında, daha fazla genişliği ayarlanan hatların sayısı arttıkça, hat genişliğinin Minimum Duvar Hat Genişliği'nin izin verdiği kadar aşırı olmayacağı anlamına gelir. Örneğin, ortadaki iki hat ayarlandığında, hat genişliği normal hat genişliği ile Minimum Duvar Hat Genişliği'nin ortalamasının altına düşmez.

Ayar, [Minimum Çift Duvar Hattı Genişliği](min_even_wall_line_width.md) ve [Minimum Tek Duvar Hattı Genişliği](min_odd_wall_line_width.md) duvar sayıları için ayrı ayrı ayarlanabilir. 0 duvarın ayrı bir durum olduğunu unutmayın, bu durum [Minimum Yüz Hattı Boyutu](min_feature_size.md) ayarı kullanılarak ayarlanabilir.

Ayar
----
Teoride, bunu hat genişliğinin %50'sine ayarlamak, hat genişliğinin normal hat genişliğine en yakın kalmasını sağlar. Ancak, biraz daha yukarıda olmak daha iyidir. Yazıcının nozül boyutundan daha geniş hatları yazdırması, daha ince hatları yazdırmaktan daha kolaydır ve daha az hat ayrıca baskının daha hızlı olacağı anlamına gelir.

Çok viskoz malzemeler veya hızlı yazdırırken, Minimum Duvar Hat Genişliği, çok geniş hatlar oluşturulmasını önlemek için azaltılmalıdır. Eğer Minimum Duvar Hat Genişliği çok yüksekse, duvarlar iyi bir şekilde birbirine yapışmaz ve bu da baskının kırılgan olmasına neden olur.

**Bu ayar sadece normal duvarlar için değil, aynı zamanda ekstra deri duvarları, destek duvarları, dolgu duvarları ve konsantrik desenler için de geçerlidir.**