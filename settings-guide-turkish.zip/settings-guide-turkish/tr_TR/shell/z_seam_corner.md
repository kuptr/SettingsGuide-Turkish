Dikiş Köşesi Tercihi
====
Bu ayar ile modelinizdeki köşelere göre dikişlerin nasıl konumlandırılacağını kontrol edebilirsiniz.

Genellikle dikişin yerleştirilebileceği iki seçenek bulunmaktadır: iç köşede gizli veya dış köşede açıkta. Dikişi iç köşede gizlemek genellikle tercih edilir çünkü dikiş orada neredeyse görünmez olacaktır. Ancak, dikişi bir dış köşeye koymak da mümkündür, böylece parça üzerinde bazı son işlemeler yapılabilecekse, bir bıçakla kesilebilir veya biraz zımparalanarak düzeltilir.

Bu ayar için kullanılabilir seçenekler ve etkileri şunlardır:
* **None:** Hiçbiri: Köşeler için hiçbir tercih yoktur. Dikiş, [Z Dikiş Hizalama](z_seam_type.md) gereksinimlerine en uygun şekilde seçilir.
* **Hide Seam:** Dikişi Gizle: Bu, dikişi iç köşede gizlemeyi tercih eder. Z Dikiş Hizalama "En Sivri Köşe" olarak ayarlandığında, her zaman en içteki köşe seçilir. "En Kısa" olarak ayarlandığında, başlangıç konumu yakınında olan bir iç köşe seçilir.
* **Expose Seam:** Dikişi Açığa Çıkar: Bu, dikişi dış köşede açığa çıkarmayı tercih eder. Z Dikiş Hizalama "En Sivri Köşe" olarak ayarlandığında, her zaman en sivri dış köşe seçilir. "En Kısa" olarak ayarlandığında, başlangıç konumu yakınında olan bir dış köşe seçilir.
* **Hide or Expose Seam:** Dikişi Gizle veya Açığa Çıkar: Bu, dikişi, düz bir duvar üzerinde olmadığı sürece, sivri bir köşeye yerleştirir.
* **Smart Hiding:** Akıllı Gizleme: Bu, dikişi "Dikişi Gizle veya Açığa Çıkar" gibi sivri bir köşeye yerleştirir, ancak dikiş, konturda herhangi bir iç köşe varsa, dış köşelerden daha sık iç köşeleri seçer. İç köşe yoksa, bir dış köşe seçer.