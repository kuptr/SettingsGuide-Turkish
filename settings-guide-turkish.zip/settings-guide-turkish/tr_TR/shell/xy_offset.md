Yatay Büyüme
====
Bu ayar, tüm modelin biraz daha geniş veya daha ince olmasını sağlar. Baskı işlemi sırasında boyutsal doğruluk hatalarını telafi etmek için bir önlem olarak kullanılır.

<!--screenshot {
"image_path": "xy_offset_neutral.png",
"models": [{"script": "flipper_grip.scad"}],
"camera_position": [62, -91, 176],
"settings": {"xy_offset": 0},
"colours": 32
}-->
<!--screenshot {
"image_path": "xy_offset_wider.png",
"models": [{"script": "flipper_grip.scad"}],
"camera_position": [62, -91, 176],
"settings": {"xy_offset": 1},
"colours": 32
}-->
<!--screenshot {
"image_path": "xy_offset_slimmer.png",
"models": [{"script": "flipper_grip.scad"}],
"camera_position": [62, -91, 176],
"settings": {"xy_offset": -1},
"colours": 32
}-->
![Orijinal model](../images/xy_offset_neutral.png)
![Yatay olarak genişletilmiş, vida delikleri artık daha küçük](../images/xy_offset_wider.png)
![Negatif bir değer modeli küçültür, vida deliklerini genişletir](../images/xy_offset_slimmer.png)

Pozitif bir değer baskıyı daha şişman yapar. Bu, boşlukların boyutunu azaltır. Negatif bir değer baskıyı daha ince yapar ve boşlukların boyutunu artırır.

Bir baskının toleransı önemliyse, bu ayar çok faydalı olabilir. Plastiklerin hafif deformasyonundan dolayı, baskının gerçek boyutları dijital modelin boyutlarıyla tam olarak uyuşmayabilir. Ölçek aracıyla modeli sadece yapı platformunda ölçeklendirerek kazanılan hatalar telafi edilebilir, ancak baskı yönteminden kaynaklanan ofset hataları bu ayarla telafi edilebilir.

Yazıcınızın her zaman bir miktar fazla ekstrüzyon veya hareketlerindeki doğruluk kaybı nedeniyle fazla genişlediğini biliyorsanız, bu ayarla bunu da telafi edebilirsiniz.