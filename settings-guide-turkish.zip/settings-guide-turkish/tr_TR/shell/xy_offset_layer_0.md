İlk Katmanın Yatay Genişlemesi
====
Bu ayar sadece baskı platformuna (veya rafta) dayanan ilk katı genişletir. [Yatay Büyüme](xy_offset.md) gibi, pozitif bir değer ilk katı daha geniş yaparken, negatif bir değer ilk katı küçültür.

<!--screenshot {
"image_path": "xy_offset_layer_0_original.png",
"models": [
    {
        "script": "d1.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 30, 0],
"camera_lookat": [0, 0, 0],
"settings": {"xy_offset_layer_0": 0},
"colours": 16
}-->
<!--screenshot {
"image_path": "xy_offset_layer_0_enabled.png",
"models": [
    {
        "script": "d1.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 30, 0],
"camera_lookat": [0, 0, 0],
"settings": {"xy_offset_layer_0": -0.6},
"colours": 16
}-->
![Orijinal model](../images/xy_offset_layer_0_original.png)
![İlk kat küçültülmüştür](../images/xy_offset_layer_0_enabled.png)

İlk kat genellikle ısıtmalı bir baskı platformunda basılır, bu da yapışmayı iyileştirmek için biraz sıvı halde kalmasını sağlar. İlk kat normalde diğer katlardan çok daha kalındır. Bu, katın yan yana sarkmasına ve alt kısmının hafifçe daha geniş bir dudak oluşturmasına neden olan "fil ayağı" denilen bir fenomen oluşturacak kadar yeterli zaman ve malzeme sağlar. Bu ayar, fil ayağını telafi etmek için ilk katı önceden daha ince hale getirerek telafi edebilir. Fil ayağını telafi etmek için bu ayara küçük bir negatif değer verin.

Bu ayara büyük bir değer de verebilirsiniz, böylece baskınızın etrafında bir sahte kenar oluşturabilir ve raft gibi diğer yapışma teknikleri ile birleştirebilirsiniz. Ancak, bu derinin de genişletilmesine neden olacağından, ikinci katın duvarlarının altında deri olacaktır.

**Bu ayarı kenar ile birleştirmek etkisizdir, çünkü kenar zaten ilk katın etrafında geniş bir kenar oluşturacaktır.**