Minimum Duvar Akışı
====
Duvar çizgilerindeki örtüşmeleri telafi etmek, bazı duvarların akış hızını azaltacaktır. Bu, akış hızını istenmeyen derecede düşük seviyelere kadar indirebilir, duvarlar neredeyse tamamen örtüşüyorsa %1'e kadar. Son derece düşük akış hızlarında baskı yapmak iyi çalışmaz. Sürekli çizgiler yerine bir damla deseni oluşturma eğilimindedir.

Bu ayar, akış hızı son derece düşük olan bu çizgileri seyahat hareketlerine dönüştürür, akış hızını etkili bir şekilde %0'a düşürür. Malzeme, normal seyahat hareketlerinde olduğu gibi dışarı sızar, ancak boncuk oluşturmaz.

![Duvarlar arasındaki örtüşmeler normal şekilde telafi edilir](../images/wall_min_flow_0.png)
![%50'den az ekstrüzyona sahip duvarlar seyahat hareketlerine dönüştürülür](../images/wall_min_flow_50.png)

Nozül hala sızmanın doğru konumda gerçekleşmesi için duvarın yolunu takip eder.

Bu ayarı artırmak, duvarlarınızın istenenden daha ince olmasına neden olur. Çok ince çizgiler çizmek yerine hiçbir şey çizmeyeceksiniz. Teknik olarak bu, parçanızın istenenden daha ince olmasına neden olan az ekstrüzyondur. Ancak duvar zaten iyi basılmazdı. Duvarın üzerinde uzun bir dizi sıçramalar veya boncuklar çizmek yerine, hiçbir şey basılmayacak, duvar biraz daha düzgün hale gelecektir.

Bu ayarı Nozülün damla oluşturmadan ulaşabileceği minimum duvar akış hızına ayarlayın. Tipik olarak bu yaklaşık %60'tır. Çizgi genişliği %60'ın altına indirilirse, bu damlalar oluşur, bu nedenle bu çizgileri seyahat hareketlerine dönüştürmek daha iyidir. Daha büyük katman yüksekliklerinde veya daha kalın duvar çizgileri kullanıyorsanız, bu ayarı biraz azaltarak daha büyük boyut hassasiyeti elde edebilirsiniz.