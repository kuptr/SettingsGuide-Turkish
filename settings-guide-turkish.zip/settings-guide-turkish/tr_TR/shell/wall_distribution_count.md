Duvar Dağılım Sayısı
====
Cura, basmakta olduğunuz şekle daha iyi uyacak şekilde duvar çizgilerinin genişliğini ayarlayabilir, ancak her duvarı aynı miktarda ayarlamak zorunda değildir. Modelin iç kısmına doğru duvar genişliğini değiştirmeyi tercih eder. Bu ayar, kullanılabilir alanı doldurmak için ayarlanan duvar sayısını, içten dışa doğru sayar.

<!--screenshot {
"image_path": "wall_distribution_count_1.png",
"models": [
	{
		"script": "misaligned_ring.scad",
		"transformation": ["scale(2)"]
	}
],
"camera_position": [-11, 0, 111],
"settings": {
	"wall_line_count": 5,
	"wall_distribution_count": 1
},
"colour_scheme": "line_width",
"colours": 128
}-->
<!--screenshot {
"image_path": "wall_distribution_count_5.png",
"models": [
	{
		"script": "misaligned_ring.scad",
		"transformation": ["scale(2)"]
	}
],
"camera_position": [-11, 0, 111],
"settings": {
	"wall_line_count": 5,
	"wall_distribution_count": 5
},
"colour_scheme": "line_width",
"colours": 128
}-->
![Orta kısımda yoğunlaşmış, burada büyük genişlik farkları vardır](../images/wall_distribution_count_1.png)
![Birçok duvarda yayılmış](../images/wall_distribution_count_5.png)

Değişken genişlikteki duvarlar, basit sabit genişlikli duvarlardan daha zor basılır. Meme çıkış hızını ayarlamak ve geçişi sağlamak için biraz zaman alır, ayrıca bazı keskin köşeler yapmak zorundadır ki bu, yankılanmaya neden olabilir. Tüm bunlar, mümkün olduğunca dışarıdaki yüzeyde görünür olacak şekilde, dışarıya mümkün olduğunca uzakta yapılır. Bu nedenle, Cura, genişlik ayarlarını en içteki duvarlara yoğunlaştırır.

Öte yandan, değişkenliği yoğunlaştırmak, ortadaki bu çizgilerin genişliklerinin geniş ölçüde ayrılacağı anlamına gelir. Bunun birçok duvara yayılması, değişken çizgi genişliğinin etkisini azaltarak, bunu içeride gizlemek yerine dağıtılmasını sağlar.

Bu ayar, kullanılabilir alanı doldurmak için içten birkaç duvarı seçer. Bu, merkezden her iki yöne de sayar, bu nedenle bunun 2 olarak ayarlanması durumunda, merkezde 4 duvar ayarlanabilir. Ayarlama bu duvarlar içinde de eşit olarak dağıtılmaz. Merkezdeki duvarlar, dışarıya daha yakın duvarlardan her zaman biraz daha fazla ayarlanır.

Dış duvar mümkün olduğunda her zaman nominal çizgi genişliğinde tutulur. Bu duvar, baskı kalitesi üzerinde o kadar etkilidir ki, yüzeyi mümkün olduğunca düz yapmak için sabit bir çizgi genişliğinde tutulur. Sadece parça o kadar ince hale gelirse ki sadece dış duvarlardan oluşursa, bu duvarlar ayarlanır.

Uygulamada, kusurları merkezde gizlemek neredeyse her zaman birden fazla duvarda kusurları yaymaktan daha iyi bir stratejidir. Sonuç olarak, bu ayarı mümkün olduğunca düşük tutmak en iyisidir. Esnek malzemeler gibi ekstrüzyonu veya akışını değiştirmesi zor malzemelerle çalışırken, akış değişikliklerini azaltmak için bu ayarı artırmak yardımcı olur. Ancak bu, akış değişikliklerini tamamen önleyemez.

**Bu ayar sadece normal duvarlara değil, aynı zamanda ek cilt duvarlarına, destek duvarlarına, doldurma duvarlarına ve konsantrik desenlere de uygulanır.**