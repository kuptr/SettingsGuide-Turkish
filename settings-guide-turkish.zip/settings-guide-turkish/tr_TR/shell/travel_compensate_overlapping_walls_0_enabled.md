Compensate Outer Wall Overlaps
====
Çok ince parçaları basarken, zıt dış duvarlar yeterince yaklaşabilir ve üst üste gelebilir. Her iki duvarı da normal hat genişliği ile bastığınızda aşırı çıkarım olurdu. Bu ayar, bir hat genişliğini azaltarak bu aşırı çıkarımı önler ve daha iyi boyutsal doğruluk elde eder.

![Hat genişliği azaltılan yer](../images/travel_compensate_overlapping_walls_enabled_schematic.svg)
![Tüm hatlar tam genişlikte ekstrüde edilir, bu da çok geniş bir parçaya neden olur](../images/travel_compensate_overlapping_walls_enabled_disabled.png)
![Hatların yarısı genişliğini azaltmış, daha doğru bir baskı sağlamıştır](../images/travel_compensate_overlapping_walls_enabled_enabled.png)

Bir dış duvarın, başka bir dış duvarla örtüşen alan tarafından azaltılır. Bu aşırı çıkarımı telafi eder.

Yukarıda açıklandığı gibi, bu özellik genellikle boyutsal doğruluğu artırır. Ancak, dezavantajı akış hızının daha az düzgün hale gelmesidir, bu da bazı yerlerde aşırı çıkarıma ve diğerlerinde aşırı çıkarıma neden olur. Ayrıca, akış hızı nozül ve ekstruder kurulumunun minimum akış hızının altına düşebilir ve tutarsız akış ve boncuklanmaya neden olabilir. Bu etkiyi azaltmak için, bazı ince duvarları boyutsal doğruluk maliyetinde seyahat hareketlerine dönüştürecek olan [Minimum Duvar Akışı](wall_min_flow.md)'nı ayarlayabilirsiniz.

**Bu ayar katman görünümünde daha karışık görünme eğilimindedir. Gerçek baskıda, hatlar arasında sınırlar yoktur. Katman görünümü yalnızca g-kodu yollarını gösterir, ancak gerçekte malzeme, üzerine bindiği diğer duvar tarafından kenara itilir. Ayrıca, akışta küçük azalmalar gerçek baskıda kendini göstermez çünkü nozüldeki akış hızı bu kadar hızlı ayarlanamaz. Bu etkiler, gerçek baskının katman görünümünden daha pürüzsüz çıkmasını sağlar.**