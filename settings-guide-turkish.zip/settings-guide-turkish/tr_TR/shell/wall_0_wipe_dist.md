Dış Duvar Sürme Mesafesi
====
Bu ayarla, her dış duvarın sonunda, meme biraz daha ileri hareket edecek ancak ekstrüzyon olmayacak, konturu kapatmak için silecek.

<!--screenshot {
"image_path": "wall_0_wipe_dist.png",
"models": [
    {
        "script": "thin_cylinder.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 0, 50],
"settings": {
    "wall_0_wipe_dist": 4
},
"structures": ["travels", "helpers", "shell", "infill", "starts"],
"minimum_layer": 2,
"layer": 2,
"colours": 16
}-->
![Dış duvarın tamamlanmasından sonra küçük bir hareket](../images/wall_0_wipe_dist.png)

Bu özelliğin amacı, dikişin görünürlüğünü azaltmaktır. Duvar normal şekilde tamamlandığında boncuk hala biraz memenin gerisinde kalır. Bu küçük hareket, boncuğu konturun başlangıcıyla birleştirir, böylece dikiş kapanır.

Dikiş hala görünür olacaktır, ancak küçük bir silme mesafesi ile sonuç biraz daha iyi olmalıdır. Bu ayarı çok fazla artırmak, meme dikişin ötesine gittikçe ve meme odası dış duvarda sızarak boşaldıkça daha sonra bazı az ekstrüzyona neden olabileceğinden artık etkisi olmaz.

Bu etki temel olarak [Taramayı Etkinleştir](../experimental/coasting_enable.md)'in tersidir, ki bu kontur tamamlanmadan hemen önce ekstrüzyonu durdurur.