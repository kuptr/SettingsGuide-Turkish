İnce Duvarları Yazdır
====
Normalde, Cura [Minimum Tek Duvar Hattı Genişliği](min_odd_wall_line_width.md)'nden daha ince olan duvarları, baskı için çok küçük oldukları gerekçesiyle atlayacaktır.

Bu ayar etkinleştirildiğinde, Cura yine de bu parçaları yazdırmaya çalışacaktır. Ortaya çıkan baskı tam olarak doğru olmayacaktır, ancak istenen şekli bir dereceye kadar güvenilir bir şekilde üretebilmelidir.

![Bazı parçalar baskı için çok incedir](../images/fill_outline_gaps_disabled.png)
![Bu ayar etkinleştirildiğinde, ince parçalar bile yazdırılacaktır](../images/fill_outline_gaps_enabled.png)


İnce parçalar, çok ince bir duvar hattı kullanılarak yazdırılır. Ancak bu ince hat iyi yazdırılmayabilir. Bunu düzeltmek için [Minimum İnce Duvar Hattı Genişliği](min_bead_width.md) ayarı da bulunmaktadır. Bu ayar, hat genişliği için alt sınır sağlar. Eğer hat daha ince olursa, çizgi teorik olarak modelin sınırlarını aşarak fazla kalın yazdırılacaktır, ancak en azından güvenilir bir şekilde yazdırılmalıdır. [Minimum Yüz Hattı Boyutu](min_feature_size.md) 'ndan daha ince olan herhangi bir şey ise hiç yazdırılmayacaktır.


**Bu yalnızca yatay düzlemde ince olan parçaları yazdırmayı deneyecektir. Z yönünde ince parçalar için [Dilimleme Toleransı](../experimental/slicing_tolerance.md) ayarına bakın veya katman yüksekliğini azaltın.**