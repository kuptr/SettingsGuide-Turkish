Duvar Sıralaması
====
Bu ayar, duvarların hangi sırayla yazdırılacağını belirler; dıştan içe veya içten dışa doğru yazdırılır.

<!--screenshot {
"image_path": "outer_inset_first_disabled.gif",
"models": [{"script": "calendar_holder.scad"}],
"camera_position": [0, 0, 120],
"settings": {
    "skin_outline_count": 0,
    "inset_direction": "inside_out"
},
"layer": 2,
"line": [0, 6, 12, 18, 25, 35, 41, 47, 54, 57, 61, 64, 65, 68, 72, 74, 77, 79, 80, 82, 86, 96, 102, 108, 114, 125, 131, 137, 144],
"delay": 125,
"colours": 32
}-->
<!--screenshot {
"image_path": "outer_inset_first_enabled.gif",
"models": [{"script": "calendar_holder.scad"}],
"camera_position": [0, 0, 120],
"settings": {
    "skin_outline_count": 0,
    "inset_direction": "outside_in"
},
"layer": 2,
"line": [0, 6, 12, 18, 25, 35, 41, 47, 54, 58, 61, 63, 64, 66, 70, 72, 76, 79, 80, 83, 88, 97, 103, 109, 116, 125, 131, 137, 144],
"delay": 125,
"colours": 32
}-->
![İç duvar önce yazdırılır](../images/outer_inset_first_disabled.gif)
![Dış duvar önce yazdırılır](../images/outer_inset_first_enabled.gif)

Bu ayar, kalite ve boyutsal doğruluk üzerinde küçük bir etkiye sahiptir:
* Dıştan içe doğru yazdırmak boyutsal doğruluğu artırır. Bitişik duvarlar genellikle birbirini biraz iter, özellikle de duvar hat genişliği nozül boyutundan küçükse. İlk yazdırılan duvar katılaşır ve bu nedenle o kadar fazla itilmez. Bu nedenle dış duvarı önce yazdırmak, dış duvarın daha doğru bir konumda olmasını sağlar.
* Dolgu, duvarlardan önce yazdırılıyorsa, dıştan içe doğru yazdırmak dolgunun yüzeyde ne kadar göründüğünü azaltır. Aksi takdirde, dolgu önce yazdırılır, sonra iç duvarlar, dolgu tarafından dışa doğru itilir ve ardından iç duvarlar tarafından dışa doğru itilen dış duvar yazdırılır. Sonuç olarak, dışta bir desen görülebilir. Dış duvar önce yazdırılırsa, dış duvar katılaşarak iç duvarın üzerine itmesini engelleyebilir.
* İçten dışa doğru yazdırmak çıkıntılar için daha iyidir. Dış duvar, önceki katmandan iç duvardan daha uzaktır. Dış duvar önce yazdırıldığında, dış duvarın tutunacak bir şeyi olmaz. İç duvar önce yazdırıldığında, dış duvar yana doğru iç duvara tutunabilir.

Tek sayıda duvar olduğunda, ortadaki duvar her zaman son yazdırılır