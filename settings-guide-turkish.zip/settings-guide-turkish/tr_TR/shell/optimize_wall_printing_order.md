Duvar Yazdırma Sırasını Optimize Et
====
Bu özellik etkinleştirildiğinde, Cura, duvarların basılma sırasını optimize etmek için ek dilimleme zamanı harcayacaktır. Amaç, aynı parçayı çevreleyen duvarları ardışık olarak basarak seyahat hareketlerini ve geri çekilmelerin sayısını azaltmaktır.

<!--screenshot {
"image_path": "optimize_wall_printing_order_disabled.gif",
"models": [
    {
        "script": "plate_with_indent.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 0, 120],
"settings": {
    "skin_outline_count": 0,
    "optimize_wall_printing_order": false
},
"layer": 37,
"line": [0, 5, 9, 13, 17, 25, 29, 33, 37, 47, 54, 61, 71, 89, 106, 122, 142, 156, 160, 164, 169, 176, 183, 188, 194, 225, 241, 262, 282, 293, 297, 302, 309, 319, 326, 332, 343, 353, 358, 363, 368],
"delay": 125,
"colours": 32
}-->
<!--screenshot {
"image_path": "optimize_wall_printing_order_enabled.gif",
"models": [
    {
        "script": "plate_with_indent.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 0, 120],
"settings": {
    "skin_outline_count": 0,
    "optimize_wall_printing_order": true
},
"layer": 37,
"line": [0, 4, 7, 11, 17, 25, 31, 36, 41, 47, 51, 55, 60, 67, 71, 76, 83, 92, 99, 106, 114, 123, 130, 136, 147, 165, 181, 197, 217, 239, 256, 278, 299, 312, 316, 320, 325, 331, 336, 343, 350],
"delay": 125,
"colours": 32
}-->
![Optimizasyon devre dışı bırakıldı](../images/optimize_wall_printing_order_disabled.gif)
![Optimizasyon etkinleştirildi](../images/optimize_wall_printing_order_enabled.gif)

Bu optimizasyon etkinleştirildiğinde, meme bir parçanın çevresindeki tüm duvarları önce basacak ve ardından bir sonraki parçaya geçecek şekilde basar. Bu optimizasyon genellikle olumlu bir etki yaratır, ancak bazı parçalarda boyut hassasiyetini etkileyebilir çünkü bir sonraki duvar yanına yerleştirildiğinde önceki duvar henüz sertleşmemiştir.

İç duvar ve dış duvarın akış hızları çok farklı ise, bu optimizasyon ayrıca akış hızında birçok değişikliğe neden olur. Bu, daha büyük bir [dikiş izi](../troubleshooting/seam.md) veya bazı [kabarcık/lekeler](../troubleshooting/blobs.md) şeklinde kendini gösterir. Hat genişliği, baskı üzerinde seyahat optimizasyonundan daha büyük bir etkiye sahiptir, bu nedenle baskınızda bu sorun olabilirse optimizasyonu kapatmak daha iyidir.