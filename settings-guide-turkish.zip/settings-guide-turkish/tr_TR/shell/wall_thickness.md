Duvar Kalınlığı
====
Bu ayar, baskının etrafındaki duvarın ne kadar kalın olacağını belirler. Sonuç olarak, istenilen kalınlığa ulaşmak için iç duvarların sayısını ayarlar.

<!--screenshot {
"image_path": "wall_thickness_0.8.png",
"models": [
    {
        "script": "rotary_tumbler_lid.scad",
        "transformation": ["scale(0.4)"]
    }
],
"camera_position": [50, 50, 124],
"settings": {
    "skin_outline_count": 0,
    "wall_line_count": 2
},
"colours": 32
}-->
<!--screenshot {
"image_path": "wall_thickness_1.6.png",
"models": [
    {
        "script": "rotary_tumbler_lid.scad",
        "transformation": ["scale(0.4)"]
    }
],
"camera_position": [50, 50, 124],
"settings": {
    "skin_outline_count": 0,
    "wall_line_count": 4
},
"colours": 32
}-->
![Duvarlar 0.8 mm kalınlığında](../images/wall_thickness_0.8.png)
![Duvarlar 1.6 mm kalınlığında](../images/wall_thickness_1.6.png)

Duvar kalınlığı, duvar çizgi genişliğinin bir katı olmalıdır. Değilse, tam bir kat olacak şekilde yuvarlanır. Ancak unutmayın ki duvarlardan biri dış duvar olacak, geri kalanları iç duvarlar olacaktır. Bu duvarlar farklı çizgi genişliklerine sahip olabilir.

Duvarların kalınlığı, baskının ne kadar güçlü olacağında önemli bir faktördür. Duvarlar bitişik olduklarından, birbirlerini güçlendirebilirler ve daha sağlam bir parça elde edilir. Daha büyük baskılarda, şekle bağlı olarak, bu, sağlam bir nesne elde etmenin doldurmayı ayarlamaktan çok daha etkili bir yoludur.

Duvar kalınlığını arttırmak şunları sağlar:
* Baskının dayanıklılığını büyük ölçüde artırır.
* Doldurma deseninin dışarıdan görülebileceği ışık geçirme etkisini azaltır.
* Overhangları iyileştirir, çünkü duvar çizgileri genellikle en yakın dinlenme noktalarına daha fazla yöneliktir.
* Modelin su geçirmezliğini daha kolay sağlar.
* Baskının basılma süresini ve malzeme kullanımını büyük ölçüde artırır.