Outer Before Inner Walls
====
Bu ayar, hangi duvarların önce basılacağını belirler, dış veya iç duvarlar.

<!--screenshot {
"image_path": "outer_inset_first_disabled.gif",
"models": [{"script": "calendar_holder.scad"}],
"camera_position": [0, 0, 120],
"settings": {
    "skin_outline_count": 0,
    "outer_inset_first": false
},
"layer": 2,
"line": [0, 1, 2, 3, 4, 5, 6, 7, 8, 17, 23, 29, 35, 45, 51, 57, 63, 67, 68, 69, 70, 71, 72, 73, 74, 84, 90, 96, 102, 113, 119, 125, 131],
"delay": 125,
"colours": 32
}-->
<!--screenshot {
"image_path": "outer_inset_first_enabled.gif",
"models": [{"script": "calendar_holder.scad"}],
"camera_position": [0, 0, 120],
"settings": {
    "skin_outline_count": 0,
    "outer_inset_first": true
},
"layer": 2,
"line": [0, 1, 2, 3, 4, 5, 6, 7, 8, 18, 24, 30, 36, 47, 53, 59, 65, 70, 71, 72, 73, 74, 75, 76, 77, 86, 92, 98, 104, 114, 120, 126, 132],
"delay": 125,
"colours": 32
}-->
![İç duvar önce yazdırılır](../images/outer_inset_first_disabled.gif)
![Dış duvar önce yazdırılır](../images/outer_inset_first_enabled.gif)

Bu ayarın etkinleştirilmesi, kalite üzerinde küçük bir etkiye ve boyutsal doğruluk üzerinde de etkiye sahiptir:
* Boyutsal doğruluğu artıracaktır. Komşu duvarlar genellikle birbirini biraz iter, özellikle duvar hat genişliği nozül boyutundan daha küçükse. İlk olarak basılan duvar katılaşmış olacak ve daha az itilecektir. Bu nedenle dış duvarı önce basmak, dış duvarınızın daha doğru bir konumda olmasını sağlayacaktır.
* Dolgu, duvarlardan önce basılırsa, yüzeye dolgunun ne kadar gözükeceğini azaltır. Aksi takdirde, dolgu önce basılır, ardından dolgu tarafından dışa doğru itilen iç duvarlar ve ardından iç duvarlar tarafından dışa doğru itilen dış duvar basılır. Sonuç olarak, dışarıda bir desen görülebilir. Dış duvar önce basılırsa, dış duvar iç duvarın üzerine itilmeden önce katılaşabilir.
* Dış duvarın önce basılması genellikle aşağı sarkmalarda daha kötüdür. Dış duvar, iç duvardan bir önceki katmandan daha fazla uzaktadır. Dış duvarın önce basılması durumunda, dış duvarın henüz tutunacak hiçbir şeyi yoktur. İç duvar önce basıldığında, dış duvar yan yana bağlanabilir.