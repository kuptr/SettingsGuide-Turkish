Z Dikişi X
====
[Z Dikiş Hizalama](z_seam_type.md) ayarlarında dikiş konumu "Kullanıcı Belirledi" olarak ayarlandığında, dikiş [Z Dikişi Y](z_seam_y.md) ayarları ile belirtilen konuma yakın bir yerde yerleştirilir.

<!--screenshot {
"image_path": "z_seam_x_left.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["rotateZ(-90)"]
    }
],
"camera_position": [-55, 128, 40],
"settings": {
    "z_seam_type": "back",
    "z_seam_position": "left"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "z_seam_x_right.png",
"models": [
    {
        "script": "rod_holder.scad",
        "transformation": ["rotateZ(-90)"]
    }
],
"camera_position": [55, 128, 40],
"settings": {
    "z_seam_type": "back",
    "z_seam_position": "right"
},
"colours": 64
}-->
![Dikiş, sol tarafta yer alır](../images/z_seam_x_left.png)
![Dikiş, sağ tarafta yer alır](../images/z_seam_x_right.png)

Bu ayar, [Z Dikişi Göreliliği](z_seam_relative.md) devre dışı bırakıldığında, baskı tablası üzerindeki mutlak bir konumu veya Z Dikişi Göreceli etkinleştirildiğinde modelin merkezine göre göreceli bir konumu belirtir. Konum mutlak olduğunda, koordinat g-code koordinat sistemindedir, bu da Cura'nın nesnelerin yerleştirilmesi için gösterdiği koordinatlardan farklıdır.

Dikişi, baskınızın uygulamasında gözle görülmesi zor bir konumda seçmek faydalıdır. Eğer böyle bir konum yoksa veya baskıdan sonra biraz işlem yapılabilecekse, dikişi kolayca bıçakla kesilebilecek veya zımparalanabilecek bir konuma yerleştirmeyi tercih edebilirsiniz.