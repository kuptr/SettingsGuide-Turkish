Duvar Geçişi Filtresi Kenar Boşluğu
====
Bazı modeller, farklı duvar sayılarının kullanıldığı eşikte ince parçalar içerebilir. Bu durum, parçanın gerçek genişliği çok fazla değişmese bile duvar sayısının sürekli olarak değişmesine neden olabilir. Bu değişim, baskı kalitesini bozar, çok sayıda akış değişikliği gerektirir ve daha fazla seyahat hareketi ekler. Bu özelliği kullanarak, geçişler, sürekli olarak ileri geri geçiş yapacak şekilde yapılmaz.

Bir geçiş kaldırıldığında, geçici olarak bazı çizgiler çok geniş veya çok ince olabilir. Bu ayar, çizginin ne kadar daha geniş veya ince olabileceğini sınırlayarak hangi geçişlerin filtrelenmesinin gerektiğini belirleyerek bu sorunu çözer.

<!--screenshot {
"image_path": "wall_transition_filter_off.png",
"models": [{"script": "signet.scad"}],
"camera_position": [0, 11, 106],
"settings": {
	"wall_transition_filter_distance": 0,
	"wall_transition_filter_margin": 0,
	"wall_line_count": 3
},
"colours": 64
}-->
<!--screenshot {
"image_path": "wall_transition_filter_on.png",
"models": [{"script": "signet.scad"}],
"camera_position": [0, 11, 106],
"settings": {
	"wall_transition_filter_distance": 100,
	"wall_transition_filter_margin": 0.2,
	"wall_line_count": 3
},
"colours": 64
}-->
![Düşük bir marjla, 2 ve 3 duvar arasında sürekli olarak değişir](../images/wall_transition_filter_off.png)
![Daha yüksek bir marjla, artık sürekli olarak değişmez](../images/wall_transition_filter_on.png)

Daha kesin olmak gerekirse, bu marj, geriye dönüşü engellemek için çizginin [Minimum Duvar Hattı Genişliği](min_wall_line_width.md) kadar ince olmasına izin verir. Benzer şekilde, çizgilerin, ek bir duvarın Minimum Duvar Çizgisi Genişliği kadar sığabileceği durumlarda, bu marjla bir miktar daha geniş olmasına da izin verilir.

Bu filtre, düşük çözünürlüklü 3B kafesler kullanan ince parçaların yaygın bir sorununu çözmeyi amaçlar. Düz üçgenlerden oluşan 3B model, bir eğriyi tam olarak temsil edemez, sadece onu yaklaşık olarak temsil eder. Eğri, kenarlara sahip olacaktır ve aralarında düz yüzeyler olacaktır. Sabit bir genişlikte kavisli bir parçayı modelleme yaparken, dıştaki kenarların içteki kenarlarla hizalanması önemlidir. Eğer hizalanmazlarsa, halkanın genişliği hafifçe değişir, bu da yukarıda gösterilen etkiye neden olabilir. Geçiş filtresi, bu etkinin fazla olmasını önlemelidir.

Marj artırıldığında, bazı durumlarda küçük çizgi segmentleri oluşturulması önlenir. Bu, daha hızlı baskı alır ve yüzeyin daha düzgün görünmesini sağlayabilir. Ancak aynı zamanda, nozülünüzden iyi çıkmayabilecek daha aşırı çizgi genişliklerine izin verir. Düşük çözünürlüklü modellerde ince parçalar basarken, marjı artırmak kaliteyi artırmaya yardımcı olabilir. Zorlu malzemelerle çalışırken, güvenli tarafta kalmak daha iyidir.

**Bu ayar sadece normal duvarlara değil, aynı zamanda ek cilt duvarlarına, destek duvarlarına, doldurma duvarlarına ve konsantrik desenlere de uygulanır.**