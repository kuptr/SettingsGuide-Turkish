Alternate Skin Rotation
====
Bu ayar etkinleştirildiğinde, üst ve alt kısımlar çizgi veya zik zak [Üst/Alt Şekil](../top_bottom/top_bottom_pattern.md)'i ile basılırken, normalde çizgiler iki çapraz yönde sırayla değişir. Bu ayar etkinleştirilirse, çizgiler dört yönde sırayla değişecektir: iki çapraz yönde, dikey ve yatay.

![Dört yönde sırayla değişim](../images/skin_alternate_rotation.gif)

Bu ayar, [Üst/Alt Çizgi Yönleri](../top_bottom/skin_angles.md) ayarını geçersiz kılar. Davranış aynıdır, aslında bu ayar, `[45, 135, 0, 90]` açılarını girerek tamamen taklit edilebilir.

Genellikle, baskınız, çizgilerin uzunlamasına yönü boyunca en sert olacaktır. Bu ayar etkin değilse, en sert olan yön iki çapraz yönde olacaktır, bu da dik yönlere göre daha zayıf olmasını sağlar. Bu çapraz yönlere, 3D yazıcıların en yaygın hareket mekanizmaları, bu yönlere daha hızlı ivmelenmelerini sağlayan daha fazla motor kullanır.

Bu ayar etkinse, çizgilerin yönleri daha dengeli bir şekilde dağıtılır. Bu da nesnenin gücünü daha dengeli bir şekilde etrafa yayılır. Nesneyi dikey ve yatay yönlere karşı daha güçlü yapar, ancak çapraz yönlere karşı biraz daha zayıf yapar. Ayrıca nesneyi biraz daha uzun sürede yazdırmak demektir.