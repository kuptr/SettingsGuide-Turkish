Maksimum Çıkıntı Deliği Alanı
====
[Çıkıntıyı Yazdırılabilir Yap](conical_overhang_enabled.md) sarkmaları ortadan kaldırdığı için, herhangi bir köprü otomatik olarak alçaltılır ve altındaki sarkma kapatılır. Ancak, sarkma her taraftan çevriliyse, bu sarkma tamamen doldurulana kadar alçaltılmaya devam edecektir. Etkili bir şekilde, aşağıya bakan delikler tamamen doldurulacaktır, hatta üstte sadece küçük bir noktada sarkma olsa bile.

Bu etkiyi önlemek için, bu ayar sarkmanın her taraftan çevrili olması ve belirli bir alanın altında olması durumunda açık kalmasına izin verir. Bu sadece delikler için geçerlidir. Modelin dışındaki normal sarkmalar, makul bir yazdırılabilir açıyı korumak için hala aşağıya doğru uzatılır.

<!--screenshot {
"image_path": "conical_overhang_hole_size.png",
"models": [{"script": "plopper.scad"}],
"camera_position": [-86, 29, -85],
"settings": {
    "conical_overhang_enabled": true,
    "conical_overhang_hole_size": 20
},
"colours": 64
}-->
![Üstte küçük bir noktanın sarkmasına izin verilir, böylece bu delik doldurulmaz](../images/conical_overhang_hole_size.png)

Çoğu model için bu ayarı birkaç düzine milimetrekareye ayarlamak oldukça güvenlidir. Çok düşük ayarlanırsa, sarkmaları desteklemek için gerçekten desteğe ihtiyaç duymayan küçük sarkmalar bile desteklenir ve model daha fazla değiştirilir. Çok yüksek ayarlanırsa, köprülemek zor olabilecek önemli sarkma alanları oluşabilir.

Bu ayar nedeniyle büyük sarkma alanları varsa, sarkmayı ortadan kaldırmak için modeli değiştirmeden önce [Köprü Ayarlarını Etkinleştir](bridge_settings_enabled.md)meyi düşünmek iyi bir fikirdir.