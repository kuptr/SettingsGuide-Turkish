WP Connection Flow
====
Bu ayar, tel çerçeve yapısındaki yukarı ve aşağı bağlantı tellerinin akış hızını (ve böylece tellerin kalınlığını) yapılandırır. Bu, yatay halkalardan ayrı olarak yapılandırılabilir.

![Farklı akış ayarlarının uygulandığı yerler](../images/wireframe_flow.svg)

Akışı artırmak telleri kalınlaştırır. Bu, bağlantıların katılaştıktan sonra daha sağlam olmasını sağlar. Ancak aynı zamanda tellerin ısıl kütlesini artırır, bu da katılaşmalarının daha uzun sürmesine neden olur. Bu durum, tellerin doğru şekilde bağlanmamasına ve baskının güvenilirliğinin azalmasına yol açabilir.