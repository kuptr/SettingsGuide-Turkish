WP Drag Along
====
Tel Baskı için testere dişi deseninin aşağı doğru çapraz hareketini yazdırırken, malzeme biraz sürükleme eğilimindedir. Bu ayar, testere dişi deseninin şeklini hafifçe değiştirerek bu etkiyi telafi eder. Dişlerin uçları yukarı ve geri doğru hareket ettirilir.

![Testere dişi dişlerinin uçları geriye ve yukarıya hareket ettirilir](../images/wireframe_drag_along.svg)

Diagonal aşağı hareketin tam tersi yönde diş uçları hareket ettirilir. Malzeme sürüklendiğinde, umarız testere dişi deseninin uçları amaçlanan konumda kalır.

İyi ayarlandığında, bu testere dişi desenin daha doğru yazdırılmasını sağlar. Sonuç olarak, testere dişi deseninin üzerine yerleştirilen sonraki yatay halka, aksi halde olduğundan daha az sarkar. Tüm yapı daha sağlam hale gelir ve baskı daha güvenilir olur.