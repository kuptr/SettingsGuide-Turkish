Maksimum Model Açısı
====
Bu ayar ile [Çıkıntıyı Yazdırılabilir Yap](conical_overhang_enabled.md) (derece cinsinden) yapılandırılır, bu da sarkmayı yazdırılabilir hale getirir. Bu açıyı artırmak, daha büyük sarkmalara izin verir ve Cura'nın modeli daha az değiştirmesine neden olur. Bu açıyı azaltmak, nesnenin neredeyse hiç sarkma içermemesini sağlar.

<!--screenshot {
"image_path": "conical_overhang_enabled_enabled.png",
"models": [{"script": "castle.scad"}],
"camera_position": [0, 189, 25],
"settings": {
    "conical_overhang_enabled": true,
    "conical_overhang_angle": 50
},
"colours": 8
}-->
<!--screenshot {
"image_path": "conical_overhang_angle_20.png",
"models": [{"script": "castle.scad"}],
"camera_position": [0, 189, 25],
"settings": {
    "conical_overhang_enabled": true,
    "conical_overhang_angle": 20
},
"colours": 8
}-->
![50° maksimum model açısı.](../images/conical_overhang_enabled_enabled.png)
![20° maksimum model açısı.](../images/conical_overhang_angle_20.png)

90°'lik bir açı, modelin tüm sarkmalarıyla olduğu gibi kalmasını sağlar. Model değiştirilmeyecektir. 0°'lik bir açı, tüm eğimleri tamamen dikey yapar.

Bu açıyı azaltmak, modeldeki sarkmaları azaltır. Bu, modelin daha iyi yazdırılmasını sağlar. Fazla sarkma olmaz ve bu nedenle alt yüzeylerdeki yüzey daha düzgün olur. Ancak, bu aynı zamanda basılan nesnenin orijinal modele daha az sadık olmasını sağlar. Ayrıca, yazdırmak için biraz daha fazla zaman ve malzeme gerektirir.

Açı negatif de olabilir. Bu, tüm baskıyı geniş tabanlı konik bir hale getirir. Bu, ilginç efektler üretebilir, ancak gerçek anlamda pratik bir kullanımı yoktur.