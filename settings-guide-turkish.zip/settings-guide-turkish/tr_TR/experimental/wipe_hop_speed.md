Sürme Sıçrama Hızı
====
Bu ayar, silme işlemi için Z hop yapılırken nozülün ne kadar hızlı hareket edeceğini veya yapı platformunun ne kadar hızlı aşağı hareket edeceğini yapılandırır. Bu ayar, normal [Z Atlama Hızı](../speed/speed_z_hop.md)'ndan ayrı olarak yapılandırılabilir.

[Sürme Z Sıçraması Yüksekliği](wipe_hop_amount.md)'ni ayarlarken, ekstra kat edilmesi gereken mesafeye uyum sağlamak için hızı da ayarlamak isteyebilirsiniz. Ancak unutmayın ki, daha büyük mesafe aynı zamanda hızlanma limitleri nedeniyle maksimum hızın hiçbir zaman ulaşılamamasına izin verebilir.