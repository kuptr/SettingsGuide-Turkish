WP Roof Outer Delay
====
Bu ayarla, tel çerçevenin tavanında testere dişi desenini yazdırırken, nozülün dış konturu her vurduğunda kısa bir süre durmasını yapılandırabilirsiniz.

![Kırmızı noktalar, nozülün duracağı yerlerdir](../images/wireframe_roof_outer_delay.svg)

Durduğunda, nozül damlatmadan dolayı durduğu yerde küçük bir damlacık üretecektir. Bu damlacık, testere dişi deseni ile etrafındaki kontur arasındaki bağlantıyı iyileştirir.

Duraklama, nozülün duracağı birçok yer olduğu için önemli bir baskı süresi alır.