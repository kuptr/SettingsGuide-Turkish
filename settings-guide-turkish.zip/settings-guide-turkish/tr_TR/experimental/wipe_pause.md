Sürmeyi Durdurma
====
Bu ayar, silme işlemi tamamlandıktan hemen sonra nozülün kısa bir süre duraklamasını sağlar.

Silme işlemi oldukça uzun bir seyahat hareketidir. Nozül, yapı platformunun kenarına kadar hareket eder, orada ileri geri hareket eder ve ardından yazıcıya geri dönmek zorundadır. Bu süreçte fazla malzeme akması olabilir ve daha uzun bir [Sürme Geri Çekme Mesafesi](wipe_retraction_amount.md) gerekebilir. Retraksiyon sonrası, nozüldeki malzemenin tekrar basınca gelmesi için bir süre geçmesi gerekecektir. Bu duraklama, malzemenin tekrar retraksiyona geldiğinde nozül odasının basınca geri gelmesine izin verir, böylece ilk satırın önemli bir şekilde eksik ekstrüzyon olmadan doğru bir şekilde basılmasını sağlar.

Fazla uzun süre duraklama, nozülün indiği yerde bir topak oluşturabilir. Baskı sırasına bağlı olarak (örneğin, [Duvarlardan Önce Dolgu](../infill/infill_before_walls.md) ayarı) bu önemli olmayabilir çünkü topak baskının görünmeyen iç kısmında olabilir. Ancak bu topak için kullanılan malzeme, sonraki basılacak satırlar için kullanılmayacak ve bu alanlarda eksik ekstrüzyona neden olabilir. Bu ayarın dikkatli bir şekilde ayarlanması gerekmektedir.