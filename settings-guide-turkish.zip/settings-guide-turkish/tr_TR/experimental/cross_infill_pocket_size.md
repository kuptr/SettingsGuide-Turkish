Çapraz 3D Cebin Boyutu
====
Çapraz 3D [Dolgu Şekli](../infill/infill_pattern.md) esnek baskıları kolaylaştırmak amacıyla yapılmıştır. Desen, çok katı olan 4 yönlü kesişmeler içerir. Bu ayar, desenin belirli yerlerde çok katı olmasını önlemek için kesişmeyi kaçınmasına neden olur. Deseni, kesişimde hava boşluğu bırakacak şekilde ayarlar. Bu ayar, cebin boyutunu belirler.

<!--screenshot {
"image_path": "infill_pattern_cross_3d.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "cross_3d",
    "cross_infill_pocket_size": 2
},
"colours": 32
}-->
<!--screenshot {
"image_path": "cross_infill_pocket_size_0_5.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "cross_3d",
    "cross_infill_pocket_size": 0.5
},
"colours": 32
}-->
![Varsayılan cebi boyutu 2mm](../images/infill_pattern_cross_3d.png)
![0.5mm cebi boyutu](../images/cross_infill_pocket_size_0_5.png)

Desen, 4 yönlü kesişim etrafındaki mesafeyi değiştirir. Bu ayar, hatların tamamen temas ettiği katmanlarda cebi boyutunu belirler. Cebin maksimum boyutu dolgu yoğunluğu tarafından belirlenir. Cebi boyutu, dolgu hat mesafesinin karekökünden büyük olmayacak şekilde çizilmez. Daha büyük bir değer girilirse etkisi olmayacak, ancak daha büyük cebi boyutlarına izin vermek için [Aşamalı Dolgu Basamakları](../infill/gradual_infill_steps.md) veya [Çapraz Dolgu Yoğunluğu Görüntüsü](cross_infill_density_image.md) kullanılıyorsa büyük değerler girilebilir.

Bu ayarın değeri arttıkça, dolgu dikey yönde daha zayıf hale gelir ve gücü daha iyi dağıtarak daha dengeli bir mukavemet dağılımı yaratır.