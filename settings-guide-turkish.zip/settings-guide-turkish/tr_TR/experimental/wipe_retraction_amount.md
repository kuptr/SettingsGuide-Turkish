Sürme Geri Çekme Mesafesi
====
Bu ayar, silme işlemi sırasında malzemenin ne kadar geri çekileceğini yapılandırır. Bu, normal [Geri Çekme Mesafesi](../travel/retraction_amount.md) ayrı olarak yapılandırılabilir.

Silme işlemi, nozülün yazıcı tarafındaki kenara kadar gitmesini, orada ileri geri hareket etmesini ve ardından geri dönmesini içerir. Bu aslında çok uzun bir seyahat hareketidir. Bu seyahat hareketi, baskı boyunca yapılan ortalama seyahat hareketlerinden daha uzundur, bu nedenle silmeler sırasında kullanılan geri çekme mesafesini artırmak isteyebilirsiniz.

Malzemeyi daha fazla geri çekmek daha fazla zaman alacak ve filamentin daha hızlı aşınmasına neden olacaktır, ancak sızıntıdan kaynaklanan malzeme kaybını azaltacaktır.