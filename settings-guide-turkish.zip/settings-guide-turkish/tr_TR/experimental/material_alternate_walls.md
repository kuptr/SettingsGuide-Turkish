Duvar Yönlerini Değiştir
====
Bu ayar etkinleştirildiğinde, duvarların sarılma yönü saat yönü ve saat yönü tersi arasında değişir.

İç duvarların ilki dış duvarın ters yönünde basılacak, ikinci iç duvar tekrar ters yönde basılacak. Dahası, sonraki katında da aynı şekilde başlayacak, böylece üst üste gelen duvarlar da sırayla değişecektir.

Yazdırma yönlerini değiştirmek, modelin içindeki gerilim etkilerini azaltır, [eğrilme](../troubleshooting/warping.md)etkisini azaltır. Herhangi bir çizginin yazdırılması sırasında, nozül erimiş malzemenin ipliğini oldukça sıkı çeker, bu da plastik malzemeyi gerer. Katılaştığında, bu gerilim modeli şekillendirebilir. Yan yana gelen çizgi ters yönde basıldığında, bu gerilim, ters yönde çekilen yan yana çizgiler tarafından karşılanır. Gerilimin kuvveti ters yönde gerilim tarafından karşılanır.

Duvar yönlerini alternatif olarak basmanın dezavantajı, yazıcının kirişindeki histerezisten gelir. Yazıcının millerinde veya kasnaklarında herhangi bir oynama varsa, ters yönde basıldığında çapraz çizgiler biraz farklı bir noktaya yerleştirilir. Sonuç olarak, duvar daha az pürüzsüz hale gelir ve baskı boyutları daha az doğru olur. İyi ayarlanmış bir yazıcı bu etkiyi göstermez, bu yüzden sıkı kemerler, kasnaklar ve hassas bileşenler varsa, duvar yönlerini alternatif olarak basmak genellikle yalnızca avantaj sağlar.

Yazdırma [İçten Dışa](../shell/inset_direction.md) durumunda, bu ayar duvarın dikişini daha görünür hale getirir ve titreşime neden olan dış duvarın başlamasından hemen önce nozülün tam 180° dönmesine neden olur. Bu etki dışarıdan içeri doğru yazdırma durumunda belirgin değildir.