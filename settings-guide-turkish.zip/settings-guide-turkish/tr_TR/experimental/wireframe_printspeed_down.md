WP Downward Printing Speed
====
Bu ayar, testere dişi deseninde çapraz hareket yaparken nozülün aşağı doğru ne kadar hızlı hareket edeceğini belirtir. Aşağı hareket hızı, tel baskı hızının geri kalanından ayrı olarak yapılandırılabilir.

![Farklı Tel Baskı hızlarının uygulandığı yerler](../images/wireframe_printspeed.svg)

Daha yavaş aşağı hareket etmek daha fazla zaman alır, ancak malzemenin katılaşması için daha fazla zaman sağlar. Bu, baskının daha güvenilir olmasını sağlar.