WP Nozzle Clearance/Temizleme
====
Bu ayar, Tel Baskı'nın testere dişi deseninin dikey destekleri arasındaki mesafeyi ayarlar. Deseni, nozulun önceki yatay halkaya inmesi için boşluk bırakacak şekilde daha geniş yapar.

Normalde, testere dişi deseninde 45°'lik tam bir çapraz bulunur. Dişlerin yüksekliği genişliği ile tam olarak aynıdır. Bu ayar, bu dişlerin genişliğini artırır. Sonuç olarak, çapraz çizgi daha sığ bir şekilde yazdırılır.

Bu ayarı artırmak, tel çerçevenin yatay halkaları arasındaki bağlantı miktarını azaltır. Bu çerçevenin daha zayıf olmasına yol açar, ancak baskı süresini biraz azaltır. Eğer nozul çok geniş ve sığsa, bu ayar nozulun yanındaki dişlere çarpmasını önlemek için kullanılabilir.