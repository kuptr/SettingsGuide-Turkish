Minimum Poligon Çevre Uzunluğu
====
Cura genellikle nozülün yazdırabileceği boyuttan daha küçük olan model ayrıntılarını kaldırır. Bu ayarla, bu eşiği daha fazla veya daha az ayrıntı kaldırmak için ayarlayabilirsiniz. Bu ayar, her katmandaki her şeklin çevresini ölçer ve bu ayarın değerinden daha küçükse, o şekil yazdırılmaz.

Bir hat genişliğinden daha küçük ayrıntıları kaldırmak genellikle iyi bir fikirdir. Bu dilimleme işlemini biraz hızlandırır. Ancak, [Dış Duvar Hattı Genişliği](../resolution/wall_line_width_0.md) ve [İnce Duvarları Yazdır](../shell/fill_outline_gaps.md) özelliği etkinleştirildiğinde bu her zaman geçerli değildir. Eğer çok küçük parçalar hala denemeye değerse, bu ayarı daha küçük yapabilirsiniz.

Bu ayarı artırmak, küçük ayrıntıları kaldırmaya ve daha hızlı bir baskı elde etmeye yardımcı olabilir. Eğer bu küçük ayrıntıları yazdırmaya ihtiyaç yoksa, onlara ulaşmak için bazı seyahat hareketlerinden tasarruf edebilirsiniz.