Köprü Duvarı Tarama
====
Duvar hatları ile köprüleme yaparken, bir köprü yazdırılmadan hemen önce, malzeme beslemesi bir an duraklatılır. Bu süre zarfında, nozul odası içinde kalan artık malzemenin akması izin verilir, bu da nozul odası içindeki basıncı azaltır. Bu teknik [Taramayı Etkinleştir](coasting_enable.md) olarak adlandırılır. Bu ayar ile, duraklamanın miktarı kontrol edilebilir. Temel olarak, bu malzemenin ne kadar önceden durdurulacağını kontrol eder.

Köprü tamamlandıktan sonra, ekstrüde edilmeyen malzeme yine atılacaktır. Toplam malzeme ekstrüzyon miktarı aynı kalacaktır. Bu, nozul üzerindeki basıncı geri getirir ve bu da eksik ekstrüzyonu önler.

<!--screenshot {
"image_path": "bridge_skin_density_100.png",
"models": [{"script": "bridge.scad"}],
"layer": 80,
"settings": {
    "bridge_settings_enabled": true,
    "bridge_skin_density": 100,
    "bridge_skin_material_flow": 100,
    "bridge_wall_material_flow": 100
},
"camera_position": [0, 18, 79],
"colours": 64
}-->
![Köprü üzerinde hiçbir ekstrüzyon olmazken, diğer tarafta fazladan ekstrüzyon olur](../images/bridge_skin_density_100.png)

Bu ayarın birimleri sezgisel olması için tasarlanmamıştır. Malzemenin akışının köprüden önce ne kadar önceden duracağı birkaç faktöre bağlıdır:
* Şu ana kadar duvarın uzunluğu, köprüye kadar olan kısım. Duvar ne kadar uzunsa, o kadar çok duraklayabilir.
* Normal duvar boyunca nozuldan çıkan akış hızı, bu da normal duvarların [Duvar Hızı](../speed/speed_wall.md), [Duvar Hattı Genişliği](../resolution/wall_line_width.md), [Duvar Akışı](../material/wall_material_flow.md) ve [Katman Yüksekliği](../resolution/layer_height.md) ile ilgilidir. Normal duvarlardaki akış oranı ne kadar büyükse, duraklama mesafesi o kadar uzun olur.
* Köprüdeki duvar boyunca nozuldan çıkan akış hızı, bu da köprü duvarlarının [Köprü Duvarı Hızı](bridge_wall_speed.md) ve [Köprü Duvarı Akışı](bridge_wall_material_flow.md) ile ilgilidir. Köprü duvarlarındaki akış oranı ne kadar büyükse, duraklama mesafesi o kadar *kısa* olur.

Bu ayar, nihai uzunluğun üzerine çarpılan bir faktördür.

Bu duraklamanın amacı, nozul odası içindeki basıncı azaltmaktır. Bu gerekli çünkü nozul odası içinde kalan herhangi bir basınç, karşı basınç kaybolduğunda malzemenin katılaşmadan önce oldukça uzun bir mesafeye püskürmesine neden olacaktır. Bu malzemenin püskürtülmesi, sarkmaya neden olur. Temelde, sarkan hatlar, hala nozul içindeki geri kalan malzeme tarafından aşağı doğru itilir. Nozul odası içindeki basınç azaltıldığında, bu kuvvet de azalır ve daha az sarkma olur.

Duraklama miktarını arttırmak, köprü yazdırılması gereken zamana kadar nozul odası içindeki basıncı azaltır, bu da sarkma miktarını azaltır. Baskı daha doğru olacaktır. Ancak, duraklamanın miktarını fazla arttırmak, köprü yazdırılmadan hemen önce bir dönem eksik ekstrüzyona neden olacaktır. Bu eksik ekstrüzyon, baskının yan tarafında çok belirgin olacaktır.