Belirsiz Dış Katman Yoğunluğu
====
Bu ayar, duvar boyunca hareket ederken nozülün titreştiği frekansı yapılandırır. Daha yüksek yoğunlukta, nozül yüzey boyunca daha sık yukarı ve aşağı hareket eder. Buradaki "yoğunluk", nozülün yönlendirme değiştirebileceği noktaların yoğunluğunu ifade eder.

Daha yüksek yoğunlukta, kabartma daha ince olacak ve daha kaba bir dokuya yol açacaktır. Bu aynı zamanda baskı süresini önemli ölçüde etkiler. Daha düz, ancak kabarık bir dokuya sahip olmak için yoğunluğu azaltabilirsiniz.

Bulanık Cilt etkinleştirildiğinde, dış duvar tamamen titreşim hareketleri arasındaki düz çizgi segmentlerinden oluşur, orijinal yüzey yerine. Düşük yoğunlukta, bulanık cilt etkisi nedeniyle eğrisel yüzeylerin orijinal çözünürlüğünden daha düz olması mümkündür.

Algoritma kısıtlamaları nedeniyle, yoğunluk [Belirsiz Dış Katman Kalınlığı](magic_fuzzy_skin_thickness.md) çok yüksekse fazla artırılamaz.