Çapraz Dolgu Yoğunluğu Görüntüsü
====
Bu ayarda, dolgunun çeşitli yerlerdeki yoğunluğunu belirlemek için bir görüntü sağlayabilirsiniz. Görüntünün parlaklığına bağlı olarak dolgu yoğunluğu belirli yerlerde değişecektir. Bu ayar sadece [Çapraz 3D Dolgu Şekli](../infill/infill_pattern.md) ile çalışır, çünkü bu desen, hatları kesmeden yoğunluğunu ayarlayabilir ve böylece kesintili akışı ve azalan dayanıklılığı önler.

<!--screenshot {
"image_path": "cross_infill_density_image.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "cross_3d",
    "infill_sparse_density": 101,
    "cross_infill_density_image": "{root}/resources/articles/images/cross_infill_density_image_mask.png"
},
"colours": 32
}-->
![Nesne üzerinde dolgu yoğunluğu değişiyor](../images/cross_infill_density_image.png)
![Bu deseni oluşturmak için kullanılan görüntü dosyası](../images/cross_infill_density_image_mask.png)

Görüntünün yolunu yerel bir yol olarak sağlarsınız, örneğin Windows'ta `C:\Projects\3D Printing\infill_density.png` veya Unix'te `/home/ghostkeeper/3d_printing/infill_density.png`. Desteklenen dosya formatları JPG, PNG, TGA, BMP, PSD, GIF, HDR ve PIC'dir. Görüntü, nesnenin sınırlayıcı kutusuna tam olarak sığacak şekilde ölçeklendirilir. Görüntüdeki parlaklık dolgu yoğunluğunu belirler:
* Görüntü siyah ise, [Dolgu Yoğunluğu](../infill/infill_sparse_density.md) kullanılır.
* Görüntü beyaz ise, dolgu yoğunluğu yaklaşık olarak %0 olacaktır.

Dolgu yoğunluğu, [Dolgu Hattı Mesafesi](../infill/infill_line_distance.md) tarafından belirtilen değeri aşmayacaktır. Yalnızca azaltılabilir. Desen, yoğunluğunu azaltabileceği yerlerde sınırlıdır. İstenen dolgu yoğunluğunu mümkün olduğunca yakın taklit etmeye çalışsa da, bu her zaman mümkün olmayabilir. Dolgu yoğunluğu gerçekten düşük olduğunda, desenin dolgu yoğunluğunu ayarlaması için özellikle az fırsat olacaktır, bu da baskının görüntüyü çok gevşek bir şekilde takip etmesine neden olabilir. Yoğunluk seçimi ayrıca oldukça kantitatiftir. Yoğunluk sadece ikiye katlanabilir veya yarıya indirilebilir, ancak Cura, daha büyük bir etkili hassasiyet elde etmek için modeli [dither/titretir](https://en.wikipedia.org/wiki/Dither).

Bu ayar ile dolgunuzu çok özelleştirebilirsiniz. Çapraz Dolgu desenleri esnek malzemelerle en çok kullanılır, bu ayar belirli yumuşaklık veya sertlik sınırlamalarını elde etmek için kullanılır. Örneğin, daha iyi uyan bir ayakkabı tabanı veya belirli bölgelerde bükülmesi gereken mekanik bir cihaz yazdırabilirsiniz. 

**Bu ayar, Cura proje dosyaları üzerinden iyi aktarılmaz. Proje dosyası ayar değerini görüntü yolunu saklar, ancak görüntüyü saklamaz. Proje dosyası farklı bir bilgisayarda açıldığında, dolgu yoğunluğu görüntüsü muhtemelen geri yüklenmez.**