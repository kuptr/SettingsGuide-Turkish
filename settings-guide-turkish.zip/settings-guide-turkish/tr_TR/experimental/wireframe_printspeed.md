WP Speed
====
Bu ayar, Tel Baskı sürecinin her aşamasında baskı kafasının genel hareket hızını yapılandırır. Hız,  [upwards/yukarı](wireframe_printspeed_up.md), [downwards/aşağı](wireframe_printspeed_down.md) ve [horizontal/yatay](wireframe_printspeed_flat.md) hareketler için ayrı olarak ayarlanabilir, aynı zamanda [first layer/ilk katman](wireframe_printspeed_bottom.md) üzerindeki yatay hareketler için de.

Baskı hızını artırmak baskının daha az zaman almasını sağlar. Ancak bununla birlikte, titreşimleri artırabilir ve nozül hareketlerinin doğruluğunu azaltabilir. Tel Baskının güvenilirliği çoğunlukla bağlantıların gücüne bağlıdır. Hızı artırmak, çerçevedeki iki noktanın doğru şekilde birleşme olasılığını azaltır.