WP Top Delay
====
Bu ayarla, nozül yukarı doğru bir çizgi yazdırdıktan sonra bir süre duracak.

![Nozülün duraklayacağı konum](../images/wireframe_top_delay.svg)

Nozül yukarı doğru çizginin üstünde dururken, çizginin katılaşması için biraz zaman alır. Böylece nozül tekrar aşağı hareket etmeye başladığında çizginin sürüklenmesini önler.

Tabii ki, gecikme eklemek baskı süresini önemli ölçüde artırır. Durakladığında, nozülün sıcaklığı malzemeyi eritebilir ve üstte orada damlamaya başlar. Bu, filamentin tek bir hattının üstüne erimiş malzeme bir damla ekler, bu da o hattı biraz üst ağırlıklı yapar.

Bu ayar, baskıya tahmin edilmesi zor faktörler ekler. Hangi kesin gecikmenin malzemeniz, yazıcınız ve modeliniz için en uygun olduğu deneysel olarak belirlenmelidir. Genel olarak, makul ölçüde gecikmeyi artırmak, baskının güvenilirliği üzerinde olumlu bir etkiye sahip olabilir ancak baskı hızı üzerinde büyük negatif bir etkiye sahiptir.