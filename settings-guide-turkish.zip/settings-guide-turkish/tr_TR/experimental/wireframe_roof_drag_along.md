WP Roof Drag Along
====
Eriyik plastik yazdırılırken, nozülün malzemeyi extrüde ettikten sonra bile hareketi sırasında bir miktar malzemeyi sürüklemesi eğilimindedir. Tel Baskı modunda çatının ortasında havada yazdırılırken bu etki daha da güçlü olabilir. Bu ayar, yazdırmanın üst kısmındaki testere dişi desenin nozülle sürüklenen malzeme nedeniyle biraz daha derin içeriye doğru devam etmesini sağlar.

![İçeriye eklenen ek mesafe bu ayar tarafından yapılandırılır](../images/wireframe_roof_drag_along.svg)

Bu ayar, yazdırmanın üst tarafındaki testere dişi desenin iç uçlarının daha da içeri hareket etmesine neden olur. Uçlar, dışa doğru hareket eden çaprazların tam tersi yönde hareket ettirilir, içeriye doğru hareket eden düz çizgiler değil.

Bu ayarın dikkatli ayarlanmasıyla, amaçlanan sonuç yazdırmanın üst kısmına yerleştirilen konsantrik halkaya iç uçların daha iyi bağlanmasını sağlamaktır.