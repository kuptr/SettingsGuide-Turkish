WP Roof Inset Distance
====
Modelin üst yüzeyi gibi yüzey yatay olduğunda, bir dizi konsantrik halka ve aralarında bir testere dişi deseni ile bağlantılar yazdırılacaktır. Bu ayar, bu konsantrik halkalar arasındaki mesafeyi belirler.

![Tel çerçevenin üst yüzeyinin gözden geçirilmesi, içe gömme mesafesi ile işaretlenmiş](../images/wireframe_roof_inset.svg)

Her konsantrik içe gömme arasına bir testere dişi deseni çizilir. Testere dişi deseni sadece bu ayar tarafından belirtilen yüksekliğe sahip olmakla kalmaz, aynı zamanda testere dişi deseninin taban genişliği de vardır. Çapraz çizgi, en içteki halkada bu ayar tarafından belirtilen mesafeye göre düz çizginin tabanından bir mesafeye yerleştirilir. Bu nedenle, bu ayar, çatı deseninin genel yoğunluğunu gösterir, sadece içe gömme arasındaki mesafeyi değil.

Bu ayarı azaltmak, konsantrik içe gömmeleri birbirine daha yakın yerleştirir ve desenin genel yoğunluğunu artırır. Bu, malzemenin modelin üst yüzeyini geçerken köprü kurması gereken mesafeyi azaltır. Bu güvenilirliği artırır, her içe gömme arasında doğru bir bağlantı kurulma olasılığını artırır.