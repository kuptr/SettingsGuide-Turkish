Spaghetti Dolgu Basamağı/Adımı
====
Bu ayar, dolgu malzemesinin baskı sırasında periyodik olarak mı yoksa dolgunun üst kısmını kapatmadan hemen önce mi eklenip eklenmeyeceğini belirler.

Eğer malzeme baskı sırasında periyodik olarak eklenirse, daha iyi yayılmasını sağlar. Bu, dolgunun modelin alt kısımlarına doğru yayılmasına ve daha kaotik hale gelmesine olanak tanır, bu da dolgunun tüm yönlere eşit şekilde yumuşak olmasını sağlar.

Ancak dolgu malzemesinin daha sık ekstrüde edilmesi daha fazla zaman alacaktır. Malzeme akışının başlaması ve durması bir süre alır, bu da aşırı ekstrüzyona ve yetersiz ekstrüzyona neden olabilir. Eğer dolgu başka bir ekstrüder ile, örneğin bir döküm nozulu ile basılıyorsa, daha fazla araç değişimi gerektirecektir.