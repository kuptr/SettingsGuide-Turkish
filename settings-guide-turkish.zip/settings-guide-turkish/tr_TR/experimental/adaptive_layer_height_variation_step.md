Uyarlanabilir Katmanların Değişkenlik Adım Boyu
====
Eğer bir katmanın istenen katman kalınlığı bitişik bir katmandan çok farklıysa, nozuldaki akış hızında büyük bir fark olacaktır ve bu da aşırı ekstrüzyon veya yetersiz ekstrüzyona neden olabilir. Bu ayar, katman kalınlığı farkının kademeli bir değişim olmasını sağlayarak bunu önler. Bu ayarla, bitişik iki katman arasındaki katman kalınlığındaki maksimum değişimi belirleyebilirsiniz.

<!--screenshot {
"image_path": "adaptive_layer_height_variation_step_0_05.png",
"models": [{"script": "barn.scad"}],
"camera_position": [-108, -229, 118],
"settings": {
    "adaptive_layer_height_enabled": true,
    "adaptive_layer_height_variation_step": 0.05,
    "layer_height": 0.2
},
"colour_scheme": "layer_thickness",
"colours": 128
}-->
<!--screenshot {
"image_path": "adaptive_layer_height_enabled.png",
"models": [{"script": "barn.scad"}],
"camera_position": [-108, -229, 118],
"settings": {
    "adaptive_layer_height_enabled": true,
    "layer_height": 0.2
},
"colour_scheme": "layer_thickness",
"colours": 128
}-->
![Büyük bir adım boyutu, katman kalınlığında ani değişikliklere izin verir](../images/adaptive_layer_height_variation_step_0_05.png)
![Küçük bir adım boyutu, katman kalınlığındaki değişikliklerin daha yumuşak olmasını gerektirir](../images/adaptive_layer_height_enabled.png)

Bu ayarı azaltmak, katman kalınlığının daha kademeli geçiş yapmasını zorunlu kılar. Bu, baskı üzerinde çeşitli etkiler yapar:
* Daha düşük katman kalınlığına geçiş yaparken aşırı ekstrüzyon daha az olur, çünkü nozuldaki akış, daha düşük bir akış hızına ayarlanmak için biraz zamana sahip olur. Bu, yüzeyde yığın oluşumunu önler.
* Benzer şekilde, daha büyük katman kalınlığına geçiş yaparken yetersiz ekstrüzyon daha az olur, çünkü nozuldaki akış, daha yüksek bir akış hızına kademeli olarak ayarlanabilir.
* Bantlanma daha az görünür hale gelir. Farklı katman kalınlıklarına sahip alanlar hala farklı bir doku ve renge sahip olsa da, bu alanlar şimdi birbirinden daha uzak olacaktır, bu da görülmelerini zorlaştırır.
* Modelde ani bir geçişe neden olacak keskin bir açı olduğunda, topografi etkisi yeniden ortaya çıkar. Bunun nedeni, katman kalınlığının bu kadar hızlı ayarlanmasına izin verilmemesidir ve bu nedenle sığ yüzeyler için daha kalın katmanlar kullanılmalıdır.
* Benzer şekilde, modelde ani bir geçişe neden olacak keskin bir açı olduğunda, yazıcı gereksiz yere ince katmanlar oluşturacak ve baskı süresini gereksiz yere uzatacaktır.

Adaptif Katmanlar algoritmasının uygulanması nedeniyle, farklı bir katman kalınlığına kademeli geçiş, her zaman modelde geçişe neden olan açının *üstünde* gerçekleşir.