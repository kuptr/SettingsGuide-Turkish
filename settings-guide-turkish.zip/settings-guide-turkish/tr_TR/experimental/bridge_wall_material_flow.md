Köprü Duvarı Akışı
====
Bu ayar, köprü duvarlarının yazdırılması için ekstrüde edilen malzemenin miktarını ayarlar.

Malzeme miktarını azaltmak, bir boşluğu köprüleme durumunda duvarların çizgi genişliğini etkili bir şekilde azaltacaktır. Azalan çizgi genişliği ile, çizgilerin yüzey-kütle oranı daha büyük olur, bu da daha hızlı soğumalarını sağlar ve bu da sarkmaları önler.

Ancak, akış hızını çok fazla azaltmak, özellikle bir [Köprü Duvarı Hızı](bridge_wall_speed.md) ile birleştirildiğinde, akış hızında büyük bir değişikliğe neden olur. Gerçekte malzeme, akış hızı hızlandıkça ve yavaşladıkça istenildiği gibi akış hızını değiştiremeyecektir, bu da akış hızı yavaşladığında çizgilerin istenenden biraz daha kalın olmasına ve akış hızı hızlandığında istenenden biraz daha ince olmasına neden olur. Bu etkilerden ilki, bazı [Köprü Duvarı Tarama](bridge_wall_coast.md) ile telafi edilebilir, ancak bu dikkatli ayarlama gerektirir.