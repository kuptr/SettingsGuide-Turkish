WP Flat Flow
====
Bu ayar, tel çerçeve yapısındaki yatay halkaların akış hızını (ve böylece tellerin kalınlığını) yapılandırır. Bu, yukarı ve aşağı bağlantı tellerinin hızından ayrı olarak yapılandırılabilir.

![Farklı akış ayarlarının uygulandığı yerler](../images/wireframe_flow.svg)

Akışı artırmak telleri kalınlaştırır. Bu, yatay halkaların katılaştıktan sonra daha sağlam olmasını sağlar. Ancak aynı zamanda yatay halkaların ısıl kütlesini artırır, bu da katılaşmalarının daha uzun sürmesine neden olur. Bu, tellerin sarkmasına ve baskının güvenilirliğinin azalmasına yol açabilir, çünkü teller artık doğru şekilde bağlanmayabilir.