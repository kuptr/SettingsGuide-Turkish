Köprü Yüzey Alanı Yoğunluğu
====
Bu ayar, bir boşluğu köprülediğinde baskının alt tarafının yoğunluğunu kontrol eder. %100 yoğunlukta, çizgiler doğrudan bitişiktir. Daha düşük yoğunluklarda, çizgiler daha aralıklıdır.

<!--screenshot {
"image_path": "bridge_skin_density_100.png",
"models": [{"script": "bridge.scad"}],
"layer": 80,
"settings": {
    "bridge_settings_enabled": true,
    "bridge_skin_density": 100,
    "bridge_skin_material_flow": 100,
    "bridge_wall_material_flow": 100
},
"camera_position": [0, 18, 79],
"colours": 64
}-->
<!--screenshot {
"image_path": "bridge_skin_density_50.png",
"models": [{"script": "bridge.scad"}],
"layer": 80,
"settings": {
    "bridge_settings_enabled": true,
    "bridge_skin_density": 50,
    "bridge_skin_material_flow": 100,
    "bridge_wall_material_flow": 100
},
"camera_position": [0, 18, 79],
"colours": 64
}-->
![%100 yoğunlukta, çizgiler doğrudan birbirine bitiştirilir](../images/bridge_skin_density_100.png)
![%50 yoğunlukta, çizgiler arasında bir miktar boşluk bulunur](../images/bridge_skin_density_50.png)

Bu ayarı ayarlarken iki büyük etki devrede: Çizgiler arasındaki yapışma ve soğuma.

Cilt çizgilerini doğrudan birbirine bitiştirdiğinizde, birbirine yapışırlar. Bu, köprülenmiş boşluğun alt tarafının daha güzel görünmesini sağlar, çünkü yüzey dizme yerine sürekli olacaktır. Ayrıca, ikinci çizgi köprülenirken biraz birinci çizgiye dayanabilir, bu da köprünün biraz daha az sarkmasını sağlar.

Ancak başka bir etki daha vardır: soğuma. Çizgiler arası daha geniş bir boşluk olduğunda, daha hızlı soğuyacaklar ve sonra da o kadar sarkmayacaklar. Tabii ki, bu sadece fan açıkken geçerlidir, bu nedenle yüksek sıcaklıkta malzemeler için bu strateji çalışmayacaktır.

Hangi etkinin daha güçlü olduğu, malzemenin viskozitesine, ne kadar hızlı katılaştığına ve fan hızına bağlıdır. Her zaman biraz ayarlama gereklidir.

**Eğer [Köprü Yüzey Alanı Akışı](bridge_skin_material_flow.md) %100'den az ise, yoğunluk %100 olsa bile, çizgiler daha ince olduğu için aralarında bazı boşluklar olacaktır.**