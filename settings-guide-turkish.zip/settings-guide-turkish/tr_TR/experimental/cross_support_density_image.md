Destek için Çapraz Dolgu Yoğunluğu Görüntüsü
====
Bu ayar, destek üzerinde çeşitli yerlerde yoğunluğu belirleyen bir görüntü sağlamanıza olanak tanır. Görüntünün parlaklığına bağlı olarak destek yoğunluğu belirli yerlerde değişecektir. Bu ayar yalnızca [Çapraz deseni](../support/support_pattern.md) ile çalışır, çünkü bu desen, hatları kesmeden yoğunluğunu ayarlayabilir ve böylece kesintili akışı ve azalan dayanıklılığı önler.

<!--screenshot {
"image_path": "cross_support_density_image.png",
"models": [{"script": "wide_bridge.scad"}],
"camera_position": [0, 0, 120],
"layer": 79,
"settings": {
    "support_enable": true,
    "support_pattern": "cross",
    "support_infill_rate": 100,
    "cross_support_density_image": "{root}/resources/articles/images/cross_support_density_image_mask.png"
},
"colours": 32
}-->
![Destek yoğunluğu kenarlarda daha fazladır](../images/cross_support_density_image.png)
![Bu deseni oluşturmak için kullanılan görüntü dosyası](../images/cross_support_density_image_mask.png)

Görüntünün yolunu yerel bir yol olarak sağlarsınız, örneğin Windows'ta `C:\Projects\3D Printing\support_density.png` veya Unix'te `/home/ghostkeeper/3d_printing/support_density.png`. Desteklenen dosya formatları JPG, PNG, TGA, BMP, PSD, GIF, HDR ve PIC'dir. Görüntü, yazdırılan sahnenin sınırlayıcı kutusuna tam olarak sığacak şekilde ölçeklendirilir. Görüntüdeki parlaklık, destek yoğunluğunu belirler:
* Görüntü siyah ise, [Destek Yoğunluğu](../support/support_infill_rate.md) kullanılır.
* Görüntü beyaz ise, destek yoğunluğu yaklaşık olarak %0 olacaktır.

Destek yoğunluğu, [Destek Hattı Mesafesi](../support/support_line_distance.md) tarafından belirtilen değeri aşmayacaktır. Yalnızca azaltılabilir. Desen, yoğunluğunu azaltabileceği yerlerde sınırlıdır. İstenen destek yoğunluğunu mümkün olduğunca yakın taklit etmeye çalışsa da, bu her zaman mümkün olmayabilir. Destek yoğunluğu gerçekten düşük olduğunda, desenin destek yoğunluğunu ayarlaması için özellikle az fırsat olacaktır, bu da baskının görüntüyü çok gevşek bir şekilde takip etmesine neden olabilir. Destek yoğunluğu yüksek olduğunda ise, görüntü çok yakından takip edilecektir. Seçilen yoğunluk aynı zamanda oldukça kantitatiftir. Yoğunluk sadece ikiye katlanabilir veya yarıya indirilebilir, ancak Cura, daha büyük bir etkili hassasiyet elde etmek için deseni [dither/titreme](https://en.wikipedia.org/wiki/Dither).

Bu ayar ile destekleri çok özelleştirebilirsiniz. Eğer baskınızın belirli kısımları sarkmaya meyilli veya çok hassas bir şekilde yazdırılması gerekiyorsa, yoğunluğu yerel olarak artırarak bu bölgeleri daha iyi destekleyebilirsiniz, baskı süresinde büyük bir artış yapmadan veya destekleri çıkarmayı zorlaştırmadan.  

**Bu ayar, Cura proje dosyaları üzerinden iyi aktarılmaz. Proje dosyası ayar değerini görüntü yolunu saklar, ancak görüntüyü saklamaz. Proje dosyası farklı bir bilgisayarda açıldığında, yoğunluk görüntüsü muhtemelen geri yüklenmez.**