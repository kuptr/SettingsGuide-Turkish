Dilimleme Toleransı
====
Kesme toleransı, bir ağın belirli bir sayıda katmana bölünmesinin doğruluğuyla ilgili olarak nasıl başa çıkılacağını ayarlamanıza olanak tanır. Katmanların yüzeye ne kadar yakın olması gerektiğini, sınırlı olmasını veya yüzeyi tamamen içermesini seçebilirsiniz.

Ortalayıcı
----
![Ortalayıcı](../images/slicing_tolerance_middle.svg)

Ortalayıcı tolerans kullanıldığında, katmanlar mümkün olduğunca orijinal yüzeye yakın kalacaktır. Bu, katmanların bazen orijinal yüzeyin dışına taşabileceği ve bazen içine girebileceği anlamına gelir. Genel olarak, katmanların hacmi orijinal ağın hacmine çok yakın olacaktır.

Ortalayıcı tolerans elde etmek için, Cura her katmanın kalınlığının yarısında bir kesit hesaplar. Kesitin içinde kalan her şey, katmanın bir parçası olarak kabul edilir.

Kapsayıcı
----
![Kapsayıcı](../images/slicing_tolerance_inclusive.svg)

Kapsayıcı tolerans kullanıldığında, katmanlar *en azındant* tüm orijinal hacmi içerecektir. Yüzey eğimli olduğunda, katmanlar biraz dışarıya taşacaktır. Katmanların toplam hacmi genellikle orijinal ağın hacminden fazla olacaktır.

Kapsayıcı tolerans elde etmek için, Cura her katmanın yüksekliğinin üstünde ve altında kesitler hesaplar. Bu kesitlerin *herhangi* birinde olan yüzeyler, o katmanın bir parçası olarak kabul edilir. İki kesit arasına düşen küçük detaylar hala ihmal edilir, çünkü bir katman kalınlığından daha küçüktür.

Dışlayıcı
----
![Dışlayıcı](../images/slicing_tolerance_exclusive.svg)

Dışlayıcı tolerans kullanıldığında, katmanlar orijinal hacmin içinde kalacaktır. Yüzey eğimli olduğunda, katmanlar orijinal hacminden biraz daha küçük olacaktır. Katmanların toplam hacmi genellikle orijinal ağın hacminden az olacaktır.

Dışlayıcı tolerans elde etmek için, Cura her katmanın yüksekliğinin üstünde ve altında kesitler hesaplar. Sadece bu *iki* kesitin her ikisinde de olan yüzeyler, o katmanın bir parçası olarak kabul edilir.

Kullanım
----
Bu ayarın adı, işlevsel etkisi yerine niyet edilen kullanımına göre verilmiştir. Birbiri üzerinden kayması gereken birden fazla parçanız varsa, katmanların teorik şekli fiziksel olarak tam uymayı engelleyebilir. Bu tür bir durumda, ayarı Dışlayıcı olarak ayarlayarak katmanların orijinal hacim sınırları içinde kalmasını sağlayabilirsiniz. Eğilme, sarkma ve benzeri deformasyon etkileri dışında, bu parçaların birbirine tam olarak uymasını ve birbirinden kaymasını garanti eder.

Ancak gerçekte, bunu engelleyen başka etkiler her zaman mevcuttur. Uygulamada, bu ayar, eğimli yüzeyler arasında biraz daha fazla veya az tolerans elde etmek için kullanılabilir, yukarıdaki görsellerde görüldüğü gibi.