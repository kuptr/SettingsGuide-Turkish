Köprü Ayarlarını Etkinleştir
====
Modelinizin her iki tarafını da destekleyen bazı taşması olan alanları algıladığında, Cura bunu tespit edecek ve daha iyi basmak için taşan cilt alanını değiştirecektir. Bu ayar etkinleştirilmişse, bu köprüleme alanlarının tespitini ve sonuçta ortaya çıkan davranışı ayarlayabilirsiniz, böylece daha iyi köprü yapabilirsiniz.

<!--screenshot {
"image_path": "bridge_settings_enabled_default.png",
"models": [
    {
        "script": "rack_straight.scad",
        "scad_params": ["length=40"]
    }
],
"camera_position": [0, 74, -137],
"colours": 32
}-->
<!--screenshot {
"image_path": "bridge_settings_enabled_enabled.png",
"models": [
    {
        "script": "stairwell.scad",
        "scad_params": ["steps=4", "width=10", "height=20"]
    }
],
"layer": 275,
"settings": {
    "bridge_settings_enabled": true
},
"camera_position": [-12, 28, 63],
"colours": 64
}-->
![Bir köprü tespit edildiğinde, cilt çizgileri boşluğu en iyi şekilde köprülemek üzere yönlendirilir](../images/bridge_settings_enabled_default.png)
![Köprü ayarları etkinleştirildiğinde, köprüleme çizgileri farklı ayarlarla yazdırılır](../images/bridge_settings_enabled_enabled.png)

Normalde, Cura oldukça basit bir köprüleme tekniği kullanır. Cura, çoklu taraflarca desteklenen taşan cilt alanlarını tespit eder. Bu cilt çizgilerinin [Üst/Alt Çizgi Yönleri](../top_bottom/skin_angles.md) bu alanları otomatik olarak köprülemek için ayarlanır. Bu, taşan alanın en büyük bölümünün birden fazla taraftan desteklenmesini sağlar ve baskı kalitesini artırır.

Ancak bu ayar etkinleştirildiğinde, bu davranışı daha hassas şekilde gereksinimlerinize göre ayarlayabilirsiniz. Bu, aşağıdakileri ayarlamanızı sağlar:
* baskı hızı
* akış hızı
* yoğunluk (infill yoğunluğu gibi, ancak cilt çizgileri için)
* fan hızı
* duvarlar için coasting de dahil olmak üzere

Bu ayarlar, köprüdeki bir boşluğu köprüleyen cilt için ayrı ayrı ayarlanabilir. [Köprüde Birden Fazla Katman Var](bridge_enable_more_layers.md) etkinleştirildiyse, bunlar ayrıca köprünün üstündeki ikinci ve üçüncü katmanlar için de ayrı ayrı ayarlanabilir. Ayrıca, [Köprü Yüzey Alanı Destek Eşiği](bridge_skin_support_threshold.md) ve [Minimum Köprü Duvarı Uzunluğu](bridge_wall_min_length.md) gibi ayarları da ayarlayarak hangi baskı parçalarının köprüleme alanları olarak kabul edileceğini ayarlayabilirsiniz.

Köprüleme ayarlarını etkinleştirerek, baskınızda köprülerin nasıl ele alınacağı konusunda daha fazla kontrol elde edersiniz. Köprüleme parametrelerini çok iyi ayarlayarak, taşmalarınızın kalitesini önemli ölçüde artırabilir ve dikey yönde hassasiyeti artırabilirsiniz. Tek dezavantajı, köprü ayarlarını yazıcınıza ayarlamazsanız, baskının kötüleşebileceği olasılığının eşit derecede olmasıdır.