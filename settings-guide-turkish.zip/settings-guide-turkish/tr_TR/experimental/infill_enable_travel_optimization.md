Dolgu Hareket Optimizasyonu
====
Bu ayarı etkinleştirmek, baskınızdaki seyahat süresini hafifçe azaltabilir. Seyahat hareketlerinin uzunluğunu kısaltarak baskı biraz daha hızlı ilerler ve nozul biraz daha az akar. Ancak modeli dilimlemek daha fazla zaman alabilir.

Normalde Cura, iç dolgu hatlarının çizilme sırasını oldukça basitçe optimize eder. Her hat çizildikten sonra, Cura bir sonraki en yakın hatı çizmek için bakar ve onu çizer. Ancak bazı alışılmadık, karmaşık şekiller için, nozul [Tarama Modu](../travel/retraction_combing.md) nedeniyle bir sapma yapmak zorunda kalabilir ve bu durumda bir sonraki iç dolgu hattına olan yol oldukça uzun olabilir. Basitçe, Cura bu mesafeyi yanlış hesaplar ve kısa olanı tercih etmek yerine uzun bir seyahat hareketi seçebilir. Bu ayar etkinleştirildiğinde, mesafe hassas bir şekilde hesaplanır ve daha iyi bir seçim yapılabilir.

Bu ayar genellikle dilimleme süresini çok fazla etkilemez. Ancak çok sayıda küçük parçadan oluşan karmaşık baskılarda (en yararlı olduğu yer), dilimleme süresini büyük ölçüde artırabilir.