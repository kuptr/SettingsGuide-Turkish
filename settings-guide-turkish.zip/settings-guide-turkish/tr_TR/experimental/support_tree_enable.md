Ağaç Desteği
====
Ağaç destek, modelin normal destek tekniğinden farklı bir yaklaşım sunar. Ağaç destekte, desteklenmesi gereken parçalara doğru genişleyen, tabanı küçük bir yapı tabakasında başlayan dallı bir yapı oluşturulur.

<!--screenshot {
"image_path": "support_structure_tree.png",
"models": [{"script": "duct.scad"}],
"camera_position": [56, 127, 60],
"settings": {
    "support_enable": true,
    "support_structure": "tree",
    "support_tree_collision_resolution": 0.05
},
"colours": 32
}-->
![Aşağısalımı destekleyen ağaç biçimli yapı](../images/support_structure_tree.png)

Ağaç destek, aşağısalımlara doğru büyürken engellerden kaçınabilir. Mümkünse, ağaç, desteklerin oturduğu yüzeyi çizmezden korumak için yapım tabakasından yukarı doğru büyür. Bu mümkün değilse, ağaç, zamanı ve malzeme kullanımını en aza indirmek için mümkün olduğunca aşağısalıma yakın bir şekilde modelin yüzeyinde dinlenecektir. Ağaç desteklerin dalları, [Maksimum Dal Açısı](../support/support_tree_angle.md) ile sınırlıdır, böylece kendi başlarına çok dik bir aşağısalım oluşturmazlar. Bu, engellerin etrafında büyüme yeteneğini sınırlar ve ayrıca gövdelerin dallanmaya başlayacağı yüksekliği belirler.

Ağaç destek varsayılan olarak boştur. Ancak ağacın dalları tarafından çevrilen alan için hala normal destek ayarları geçerlidir. Özellikle, [Destek Yoğunluğu](../support/support_infill_rate.md), desteklere daha fazla yapısal dayanıklılık sağlamak için kullanılabilir. Ağaç destek doğası gereği oldukça kaba olduğundan, genellikle amacı için yeterli dayanıklılığa sahiptir.

Ağaç destek, normal desteklere göre birçok avantaja sahiptir:
* Ağaç destek genellikle normal destekten çok daha az malzeme kullanır. Tipik olarak malzeme kullanımının %25 ila %50'si arasındadır. Bu, zaman ve malzeme maliyetinde büyük tasarruf sağlar.
* Aynı malzeme ile basıldığında, aşağısalımların görünümü genellikle daha iyidir.
* Ağaç destek, normal destekten daha kolay çıkarılır.
* Ağaç destek, modelin etrafındaki yapım tablasına doğru uzanabilme yeteneği nedeniyle, yüzeyde normal destekten daha az iz bırakır.

Ancak bununla birlikte bazı dezavantajları vardır:
* Ağaç destek dilimlemesi normal destekten çok daha uzun sürer. Özellikle yüksek modellerle sabır gereklidir.
* En küçük dallar basıldığında akışta çok fazla kesinti olur, bu nedenle PVA veya esnek malzemeler gibi zor ekstrüzyon malzemeleriyle basmak için uygun değildir.
* Ağaç destek, bazı mekanik modelleri desteklemekte çok iyi çalışmaz. Özellikle düz veya eğimli aşağısalımları desteklemek için yeterli sayıda dal yerleştirmez.

Ağaç destek, normal destekle birlikte aynı anda etkinleştirilebilir, ancak genellikle tercih edilmez. İki tür destek birbirini keser ve aşırı ekstrüzyona neden olabilir.