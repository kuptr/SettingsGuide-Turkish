Spaghetti Dolgu
====
Bu ayar etkinleştirildiyse, Cura, bir üst katmanda birden fazla katmanın tüm dolgusunu aynı anda ekstrüde eder. Bu, [Dolgu Katmanı Kalınlığı](../infill/infill_sparse_thickness.md) şeklindeki bir aşırı formu sunar, ancak dolgunun sertliğini koruma amacı taşımaz. Aşırı miktarda ekstrüzyonla başa çıkma işlevselliğine sahiptir.

Bu özellik normal malzemeler için işlevsel değildir. Genellikle ya normal dolgu desenlerinin dayanıklılığını istersiniz ya da dolguyu tamamen dışarıda bırakırsınız. Ancak iki kullanım durumu vardır.

Kullanım Durumları
----
Esnek malzemelerle, bu teknik çok yumuşak dokular üretebilir. Spaghetti dolgu genellikle birbirine sıkıca yapışmayan gevşekçe yerleştirilmiş halkalar oluşturur. Bu halkalar her yönde eşit derecede yumuşaktır. Bu etkiyi elde etmek için dolgu yoğunluğu çok düşük olmamalıdır, aksi takdirde tüm spagetti baskının altında toplanabilir. Hattın genişliğine ve katman yüksekliğine bağlı olarak, [akış yoğunluğu](spaghetti_flow.md) %30 ile %60 arasında olması önerilir. Sonuç, her yönde eşit derecede sert ve oldukça yumuşak bir dolgu olacaktır.

Spaghetti dolgunun diğer uygulaması dökümdür. Belirli yerlerde döküm yapabilen bir yazıcınız varsa, bu özellik kontrol edilmiş malzeme birikimleri ile modelinizi neredeyse eşit şekilde doldurmak için kullanılabilir. Bu durumda, döküm malzemesinin büzülme/genleşme oranına bağlı olarak, [akış yoğunluğu](spaghetti_flow.md)'nun yaklaşık olarak %100 olması gerekebilir.

Diğer ayarları spagetti dolgu için ayarlama
----
Bu uygulamaların her ikisi de dolgunuzun çok özel bir şekilde işlenmesini gerektirir. İhtiyacınıza göre ayarlamak isteyeceğiniz bazı ayarlar şunlardır:
* [Baskı Dolgu Hızı](../speed/speed_infill.md) büyük ölçüde azaltmanız gerekecek. Nozül aynı anda 10 katmanın dolgusunu ekstrüde etmek zorunda kalıyorsa, basım hızını en az 8 katına kadar azaltmanız gerekecek.
* [Dolgu Katmanı Kalınlığı](../infill/infill_sparse_thickness.md) katman yüksekliğine eşit olarak ayarlayın.
* [Yazdırma Sıcaklığı](../material/material_print_temperature.md) biraz artırın (dolgu basacak ekstrüder için). Bu, malzemenin düzgün bir şekilde nozülden akmasını sağlar ve daha hızlı ekstrüzyona olanak tanır.
* Yapıyı rastgele olarak dağıtmak için [Z Dikiş Hizalama](../shell/z_seam_type.md)'yı "Gelişigüzel" olarak ayarlayın.

**Cura'nın katman görünümünde, dolgu çok kalın çizgiler olarak görünecektir. Bu, Cura'nın malzemenin aynı katmanda kalmasını ve orada yayılmasını varsaydığı içindir. Gerçekte ise malzeme aşağı düşecektir.**

**Spagetti dolgu kullanılırken, [Dolgu Hattı Genişliği](../resolution/infill_line_width.md) ayarının artık bir etkisi yoktur. Çizgi genişliği, [Dolgu Hattı Mesafesi](../infill/infill_line_distance.md) ve [spaghetti akışı](spaghetti_flow.md) ayarlarının gereksinimlerini karşılamak üzere ayarlanır.**