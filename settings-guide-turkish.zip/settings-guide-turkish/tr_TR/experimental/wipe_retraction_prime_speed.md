Sürme Geri Çekme Sırasındaki Çalışmaya Hazırlama Hızı
====
Bu ayar, silme işleminden sonra malzemenin ne kadar hızlı ilave edileceğini yapılandırır. Bu, normal [Geri Çekme Sırasındaki Astar Hızı](../travel/retraction_prime_speed.md)ndan ayrı olarak yapılandırılabilir.

Malzemeyi daha yavaş bir şekilde ilave etmek, silme işleminden sonra nozülün indiği yerde küçük bir topak oluşmasına neden olabilir. Ancak, malzemeyi silme işlemi için yapılan uzun bir geri çekmeden sonra düzgün bir şekilde akıtmak için daha yavaş ilave etmek gerekebilir.