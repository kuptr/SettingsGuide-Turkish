Akış Sıcaklık Grafiği
====
Daha hızlı baskı yaparken, malzemenin nozül açıklığından daha hızlı akması için biraz daha yüksek bir sıcaklıkta baskı yapmak en iyisidir. Bu, termoplastiği daha akışkan hale getirir ve malzemenin nozül açıklığından daha hızlı akmasını sağlar. [Auto Temperature](material_flow_dependent_temperature.md) etkinleştirildiğinde, bu ayar her akış hızı için malzemenin hangi sıcaklıkta basılması gerektiğini belirtir. Akış hızı, her katman için ortalama olarak hesaplanır ve o katman için bir sıcaklık belirlemek için kullanılır.

Akış hızı, saniyedeki kübik milimetre cinsinden hesaplanır ve her katman için ortalama alınır. Sıcaklık derece Celsius cinsindendir. Bu ayarın değeri,  `[<akış hızı>, <sıcaklık>]` biçimindeki her bir koordinattan oluşan virgülle ayrılmış bir liste olmalıdır.

Bu ayarın amacı, baskı sırasında büyük akış değişiklikleri varsa daha iyi bir baskı kalitesi elde etmektir; aşırı veya yetersiz ekstrüzyonu azaltır. Bu durum genellikle cilt ve iç dolgu arasındaki sınırda ortaya çıkar. Cilt genellikle iç dolgudan çok daha yavaş bir şekilde basılır, bu yüzden iç dolgu baskısı sırasında malzemenin doğru şekilde ekstrüde edilebilmesi için bu katmanlar biraz daha yüksek bir sıcaklıkta basılmalıdır.

Birçok yazıcı için, yazıcının nozülünde sıcaklığı düzenleyen PID regülatörü, kısa sürede çok sayıda sıcaklık değişikliği olduğunda aşırı tepki gösterme eğilimindedir. Bu durum, bu ayar kullanıldığında baskı sıcaklığının vahşi bir şekilde doğru olmamasına neden olabilir.

**Bu ayar şu anda Cura'nın arayüzünde görünür değil ve etkinleştirilemez.**