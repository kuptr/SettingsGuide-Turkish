Köprüde Birden Fazla Katman Var
====
Eğer bu ayar etkinleştirilirse, köprünün üzerindeki daha yüksek katmanlardaki yüzey de ayarlanacaktır. Böylece köprünün üzerindeki ikinci ve üçüncü katmanın akış hızını, hızını, yoğunluğunu ve fan hızını dikkatlice ayarlayabilirsiniz.

Köprüyü geçen ilk katman, köprünün nasıl görüneceği konusunda en etkili olanıdır. O katmanda herhangi bir sarkma olursa, onu tutacak bir şey olmayacaktır. İkinci ve üçüncü katmanlarda ise altındaki malzeme, üstündeki katmanın ağırlığının (bir kısmını) tutabilir. Yine de, üstteki katmanları ayarlamak bazı olumlu etkiler oluşturabilir.
* Yoğunluğu azaltmak, alt katmanda dinlenecek malzemenin ağırlığını azaltabilir.
* Fan hızını artırmak, malzemenin daha az sarkmasını sağlar ve alt katmana daha az ağırlık bindirir.
* Baskı hızını azaltmak, fan hızını artırmaya benzer bir etki yapar, çünkü malzemenin üzerinde fanların daha fazla üflemesine olanak tanır.
* Akışı azaltmak, malzemenin ağırlığını azaltabilir ve soğutmanın etkinliğini artırabilir.

Ancak, her bir ayarın dengeleyici bir rolü olduğu başka etkiler de vardır. İkinci ve üçüncü katmanlar için köprü ayarlarını etkinleştirmek daha hassas ayarlama yapılmasına olanak tanır, ancak iyi bir sonuç elde etmek için daha fazla deneme gerektirir.