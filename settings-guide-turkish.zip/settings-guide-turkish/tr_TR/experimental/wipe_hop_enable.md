Sürme Z Sıçraması
====
Bu ayar, silme işlemi sırasında Z hop yapılmasını sağlar. Bu, normal [Geri Çekildiğinde Z Sıçraması](../travel/retraction_hop_enabled.md)'larından ayrı olarak yapılandırılabilir.

Silme işlemi, yapı platformunun kenarına kadar giden iki uzun seyahat hareketini içerir. Bu seyahat hareketleri sırasında yazıcı kafa hızlanma için çok fazla zamanı olduğundan dolayı oldukça hızlı hızlanabilir. Yüksek hızlarda, yazıcı kafasının yanlışlıkla daha önce yazdırılmış parçaları devirmesi riski artabilir. Bu nedenle, normal baskı işlemi için Z hop'u etkinleştirmeseniz bile, silme işlemi için Z hop'u etkinleştirmek isteyebilirsiniz.

Bu Z hop işlemi, [Sadece Yazdırılan Parçalar Üzerindeki Z Sıçraması](../travel/retraction_hop_only_when_collides.md) veya arada yazdırılmış parçalar varsa bile gerçekleştirilir.