WP Horizontal Printing Speed
====
Bu ayar, tel çerçevenin yatay halkalarını yazdırırken nozülün yatay olarak ne kadar hızlı hareket edeceğini belirtir. Yatay çizgilerin hızı, tel baskı hızının geri kalanından ayrı olarak yapılandırılabilir.

![Farklı Tel Baskı hızlarının uygulandığı yerler](../images/wireframe_printspeed.svg)

En alttaki yatay katman, [Bottom Speed/Alt Baskı hızında](wireframe_printspeed_bottom.md) yazdırılacaktır. Bu ayrı olarak yapılandırılabilir.

Daha yavaş yazdırmak daha fazla zaman alır, ancak malzemenin katılaşması için daha fazla zaman sağlar. Bu, malzemenin köprüleme kapasitesini artırır ve baskının daha güvenilir ve sonunda daha iyi görünmesini sağlar.