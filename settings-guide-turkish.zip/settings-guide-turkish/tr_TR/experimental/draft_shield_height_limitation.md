Cereyan Kalkanı Sınırlaması
====
Cereyan kalkanı, modelin tam yüksekliğine kadar veya belirli bir yüksekliğe kadar basılabilir. Bu ayar, Cereyan kalkanının ne kadar yükseğe kadar gideceğini seçmenizi sağlar.

<!--screenshot {
"image_path": "draft_shield_enabled.png",
"models": [{"script": "headphone_hook.scad"}],
"camera_position": [-56, 139, 305],
"settings": {
    "draft_shield_enabled": true
},
"colours": 32
}-->
<!--screenshot {
"image_path": "draft_shield_height_limitation.png",
"models": [{"script": "headphone_hook.scad"}],
"camera_position": [-56, 139, 305],
"settings": {
    "draft_shield_enabled": true,
    "draft_shield_height_limitation": "limited",
    "draft_shield_height": 20
},
"colours": 32
}-->
![Cereyan kalkanı, modelin tam yüksekliği kadar yüksektir](../images/draft_shield_enabled.png)
![Cereyan kalkanı, maksimum 20mm yüksekliğe sınırlıdır](../images/draft_shield_height_limitation.png)

Baskının alt tarafı genellikle sıcaklık dalgalanmalarına en duyarlı olan kısımdır. Eğer oda soğuksa, burada çoğu warp oluşur ve bu, baskının yapı platformundan ayrılmasına neden olabilir. Bu ayar ile, cereyan kalkanının yüksekliğini belirli bir yüksekliğe sınırlayabilirsiniz. Bu, zaman ve malzeme tasarrufu sağlayabilir. Cereyan kalkanı, baskının alt tarafını korumaya devam edecek ve ayrıca sıcak havanın yükselmesi nedeniyle oluşan konveksiyonu engelleyecektir (belirli bir ölçüde).

Cereyan kalkanı, nesnenin kendisinden daha yüksek basılamaz.