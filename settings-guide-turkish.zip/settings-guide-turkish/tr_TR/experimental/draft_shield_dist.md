Cereyan Kalkanı X/Y Mesafesi
====
Bu ayar, cereyan kalkanının baskıdan ne kadar uzakta olacağını yapılandırır.

Cereyan kalkanının baskıdan ne kadar uzakta olduğu, cereyan kalkanının içindeki sıcaklığı sabit tutma etkinliğini etkiler. Baskı etrafında daha fazla hava akacaktır, bu nedenle baskı hava akımlarına karşı daha az korunaklı olacaktır.

Ancak cereyan kalkanını baskıdan daha uzakta basmak, baskınızın soğuması üzerinde olumlu bir etkisi olabilir, çünkü baskı kafasındaki fanların baskınıza doğru doğru şekilde üflemesine izin verir.

Ayrıca, cereyan kalkanını nesneden daha uzağa yerleştirmek daha fazla alan alacaktır. Nesnenizde inşa hacminizin izin verdiği mesafeden daha uzakta basamazsınız.