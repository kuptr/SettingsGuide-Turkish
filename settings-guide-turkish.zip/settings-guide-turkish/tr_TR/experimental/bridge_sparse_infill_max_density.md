Maksimum Köprü Seyrek Dolgu Yoğunluğu
====
Eğer çok düşük bir doluluk yoğunluğuyla baskı yaparsanız, üst cilt sarkma eğilimindedir, bu da genellikle baskının üst tarafında [yastıklanmaya](../troubleshooting/pillowing.md) ve genel olarak düzensiz yüzeylere neden olur. İsteğe bağlı olarak, köprüleme teknikleri üst cilde de uygulanabilir. Bu ayar, köprüleme tekniğinin uygulanmaya başlayacağı doluluk oranını yapılandırır.

<!--screenshot {
"image_path": "bridge_sparse_infill_max_density.png",
"models": [
    {
        "script": "stamp.scad",
        "transformation": ["scale(0.5)"]
    }
],
"layer": 108,
"settings": {
    "bridge_settings_enabled": true,
    "bridge_sparse_infill_max_density": 100
},
"camera_position": [58, 27, 104],
"colours": 64
}-->
![Cilt doluluk üzerinde köprü yapıyor](../images/bridge_sparse_infill_max_density.png)

Bu ayar, profillerin tek bir değer içermesine izin vermek için bir eşik olarak yapılandırılmıştır. Kullanıcı sürekli doluluk yoğunluğunu ayarlarken, cilt için köprüleme otomatik olarak etkinleştirilecek veya devre dışı bırakılacaktır.

Üst cilt için köprüleme genellikle çok düşük doluluk oranlarında daha düz bir üst yüzey üretir. Ancak bunun kullanılması durumunda, en yüksek katmanlarda köprüleme tekniğinin uygulanmadan yüzeyi uygun şekilde kapatmak için yeterli [Üst Katmanlar](../top_bottom/top_layers.md) olduğundan emin olun. Özellikle azaltılmış [Köprü Üçüncü Yüzey Alanı Akışı](bridge_skin_material_flow_3.md) ile köprüleme tekniği yüzeyi tam olarak kapatmaz. Üst ciltte yeterli katman yoksa, baskıda delikler oluşur ve dayanıklılık tehlikeye girer.