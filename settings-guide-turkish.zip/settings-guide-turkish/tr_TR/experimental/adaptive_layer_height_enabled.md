Uyarlanabilir Katmanların Kullanımı
====
Adaptif Katmanlar, modelin yüzey özelliklerine göre baskı süresini ve kalitesini optimize etmek için baskının katman kalınlığını yerel olarak ayarlar. Katmanlar, eğimlerin sığ olduğu yerlerde daha ince, duvarların dik olduğu yerlerde daha kalın hale getirilir. Bunun amacı, mümkün olan yerlerde hızlı baskı yapmak, ancak gerekli yerlerde ayrıntılı baskı yapmaktır.

<!--screenshot {
"image_path": "adaptive_layer_height_enabled.png",
"models": [{"script": "barn.scad"}],
"camera_position": [-108, -229, 118],
"settings": {
    "adaptive_layer_height_enabled": true,
    "layer_height": 0.2
},
"colour_scheme": "layer_thickness",
"colours": 128
}-->
!["Katman kalınlığı" renk şeması ile, ince katmanların mavi ve kalın katmanların sarı renkle gösterildiğini görebilirsiniz.](../images/adaptive_layer_height_enabled.png)

Katman yüksekliği, katmanların kenarları arasındaki yatay mesafe sabit kalacak şekilde ayarlanır. Sığ yüzeyler küçük bir dikey yer değiştirme ile büyük bir yatay yer değiştirmeye neden olur, bu nedenle yatay yer değiştirmeyi sabit tutmak için küçük bir dikey yer değiştirme yapılır. Dik yüzeylerde, büyük bir dikey yer değiştirme ile küçük bir yatay yer değiştirme olur, bu nedenle yatay yer değiştirmeyi sabit tutmak için büyük bir dikey yer değiştirme yapılır. Böylece katmanların topografya etkisi sabit tutulur. İki bitişik katman arasındaki maksimum mesafe, [Uyarlanabilir Katman Topografisi Boyutu](adaptive_layer_height_threshold.md) ayarı mesafesinde sabit tutulur.

Eğer modelin aynı yükseklikte hem sığ hem de dik yüzeyleri varsa, katman kalınlığı, katman kalınlıklarının daha küçük olanı olarak alınır. Bu bazen katman yüksekliğinin gereksiz yere küçük olmasına neden olur çünkü yanında yatay bir yüzey vardır. Bu, yukarıdaki ekran görüntüsünde de sol taraftaki silonun yarı yüksekliğinde görülebilir.

Adaptive Layers, baskı kalitesini artırmak için büyük ölçüde kısıtlanmıştır. Katman yüksekliği, orijinal [Katman Yüksekliği](../resolution/layer_height.md) ayarından belirtilen [Uyarlanabilir Katmanların Azami Değişkenliği](adaptive_layer_height_variation.md) kadar sapmasına izin verilmez. İki bitişik katman arasında katman yüksekliği farkı belirli bir [Uyarlanabilir Katmanların Değişkenlik Adım Boyu](adaptive_layer_height_variation_step.md) fazla olamaz. Bu, katman kalınlığının bir katmandan diğerine aniden yarıya inmesi yerine kademeli olarak geçiş yapmasını sağlar.

Adaptive Layers, baskı kalitesinde bir kayıp olmadan veya bazı durumlarda kaliteyi artırarak baskı süresini önemli ölçüde azaltabilir. Katman kalınlığını ayarlamanın etkisi büyüktür. Çoğu durumda, modelin dik olduğu yerlerde daha kalın katmanlar kullanılarak baskı süresi büyük ölçüde azaltılacaktır. Katmanlar yatay olarak daha yakın aralıklı olduğundan [topography efekti](../troubleshooting/topography.md) de azalır.

Ancak bu özellik bazı sorunları da beraberinde getirebilir.
* Katman yüksekliğini değiştirirken, tipik olarak diğer bazı ayarların da ayarlanması gerekir, örneğin nozul sıcaklığı gibi. Adaptif Katmanlar bu ayarları otomatik olarak ayarlamaz. Bu, daha düşük baskı sıcaklığında daha iyi sonuç verecek çıkıntılar için baskının optimal olmamasına neden olabilir.
* Katman yüksekliği, katmanın küçük bir bölümündeki küçük bir özellik için tüm katman boyunca değiştirilirse, katmanın geri kalanında bantlanma görülebilir.
* Bu işlemle dikey mesafeler de istemeden ayarlanır. Bu, baskı kalitesi üzerinde olumsuz bir etki yaratabilir. Örneğin, [Üst/Alt Kalınlık](../top_bottom/top_bottom_thickness.md) tipik olarak daha düşük hale gelir çünkü Cura [Üst Katmanlar](../top_bottom/top_layers.md) ayarını doğru kabul eder ve katmanlar incelir. Bu, kabarcıklanmaya neden olabilir. Artık doğru olmayabilecek etkilenen ayarlar şunları içerebilir:
  * [Üst Kalınlık](../top_bottom/top_thickness.md)
  * [Alt Kalınlık](../top_bottom/bottom_thickness.md)
  * [Genişleme için Maksimum Yüzey Açısı](../top_bottom/max_skin_angle_for_expansion.md)
  * [Aşamalı Dolgu Basamak Yüksekliği](../infill/gradual_infill_step_height.md)
  * [Aşamalı Destek Dolgusu Basamak Yüksekliği](../support/gradual_support_infill_step_height.md)
  * [Dolgu Katmanı Kalınlığı](../infill/infill_sparse_thickness.md)
  * [Destek Dolgusu Katmanı Kalınlığı](../support/support_infill_sparse_thickness.md)
  * [Destek Z Mesafesi](../support/support_z_distance.md)
  * [Destek Tavanı Kalınlığı](../support/support_roof_height.md)
  * [Destek Zemini Kalınlığı](../support/support_bottom_height.md)
  * [Destek Çıkıntı Açısı](../support/support_angle.md)
  * [Destek Merdiveni Basamak Yüksekliği](../support/support_bottom_stair_step_height.md)
  * [Direk Tavanı Açısı](../support/support_tower_roof_angle.md)
  * [Sızdırma Kalkanı Açısı](../dual/ooze_shield_angle.md)
  * [Maksimum Model Açısı](../experimental/conical_overhang_angle.md)