WP Flat Delay
====
Tel çerçevenin yatay halkalarını yazdırırken, nozül her hat parçasında bir an için tamamen duracak. Bu ayar, bu duraklamanın süresini yapılandırır. Duraklama, yatay halkanın altındaki testere dişi desene bağlandığı noktada tam olarak yer alır.

![Nozülün duraklayacağı konumlar](../images/wireframe_flat_delay.svg)

Tamamen durarak bir an için durakladığında, nozülün durakladığı noktalarda malzemenin akması sonucu küçük bir damlacık oluşur. Nozül odasındaki malzeme akışının basıncı aynı zamanda yatay halkayı hafifçe aşağı doğru iter. Bu, halkayı altındaki testere dişi desene ekstra sağlam bir şekilde bağlar.

Bu duraklama, toplam baskı süresine önemli ölçüde eklenir. Nozülün duraklayacağı birçok nokta bulunmaktadır.