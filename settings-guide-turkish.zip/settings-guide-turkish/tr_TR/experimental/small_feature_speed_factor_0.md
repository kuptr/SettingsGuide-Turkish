Küçük Özellik İlk Katman Hızı
====
[Maksimum Küçük Özellik Uzunluğu](small_feature_max_length.md) ayarından daha kısa olan konturlar, azaltılmış bir hızda basılabilir. Bu ayar ile, bu konturların ilk katmanda [Duvar Hızı](../speed/speed_wall.md) faktörü olarak hangi hızda basılacaklarını belirtebilirsiniz. Bu, [Küçük Özellik Hızı](small_feature_speed_factor.md) baskı hızından ayrı olarak yapılandırılabilir.

Küçük konturların, yapı plakasına yapışmak için yeterli yüzey alanı yoktur. Özellikle [dolgu öncesi duvarları yazdırırken](../infill/infill_before_walls.md), küçük deliklerin duvarları genellikle yapı plakası üzerinde duran küçük dairelerdir. Daha sonra nozul bir hareket sırasında bunların üzerinden geçerse, yapı plakasından kopabilirler. Bu nedenle, bu küçük konturların yazdırma hızı diğer konturlara göre azaltılabilir. Bu, malzemenin daha fazla akmasını ve yapı plakasına daha iyi yapışmasını sağlar, böylece yapı plakasından kopma olasılığını azaltır.

Bu küçük konturların baskı hızını azaltmak, baskı hızı üzerinde çok küçük bir negatif etkiye sahiptir. Neyse ki, bu konturlar tanım gereği küçüktür ve yalnızca ilk katmanı etkilediği için toplam ek baskı süresi önemli değildir.