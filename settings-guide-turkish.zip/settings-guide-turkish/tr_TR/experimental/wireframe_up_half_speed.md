WP Ease Upward
====
Tel Baskı modundaki çerçevenin yatay halkalarını birbirine bağlayan testere dişi desenin yukarı doğru hareketine başladığında, yukarı doğru hareketin ilk kısmı yavaş yapılabilir. Bu ayar, dikey çizginin hangi bölümünün daha yavaş basılacağını yapılandırır. Bu dikey çizginin bu segmenti [upward speed/yukarı yönlü hızın](wireframe_printspeed_up.md) yarısında basılacaktır.

![Farklı Tel Baskı hızlarının nerede uygulandığı](../images/wireframe_printspeed.svg)

Altta [pausing/beklemek](wireframe_bottom_delay.md) yerine, nozülün devam etmesi daha iyi olabilir. Bu, sıcak nozülün altındaki yatay halkayı yeniden eritmesini önler, ancak testere dişi desenini yine de sıkı bir şekilde yatay halkaya bastırır. Nozül odası içindeki basınç, malzemenin alttaki halkaya doğru itilmesine neden olur.

Bu tel boyunca nozülün hareket ettiği hız ayrı olarak yapılandırılamaz. Her zaman normal hızın yarısı olacaktır.