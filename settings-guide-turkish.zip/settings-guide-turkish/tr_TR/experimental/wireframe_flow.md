WP Flow
====
Bu ayar, Tel Baskı tekniği kullanılarak yazdırma yaparken akış hızının ayarlanmasını sağlar. Bu ayar, basitçe çizgi genişliği ve katman yüksekliği üzerinde bir çarpan olarak işlev görür. Tel Baskı için kullanılacak malzeme miktarını doğrudan belirler.

Bu ayar, tüm baskı için akışı ayarlar, ancak akış ayrıca [yatay parçalar/horizontal parts](wireframe_flow_flat.md) veya [connections](wireframe_flow_connection.md) için ayrı olarak da ayarlanabilir.

Tel Baskı, çizgi genişliği veya katman yüksekliğini kullanarak çizgilerin ve katmanların ne kadar aralıklı olduğunu belirlemez. Yalnızca [height](wireframe_height.md) ve [inset distance/içeriye mesafe](wireframe_roof_inset.md) kullanır. Dolayısıyla Tel Baskı akışını ayarlamak yerine, [Katman Yüksekliği](../resolution/layer_height.md) veya [Hat Genişliği](../resolution/line_width.md) ayarlarını veya [ordinary Flow/normal Akış](../material/material_flow.md) ayarını ayarlamak aynı etkiyi yapacaktır. Ancak bu ayarlar, Tel Baskı için doğru akışa sahip bir baskı profilinin oluşturulmasına izin verirken, Tel Baskı kullanmayan normal baskıların kalitesini etkilemez.

Akışı artırmak telleri kalınlaştırır. Bu, çerçevenin katılaştıktan sonra daha sağlam olmasını sağlar. Ancak aynı zamanda çerçevenin ısıl kütlesini artırır, bu da tellerin katılaşmasının daha uzun sürmesine neden olur. Bu, tellerin sarkmasına ve baskının güvenilirliğinin azalmasına yol açabilir, çünkü teller artık doğru şekilde bağlanmayabilir.