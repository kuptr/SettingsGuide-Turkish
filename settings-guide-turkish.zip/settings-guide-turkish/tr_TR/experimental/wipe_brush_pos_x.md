Sürme Fırçası X Konumu
====
Bu ayar, nozzleun silme işlemi sırasında nereye hareket edeceğini yapılandırır.

Silme işlemi yalnızca X yönünde yapılabilir. Bu, silme fırçasının tüm Y eksenini kapsaması gerektiği anlamına gelir. Silme işlemi, nozulun katman üzerinde nerede sona erdiği noktadan doğrudan sol veya sağ yöne yapılır. Silme hareketi kendisi de sadece X yönünde gerçekleştirilir.

Silme fırçanız ya negatif X yönünde olabilir ya da pozitif X yönünde olabilir. Eğer pozitif X yönü kullanılıyorsa, fırçanın inşa hacminin kenarından biraz ilerisine hareket etmesi gerekebilir. Eğer fırça negatif X yönünde ise, bu koordinat muhtemelen negatif olacaktır.

Nozul, silme işlemi için bu noktadan ötesine asla hareket etmez. Silme işlemi, bu noktadan modelin üzerine doğru yapılır. Bu nokta gecikmez.

Bu koordinat, Cura'nın nesnelerin yerleştirilmesi için hareket aracında gösterdiği koordinatlardan farklı olarak, g-kod koordinat sisteminde belirtilmiştir.