WP Upward Printing Speed
====
Bu ayar, testere dişi deseninde dikey hareket yaparken nozülün yukarı doğru ne kadar hızlı hareket edeceğini belirtir. Yukarı hareket hızı, tel baskı hızının geri kalanından ayrı olarak yapılandırılabilir.

![Farklı Tel Baskı hızlarının uygulandığı yerler](../images/wireframe_printspeed.svg)

Yukarı doğru hareket, tüm hareket için belirtilen hızda olmayacak. [Ease Upward/Yukarı Kolaylaştırma](wireframe_up_half_speed.md) ayarı tarafından tanımlandığı gibi, yukarı hareketin en alt kısmı için baskı kafası bu hızın yarısında hareket edecektir.

Daha yavaş yukarı hareket etmek daha fazla zaman alır, ancak malzemenin katılaşması için daha fazla zaman sağlar. Bu şekilde, malzeme çapraz yönde çok fazla sürüklenmez. Ancak çok yavaş hareket etmek, basınçlı nozül odasındaki filamanın ataleti nedeniyle çizgiyi aşağıya itebilir. Filaman o zaman sallanma eğilimindedir ve bu, bir sonraki yatay çizginin uygun bir bağlantı yapmasını daha az olası hale getirir.