Parçalarda Döküm Desteği
====
Eğer destek için zikzak [şekli](../support/support_pattern.md) kullanılıyorsa, destek kolayca kaldırılabilen bir şekilde katlanabilir. Ancak destek çok genişse bu işlem daha zor olabilir. Bu ayar ile zigzag destek parçalara bölünerek her bir parçanın tek başına daha kolay kırılmasını sağlar, ancak yine de stabilitesini koruyacak kadar geniş kalır.

<!--screenshot {
"image_path": "support_skip_some_zags.png",
"models": [{"script": "rack.scad"}],
"camera_position": [0, 184, 10],
"settings": {
    "support_enable": true,
    "support_pattern": "zigzag",
    "support_skip_some_zags": true,
    "support_skip_zag_per_mm": 20
},
"colours": 32
}-->
![Her 8 satırda bir bağlantı hattı bırakılır, destek parçalara bölünür](../images/support_skip_some_zags.png)

Destek parçalara bölündüğünde destekleri tek tek kırmanız daha kolay olur, çünkü destekleri parça parça kırabilirsiniz. Ancak bu, desteklerin dayanıklılığını ve rijitliğini biraz azaltır, özellikle [Destek Parçasının Boyutu](support_skip_zag_per_mm.md) çok küçükse. Sonuç olarak, desteklerin devrilme ve aşırı asma sorunlarının artma olasılığı biraz daha yüksektir.

Bu ayar aynı zamanda tüm destekleri tek parça halinde çıkarmayı engeller. Eğer çok sayıda destek parçası varsa, bunları tek tek çıkarmak gerekir. Diğer türlü destekler kolayca çıkıyorsa, bu ayar aslında destekleri çıkarmayı daha zorlaştırabilir (ancak yine de genellikle daha kolay olabilir).

Bu ayar [Duvar Hattı Sayısını Destekle](../support/support_wall_count.md) ile iyi bir şekilde birleşmez. Eğer destek etrafında ek bir duvar varsa, bu duvar parçaları tekrar birleştirerek destekleri kırmayı zorlaştırabilir.