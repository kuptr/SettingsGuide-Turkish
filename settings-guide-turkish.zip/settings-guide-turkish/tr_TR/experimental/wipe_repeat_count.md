Sürme Tekrar Sayısı
====
Bu ayar, her silme işlemi sırasında nozülün fırçadan kaç kez silineceğini yapılandırır. Nozül, fırçanın üzerinden ileri geri hareket edene kadar bu kadar kez silinir.

Bu ayar, silme pozisyonlarına gidiş geliş hareketleri bu sayıya dahil edilmeden önceki başlangıç konumunu içermez, ancak başlangıç pozisyonu [Sürme Fırçası X Konumu](wipe_brush_pos_x.md) her zaman fırçanın ötesindedir. Bu nedenle, nozül fırçada ileri geri hareket etmeden önce ve sonra ekstra iki kez daha silinecektir.

Daha sık silme, nozül üzerinde kalan tüm malzemeyi temizleme işlemini daha etkili hale getirir. Ancak bu daha fazla zaman alabilir ve silme işlemi sırasında nozülün üzerindeki malzemenin daha fazla akmasına izin verebilir.