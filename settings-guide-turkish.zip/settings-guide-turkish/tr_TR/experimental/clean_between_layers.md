Katmanlar Arasındaki Sürme Nozülü
====
Bu ayar, her katmanın sonunda nozül ucundan herhangi bir malzemeyi silmek için yürütülen bir prosedürü etkinleştirir. Yerleşik bir silme fırçasına sahip bir yazıcınız varsa, bu ayarın etkinleştirilmesi, Cura'nın yazıcıya nozülü periyodik olarak bu fırçada silmesini talimat verecektir.

![Silme prosedüründeki hareketlerin görselleştirilmesi](../images/clean_between_layers.svg)

Bu silme prosedürü birkaç adımdan oluşur:
1. [Sürme Geri Çekmenin Etkinleştirilmesi](wipe_retraction_enable.md) etkin ise, malzeme geri çekilir.
2. [Sürme Z Sıçraması](wipe_hop_enable.md) etkin ise, nozül yukarı veya baskı tablası aşağı hareket ettirilir.
3. Nozül, [Sürme Fırçası X Konumu](wipe_brush_pos_x.md) ötesine hareket ettirilir.
4. Nozül, fırçada [Sürme Tekrar Sayısı](wipe_repeat_count.md) kez silinir.
5. Nozül, orijinal konumuna geri hareket ettirilir.
6. Z-hop sona erdirilir, eğer etkinse. Malzeme geri çekilir.
7. Baskı, belirli bir süre boyunca ([Sürmeyi Durdurma](wipe_pause.md)) duraklatılır.

Bu prosedürün amacı, nozülü periyodik olarak herhangi bir kalıntıdan temizlemektir. Bazı malzemeler, yüksek yüzey gerilimi nedeniyle kapiler etki ile nozül üzerine tırmanma eğilimindedir. Bu, baskı kafasına sızabilir ve orada birikebilir, bu da baskı kafasının bozulmasına neden olabilir. Elyaf veya diğer dolguları içeren diğer malzemeler, yazdırma sırasında dolgunun nozül üzerine püskürtülmesine neden olabilir. Bu prosedür, bu malzemeyi silerek temizler.

Ancak, silme prosedürü şu anda çok yapılandırılabilir değildir. Her zaman X yönünde siler, baskının son konumunda Y pozisyonunu korur. Bu, köşede bir fırçaya sahip bir yazıcı ile bu işlevin iyi çalışmayacağı anlamına gelir. Baskı hacminin bir kenarı boyunca bir fırçaya ihtiyacınız olacaktır.