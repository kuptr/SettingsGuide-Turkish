Cereyan Kalkanını Etkinleştir
====
Bu ayar etkinleştirildiğinde, yazıcı baskınızın etrafına bir kabuk inşa eder ve bu kabuk, baskınızı dış çevreden gelen hava akımlarına karşı korur.

<!--screenshot {
"image_path": "draft_shield_enabled.png",
"models": [{"script": "headphone_hook.scad"}],
"camera_position": [-56, 139, 305],
"settings": {
    "draft_shield_enabled": true
},
"colours": 32
}-->
![Cereyan kalkanı, modelin etrafında basılır](../images/draft_shield_enabled.png)

Bazı yazıcılar ve baskı malzemeleri, baskının yapıldığı ortama çok duyarlıdır. Baskı platformunun farklı konumlarında baskı yapmak, dışarıdan gelen hava akımlarına daha duyarlı oldukları için farklı sonuçlara yol açabilir. Eğer baskı gece boyunca çalışmaya bırakılırsa ve oda daha soğuksa, bu baskı üzerinde önemli bir etkiye sahip olabilir. Cereyan kalkanı, baskının etrafında küçük ve izole bir hacim yaratarak bu etkiyi azaltmayı amaçlar. Bu, baskıyı sıcak tutar ve dışarıdan gelen soğuk hava akımlarına karşı korur, adeta bir "ısıtılmış oda" işlevi görür.

Kalkan, model basıldıkça anlık olarak basılır. Eğer baskıda birden fazla ekstruder varsa, cereyan kalkanı, katmanı başlatan ekstruder kullanılarak basılır. Bu, katmandan katmana değişir.

Cereyan kalkanının baskı üzerinde birkaç önemli etkisi vardır:
* Baskının sıcaklığını daha sabit tutar. Bu, cereyan kalkanının amaçlanan etkisidir. Böylelikle oda sıcaklığındaki değişimlerden kaynaklanan bantlanma azaltılmalıdır.
* Genellikle cereyan kalkanının içindeki sıcaklık, cereyan kalkanı olmadığında olduğundan daha yüksek olacaktır. Bu, ısı kaçışının zorlaşması ve sıcak hava ile yükselen konvektif akımların olmaması nedeniyledir. Bu, baskının tüm yönlerini etkiler. Özellikle daha fazla sarkma ve ipliklenme olabilir.
* Baskı kafasındaki fanlar daha az etkili olacaktır. Kalkan ayrıca orada hava akışını bozar. Baskı kafasındaki fanların etkinliğini artırmak için cereyan kalkanının [Cereyan Kalkanı X/Y Mesafesi](draft_shield_dist.md) artırılabilir.
* Cereyan kalkanı aynı zamanda bir [Sızdırma Kalkanını Etkinleştir](../dual/ooze_shield_enabled.md) olarak da kullanılabilir. Baskı sırasında korunan bir nesneye doğru seyahat hareketleri yapılırsa, nozülde kalan herhangi bir sızıntı, kalkana silinecektir.
* Cereyan kalkanı aynı zamanda bir [İlk Direği Etkinleştir](../dual/prime_tower_enable.md) olarak da kullanılabilir. Nesne öncesi basıldığından, cereyan kalkanının basılması malzemenin temizlenmesi ve düzgün akışının sağlanması için bir yoldur. Ancak bu, sadece 2 ekstruder ile etkilidir, çünkü 2'den fazla ekstruder varsa, tüm ekstruderler temizlenmez.