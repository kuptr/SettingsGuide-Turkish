Sürme Geri Çekme Sırasındaki İlave Astar Miktarı
====
Eğer silme işlemi sırasında [Sürme Geri Çekmenin Etkinleştirilmesi](wipe_retraction_enable.md)'ni etkin yapıyorsanız, silme işlemi tamamlandıktan sonra malzeme geri çekilecektir. Bu durumda, geri çekmeye rağmen kaybedilen herhangi bir malzemeyi telafi etmek için malzemenin orijinal [Sürme Geri Çekme Mesafesin](wipe_retraction_amount.md)den biraz daha ileri itilmesini isteyebilirsiniz. Bu, normal [Geri Çekme Sırasındaki İlave Astar Miktarı](../travel/retraction_extra_prime_amount.md)ndan ayrı olarak yapılandırılabilir.

Silme işlemi, nozülün yazıcı tarafındaki kenara kadar gitmesini, orada ileri geri hareket etmesini ve ardından geri dönmesini içerir. Bu aslında çok uzun bir seyahat hareketidir. Bu seyahat hareketi, baskı boyunca yapılan ortalama seyahat hareketlerinden daha uzundur, bu nedenle sızma nedeniyle daha fazla malzeme kaybı olabilir. Bunu telafi etmek için, silme işleminden sonra normal seyahat hareketlerinden daha fazla malzeme ilave etmeniz gerekebilir.

Fazla malzeme ilave ederseniz, aşırı ekstrüzyon olabilir. Bu, silme işleminden sonra nozülün indiği yerde bir topak olarak ortaya çıkar.