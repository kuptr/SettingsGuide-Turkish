Tarama Öncesi Minimum Hacim
====
Bu ayar, tarama uygulanmadan önce minimum miktarda malzemenin düzgün bir şekilde ekstrüze edilmesini sağlar. Eğer kontur o kadar küçükse ve bu minimum miktarda malzeme düzgün bir şekilde ekstrüze edilmiyorsa, konturun sonuna doğru tarama uygulanmaz.

Bu gereklidir çünkü çok küçük parçalar için tarama uygulanırsa, bir taranmış konturdan diğerine geçerken malzemenin yeniden düzgün bir şekilde akması için yeterli zaman kalmaz. Bu da çok kolay bir şekilde yetersiz ekstrüzyona yol açar. Bu durumda tarama tekniğini atlamak daha iyidir.

Bu ayarın artırılması, çok küçük parçalarla yetersiz ekstrüzyonu azaltacaktır. Ancak, bu parçalar için dikişlerin görünürlüğünü de artıracaktır.