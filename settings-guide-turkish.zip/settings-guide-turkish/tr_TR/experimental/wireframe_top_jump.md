WP Knot Size
====
Eğer [Wire Printing Strategy/Tel Baskı Stratejisi](wireframe_strategy.md) "Düğüm(Knot)" olarak ayarlanmışsa, her testere dişi deseninin üstünde küçük bir yukarı ve geri hareket yapılacaktır. Bu ayar, bu hareketin büyüklüğünü yapılandırır.

![Düğümün nerede çizildiği ve boyutunun ne anlama geldiği](../images/wireframe_top_jump.svg)

Bu "düğüm" hareketi bir dizi seyahat hareketinden oluşur:
1. İlk olarak, nozül bu ayarla belirtilen mesafe kadar yukarı hareket eder. Aynı zamanda, nozül bu mesafenin yarısı kadar geriye doğru hareket eder.
2. Üstte herhangi bir gözlemlenen [delay/gecikme](wireframe_top_delay.md) varsa, nozül bu ayarlanan gecikme süresince duraklar. Bu duraklama, düğüm hareketinin ucunda gerçekleşir.
3. Üçüncü olarak, nozül normal yüksekliğe geri iner. Aynı anda, nozül Düğüm Boyutu'nun 1.5 katı kadar ileri hareket ederek, bu ayarlanan mesafeye dikey çizgiden uzaklaşır.

Düğümün amacı, üzerindeki yatay halkanın testere dişi desenine bağlanabileceği bir alan sağlamaktır. Düğüm, biraz sağa sola değişebilir, bu nedenle yatay halka çok hassas bir şekilde yerleştirilmemişse bile birbirine bağlanma olasılığı daha yüksektir. Ayrıca, düğüm yukarı doğru çizginin biraz daha yukarı doğru uzanmasını sağlayarak, yatay halkayı üstüne itmeye yardımcı olur. Son olarak, düğüm, bu seyahat hareketinde geri çekilme olmadığından dolayı bir miktar sızıntı oluşturur. Bu, yatay halkanın daha iyi dinlenebileceği bir yüzeye neden olur.