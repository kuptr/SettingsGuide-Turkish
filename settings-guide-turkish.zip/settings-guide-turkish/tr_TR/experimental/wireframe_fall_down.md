WP Fall Down
====
Tel çerçeve yazdırılırken, malzeme katılaşmadan önce latent ısı nedeniyle sarkması beklenir. Bu durum testere dişi desenini çok kısa yapabilir. Yatay halkalar sürekli yatay hareketleri sayesinde köprü kurabilirken, testere dişi deseni bunu yapamaz. Bu ayar, testere dişi deseninin kısa boyunu telafi ederek deseni biraz daha uzun yapar, böylece bir sonraki yatay halkanın üzerine düzgün bir şekilde oturmasını sağlar.

![Testere dişi deseninin yüksekliği nasıl telafi edilir](../images/wireframe_fall_down.svg)

Ayarın değeri testere dişi dişlerinin yüksekliğine eklenir. Umarız bu ayar, testere dişi dişlerinin yazdırılması sırasında meydana gelen sarkmayı telafi eder. İyi ayarlandığında, yatay halka testere dişi deseninin üzerine sağlamca oturarak, amaçlanan yazdırılmış yükseklikten daha düşük bir noktaya düşmez.

[Drag Along](wireframe_drag_along.md) ile birleştirildiğinde, testere dişi deseninin yüksekliği normal [height](wireframe_height.md) artı Drag Along ayarının değeri, artı bu ayarın değeri olacaktır.

Yani, "Drag Along" ve bu ayar bir arada kullanıldığında, testere dişi desenin yüksekliği, normal yüksekliğine ek olarak "Drag Along" ayarının değeri ve bu ayarın değeri kadar artar.