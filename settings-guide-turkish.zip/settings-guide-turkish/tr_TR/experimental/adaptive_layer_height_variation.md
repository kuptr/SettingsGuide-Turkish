Uyarlanabilir Katmanların Azami Değişkenliği
====
Bu ayar ile Adaptif Katmanlar'ın seçebileceği katman kalınlığı aralığını sınırlayabilirsiniz. Katman yüksekliği, normal [Katman Yüksekliği](../resolution/layer_height.md) ayarından bu varyasyondan daha fazla sapamaz.

Örneğin, normal katman yüksekliği 0.15mm ve varyasyon 0.1mm olarak ayarlandığında, Adaptif Katmanlar 0.05mm ile 0.25mm arasında kalınlığa sahip katmanlar üretebilir.

Bu ayar, Adaptif Katmanlar özelliğinin gücünü sınırlar. Eğer katman kalınlığı aralığı çok darsa, katman kalınlığı her zaman Katman Yüksekliği ayarı tarafından belirlenen orijinal katman kalınlığına çok yakın olacaktır. Bu durumda Adaptif Katmanlar, zaman tasarrufu sağlamak veya kaliteyi artırmak için çok az şey yapabilir.

Ancak aralık çok genişse, katmanlar çok kalın veya çok ince olabilir. Çok kalın katmanlar, nozuldaki sınırlı boyut ve yazıcı kafasındaki ısıtma hattının eritme kapasitesi nedeniyle her zaman mümkün değildir. Çok ince katmanlar da malzemenin viskozitesi veya Z ekseninin doğruluğu nedeniyle her zaman mümkün olmayabilir. Bu yüzden Adaptif Katmanlar'ın katman kalınlığını ayarlayabileceği aralığı sınırlamak iyidir. Aksi takdirde yazıcı istenen katman kalınlığına ulaşmakta zorlanacaktır.

Katman kalınlığı, aralık buna izin verse bile asla 0.001mm'nin altına inemez.