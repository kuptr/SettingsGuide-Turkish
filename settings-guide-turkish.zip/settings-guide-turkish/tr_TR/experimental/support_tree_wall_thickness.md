Ağaç Destek Duvar Kalınlığı
====
Bu ayar, ağaç desteklerin çevresinin ne kadar kalın olacağını belirler. Daha kalın bir çevre için, ağaç destek şeklinde daha fazla kontur çizilecektir.

![Örneğin, 0.8mm kalınlığında bir duvar kullanımı ağaç destek içinde iki kontur çizilmesine neden olur](../images/support_tree_wall_count.png)

Daha kalın duvarlar, özellikle büyük [Maksimum Dal Açısı](../support/support_tree_angle.md) ile destek çok daha sağlam yapar. Bu, baskının güvenilirliğini artırır ve destek dallarının kırılma olasılığını azaltır.

Ancak bu, destek üzerinde harcanan zamanı ve malzemeyi büyük ölçüde artırır.

Bu ayar, [Duvar Hattı Sayısını Destekle](../support/support_wall_count.md) ayarı ile çok benzer şekilde çalışır.