Belirsiz Dış Katman Noktası Mesafesi
====
Bu ayar, bulanık cilt için orijinal duvar boyunca hareketler arasındaki mesafeyi yapılandırır. Mesafe küçükse, baskı kafası duvar boyunca çok sık farklı yönlere hareket eder. Yüksek frekansta titreşim yapar.

Daha küçük mesafelerde, kabartma daha ince olacak ve daha kaba bir dokuya yol açacaktır. Bu aynı zamanda baskı süresini önemli ölçüde etkiler. Daha düz, ancak kabarık bir dokuya sahip olmak için mesafeyi artırabilirsiniz.

Belirsiz Dış Katman etkinleştirildiğinde, dış duvar tamamen titreşim hareketleri arasındaki düz çizgi segmentlerinden oluşur, orijinal yüzey yerine. Yüksek mesafelerde, Belirsiz Dış Katman etkisi nedeniyle eğrisel yüzeylerin orijinal çözünürlüğünden daha düz olması mümkündür.

Algoritma kısıtlamaları nedeniyle, noktalar arası mesafe [Belirsiz Dış Katman Kalınlığı](magic_fuzzy_skin_thickness.md) çok yüksekse çok küçük olamaz.