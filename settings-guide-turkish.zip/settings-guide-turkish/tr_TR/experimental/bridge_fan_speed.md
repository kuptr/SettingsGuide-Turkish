Köprü Fan Hızı
====
Bu ayar, hem duvarların hem de yüzeyin köprüleme sırasında fan hızını kontrol eder. Bu fan hızı, normalde kullanılacak olan [Fan Hızı](../cooling/cool_fan_speed.md) yerini alır.

Köprüleme sırasında fan hızının mümkün olduğunca yüksek tutulması genellikle istenir. Fan hızı, baskının geri kalanına göre daha yüksek olmalıdır. Bu, malzemenin daha hızlı katılaşmasını sağlayarak sarkmayı önler.

Ancak, bazı yüksek sıcaklıklı malzemeler için fanı çok yüksek açmak, yetersiz ekstrüzyona veya hatta nozulun tamamen tıkanmasına neden olabilir.