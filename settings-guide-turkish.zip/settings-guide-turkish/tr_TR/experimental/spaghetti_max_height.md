Spaghetti Dolgu Maksimum Yükseklik
====
Bu ayar ile, spagetti dolgu [basamağı](spaghetti_infill_stepped.md) basılıyorsa adımların ne sıklıkta olacağını yapılandırabilirsiniz.

Spagetti dolgunun daha fazla adımla üretilmesi, spagettinin dolgu hacmi boyunca daha uniform şekilde dağılmasını sağlar. Malzeme modelin çukurlarına yayılabilir. Eğer spagetti dolgu esnek bir dolgu üretmek için kullanılıyorsa, bu dolgudaki zayıf noktaları önler. Eğer spagetti dolgu döküm malzemesi olarak kullanılıyorsa, dolgu içinde çok fazla hava boşluğu olmayacaktır.

Ancak adım sayısını artırmak daha fazla basım süresi alacaktır. Basım kafası daha fazla hareket yapmak zorunda kalacak ve dolgu farklı bir ekstrüder ile basılıyorsa araçlar daha sık değiştirilmelidir.