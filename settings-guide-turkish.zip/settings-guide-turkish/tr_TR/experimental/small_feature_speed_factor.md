Küçük Özellik Hızı
====
[Maksimum Küçük Özellik Uzunluğu](small_feature_max_length.md) ayarından daha kısa olan konturlar azaltılmış bir hızda basılabilir. Bu ayar ile, bu konturların [Duvar Hızı](../speed/speed_wall.md) faktörü olarak hangi hızda basılacaklarını belirtebilirsiniz.

Küçük deliklerin basımı sırasında boncuk uç ve nozülün köşeye doğru çekilme eğilimi gösterir. Köşe çok keskin ise, küçük deliklerde bu çekilme deliği daha küçük yapma etkisine sahiptir. Daha yavaş basılması durumunda, malzemenin yerleşmesi için daha fazla zaman olduğundan ve mekanik çekme basitçe daha düşük olduğundan, bu çekilme azalır.

Bu küçük özellikler için hızı azaltmak boyutları daha doğru hale getirecektir. Ancak baskı süresini biraz artıracaktır. Neyse ki, bu konturlar tanım gereği küçük olduğundan, genellikle eklenen toplam baskı süresi çok önemli değildir.