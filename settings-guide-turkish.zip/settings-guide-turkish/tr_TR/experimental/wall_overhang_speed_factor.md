Çıkıntılı Duvar Hızı
====
Bu ayar ile [Çıkıntılı Duvar Açısı](wall_overhang_angle.md) basılırken kullanılan hız ayarlanabilir. Hızları, normal baskı hızlarının bir oranı olarak ayarlanır; bu hızlar ya [Dış Duvar Hızı](../speed/speed_wall_0.md) ya da [İç Duvar Hızı](../speed/speed_wall_x.md) olarak adlandırılır.

Aşağısalım duvarlarını daha düşük hızda basmak, sarkma olasılığını azaltmak için çok etkilidir. Bu, baskınız üzerinde birkaç olumlu etkiye sahiptir:
* Duvarlar, önceki katmanlardaki yan duvarlara daha iyi bağlanma fırsatı bulur. Bu, duvarların daha dik durmasına yardımcı olur ve sarkmayı azaltır.
* Eğer fan hızınız yüksekse, fanlar filamenti daha hızlı soğutur. Bu, filamentin daha hızlı katılaşmasını sağlar. Eğer baskı hızı yüksek olursa, malzeme daha fazla sarkma eğilimindedir.
* Aşağısalım alanındaki malzeme, hala nozulden çıkan bir boncukla bağlıdır. Daha yavaş basıldığında, nozul katılaşma sırasında daha yakın kalır, bu da boncuğun katılaşırken daha dik durmasını sağlar.

Ancak aşağısalımı daha düşük (veya farklı) hızlarda basmak bazı olumsuz etkilere de sahip olabilir:
* Baskının tamamlanması daha uzun sürebilir.
* Hızın farklı olduğu sınır, baskınızın dışında gözle görülür bir sınır oluşturabilir. Bu, baskınızda istenmeyen bir görünür sınır oluşturabilir.
* Hızı azalttığınızda, nozül odasında yüksek basınç nedeniyle kısa süreli olarak bazı aşırı ekstrüzyon olabilir. Bu, çıkıntı kalitesini kötüleştirebilir veya anlık pıhtılar oluşturabilir. Hızı artırdığınızda ise, aşırı ekstrüzyon olabilir. Genel olarak, bu teknik büyük aşağısalım alanları için küçük olanlardan daha iyi çalışır.