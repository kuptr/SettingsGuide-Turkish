Destek Parçası Hattı Sayısı
====
Eğer destek [parçalara ayrıldığında](support_skip_some_zags.md), bu ayar, bir parça içinde kaç destek çizgisinin birleştirileceğini belirler.

<!--screenshot {
"image_path": "support_skip_some_zags.png",
"models": [{"script": "rack.scad"}],
"camera_position": [0, 184, 10],
"settings": {
    "support_enable": true,
    "support_pattern": "zigzag",
    "support_skip_some_zags": true,
    "support_skip_zag_per_mm": 20
},
"colours": 32
}-->
![Her bir parça 8 satır içerir](../images/support_skip_some_zags.png)

Daha küçük parçalar genellikle daha büyük parçalardan daha kolay kırılır. Model üzerine yapışacak yüzey alanı daha az olduğundan, destek çekilirken daha az kuvvet gerektirir. Ancak çıkarılacak daha fazla parça olabilir, bu yüzden destek çıkarmak normalde zor değilse, destek çıkarmak daha fazla iş gerektirebilir. Her parça tek tek çıkarılmalıdır, bir seferde tüm destek çıkarılmaz.

Eğer parçalar çok küçük yapılmışsa, desteklerin yapısal bütünlüğü tehlikeye girebilir. Destek deseni daha çok çizgi desenine benzeyecektir ki bu da devrilme olasılığını artırır. Bu durum, desteklerin devrildiği yerlerde daha fazla dizeleme ve kötü aşağısalım kalitesine yol açabilir.