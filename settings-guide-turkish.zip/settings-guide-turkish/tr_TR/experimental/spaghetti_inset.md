Spaghetti Ekleme (Inset)
====
Spaghetti dolgunun her yönde eşit şekilde genişlemesine izin vermek için duvarlardan belirli bir mesafe tutulmalıdır. Bu ayar bu mesafeyi belirler.

Bu ayarın davranışı neredeyse [Dolgu Çakışması](../infill/infill_overlap_mm.md) ayarı ile aynıdır. Dolgu örtüşme negatif olacak şekilde bu ayarın değeri ayarlanırsa, nozülün geçeceği alan aynı olur. Ancak farklılık şudur ki, bu ayar dolgu olarak ekstrüde edilen toplam hacmi değiştirmez. Dolgu örtüşmesini azaltmak dolgu olarak ekstrüde edilen malzemenin miktarını azaltırken, bu ayarı ayarlamak dolgu olarak ekstrüde edilen toplam hacmi değiştirmez.

Esnek bir dolgu deseni olarak spagetti dolgu kullanırken, bu ayar malzemenin duvarlara çarpmadan aşağı inmesine ve dinlenmeden önce duvara yapışmasını önlemek için ayarlanmalıdır. İçerleme çok küçükse, spagetti dolgu duvarlara yapışabilir ve orada büyük malzeme topakları oluşturabilir. Ancak içerleme çok büyükse, tüm malzeme ortaya konsantre olabilir ve tüm taraflarda eşit miktarda dayanıklılık eklemek yerine orta kısmına odaklanabilir.

Spagetti dolgu ile döküm yaparken, bu ayar döküm malzemesi ekleyebilen yazıcılar için tipik olan geniş döküm nozullarına ayarlanmalıdır, böylece dolgu hacminin dışında duvar üzerine malzeme akışı olmaz.