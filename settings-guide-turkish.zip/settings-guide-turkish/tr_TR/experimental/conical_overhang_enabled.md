Çıkıntıyı Yazdırılabilir Yap
====
Bu ayar, modelinizi artık hiç sarkma içermeyecek şekilde dönüştürür. Herhangi bir sarkmanın altına ekstra malzeme yerleştirir ve bunu modelin bir parçasıymış gibi yazdırır.

<!--screenshot {
"image_path": "conical_overhang_enabled_disabled.png",
"models": [{"script": "castle.scad"}],
"camera_position": [0, 189, 25],
"settings": {
    "conical_overhang_enabled": false
},
"colours": 8
}-->
<!--screenshot {
"image_path": "conical_overhang_enabled_enabled.png",
"models": [{"script": "castle.scad"}],
"camera_position": [0, 189, 25],
"settings": {
    "conical_overhang_enabled": true,
    "conical_overhang_angle": 50
},
"colours": 8
}-->
![Sarkma içeren parçaları olan bir kule](../images/conical_overhang_enabled_disabled.png)
![Sarkma yazdırılabilir hale getirilir](../images/conical_overhang_enabled_enabled.png)

Tüm sarkan parçaların altına, aşağı doğru küçülen malzeme yerleştirilir. Birçok durumda sarkma, nesneye doğru eğimli olacaktır. Sarkmanın nesneye doğru büyüme eğimi, [Maksimum Model Açısı](conical_overhang_angle.md) ile belirlenir.

Bu ayar, destek gereksinimini önlemenin kolay bir yolu olabilir. Özellikle, yanlarında biraz pürüzlü yüzeyler veya kabartmalar olan modelleri yazdırırken etkilidir. Bu küçük sarkma parçaları normalde aşağı doğru sarkar ve kopuk plastik iplikler üretir. Bazı desteklerle desteklenebilirler, ancak bu yazdırma süresinde maliyetli olabilir ve yine de bazı izler bırakır. Bu ayar etkinleştirildiğinde, sarkma modele doğru yumuşatılır. Yazdırılacak şekilde tasarlanmış gibi görünecektir.

Eğer sarkma, ana gövdeden genişliğinden daha fazla çıkıntı yaparsa, bu durumda bir çizgi şeklinde sarkma oluşabilir. Bu, çıkıntının sonsuz inceltilerek küçültülmesi nedeniyle kaybolmasına neden olur. Bu durumda, destek yazdırmanın hala gerekli olup olmadığını düşünebilirsiniz. Yukarıdaki resimlerde, bu durum kule üzerindeki küçük bloklarla meydana gelir, ancak bu kadar küçük olduğu için basit bir köprüleme muhtemelen sarkmanın üstesinden gelmesini sağlar.