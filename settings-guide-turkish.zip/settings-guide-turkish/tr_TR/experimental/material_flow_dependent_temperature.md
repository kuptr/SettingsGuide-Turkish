Auto Temperature
====
Daha hızlı baskı yaparken, nozül açıklığından malzemenin daha hızlı akmasını sağlamak için biraz daha yüksek bir sıcaklıkta baskı yapmak en iyisidir. Bu ayar, nozülden malzeme çıkışının ortalama akış hızına bağlı olarak sıcaklığı otomatik olarak ayarlar.

Sıcaklığın ne kadar ayarlanması gerektiğini belirlemek için [Akış Sıcaklık Grafiği](material_flow_temp_graph.md) referans alınır. Akış hızı, saniyedeki kübik milimetre cinsinden hesaplanır. Bu akış hızı-sıcaklık ilişkisi kullanılarak belirli bir sıcaklık elde edilir. Bu sıcaklık, baskı sıcaklığı olarak kullanılır. Bu ayar etkinleştirildiğinde, normalde kullanılan [Yazdırma Sıcaklığı](../material/material_print_temperature.md) ayarı yerine akış hızından hesaplanan sıcaklık kullanılır.

Bu ayarın amacı, baskı kalitesini artırmaktır; baskı sırasında büyük akış değişiklikleri olduğunda aşırı veya yetersiz ekstrüzyonu azaltmak. Bu durum genellikle cilt ve iç dolgu arasındaki sınırda ortaya çıkar. Cilt genellikle iç dolgudan çok daha yavaş bir şekilde basılır, bu yüzden iç dolgu baskısı sırasında malzemenin doğru şekilde ekstrüde edilmesi için sıcaklığın biraz daha yüksek olması gerekmektedir.

Birçok yazıcı için, yazıcının nozülünde sıcaklığı düzenleyen PID regülatörü, kısa sürede çok sayıda sıcaklık değişikliği olduğunda aşırı tepki gösterme eğilimindedir. Bu ayar kullanıldığında baskı sıcaklığının vahşi bir şekilde doğru olmamasına neden olabilir.

**Bu ayar şu anda Cura arayüzünde görünür değil ve etkinleştirilemez.**