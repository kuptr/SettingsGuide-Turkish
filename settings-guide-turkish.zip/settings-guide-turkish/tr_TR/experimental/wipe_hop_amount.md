Sürme Z Sıçraması Yüksekliği
====
Bu ayar, silme işlemi sırasında seyahat ederken oluşturulması gereken boşluğu yapılandırır. Bu ayar, normal [Z Sıçraması Yüksekliği](../travel/retraction_hop.md)'nden nden ayrı olarak yapılandırılabilir.

Silme işlemi sırasında nozul hızla ileri geri hareket eder. Bu, yazıcının şiddetle sarsılmasına neden olur, bu da yapı platformunu ve gantri sistemi yukarı ve aşağı titreştirir. Eğer normal Z hop yüksekliği çok sıkı bir şekilde yapılandırılmışsa, silme işlemi sırasında Z hop için daha fazla boşluk alınması gerekebilir.