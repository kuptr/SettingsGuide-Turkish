Spaghetti Maksimum Dolgu Açısı
====
Bu ayar, dolgu malzemesinin yanına ekstrüde edildiğinde ulaşabileceği maksimum taşma açısını yapılandırır. Eğer bir nokta bu sınırlama nedeniyle uygun yoğunlukta dolmazsa, dolgu hacminin yüksekliği boyunca ek [spagetti basamağı/adımları](spaghetti_infill_stepped.md) eklenir ve bu bölgelerin uygun şekilde dolması sağlanır.

Eğer spagetti dolgunun esnek bir dolgu olarak kullanılması amaçlanıyorsa, bu ayar muhtemelen oldukça yüksek olarak ayarlanmalıdır. Bu ayarı artırmak, düşük eğimli çatıların altına ulaşmak için ek adımların eklenmesine neden olur. Spagetti dolgu yatay yönde çok fazla genişleme eğiliminde olmadığı için, ek adımların eklenmesi bu düşük çatıların altına malzeme itmek için yardımcı olur.

Eğer spagetti dolgu döküm malzemesi ile kullanılacaksa, bu ayar önemli ölçüde düşürülebilir. Çünkü döküm malzemesi sıvı olduğundan, yüzeylerin altına çok uzaklara ulaşabilir. Ancak hala 0°'e ayarlamayın çünkü çoğu döküm malzemesinin bir viskozitesi vardır. Döküm kabuğunu tamamen izlemesi için bazı düşük çatıların altına döküm yapmak isteyebilirsiniz. 