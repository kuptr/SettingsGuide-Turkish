Tarama Hızı
====
Tarama sırasında, nozül artık malzeme ekstrüze etmez. Ancak, bir hareket işlemi gibi davranmaz. Nozül, yaklaşık olarak aynı hızda hareket etmeye devam eder. Bu ayarla, nozülün hareketine devam ettiği kesin hız ayarlanabilir.

Tarama hızı, normal yazdırma hızının oranıyla ayarlanır. Bu, [Dış Duvar Hızı](../speed/speed_wall_0.md) ve [İç Duvar Hızı](../speed/speed_wall_x.md) farklı hızlarda yazdırılıyorsa, tarama hızlarının da farklı olacağı anlamına gelir. Genellikle, tarama normal yazdırma hızından biraz daha düşük bir hızda yapılır, yetersiz ekstrüzyonla mücadele etmek için.

Tarama hızının azaltılması, duvar boyunca taramanın doğal olarak neden olduğu yetersiz ekstrüzyon etkisini azaltır, ancak nozül bir sonraki yapıyı yazdırmaya geçtiğinde, nozül daha uzun süre sarktığı için yetersiz ekstrüzyon etkisini artırır. Azaltılmış hız, tarama için azaltılmış [Tarama Hacmi](coasting_volume.md) ile eşleştirilmelidir, böylece nozül çok uzun süre sarkmaz.

Hızın azaltılması, taramanın genel etkisini de azaltır, çünkü nozül dikişte daha uzun süre kalır. Bu da dikişi daha görünür hale getirir.