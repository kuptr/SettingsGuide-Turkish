Sürme Hareket Mesafesi
====
Bu ayar, silme hareketlerinin ne kadar geniş olması gerektiğini belirlemenize olanak tanır. Nozül, [Sürme Tekrar Sayısı](wipe_repeat_count.md) için bu mesafeyi hareket edecektir.

Başlangıçta nozül, [Sürme Fırçası X Konumu](wipe_brush_pos_x.md) silme fırçasının ötesine yerleştirilir. Bu ayarın belirttiği mesafe, nozülün bu mesafeyi hareket ettirerek fırçanın diğer tarafına yerleştirilmesi gerektiğini belirler. Çok fazla hareket gereksiz hareketlere neden olabilir ve nozülün yapı platformuna geri dönmesine yol açabilir, bu da [Sürme Z Sıçraması](wipe_hop_enable.md) etkin olmadığı durumlarda modelle temas etmesine neden olabilir. Yeterince uzak hareket etmemek ise fırçaya düzgün bir şekilde temas etmesini engelleyebilir.

Bu mesafe negatif de olabilir. Bu durumda nozül farklı yöne doğru silme yapacaktır. [Sürme Fırçası X Konumu](wipe_brush_pos_x.md)'na bağlı olarak, doğru yönde silme yapmak için bu gerekebilir.