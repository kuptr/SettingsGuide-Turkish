Belirsiz Dış Katman Kalınlığı
====
Bu ayar, dış duvarı yazdırırken baskı kafasının bir yönden diğerine sallanacağı genişliği belirler, eğer [Belirsiz Dış Katman](magic_fuzzy_skin_enabled.md) etkinse.

![Normal kabartma](../images/magic_fuzzy_skin_photo.jpg)
![10mm kalınlık](../images/magic_fuzzy_skin_thickness.jpg)

Kabartmayı artırmak yüzeyi daha kaba yapacaktır. Kabartmayı azaltmak ise yüzeyi orijinale daha yakın yapacaktır. Yüksek kabartma ekstrem düzeyde bir tüylü baskıya yol açar. Dış duvar esasen nesnenizin etrafında rastgele bir dize olur.