Yalnızca Belirsiz Dış Katman
====
Bu ayarı etkinleştirirseniz, [Belirsiz Dış Katman](magic_fuzzy_skin_enabled.md) sadece baskının dış duvarlarına uygulanır.

<!--screenshot {
"image_path": "magic_fuzzy_skin_outside_only.png",
"models": [{"script": "watch_strap_keeper.scad"}],
"camera_position": [-52, -37, 37],
"settings": {
    "magic_fuzzy_skin_enabled": true,
    "magic_fuzzy_skin_outside_only": true
},
"colours": 32
}-->
![Dış taraf bulanık olur, ancak iç taraf bulanık değildir](../images/magic_fuzzy_skin_outside_only.png)

Belirsiz bir dış katman, modele dokunma hissi veya artan tutuş sağlamak için güzel bir etki olabilir, ancak baskıdan beklediğiniz herhangi bir boyutsal doğruluğu tamamen ortadan kaldırır. Bu, baskının bir şeye monte edilmesi gereken durumlarda sorun olabilir, örneğin bir kulp veya birkaç vida için. Bu gibi durumlar için, belirsiz dış katman etkisini sadece baskının dış konturlarına devre dışı bırakabilirsiniz.