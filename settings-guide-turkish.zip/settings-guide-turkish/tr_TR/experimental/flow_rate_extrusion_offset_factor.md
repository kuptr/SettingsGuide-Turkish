Akış hızı dengeleme çarpanı
====
Akış oranı telafisi, Marlin'in [Linear Advance/Doğrusal İlerleme](http://marlinfw.org/docs/features/lin_advance.html) işlevine benzer bir denemedir. Akış oranı telafisi, nozuldan malzemenin çıkış hızının değiştiği durumlarda oluşan azaltma ve aşırı extrüzyonu telafi etmek amacıyla kullanılır. Bu ayar, bu etkinin büyüklüğünü yapılandırır.

Akış oranı telafisi, her hareket sırasında her bir sonraki saniyede bir artan ilave malzeme ile ileri hareket ettirir. Hareketler arasında üç farklı senaryo vardır:
* İki bitişik hareket komutu aynı akış oranına sahipse (çünkü çizgi genişlikleri, katman yükseklikleri ve hızları aynıdır), ileriye doğru da aynı ilerleme olacaktır. Bu durumda filament bu çizgiler arasında herhangi bir yöne hareket ettirilmez.
* Eğer bir sonraki çizgiyle birlikte akış oranı artarsa, ikinci çizgi sırasında filament daha ileri doğru hareket ettirilir. Bu, nozul odasındaki basıncı artırır, böylece malzeme daha hızlı extrüde edilir.
* Eğer bir sonraki çizgi ile akış oranı azalırsa, ikinci çizgi sırasında filament geriye doğru hareket ettirilir. Bu, nozul odasındaki basıncı azaltır, böylece malzeme ikinci çizgi ve sonraki çizgilerin baskısı sırasında yavaşlar.

Filamentin hareket ettiği mesafe, çizginin her saniye extrüde edilmesi gereken malzeme miktarına eşittir (eğer çizgi yeterince uzunsa bir saniye boyunca extrüde edilmesi gereken malzemeyi yazdırmak). Ancak bu ayar kullanılarak bu mesafe ayarlanabilir. Faktörü artırmak telafi etkiyi güçlendirirken, azaltmak telafi etkiyi zayıflatır. Daha yüksek faktörler aynı zamanda daha fazla zaman alır, çünkü filamentin daha fazla yukarı ve aşağı hareket ettirilmesi gerekir.

Eğer bu akış oranı telafisi etkinleştirilirse, nozul odası içindeki basınç, gelecek akış oranı ile başa çıkmak için daha iyi donatılmış olacaktır. Bu, hem alt extrüzyonu hem de aşırı extrüzyonu azaltabilir ve nesnenin daha doğru boyutlara sahip olmasını sağlar.

Ancak telafi sadece bir tek çizgi sırasında uygulanır. Bu bazen çok kısa bir çizgi olabilir, bu durumda filamentin çok hızlı hareket etmesi gerekebilir. Feeder'ın bu durumda ayak uydurabilmesi için baskı kafası yavaşlamak zorunda kalabilir, bu da bir topak oluşturabilir. Bazen bu uzun bir çizgi olabilir, bu da etkinin gücünü azaltır. Bu nedenle extrüzyon oranları için telafi etme özelliği güvenilmezdir ve bu ayarın hala deneysel olduğu nedenidir.