Belirsiz Dış Katman
====
Belirsiz Dış Katman ile baskı yaparken, baskının yan yüzeyi bilinçli olarak kaba yapılmıştır. Bu baskıya bir tür doku kazandırır.

<!--screenshot {
"image_path": "magic_fuzzy_skin_enabled.png",
"models": [{"script": "hexasphericon.scad"}],
"camera_position": [-61, 112, 136],
"settings": {
    "magic_fuzzy_skin_enabled": true
},
"colours": 32
}-->
![Cura'nın katman görünümünde duvarlar dalgalı görünüyor](../images/magic_fuzzy_skin_enabled.png)
![Baskı sonucu kaba bir doku gösterir](../images/magic_fuzzy_skin_photo.jpg)

Bu mod dış duvara rastgele bir titreme ekler. Baskı kafası en dış duvarı rastgele olarak titretir. Bu, yüzeyin dokunulduğunda kaba hissetmesini sağlar. Yüzey sadece baskının yan yüzeylerine bulanık yapılır. Üste herhangi bir bulanıklık eklenmez.

Bulanıklık tüm boyutsal doğruluğu ortadan kaldırır. Baskı kesinlikle orijinal modelden daha büyük olacaktır. Belirsiz Dış Katman aynı zamanda baskının daha uzun sürmesine neden olur, çünkü baskı kafası dış duvarı yazdırırken çok hızlı ivmelenmelere maruz kalır.