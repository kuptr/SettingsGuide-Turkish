Radye Tabanı Duvar Sayısı
====
Radye genellikle sadece lineer bir desenden oluşur, ancak radyenin taban katmanı etrafında ek duvarlar bulunabilir. Bu duvarlar, desen çizgilerini yapıştırma tablasına daha iyi yapıştırabilmek için desen çizgilerini tutar. Bu ayar, radyenin taban katmanını çevreleyecek duvar sayısını seçer.

![Taban katmanının radye içinde konumlandığı yer](../images/raft_dimensions_simplified.svg)

En az bir duvarın olması neredeyse her zaman iyi bir fikirdir. Radyenin çizgileri ayrı çizgilerdir, başlangıç ve bitiş noktaları vardır. Bu çizgiler birbirlerinden ayrı yazdırıldığında, nozül hareket ettiğinde bazı çizgilerin yapışma tablasından kopmasına neden olabilir. Bu çizgilerin katı bir şeye, örneğin bir duvara, yapıştırılması, gevşemeye daha az yatkın olmalarını sağlar.

Taban katmanının etrafında birden fazla duvar bulunması yapışmayı daha da iyileştirir. Bu durumda radye, bir [Kenar](../platform_adhesion/adhesion_type.md) gibi davranmaya başlar. Ancak ek duvarlar daha uzun sürede yazdırılır. Çoğu baskı için bir duvar yeterlidir.