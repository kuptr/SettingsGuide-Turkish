Köprü Yüzey Alanı Akışı
====
Bu ayar, köprülenen alt kenarların yazdırılması için çıkarılan malzeme miktarını ayarlar.

<!--screenshot {
"image_path": "bridge_skin_density_100.png",
"models": [{"script": "bridge.scad"}],
"layer": 80,
"settings": {
    "bridge_settings_enabled": true,
    "bridge_skin_density": 100,
    "bridge_skin_material_flow": 100,
    "bridge_wall_material_flow": 100
},
"camera_position": [0, 18, 79],
"colours": 64
}-->
<!--screenshot {
"image_path": "bridge_skin_material_flow_50.png",
"models": [{"script": "bridge.scad"}],
"layer": 80,
"settings": {
    "bridge_settings_enabled": true,
    "bridge_skin_density": 100,
    "bridge_skin_material_flow": 50,
    "bridge_wall_material_flow": 100
},
"camera_position": [0, 18, 79],
"colours": 64
}-->
![%100 akışta, çizgiler normal çizgi genişliklerinde çizilir](../images/bridge_skin_density_100.png)
![%50 akışta, çizgiler daha ince yapılır.](../images/bridge_skin_material_flow_50.png)

Malzeme miktarını azaltmak, boşluğu köprüleyen alt kenarın çizgi genişliğini etkili bir şekilde azaltacaktır. Azaltılmış çizgi genişliği ile çizgilerin yüzeyden kütleye oranı daha büyük olur, bu da onların daha hızlı soğumasını sağlar ve bu, sarkmaları önlemeye yardımcı olur.

Ancak akış hızını fazla azaltmak, özellikle de [Köprü Yüzey Alanı Hızı](bridge_skin_speed.md) ile birleştirildiğinde, akış hızında büyük bir değişikliğe neden olur. Gerçekte malzeme, akış hızlarını çok hızlı bir şekilde değiştiremez, bu nedenle akış hızı yavaşladığında çizgilerin istenenden biraz daha kalın, akış hızı hızlandığında ise istenenden biraz daha ince olmasına neden olur.