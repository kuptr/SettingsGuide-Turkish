Köprü Duvarı Hızı
====
Bu ayar, boşluğu köprülerken duvar çizgilerinin yazdırılma hızını kontrol eder.

Fanın açılmasını ve yüksek hızda çalışmasını gerektiren malzemeler (örneğin PLA) için köprülerin çok yavaş yazdırılması genellikle daha iyidir. Bu, fanların malzemenin üzerine çok fazla hava üflemesine olanak tanır ve bu da malzemenin çok hızlı bir şekilde katılaşmasına neden olur. Böylece malzeme fazla sarkma şansı bulamaz. Bu, fanın bu kadar hızlı dönmesine gerek olmayan malzemeler veya çok güçlü bir fana sahip olmayan yazıcılar için daha az etkilidir.

Ancak, yavaş yazdırmak, nozül açıklığından malzemenin ekstrüze edilmesi gereken hızda büyük bir değişiklik yaratacaktır. Yazıcı kafası genellikle çok hızlı bir şekilde yavaşlayabilse de, nozül odasındaki malzeme, nozül odasındaki gizli basınç nedeniyle bir süre daha akmaya devam edecektir. Bu nedenle, yazıcı kafası yavaşladıkça, köprü çizgisinin başlangıcında bir miktar fazla ekstrüzyon olacaktır. Yazıcı kafası tekrar hızlandığında ise bir miktar yetersiz ekstrüzyon olacaktır. Hızı, normal [Duvar Hızı](../speed/speed_wall.md)'na yakın tutmak, bunun olmasını engeller.

Genel olarak, PLA gibi düşük sıcaklıklarda yazdırılan malzemelerle köprü duvarlarını çok yavaş yazdırmak daha iyidir. Polikarbonat gibi yüksek sıcaklıklarda yazdırılan malzemelerle yazdırırken, köprü duvarlarını normal duvar hızıyla aynı hızda yazdırmak daha iyidir.