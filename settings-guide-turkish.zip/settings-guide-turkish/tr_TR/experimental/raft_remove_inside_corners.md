Radye İç Köşelerini Kaldır
====
Bu ayar etkinleştirildiğinde, radyenin tüm iç köşeleri tamamen kaldırılır ve radye [convex shape (dış bükey)](https://en.wikipedia.org/wiki/Convex_set) bir şekle dönüşür. Radye sadece dış köşelere sahip olacaktır.

<!--screenshot {
"image_path": "raft_remove_inside_corners.png",
"models": [{"script": "microwave_hook.scad"}],
"camera_position": [59, 59, 200],
"settings": {
	"adhesion_type": "raft",
	"raft_remove_inside_corners": true
},
"colours": 64
}-->
![Radye artık modelin şeklini takip etmez](../images/raft_remove_inside_corners.png)

Bu etkili bir şekilde çok yüksek bir (yumuşatma) [Radye Düzeltme](../platform_adhesion/raft_smoothing.md) elde etmeye eşdeğerdir. Radyenin iç köşelerini kaldırmak, radye üzerinde bir dizi etkiye sahiptir:
* Radyenin bazı küçük parçalarının geri kalanından daha fazla uzaması artık mümkün değildir. Özellikle yüksek sıcaklıkta baskı yapılan malzemelerde, radyenin küçük parçaları yapışma tablasından daha kolay kopabilir. İç köşelerin kaldırılması bu etkiyi azaltır ve baskının daha güvenilir olmasını sağlar.
* Radye daha büyük hale gelir, yapışma kuvvetini artırır.
* Radyenin yazdırılması daha uzun sürer ve daha fazla malzeme kullanır.