Maksimum Küçük Özellik Uzunluğu
====
Baskının küçük detayları genellikle boyut açısından çok hassastır. Bu ayar, baskıdaki küçük deliklerin daha büyük bir doğruluk elde etmek için daha yavaş bir şekilde basılmasını sağlar.

Eğer baskıdaki bir deliğin çevresi bu ayar tarafından belirtilenden daha az ise, o deliğin çevresinin baskı hızı [Küçük Özellik Hızı](small_feature_speed_factor.md) faktörü ile çarpılır (genellikle azaltılarak). Bu ayar, sadece dairesel delikler için değil, daha genel bir yaklaşımda bulunan [Maksimum Küçük Delik Boyutu](small_hole_max_size.md) ayarından farklıdır.

Bu özelliğin yaygın kullanım durumu, vida deliklerini çok hassas boyutlarda basmaktır. Küçük deliklerin basımı sırasında boncuk uç ve nozülün köşeye doğru çekilme eğilimi gösterir. Köşe çok keskin ise, küçük deliklerde bu çekilme deliği daha küçük yapma etkisine sahiptir. Daha yavaş basılması bu çekilmeyi azaltır çünkü malzemenin oturması için daha fazla zaman sağlar ve mekanik çekme basitçe daha düşüktür.

Bu ayarı artırmak, daha fazla konturun "küçük özellik" olarak işaretlenmesine neden olur. Baskıdaki deliklerin daha büyük bir kısmı daha yavaş basılır. Bu deliklerin daha doğru bir şekilde basılmasına yol açar, ancak baskı süresini artırır.