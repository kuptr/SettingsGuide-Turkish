WP Bottom Delay
====
Bu ayar ile, nozül, çapraz aşağı doğru bir çizgi yazdırdıktan sonra bir süre duracak.

![Nozülün duraklayacağı konum](../images/wireframe_bottom_delay.svg)

Nozül duraklarken, bir miktar malzeme akıtacak ve orada bir damlacık oluşturacak. Bu damlacık, altındaki yatay halkaya testere dişi desenini bağlamaya yardımcı olur. Baskının dayanıklılığını ve güvenilirliğini artırır.

Ancak, gecikme eklemek baskı süresini önemli ölçüde artırır. Nozülün duraklayacağı birçok yer bulunmaktadır.