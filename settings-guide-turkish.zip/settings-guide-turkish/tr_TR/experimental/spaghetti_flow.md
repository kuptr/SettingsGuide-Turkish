Spaghetti Akışı
====
Bu ayar doğrudan spagetti dolgu yoğunluğunu ayarlar.

Normalde, dolgu basılırken [Dolgu Yoğunluğu](../infill/infill_sparse_density.md) ayarı sadece [Dolgu Hattı Mesafesi](../infill/infill_line_distance.md)'ni etkiler. [Dolgu Hattı Genişliği](../resolution/infill_line_width.md) aynı tutulur ancak çizgiler birbirlerine daha yakın yerleştirilir, dolgu yoğunluğunu artırmak sonunda dolgu hacminin daha büyük bir kısmının malzeme ile doldurulmasını sağlar.

Bu, [spaghetti dolgusu](spaghetti_infill_enabled.md) etkinleştirilmişse farklı şekilde çalışır. Dolgu çizgi mesafesi sadece dolgu çizgileri arasındaki mesafeyi ayarlamaz, aynı zamanda çizgi genişliği de bu ayar tarafından belirlenen istenen yoğunluğa ulaşmak için ayarlanır. Bu ayar, toplam dolgu hacminin tam olarak hangi kesirinin malzeme ile doldurulacağını belirler. Bu ayarı artırmak çizgilerin daha geniş olmasına neden olur.

Spaghetti dolgu kullanarak esnek dolgu üretirken, bu ayar esasen dolgu malzemesinin ne kadar sert olacağını belirler. Akışı azaltmak daha yumuşak bir dolgu oluştururken, akışı artırmak dolguyu daha sert hale getirir. Ancak akışı çok fazla azaltmak dolgunun eşit şekilde dağılmasını önler. Bu durum dolgunun hacmin altına doğru düşmesine ve burada spagetti yığınları oluşturmasına yol açabilir, bu yığınlar üst kısmın sertliğine katkıda bulunmaz.

Malzeme dökümü için spagetti dolgu kullanırken, bu ayar muhtemelen modeli tamamen malzeme ile doldurmak için yaklaşık %100 civarında ayarlanmalıdır. Ancak malzemenizin kururken büzülme veya genleşme eğilimi varsa, bu ayarı hafifçe ayarlayabilirsiniz.

**Bu ayar hala [Dolgu Akışı](../material/infill_material_flow.md) ayarı ile çarpılır.**