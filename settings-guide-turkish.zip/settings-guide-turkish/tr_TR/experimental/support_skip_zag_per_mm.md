Destek Parçasının Boyutu
====
Eğer destek [parçalara ayrıldığında](support_skip_some_zags.md), bu ayar, destek parçalarının her birinin ne kadar büyük olacağını belirler.

<!--screenshot {
"image_path": "support_skip_some_zags.png",
"models": [{"script": "rack.scad"}],
"camera_position": [0, 184, 10],
"settings": {
    "support_enable": true,
    "support_pattern": "zigzag",
    "support_skip_some_zags": true,
    "support_skip_zag_per_mm": 20
},
"colours": 32
}-->
![Her bir parça yaklaşık olarak 20mm genişliğindedir](../images/support_skip_some_zags.png)

Daha küçük parçalar genellikle daha kolay kırılır. Modelle yapışacak daha az yüzey alanı olduğu için destekleri çekmek için daha az kuvvet gerekecektir. Ancak daha fazla parça çıkarılması gerekecektir, bu yüzden eğer destek çıkarmak normalde zor değilse, bu ayar destekleri çıkarmayı daha zor hale getirebilir. Her parça tek tek çıkarılmalıdır, tüm destekleri tek bir büyük parça halinde çıkarmak yerine.

Eğer parçalar çok küçük yapılırsa, desteklerin yapısal bütünlüğü tehlikeye girebilir. Destek deseni daha çok çizgi desenine benzeyecek ve devrilme olasılığı daha yüksek olacaktır. Bu durum, destek devrildiği yerlerde daha fazla ipliklenme ve kötü aşma kalitesine neden olabilir.