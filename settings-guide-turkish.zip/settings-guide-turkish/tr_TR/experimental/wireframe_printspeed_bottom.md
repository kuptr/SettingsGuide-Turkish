WP Bottom Printing Speed
====
Bu ayar, Tel Baskı kullanılırken baskının başlangıç katmanındaki konsantrik halkaların baskı hızını yapılandırır. İlk düz katmanın baskı hızı, diğer yatay katmanlardan ayrı olarak yapılandırılabilir.

![Farklı Tel Baskı hızlarının uygulandığı yerler](../images/wireframe_printspeed.svg)

İlk düz katmanda, tel baskı tekniği köprü yapmaya gerek duymaz. Malzemenizin katılaşma özelliklerine ve yazıcınızın fan hızlarına bağlı olarak, alt hızı genellikle diğer düz katmanlardan biraz daha yavaş yazdırılabilir.