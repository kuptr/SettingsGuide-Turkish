Köprü Üçüncü Yüzey Alanı Fan Hızı
====
Bu ayar, köprünün üzerindeki üçüncü katmanın yüzeyini yazdırırken fan hızını kontrol eder. Bu fan hızı, normalde kullanılacak olan [Fan Hızı](../cooling/cool_fan_speed.md) yerini alır.

Eğer ilk ve ikinci köprü katmanları için [Köprü Fan Hızı](bridge_fan_speed.md) artırılmışsa, muhtemelen üçüncü katman için de fan hızını artırmak istersiniz. Bu, malzemenin daha hızlı soğumasını sağlar ve önceki katmana daha az yaslanmasına neden olur. Gerçekten önemli bir dezavantajı yoktur. Teorik olarak, fan hızını çok fazla artırmak, katmanların çok zayıf bir şekilde bağlanmasına neden olarak dayanıklılığı azaltabilir. Ancak köprü sırasında katmanlar zaten çok zayıf bir şekilde bağlanır, bu nedenle fan hızını azaltmaktan kaynaklanan çok az dayanıklılık kazancı vardır.

Ancak, bazı yüksek sıcaklıklı malzemeler için fanı çok yüksek açmak, yetersiz ekstrüzyona veya hatta nozulun tamamen tıkanmasına neden olabilir.