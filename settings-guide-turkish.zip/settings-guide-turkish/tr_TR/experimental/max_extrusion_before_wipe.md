Sürme Hareketleri Arasındaki Malzeme Hacmi
====
Her katmanda temizlemenin yanı sıra, belirli bir malzeme miktarı basıldıktan sonra temizlemek isteyebilirsiniz. Bu ayar, temizlemeler arasında basılacak maksimum malzeme miktarını yapılandırır. Bir katmanda bu miktarın üstünde malzeme bulunursa, katmanın yarısında bir temizleme başlatılabilir.

Her katmanda temizleme yapmanın avantajı, zaten katman değişiminde bir dikiş olacak olmasıdır. Bu, nozülü baskıdan uzaklaştırmanın uygun bir anıdır çünkü ek bir dikiş oluşturmaz. Ancak bir katmanda çok fazla ekstrüzyon olursa (genellikle cilt içeren katmanlar için geçerlidir), malzeme hala nozülde birikebilir. Bu durumlar için, malzeme arası temizleme miktarı maksimumunu ayarlamak, nozülün temiz kalmasına yardımcı olabilir.

**Bu ayar hiçbir zaman uygulanmadı. Baskı üzerinde hiçbir etkisi yoktur.**