Akış hızı dengelemesi maksimum ekstrüzyon kayması
====
Akış oranı telafisi, Marlin'in [Linear Advance/Doğrusal İlerleme](http://marlinfw.org/docs/features/lin_advance.html) işlevine benzer bir denemedir. Akış oranı telafisinin amacı, nozuldan çıkan malzemenin akış hızı değiştikçe oluşan alt extrüzyon ve aşırı extrüzyonu telafi etmektir. Bu ayar, malzemenin telafi için geri çekilebileceği veya itilebileceği maksimum mesafeyi sınırlar.

Akış oranı telafisi, baskı sırasında filamentin orijinal konumundan daha ileriye veya daha geriye hareket etmesini sağlar. Bu ayar, filamentin orijinal konumundan ne kadar uzaklaşmasına izin verileceğini sınırlar.

Telafi, baskı boyunca ekstra filament hareketleri ekler. Bu hareketler zaman zaman filamenti hareket ettirmek için baskı kafasının yavaşlamasına neden olur. Bu etkiyi azaltmak için filamentin hareket edebileceği mesafeyi sınırlayabilirsiniz. Bu, feeder'ın ayak uydurabilmesi için baskı kafasının yavaşlamasını önler. Ancak bu, akış oranı telafisini daha az etkili hale getirir.