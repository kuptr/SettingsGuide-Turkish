Sürme Geri Çekme Hızı
====
Bu ayar, malzemenin silme işlemi için ne kadar hızlı geri çekildiği ve geri itildiği şeklinde yapılandırılır. Bu, normal [gGeri Çekme Hızı](../travel/retraction_speed.md)ndan ayrı olarak yapılandırılabilir.

Nozuldan akabilen herhangi bir malzeme bu silme işlemi sırasında zaten silineceğinden, bu işlem için geri çekme hızı baskı işleminin geri kalanına kıyasla biraz azaltılabilir. Bu, filament üzerindeki aşınmayı azaltır.