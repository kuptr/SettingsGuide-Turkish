Çıkıntılı Duvar Açısı
====
Bu ayar, bir duvarın "aşağısalım duvarı" olarak işaretleneceği eşiği gösterir. Bu aşağısalım duvarları, [Çıkıntılı Duvar Hızı](wall_overhang_speed_factor.md) ayarı kullanılarak farklı bir hızda basılabilir.

Eğer bu ayar 0° olarak ayarlanırsa, tüm duvarlar aşağısalım duvarları olarak işlem görür. Eğer bu ayar 90° olarak ayarlanırsa, hiçbir duvar aşağısalım duvarı olarak işaretlenmez. Destek üzerinde dinlenen duvarlar da aşağısalım duvarları olarak işlenmez.

Bu özelliğin amacı, [Oluşturma Desteği](../support/support_enable.md) ile desteklenmesi gereken ancak tam olarak desteklenmeyen alanlarda daha iyi aşağısalım kaliteleri sağlamaktır. Destek ve bu desteklerin çıkarılmasında yüzeyi çizmeyi önlemek için ekstra zaman ve malzeme harcamak yerine, bu aşağısalım duvarlarını biraz daha yavaş basabilir ve [Destek Çıkıntı Açısı](../support/support_angle.md) ayarını biraz daha yüksek ayarlayabilirsiniz. Bu, artan aşağısalım açılarının daha iyi basılması için daha aşamalı bir yaklaşım sağlar.

Bu ayar, Destek Aşağısalım Açısından daha yüksek ayarlandığında etkisini büyük ölçüde azaltır, çünkü destek üzerindeki duvarlar aşağısalım duvarları olarak işaretlenmez ve böylece aşağısalım duvarı olarak kabul edilen bir açıda basılan duvarlar da desteklenir ve farklı hızlarda basılmaz. Ancak destek devre dışı bırakıldığında veya [Minimum Destek Bölgesi](../support/minimum_support_area.md) gibi diğer nedenlerden dolayı desteklenmeyen aşağısalım parçaları için bu özelliğin etkisi devam eder.