Ağaç Destek Duvar Çizgi Sayısı
====
Bu ayar, ağaç destek içinde çizilecek kontur sayısını belirler. Daha fazla kontur, ağaç destek daha rijit olacaktır.

![İki Duvar](../images/support_tree_wall_count.png)

Daha fazla duvar destek, özellikle büyük [Maksimum Dal Açısı](../support/support_tree_angle.md) ile destek çok daha sağlam yapar. Bu, baskının güvenilirliğini artırır ve destek dallarının kırılma olasılığını azaltır.

Ancak bu, destek üzerinde harcanan zamanı ve malzemeyi büyük ölçüde artırır.

Bu ayar, [Duvar Hattı Sayısını Destekle](../support/support_wall_count.md) ayarı ile çok benzer şekilde çalışır.