Bridge Second Skin Speed
====
Bu ayar, köprünün üstündeki ikinci katmanın cilt çizgilerinin baskı hızını kontrol eder.

Fanın açılması ve yüksek devirde dönmesi gereken malzemeler için (örneğin PLA gibi), köprüleri çok yavaş bir şekilde yazdırmak genellikle daha iyidir. Bu, fanların malzemenin üzerine çok miktarda hava üflemesine olanak tanır, bu da onların çok hızlı bir şekilde katılaşmasını sağlar. Malzeme o zaman sarkmaya çok fazla şans bulmaz, bu da onların ilk köprüleme katmanına dayanmasına ve bunun daha fazla sarkmasına neden olur. Bu, fanın dönme hızının çok yüksek olmasını gerektirmeyen malzemeler veya çok güçlü bir fanı olmayan yazıcılar için daha az etkilidir.

Daha yavaş yazdırmak, malzemenin nozul açıklığından çıkarılması gereken akış hızında büyük bir değişiklik yaratacaktır. Bu akış hızındaki değişiklik bir süre alır, bu da köprünün hızlanması ve ardından akış hızında azalma olduğunda aşırı çıkarımı ve sonrasında eksik çıkarımı sağlar. İkinci katman, normal köprüleme katmanına göre aşağı sarkıntı kalitesi için daha az kritiktir, bu nedenle aşırı ve eksik çıkarmayı önlemek için ikinci katmanın, normal [Üst/Alt Hız](../speed/speed_topbottom.md)'ını daha yakın bir hızda yazdırılması daha iyidir.

Genel olarak, soğuk sıcaklıklarda baskı yapan malzemelerle (örneğin PLA ile) köprüleme cilt çizgilerini yavaşça yazdırmak daha iyidir. Yüksek sıcaklık malzemeleriyle baskı yaparken, köprüleme cilt çizgilerini normal üst/alt hızına yaklaşık olarak aynı hızda yazdırmak daha iyidir, örneğin polikarbonat gibi.