Köprü Üçüncü Yüzey Alanı Yoğunluğu
====
Bu ayar, köprünün üstündeki üçüncü katmanın cilt yoğunluğunu kontrol eder. %100 yoğunlukta, çizgiler doğrudan bitişiktir. Daha düşük yoğunluklarda, çizgiler daha aralıklıdır.

Cilt çizgilerini doğrudan birbirine bitiştirdiğinizde, birbirine yapışırlar. Bu, modelin su geçirmez olmasına yardımcı olur ve baskının alt tarafında daha pürüzsüz görünmesini sağlar. Ayrıca, sonraki çizgilerin bir önceki çizgilere biraz dayanmasına izin vererek sarkmayı önler.

Ancak malzeme soğumakta zorlanacaktır. Cilt çizgileri arasında bir miktar boşluk olduğunda, hava boncuklarının etrafında dolaşabilir ve bunların soğuması ve katılaşması hızı önemli ölçüde artar. Tabii ki, bu sadece fan açıkken geçerlidir, bu nedenle yüksek sıcaklıkta malzemeler için bu strateji çalışmayacaktır. Üçüncü katmanda sarkma etkisi de azalır çünkü birinci ve ikinci katlara yaslanabilir, bu nedenle bu kat için pürüzsüzlük gibi diğer faktörler daha belirleyicidir. Ayrıca, en alt kısmın su geçirmez veya düzgünlük hissi için tamamen kapalı olmasını isteyeceğiniz bir noktada olduğunu unutmayın.

Bu etkilerden hangisinin daha güçlü olduğu, malzemenin viskozitesine, ne kadar hızlı katılaştığına ve fan hızına bağlıdır. Her zaman biraz ayarlama gereklidir.

**Eğer [Köprü Üçüncü Yüzey Alanı Akışı](bridge_skin_material_flow_3.md) %100'den az ise, yoğunluk %100 olsa bile, çizgiler daha ince olduğu için aralarında bazı boşluklar olacaktır.**