Sürme Geri Çekmenin Etkinleştirilmesi
====
Bu ayar etkinleştirildiğinde, silme işlemi sırasında malzeme geri çekilecektir. Bu, normal [Geri Çekmeyi Etkinleştir](../travel/retraction_enable.md)'den ayrı olarak yapılandırılabilir.

Silme işlemi, nozülün yazıcı tarafındaki kenara kadar gitmesini, orada ileri geri hareket etmesini ve ardından geri dönmesini içerir. Bu aslında çok uzun bir seyahat hareketidir. Bu seyahat hareketi, baskı boyunca yapılan ortalama seyahat hareketlerinden daha uzundur, bu nedenle normalde geri çekmeler devre dışı bırakılsa bile bu işlem sırasında malzemenin geri çekilmesini isteyebilirsiniz.

Malzemenin geri çekilmesi, silme işlemi sırasında sızan malzemenin miktarını azaltacaktır. Silme işlemi sırasında sızan malzeme genellikle fırça ile silinecektir. Ancak bu malzeme kaybedilmiş olur. Sonuç olarak, silme tamamlandıktan hemen sonra bazı eksik ekstrüzyon olabilir çünkü bu malzeme doğru konumuna yerleştirilmesi gereken yerine sızdı.

Öte yandan, geri çekme zaman alabilir ve filamanda gereksiz aşınmaya neden olabilir. Eğer eksik ekstrüzyon sorunu yaşanmıyorsa, geri çekmeyi devre dışı bırakmak zaman kazandırabilir ve güvenilirliği artırabilir. Örneğin, [Duvarlardan Önce Dolgu](../infill/infill_before_walls.md) yazdırılıyorsa, dolgu sırasında bazı eksik ekstrüzyon pek sorun oluşturmaz. 