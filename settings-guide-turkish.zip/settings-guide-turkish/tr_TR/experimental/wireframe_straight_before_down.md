WP Straighten Downward Lines
====
Bu ayar, Tel Baskı sırasında malzemenin sarkmasını telafi etmek için uygulanabilecek başka bir telafi faktörüdür. Testere dişi deseni için doğrudan çapraz aşağı hareket etmek yerine, bu ayar nozülün belirli bir tel uzunluğu boyunca önce yatay hareket etmesini ve ardından aşağı hareket etmesini sağlar.

![Önce düz yatay hareket ediyor, sonra aşağı iniyor](../images/wireframe_straight_before_down.svg)

Düz yatay hareket, malzemenin önce hafifçe yukarıya doğru çekilmesini amaçlar ve ardından aşağı iner. Doğru ayarlandığında, bu malzemenin düz bir çapraz olarak aşağı gitmesini sağlar, sarkık bir eğri oluşturmaz. Bu, testere dişi desenini daha güçlü hale getirir ve dişlerin uçlarının bir sonraki yatay halkayı desteklemek için daha iyi durmasını sağlar.