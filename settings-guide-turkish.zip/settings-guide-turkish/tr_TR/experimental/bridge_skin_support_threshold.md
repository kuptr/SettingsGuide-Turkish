Köprü Yüzey Alanı Destek Eşiği
====
Bu ayar, köprüleme alanlarının tespitinin ne kadar duyarlı olacağını ayarlamanıza olanak tanır. Köprüleme alanları, önceki katmanda bir şey tarafından desteklenen cildin alanının bir parçası olma özelliği sayesinde tespit edilir.

Her bir ayrık cilt bölgesi için, bu, o cildin ne kadarının alttaki katman tarafından desteklendiğine bakar. Eğer bölge çok az destekleniyorsa, o zaman köprüleme tekniği, desteklenmeyen cildin bölgelerine uygulanır.

Cilde köprü tekniği uygulamak, akış hızında ve baskı hızında değişikliklere neden olur. Bunlar, malzemenin nozuldan dökülme hızını ayarlamaya çalışır, ancak bu genellikle zor değiştirilir. Sonuç olarak, akış hızı kendisini ayarlamaya çalışırken bazı baskılarda aşırı çıkarım ve diğer bazı baskılarda eksik çıkarım olacaktır. Bu nedenle, çok küçük bir askı parçası için akış hızını ayarlamak, muhtemelen baskı kalitesini iyileştirmek yerine azaltacaktır.

Bu ayarı artırmak, köprüleme tekniğinin daha küçük askıların daha az etkili olduğu ancak akış hızının hala kesintiye uğradığı daha fazla küçük parçaya uygulanmasına neden olur. Bu ayarı azaltmak, köprüleme tekniğinin yalnızca çok büyük askılı alanlara uygulanmasına neden olur. Bu, akış değişikliklerine neden olmaz, ancak daha küçük askı alanları için askı kalitesini azaltabilir.