Maksimum Küçük Delik Boyutu
====
Baskının küçük detayları genellikle boyut açısından çok hassastır. Bu ayar, baskıdaki küçük deliklerin daha büyük bir doğruluk elde etmek için daha yavaş bir şekilde basılmasını sağlar.

Eğer bir daire şeklindeki deliğin çapı bu ayarın değerinden daha küçükse, o deliğin çevresinin baskı hızı [Küçük Özellik Hızı](small_feature_speed_factor.md) (reduced, normally) faktörü ile çarpılacaktır (genellikle azaltılır). Dairesel olmayan delikler için ise, çevresi burada belirtilen çapta bir dairenin çevresinden daha küçükse farklı bir hızda basılacaktır. Ayrıca [Maksimum Küçük Özellik Uzunluğu](small_feature_max_length.md) ayarına bakınız; bu ayar aslında dilimlemede kullanılacak olan ayardır.

Bu özellik için yaygın bir kullanım durumu, vida deliklerini çok hassas boyutlarda basmaktır. Küçük deliklerin basımı sırasında boncuk uç ve nozülün köşeye doğru çekilme eğilimi gösterir. Köşe çok keskin ise, küçük deliklerde bu çekilme deliği daha küçük yapma etkisine sahiptir. Daha yavaş basılması durumunda, bu çekilme azalır çünkü malzemenin yerleşmesi için daha fazla zaman vardır ve mekanik çekme basitçe daha düşüktür.

Bu ayarı artırmak, daha fazla konturun "küçük özellik" olarak işaretlenmesine neden olur. Baskıdaki deliklerin daha büyük bir kısmı daha yavaş basılır. Bu, bu deliklerin daha doğru bir şekilde basılmasını sağlar, ancak baskı süresini artırır.