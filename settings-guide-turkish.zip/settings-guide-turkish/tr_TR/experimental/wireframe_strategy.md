WP Strategy
====
Tel Baskı'nın güvenilirliği için en kritik konu, çerçevenin katmanlarının birbirine bağlandığı bağlantı noktalarıdır. Bu bağlantıları daha güçlü hale getirmek için çeşitli stratejiler mevcuttur. Bu ayar, yazıcının kullanacağı stratejiyi seçmenizi sağlar.

Telafi (Compensate)
----
Bu strateji kullanıldığında, yazıcı malzemenin sarkma faktörlerini telafi etmeye çalışacaktır. Malzeme nozülden erimiş olarak çıktığında katılaşmadan önce biraz aşağı düşer ve nozülün hareketleriyle sürüklenir. Bu strateji, çerçevenin katmanlarını birbirine bağlayan testere dişi deseni dikey olarak deforme eder, böylece umarız tekrar doğru konumda sonlanır.

İki telafi faktörü mevcuttur: Birincisi, sadece [compensate for sagging/sarkmayı telafi etmek için](wireframe_fall_down.md) testere dişi desenini dikey olarak deforme eder; ikincisi, nozülle birlikte [compensate for the material being dragged along/sürüklenen malzemeyi telafi etmek için](wireframe_drag_along.md) testere dişi desenini çapraz yönde deforme eder.

Düğüm (Knot)
----
Bu strateji seçildiğinde, her testere dişi deseninin üstünde biraz yukarıya ve geriye doğru hareket yapılır, böylece orada bir "düğüm" oluşturulur. Düğümün amacı, üzerine gelecek yatay halkanın testere dişi desenine bağlanabileceği bir alan sağlamaktır. Düğüm, biraz yan tarafa doğru da değişebilir, bu nedenle eğer yatay halka çok doğru bir şekilde yerleştirilmezse birbirlerine bağlanma şansı daha fazladır. Ayrıca, düğüm yukarı doğru çizgiyi biraz daha yukarıya doğru uzatır, bu da yatay halkanın üstüne itilmesine neden olur. Son olarak, düğüm bu seyahat hareketinde geri çekilme olmadığından biraz damlatma yapar. Bu, yatay halkanın daha iyi dinlenebileceği bir damlacık oluşturur.

![Düğümün nerede çizildiği ve boyutunun ne anlama geldiği](../images/wireframe_top_jump.svg)

"Düğüm" hareketi, bir dizi seyahat hareketinden oluşur: is a series of travel moves:
1. İlk olarak, nozül hafifçe yukarı ve geriye doğru hareket eder.
2. Eğer üst kısımda [delay/gecikme](wireframe_top_delay.md) varsa, nozül gecikme süresi boyunca duraklar. Bu duraklama, düğüm hareketinin ucunda yapılır.
3. Üçüncü olarak, nozül normal yüksekliğe geri iner. Aynı zamanda, nozül dikey çizgiden uzaklaşmak için ileri doğru hareket eder.

Geri Çekme (Retract)
----
Bu strateji seçildiğinde, testere dişi deseni yazdırılırken her yukarı doğru hareketten sonra malzeme geri çekilir. Bu yaklaşımın amacı, malzemenin çekilerek telin kırılmasını sağlamaktır. Bu sayede malzemenin nozül hareketiyle sürüklenmesi etkisi azalır, çünkü önceki tel artık nozüle bağlı değildir. Daha sonra, nozül 1 milimetrelik küçük bir sıçrama yapar ve aşağıya doğru çapraz hareketine devam eder.

Bu stratejinin önemli bir dezavantajı, çapraz aşağı hareket eden hattın da artık bağlı olmamasıdır. Bu, bu hat boyunca ekstrüzyonun etkisiz hale gelmesine yol açar. Malzeme basitçe alt katmanda bir damla haline gelir. Ayrıca, malzeme sürekli geri çekilip ileri itildiği için öğütülmeye daha fazla maruz kalır. Tüm bu süreçler aynı zamanda çok zaman alır.