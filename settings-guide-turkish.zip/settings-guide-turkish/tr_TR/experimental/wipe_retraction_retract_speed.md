Sürme Geri Çekme Sırasındaki Çekim Hızı
====
Bu ayar, malzemenin silme işlemi için ne kadar hızlı geri çekileceğini yapılandırır. Bu, normal [Geri Çekme Sırasındaki Çekim Hızı](../travel/retraction_retract_speed.md)ndan ayrı olarak yapılandırılabilir.

Nozuldan akabilen herhangi bir malzeme bu silme işlemi sırasında zaten silineceğinden, geri çekme hızı bu işlem için baskı sırasındaki diğerlerine göre biraz azaltılabilir. Bu, filament üzerindeki aşınmayı azaltır.