Cereyan Kalkanı Yüksekliği
====
Eğer [Cereyan Kalkanı Sınırlaması](draft_shield_height_limitation.md) "Sınırlı" olarak ayarlanmışsa, bu ayar taslak kalkanının hangi yüksekliğe kadar sınırlanacağını belirtmenizi sağlar.

<!--screenshot {
"image_path": "draft_shield_height_limitation.png",
"models": [{"script": "headphone_hook.scad"}],
"camera_position": [-56, 139, 305],
"settings": {
    "draft_shield_enabled": true,
    "draft_shield_height_limitation": "limited",
    "draft_shield_height": 20
},
"colours": 32
}-->
![Cereyan kalkanı, maksimum 20mm yüksekliğe sınırlıdır](../images/draft_shield_height_limitation.png)

Baskının alt tarafı genellikle sıcaklık dalgalanmalarına en duyarlı olan kısımdır. Soğuk bir odada bu kısımda çoğu warp oluşabilir ve bu, baskının yapı platformundan ayrılmasına neden olabilir. Bu ayar ile, cereyan kalkanının yüksekliğini belirli bir yüksekliğe sınırlamayı seçebilirsiniz. Cereyan kalkanının yüksekliğini düşürmek, zaman ve malzeme tasarrufu sağlayabilir. Cereyan kalkanı, baskının alt tarafını korumaya devam edecek ve ayrıca sıcak havanın yükselmesiyle oluşan konveksiyonu engelleyecektir (belirli bir ölçüde).

Cereyan kalkanı, nesnenin kendisinden daha yüksek basılamaz.