WP Connection Height
====
Tel Baskı, dış çizgi etrafında bir dizi halka yazdırmayı içerir. Halkalar arasındaki dikey boşluğu bu ayar belirler. Bu ayar ile iki konsantrik halka arasındaki bağlantıların ne kadar uzun olması gerektiğini tanımlayabilirsiniz.

![Tel Baskı, yan görüntülenmiş ve yükseklikle işaretlenmiştir](../images/wireframe_height.svg)

Halkalar testere dişi deseni ile birbirine bağlanır. Bu desen, dikey bir çizgi ve bir çapraz çizgiden oluşur. Dikey çizgi bağlantının tam uzunluğunda olacaktır. Çapraz çizgi ise 45°'lik bir açıyla olacaktır. Bu nedenle, bu ayar yalnızca halkalar arasındaki dikey yüksekliği belirlemekle kalmaz, aynı zamanda testere dişi deseninin yatay boyutunu da belirler. Bu, çerçevenin genel olarak ne kadar yoğun olacağını belirler.

Yüksekliği azaltmak çerçevenin daha yoğun olmasını sağlar. Çerçevenin daha stabil olmasını ve baskının daha güvenilir olmasını sağlar. Ancak baskı süresi de uzayabilir.