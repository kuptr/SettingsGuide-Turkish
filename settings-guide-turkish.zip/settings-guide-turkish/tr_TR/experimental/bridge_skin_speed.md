Köprü Yüzey Alanı Hızı
====
Bu ayar, bir boşluğu köprülerken alt cilt çizgilerinin yazdırılma hızını kontrol eder.

Fanın açılması ve yüksek devirde dönmesi gereken malzemeler için (örneğin PLA gibi), genellikle köprüleri çok yavaş yazdırmak daha iyidir. Bu, fanların malzemenin üzerine çok miktarda hava üflemesine olanak tanır, bu da onların çok hızlı bir şekilde katılaşmasını sağlar. Malzeme o zaman sarkmaya çok fazla şans bulmaz. Bu, fanın dönme hızının çok yüksek olmasını gerektirmeyen malzemeler veya çok güçlü bir fanı olmayan yazıcılar için daha az etkilidir.

Ancak yavaş yazdırmak aynı zamanda nozul açıklığından malzemenin çıkarılması gereken akış hızında büyük bir değişikliğe neden olacaktır. Genel olarak, yazıcı kafası genellikle çok hızlı bir şekilde yavaşlar, ancak nozul odasındaki malzeme, nozul odasındaki latent basınç nedeniyle bir süre daha akışta kalır. Bu nedenle, yazıcı kafası yavaşladığında, köprüleme çizgisinin başlangıcında bir miktar aşırı çıkarım olacaktır. Yazıcı kafası daha sonra tekrar hızlandığında, bir miktar eksik çıkarım olacaktır. Hızı normal [Üst/Alt Hız](../speed/speed_topbottom.md)'ına yakın tutmak, bunun olmasını önler.

Genel olarak, soğuk sıcaklıklarda baskı yapan malzemelerle (örneğin PLA ile) köprüleme cilt çizgilerini çok yavaş yazdırmak daha iyidir. Yüksek sıcaklık malzemeleriyle baskı yaparken, köprüleme cilt çizgilerini normal üst/alt hızına yaklaşık olarak aynı hızda yazdırmak daha iyidir, örneğin polikarbonat gibi.