Wire Printing
====
Bu ayar, Tel Baskı adı verilen tamamen farklı bir baskı modunu etkinleştirir. Tel Baskı kullanıldığında, yazıcı katı bir nesne üretmez, ancak dış şeklin ince tellerden oluşan üçgen bir ağını oluşturur.

Bu teknik birçok avantaja sahiptir:
* Katı bir nesneden çok daha hızlı yazdırır.
* Normal baskıdan kullanacağı malzemenin sadece bir kısmını kullanır.
* 3D baskı kalemi ile manuel olarak oluşturulmuş gibi özel bir görünüme sahiptir.

Ancak, sonuç olarak elde edilen nesne fonksiyonel değildir. Yaklaşık doğru boyutta olacak, bu da baskının ölçek hissini prototip için kullanışlı hale getirir, ancak boyut çok da doğru olmayabilir. Elde edilen nesne son derece kırılgandır, sadece baskı sırasında değil sonrasında da zarar vermeden yapıştırıcı tabakadan çıkarmak zordur. Model ayrıca çoğu detayını kaybedecektir.

Tel Baskı, malzemenin birkaç milimetrelik oldukça geniş dikey boşluklarla halkalar halinde yerleştirilmesiyle çalışır. Bu halkalar arasında bir sonraki halkanın öncekine oturmasını sağlayacak testere dişi şeklinde bir çizim yapılır. Modelin yüzeyi yatay olduğunda, üst kısmı kapatmak için benzer bir teknik kullanılır. Tavan kısmında ise, dışarıdan içeriye doğru yapılarak duvara oturabilecek şekilde dikkatlice havada asılı duran testere dişi şekilde birlikte tutulan konsantrik halkalar bulunur.

Tel Baskı, [Spiral Dış Çevre](../blackmagic/magic_spiralize.md) ile iyi çalışacak türde olan neredeyse tamamen dikey şekillerle güvenilir bir şekilde çalışır. Eğer yüzey büyük alanlar boyunca yatay ise, tavanı kapatma tekniği son derece uzak bir mesafeyi geçmek zorunda kalır ki bu genellikle başarısız olur. Eğer model yatay bir yüzeyin ortasında devam ederse, neredeyse kesinlikle havada baskı yapılacaktır.

**Cura'nın katman görünümü, dilimleme işleminden hemen sonra Tel Baskıyı doğru şekilde göstermeyecektir. Ancak sonucu, g-code'u diske kaydedip daha sonra bu g-code'u Cura ile açarak önizleyebilirsiniz.**