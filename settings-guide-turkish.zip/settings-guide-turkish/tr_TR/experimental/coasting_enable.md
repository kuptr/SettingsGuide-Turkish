Taramayı Etkinleştir
====
Bu ayar etkinleştirildiğinde, nozül duvar konturunu kapatmadan hemen önce malzeme ekstrüzyonunu durduracaktır. Bu, nozül odasının son çizgi parçasında kendini boşaltmasına olanak tanır ve böylece nozül üzerindeki basıncı azaltır, konturun başlangıcı tarafından engellenmesini sağlar. Bu, konturun başladığı yerdeki dikişi azaltır ve sonraki hareket sırasında ipliklenmeyi azaltır.

<!--screenshot {
"image_path": "coasting_enable.png",
"models": [{"script": "phone_holder.scad"}],
"camera_position": [0, -215, 117],
"minimum_layer": 1,
"structures": ["travels", "helpers", "shell", "infill", "starts"],
"settings": {
    "coasting_enable": true,
    "coasting_volume": 0.06,
    "z_seam_position": "backright"
},
"colours": 32
}-->
![Katman görünümünde, tarama işlevi etkinse dikişi görmek kolaydır, çünkü orada bir hareket olacaktır](../images/coasting_enable.png)

Tarama işlevinin etkinleştirilmesi, duvarlardaki dikişlerin görünürlüğünü azaltmayı amaçlar. Normalde büyük ve belirgin dikişleriniz varsa, bu ayarı etkinleştirmek bu etkiyi azaltabilir. Temelde [Dış Duvar Sürme Mesafesi](../shell/wall_0_wipe_dist.md) ayarının yaptığı şeyin tersidir, bu yüzden taramadan önce silme mesafesini azaltmayı denemek iyi bir fikir olabilir.

Teorik olarak, tarama her zaman yetersiz ekstrüzyon üretir. Bunun gerçek baskıda görülüp görülmeyeceği ise duruma bağlıdır. Tarama, doğrudan tahrikli yazıcılarla kullanıldığında daha etkili olma eğilimindedir. Yazıcınız doğrudan tahrikli ise, Bowden tüpleri veya esnek tahrik milleri kullanıldığında olduğundan daha düşük bir [Tarama Hacmi](coasting_volume.md) ayarına sahip olmak isteyeceksiniz, çünkü akış hızının tepkisi çok daha hızlı olur. Bowden tipi besleme sistemlerinde ise tarama miktarını kontrol etmek ve dikişin görünürlüğünü etkili bir şekilde azaltmak çok daha zor olacaktır.