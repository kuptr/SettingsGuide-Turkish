WP Roof Fall Down
====
Tel Baskı modunda tel çerçevenin tavanını yazdırırken, bazı çizgiler havada asılı kalacaktır. Bu çizgiler, sonunda yerinde katılaşmadan önce erimiş malzemenin aşağı sarkmasına eğilimlidir. Bu ayar, yapıların tavanındaki bu sarkmaları telafi etmenizi sağlar. Havada asılı kalacak olan çizgiler biraz daha yüksek yazdırılır, böylece yaklaşık olarak nereye yerleştirilmeleri gerektiği planlanan yerde katılaşırlar.

Yalnızca havada asılı olarak yazdırılacak olan köşeler yukarı taşınır. Her konsantrik dairenin arasındaki bağlantılı testere dişi desen, önünde yazdırılan konsantrik halkaya yarısından fazlası yapışmıştır. Bu nedenle, bu köşeler yukarı taşınmaz. Yalnızca testere dişi desenin iç köşeleri yukarı taşınır.

Bu ayarın ayarlanması, baskı sıcaklığı ve kullanılan malzemenin hassas bir şekilde ayarlanmasını gerektirir. PLA gibi bazı malzemeler çok hızlı katılaşırken, diğerleri daha uzun sürebilir. Daha soğuk bir ortamda yazdırmak, katılaşmayı hızlandırır. Ayrıca, oda sıcaklığı da sarkma miktarını önemli ölçüde etkiler.