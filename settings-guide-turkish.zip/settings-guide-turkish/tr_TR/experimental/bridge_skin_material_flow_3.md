Köprü Üçüncü Yüzey Alanı Akışı
====
Bu ayar, bir köprünün üstündeki üçüncü cilt katmanını yazdırmak için çıkarılan malzeme miktarını ayarlar.

Malzeme miktarını azaltmak, boşluğu köprüleyen alt tarafın çizgi genişliğini etkili bir şekilde azaltır. Azaltılmış çizgi genişliği ile çizgilerin yüzeyden kütleye oranı daha büyük olur, bu da onların daha hızlı soğumasını sağlar ve bu, birinci ve ikinci köprü katmanlarına fazla yaslanmalarını önler.

Ancak akış hızını fazla azaltmak, özellikle de [Köprü İkinci Yüzey Alanı Hızı](bridge_skin_speed_2.md) ile birleştirildiğinde akış hızında büyük bir değişikliğe neden olur. Gerçekte malzeme akış hızlarını çok hızlı bir şekilde değiştiremez, bu da akış hızı yavaşlandığında çizgilerin istenenden biraz daha kalın olmasına, akış hızı hızlandığında ise istenenden biraz daha ince olmasına neden olur.

Ayrıca, muhtemelen alt tarafın belirli bir noktada kapatılmasını isteyeceksiniz, ya su geçirmez olması ya da daha iyi görünmesi için. Seyrek dolgu ile çok sayıda katmanın olması, hatta dolgu desenine kadar uzanan derin çatlaklar oluşturabilir.