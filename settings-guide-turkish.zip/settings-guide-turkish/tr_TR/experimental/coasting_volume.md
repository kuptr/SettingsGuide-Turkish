Tarama Hacmi
====
Bu ayar, konturun sonundan ne kadar önce besleyicinin malzeme beslemeyi durduracağını belirler. Kıyma uzunluğu, malzeme hacmi ile ayarlanır. Bu, nozül odasının içindeki hacimle daha yakından ilişkilidir.

<!--screenshot {
"image_path": "coasting_enable.png",
"models": [{"script": "phone_holder.scad"}],
"camera_position": [0, -215, 117],
"minimum_layer": 1,
"structures": ["travels", "helpers", "shell", "infill", "starts"],
"settings": {
    "coasting_enable": true,
    "coasting_volume": 0.06,
    "z_seam_position": "backright"
},
"colours": 32
}-->
<!--screenshot {
"image_path": "coasting_volume_0_03.png",
"models": [{"script": "phone_holder.scad"}],
"camera_position": [0, -215, 117],
"minimum_layer": 1,
"structures": ["travels", "helpers", "shell", "infill", "starts"],
"settings": {
    "coasting_enable": true,
    "coasting_volume": 0.03,
    "z_seam_position": "backright"
},
"colours": 32
}-->
![Kıyma 0.06mm³ malzeme](../images/coasting_enable.png)
![Kıyma 0.03mm³ malzeme](../images/coasting_volume_0_03.png)

Kıyma hacmini artırmak, nozülün konturu tamamlamadan daha önce malzeme ekstrüzyonunu durdurmasına neden olur. Sonuç olarak, konturun sonuna doğru daha fazla yetersiz ekstrüzyon olacaktır. Kıyma işlevi, kontur dikişi yapıldığında oluşan kabarcığı telafi etmek için kullanılır, bu yüzden kıyma hacmini artırmak daha büyük kabarcıkları telafi edebilir.

Ancak, kıyma hacminin çok fazla artırılması, konturun sonuna doğru aşırı yetersiz ekstrüzyona neden olacaktır. Bu, konturdan sonra yazdırılan herhangi bir şeyde de yetersiz ekstrüzyona yol açabilir, çünkü o zaman nozül üzerindeki basınç hala düşük olacaktır.