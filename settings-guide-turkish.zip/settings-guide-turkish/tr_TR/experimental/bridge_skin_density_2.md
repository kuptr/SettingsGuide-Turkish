Köprü İkinci Yüzey Alanı Yoğunluğu
====
Bu ayar, köprünün üstündeki ikinci katmanda cilt yoğunluğunu kontrol eder. %100 yoğunlukta, çizgiler doğrudan bitişiktir. Daha düşük yoğunluklarda, çizgiler daha aralıklıdır.

Cilt çizgilerini doğrudan birbirine bitiştirdiğinizde, birbirine yapışırlar. Bu, modelin su geçirmez olmasına yardımcı olur ve baskının alt tarafında daha pürüzsüz görünür. Ayrıca, sonraki çizgilerin bir önceki çizgilere biraz dayanmasına izin vererek sarkmayı önlemeye yardımcı olur.

Ancak malzeme soğumakta zorlanacaktır. Cilt çizgileri arasında bir miktar boşluk olduğunda, hava boncuklarının etrafında dolaşabilir ve bunların soğuması ve katılaşması hızı önemli ölçüde artar. Tabii ki, bu sadece fan açıkken geçerlidir, bu nedenle yüksek sıcaklıkta malzemeler için bu strateji çalışmayacaktır. İkinci katmanda sarkma etkisi de azalır çünkü birinci katın üzerine yaslanabilir, bu nedenle bu kat için pürüzsüzlük gibi diğer faktörler daha belirleyicidir. Ayrıca, en alt kısmın su geçirmez veya düzgünlük hissi için tamamen kapalı olmasını isteyeceğiniz bir noktada olduğunu unutmayın.

Bu etkilerden hangisinin daha güçlü olduğu, malzemenin viskozitesine, ne kadar hızlı katılaştığına ve fan hızına bağlıdır. Her zaman biraz ayarlama gereklidir.

**Eğer [Köprü İkinci Yüzey Alanı Akışı](bridge_skin_material_flow_2.md) %100'den az ise, yoğunluk %100 olsa bile, çizgiler daha ince olduğu için aralarında bazı boşluklar olacaktır.**