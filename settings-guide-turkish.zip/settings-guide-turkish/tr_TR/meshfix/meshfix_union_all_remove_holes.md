Tüm Boşlukları Kaldır
====
Bazı modeller, özellikle enjeksiyon kalıplama gibi üretim teknikleri için yapılmış olanlar, görünmeyen iç boşluklara sahip olma eğilimindedir. Bu ayar etkinleştirildiğinde, Cura bu iç boşlukları kaldırır.

<!--screenshot {
"image_path": "meshfix_union_all_remove_holes_disabled.png",
"models": [{"script": "foothold.scad"}],
"camera_position": [-68, 40, 46],
"settings": {"meshfix_union_all_remove_holes": false},
"colours": 64
}-->
<!--screenshot {
"image_path": "meshfix_union_all_remove_holes_enabled.png",
"models": [{"script": "foothold.scad"}],
"camera_position": [-68, 40, 46],
"settings": {"meshfix_union_all_remove_holes": true},
"colours": 64
}-->
![Bu modelin ortasında bir delik var](../images/meshfix_union_all_remove_holes_disabled.png)
![Bu ayar etkinleştirildiğinde, delik kaldırılır](../images/meshfix_union_all_remove_holes_enabled.png)

İç kısımdaki boşluklar, malzemeden tasarruf sağlamak için tasarlanmış olabilir, ancak 3D baskı ile bu modellerin daha kötü basılmasına neden olan bazı kısıtlamalar vardır. Örneğin, 3D yazıcılar, çizgi genişliğinin katları olmayan ince duvarlarla iyi başa çıkamaz ve üst yüzey, dolgu ile desteklenmezse sarkma eğilimindedir. Genellikle sağlam bir mesh yapmak ve dilimleyicinin nasıl dolduracağını belirlemesine izin vermek daha iyidir. Bu mesh düzeltme ayarı, mesh'i düzenlemenize gerek kalmadan bunu yapmanıza olanak tanır.

Cura, yatay olarak bir boşluğun tamamen kapatılıp kapatılmadığını kontrol eder. Boşluğun üstten veya alttan erişilebilir olup olmadığına bakmaz. Fark, yine de üstten veya alttan görülebilir.