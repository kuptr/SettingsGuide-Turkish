Boş İlk Katmanları Kaldır
====
Etkinleştirildiğinde, baskının alt tarafında boş olan herhangi bir katman kaldırılacaktır. Tüm baskı, yapım plakasına dayanacak şekilde aşağıya doğru hareket edecektir. Baskının başarısız olmasına neden olan boş katmanlar yerine, baskı biraz daha aşağıda olacaktır.

Eğer Cura tercihi olan "Modelleri otomatik olarak yapı plakasına bırak" etkinleştirilmişse, bu ayarın büyük olasılıkla çok az etkisi olacaktır. Ancak yine de bir etkisi olabilir. Modelleri otomatik olarak yapı plakasına indirirken, modeller yapı plakası ile tam olarak hizalanır. Ancak, ilk katman(lar) yalnızca çok küçük özellikler içeriyorsa (belki de alt kısım tamamen düzgün olmadığından dolayı) ilk katman hala nihai baskıda boş olabilir. Bu ayar, geri kalan katmanları bir aşağıya hareket ettirerek bunu önler.

Baskıyı aşağı doğru hareket ettirdikten sonra, ilk katmana uygulanan ayarlar hala geçerlidir. Bu nedenle, orijinal ilk katman kaldırılsa bile, [İlk Katman Yazdırma Sıcaklığı](../material/material_print_temperature_layer_0.md) ve benzeri ayarlar yeni ilk katmana uygulanır.

Normalde bu ayar her zaman baskının alt kısmının tamamen düz olmamasından veya yapı plakasına uygun şekilde hizalanmamasından kaynaklanan baskı başarısızlıklarını önlemek için etkinleştirilmelidir. Ancak, çoklu aşamalı bir baskı işi yapılıyorsa ve işlem havada başlaması gerekiyorsa, bu ayarı devre dışı bırakmayı seçebilirsiniz.

Eğer [Oluşturma Desteği](../support/support_enable.md) etkin ise, destek yapı plakasına kadar uzanır ve bu da ilk katmanların artık boş olmamasını sağlar. Hiçbir katman kaldırılmaz ve baskı aşağı doğru hareket etmez.

Eğer [Dilimleme Toleransı](../experimental/slicing_tolerance.md) ayarı "Dışlayıcı" olarak ayarlanmışsa, ilk katman her zaman boş olacaktır. Bu ayar etkin değilse, ilk katman gerçekten boş olacak ve baskınız büyük olasılıkla başarısız olacaktır.