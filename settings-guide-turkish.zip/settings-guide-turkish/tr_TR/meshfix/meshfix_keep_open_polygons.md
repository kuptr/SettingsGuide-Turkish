Bağlı Olmayan Yüzleri Tut
====
Cura, modeli malzeme ile doldurmak için modelin iç kısmının nerede olduğunu bilmelidir. Model düzgün bir şekilde su geçirmez değilse, bu belirsiz olur. Normalde Cura, düzgün şekilde kapatılmamış parçaları yazdırmaz.

Bu ayar etkinleştirildiğinde, çevresi düzgün şekilde kapatılmamış katmanlar korunur. Çevre, yapay olarak düz bir çizgi ile kapatılır. Bu, yüzeylerinde küçük boşluklar olan bazı modelleri düzeltebilir. Ancak, modelinizin iç kısmının ne olduğunu yanlış yorumlayabilir.

<!--screenshot {
"image_path": "meshfix_keep_open_polygons_shell.png",
"models": [{"script": "cube_missing_corner.py"}],
"camera_position": [85, -55, 75],
"layer": -1
}-->
<!--screenshot {
"image_path": "meshfix_keep_open_polygons_disabled.png",
"models": [{"script": "cube_missing_corner.py"}],
"camera_position": [85, -55, 75],
"settings": {
    "meshfix_keep_open_polygons": false
},
"colours": 64
}-->
<!--screenshot {
"image_path": "meshfix_keep_open_polygons_enabled.png",
"models": [{"script": "cube_missing_corner.py"}],
"camera_position": [85, -55, 75],
"settings": {
    "meshfix_keep_open_polygons": true
},
"colours": 64
}-->
![Bu küpün bir köşesi eksik](../images/meshfix_keep_open_polygons_shell.png)
![Normalde, kapatılmamış katmanlar yazdırılmaz](../images/meshfix_keep_open_polygons_disabled.png)
![Bu ayar etkinleştirildiğinde, şekil yapay olarak kapatılır](../images/meshfix_keep_open_polygons_enabled.png)

X-ray görünümü, bu ayarla kapatılabilecek boşlukları kırmızı renkte gösterir.