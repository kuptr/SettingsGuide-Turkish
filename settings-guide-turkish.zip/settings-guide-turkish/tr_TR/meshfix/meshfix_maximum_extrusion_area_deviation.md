Maksimum Ekstrüzyon Alanı Sapması
====
Değişen genişlikte çizgiler yazdırırken, çizginin uç noktalarından birine doğru kademeli olarak incelmesi yaygındır. Bu ayar, bu çizgilerin ideal olarak kaplaması gereken alana ne kadar yakın kalması gerektiğini kontrol ederek, bu çizgilerin incelme veya genişleme adım boyutunu belirler.

<!--screenshot {
"image_path": "meshfix_maximum_extrusion_area_deviation_high.png",
"models": [{"script": "twisted_triangular_hole.scad"}],
"camera_position": [0, 0, 60],
"settings": {
	"meshfix_maximum_resolution": 0.5,
	"meshfix_maximum_extrusion_area_deviation": 2000
},
"colour_scheme": "line_width",
"colours": 128
}-->
<!--screenshot {
"image_path": "meshfix_maximum_extrusion_area_deviation_low.png",
"models": [{"script": "twisted_triangular_hole.scad"}],
"camera_position": [0, 0, 60],
"settings": {
	"meshfix_maximum_resolution": 0.05,
	"meshfix_maximum_extrusion_area_deviation": 20
},
"colour_scheme": "line_width",
"colours": 128
}-->
![Yüksek sapmaya izin verildiğinde düşük çözünürlük](../images/meshfix_maximum_extrusion_area_deviation_high.png)
![Düşük sapma gerektiğinde düzgün çizgi genişliği](../images/meshfix_maximum_extrusion_area_deviation_low.png)

G-kodu komutları yazıcıya değişken genişlikte bir çizgi yazdırmasını söyleyemez. Yazıcı, sabit genişlikte çizgiler yazdırmak zorundadır. Cura, çizgiyi kademeli olarak değişen genişlikte birden fazla segmente bölebilir. Ancak, bu baskıya birçok çizgi segmenti ekler. Yazıcıdaki CPU, baskı sırasında tüm bu talimatlara ayak uyduramayabilir. Bu ayarla, değişken genişlikteki çizgi segmentlerinin detay seviyesi seçilir. Daha yüksek çözünürlük (azaltılmış sapma) teoride daha doğru çizgiler sağlar, ancak aynı zamanda talimatların miktarını da büyük ölçüde artırır.

Katman görünümünde çizginin genişliği kademeli olarak değişiyorsa güzel görünür, ancak bunun gerçek baskı üzerinde neredeyse hiçbir etkisi yoktur. Fiziksel 3D yazıcılar, burada çözünürlüğü artırarak herhangi bir iyileşme görecek kadar akış hızlarını yeterince doğru ayarlamazlar. Normal koşullar altında, bu ayarın g-kodunun çözünürlüğü üzerinde hiçbir zaman sınırlayıcı bir faktör olmaması için yeterince yüksek olması gerekir. Bu şekilde, tampon taşmalarının olma şansı minimize edilir.