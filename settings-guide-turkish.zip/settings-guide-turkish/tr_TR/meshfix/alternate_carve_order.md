Alternatif Örgü Giderimi
====
Birden fazla mesh örtüştüğünde, Cura normalde bir mesh'in bir kısmını diğerine yer açmak için kaldırır. Bu seçenekle, mesh'ler katman katman değişecek, iki mesh'in dokunmuş bir karışımını oluşturacaktır.