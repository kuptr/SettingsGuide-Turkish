Bileşim Kesişimini Kaldırın
====
Birden fazla mesh birbirine örtüşüyorsa, normalde her ikisi de basılır ve bu da aşırı ekstrüzyona neden olur. Bu ayar etkinleştirildiğinde, mesh'lerden biri diğerine göre oyulur. Bu şekilde aşırı ekstrüzyon olmayacak ve sonuç dışarıdan aynı görünecektir.