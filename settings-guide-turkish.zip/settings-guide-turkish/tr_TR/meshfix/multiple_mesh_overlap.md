Birleştirilmiş Bileşim Çakışması
====
Bu ayar, iki modelin bir araya geldiği yerde bir örtü oluşturur. Sonuç olarak, iki mesh birbirine çok daha iyi yapışır.

Bu özellik, çoklu farklı malzemelerle yapılan baskılar için faydalıdır. Tipik olarak, çok renkli baskılar için modeller birbirleriyle tam olarak eşleşecek şekilde tasarlanır. Bu şekilde yazdırmak, onların birbirine iyi yapışmasını sağlamaz. Onları biraz örtüşecek şekilde bırakmak daha iyidir, böylece baskılar birbirine geçebilir.

Dayanıklılığı artırmak için bu ayarı artırın. Ancak, bunu çok fazla artırmak, aşırı ekstrüzyona neden olur, bu da yüzeyin daha az güzel olmasına ve baskının devrilmesine neden olabilir. Ayrıca, bunu artırmak, modeller arasındaki sınırın belirsizleşmesine neden olur, bu nedenle çok renkli baskılardaki renkler tam olarak olmaz.