Maksimum Çözünürlük
====
Yüksek çözünürlüklü girişler başlangıçta daha iyi gibi görünse de, çoğu zaman yazıcı yüksek çözünürlüklü g-kodu ile iyi başa çıkamaz. Bu nedenle, Cura dilimleme sürecinde girişin çözünürlüğünü azaltır. Bu ayar, Cura'nın maksimum olarak tutacağı çözünürlüğü belirler.

<!--screenshot {
"image_path": "meshfix_maximum_resolution_0.05.png",
"models": [{"script": "cylinder.scad"}],
"camera_position": [40, -20, 116],
"settings": {
    "meshfix_maximum_resolution": 0.05
},
"colours": 64
}-->
<!--screenshot {
"image_path": "meshfix_maximum_resolution_1.png",
"models": [{"script": "cylinder.scad"}],
"camera_position": [40, -20, 116],
"settings": {
    "meshfix_maximum_resolution": 4,
    "meshfix_maximum_deviation": 0.5
},
"colours": 64
}-->
![Çözünürlük azaltılmadan önce](../images/meshfix_maximum_resolution_0.05.png)
![Çözünürlük azaltıldıktan sonra (aşırı durumda)](../images/meshfix_maximum_resolution_1.png)

Yazıcı, g-kodu yürütülürken işlemesi gerekir. G-kodu birçok küçük çizgi segmenti içeriyorsa, baskı kafası hareket boyunca o kadar hızlı ilerleyebilir ki, 3D yazıcının işlemcisi bu hıza yetişemez. Bu durumda, baskı kafası işlemcinin yetişmesi için ara sıra yavaşlayacak veya bir sonraki hareket komutunu beklemek zorunda kalacaktır. Bu, yüzeyin çok pürüzlü olmasına veya nozuldan çıkan akış hızının düzensiz hareketle tam olarak eşleşmemesi nedeniyle küçük kabarcıkların oluşmasına neden olabilir. Bazen daha düşük çözünürlük, daha iyi baskı kalitesiyle sonuçlanır.

Bu ayar, çizgi segmentleri için minimum uzunluğu belirtir. Belirtilen uzunluktan daha kısa çizgi segmentleri, diğer çizgi segmentleriyle birleştirilmek üzere değerlendirilecektir. Yeni yol, orijinal yoldan [Maksimum Sapma](meshfix_maximum_deviation.md)<!--if cura_version>5.0--> ve kapladığı alan [Maksimum Ekstrüzyon Alanı Sapması](meshfix_maximum_extrusion_area_deviation.md) kadar sapmazsa birleştirilecektir. <!--endif-->.

Aynı katmandan her bir katmandan aynı köşelerin kaldırılacağı garanti edilmez, eğer köşeler hizalanırsa. Çözünürlük azaltma, katmanın şekillerinin köşelerini kaldırarak 2D olarak gerçekleştirilir, mesh'in köşelerini kaldırarak 3D olarak değil. Sonuç olarak, çözünürlüğü çok fazla azaltmak, genellikle açısal bir yüzey yerine düzensiz bir yüzeye yol açar.

Modelin çözünürlüğünü, baskı kafasının işlemcinin yetişmesine izin vermek için önemli ölçüde yavaşlamayacağı şekilde azaltmanız önerilir. Çözünürlük yeterince azaltılmazsa, baskı kafasının hızını düşürmesi sırasında yüzey pürüzlü hale gelirken ekstrüzyon devam eder. Çözünürlük çok fazla azaltılırsa, yüzey, duvarların her yerde tam olarak üst üste binmemesi nedeniyle yine pürüzlü hale gelir.