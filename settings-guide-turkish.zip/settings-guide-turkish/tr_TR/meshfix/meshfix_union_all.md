Bağlantı Çakışma Hacimleri
====
Bir model, kesişen birden fazla hacim içeriyorsa, her iki hacmin içinde olan hacim normalde doldurulmaz. Bu ayar, Cura'nın iç yapıları görmezden gelmesine ve kaç tane kabuk olduğuna bakılmaksızın hepsini doldurmasına neden olur.

<!--screenshot {
"image_path": "meshfix_union_all_shell.png",
"models": [{"script": "intersecting_cubes.py"}],
"camera_position": [34, 86, 132],
"layer": -1,
"colours": 128
}-->
<!--screenshot {
"image_path": "meshfix_union_all_disabled.png",
"models": [{"script": "intersecting_cubes.py"}],
"camera_position": [34, 86, 132],
"settings": {"meshfix_union_all": false},
"layer": 300,
"colours": 64
}-->
<!--screenshot {
"image_path": "meshfix_union_all_enabled.png",
"models": [{"script": "intersecting_cubes.py"}],
"camera_position": [34, 86, 132],
"settings": {"meshfix_union_all": true},
"layer": 300,
"colours": 64
}-->
![Kesişen iki küp içeren bir mesh](../images/meshfix_union_all_shell.png)
![Tüm hacimleri birleştirme](../images/meshfix_union_all_disabled.png)
![Birleştirme deliği kaldırdı](../images/meshfix_union_all_enabled.png)

Teknik terimlerle, bu ayar, dolgu kuralını [Even-Odd](https://en.wikipedia.org/wiki/Even%E2%80%93odd_rule) kuralından [Nonzero](https://en.wikipedia.org/wiki/Nonzero-rule) kuralına etkili bir şekilde değiştirir. Normalde, bir hacim, tek sayıda kabuk ile çevrili ise doldurulur. Bu ayar etkinleştirildiğinde, sıfırdan fazla sayıda kabuk ile çevrili ise doldurulur.

**Bu, yalnızca aynı model içindeki hacimler için çalışır. Birden fazla dosya yükleyip Cura'da bunları kesiştirdiyseniz, bu ayar etkili olmaz. Birden fazla ayrı mesh'in çakışmasıyla ilgili sorunları çözmek için Mesh Kesişimini Kaldır ayarına bakın.**