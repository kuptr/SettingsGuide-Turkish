Geniş Dikiş
====
Cura, modeli malzeme ile doldurmak için modelin iç kısmının nerede olduğunu bilmelidir. Modelinizin yüzeyi tam olarak kapalı değilse veya iç duvarları varsa, modelin iç kısmının nerede olduğu belirsiz olabilir.

Modelin manifold olmamasının yaygın bir durumu, kapalı bir parçaya ekstra bir parçanın eklenmiş olmasıdır. Bu, Blender veya SketchUp gibi üretim için değil, yalnızca dijital görselleştirme için tasarlanmış CAD yazılımlarıyla mesh düzenlerken yaygındır. Aşağıdaki resimlerde bunun bir örneğini görebilirsiniz.

<!--screenshot {
"image_path": "meshfix_extensive_stitching_xray.png",
"models": [{"script": "external_attachment.py"}],
"camera_position": [62, 87, 68],
"layer": -1
}-->
<!--screenshot {
"image_path": "meshfix_extensive_stitching_disabled.png",
"models": [{"script": "external_attachment.py"}],
"camera_position": [62, 87, 68],
"settings": {
    "meshfix_extensive_stitching": false
},
"colours": 32
}-->
<!--screenshot {
"image_path": "meshfix_extensive_stitching_enabled.png",
"models": [{"script": "external_attachment.py"}],
"camera_position": [62, 87, 68],
"settings": {
    "meshfix_extensive_stitching": true
},
"colours": 32
}-->
![X-ray görünümü, iç kısımda ekstra bir yüzey ortaya çıkarır](../images/meshfix_extensive_stitching_xray.png)
![Bu ayar devre dışı bırakıldığında, yalnızca düzgün şekilde kapatılmış hacim yazdırılır](../images/meshfix_extensive_stitching_disabled.png)
![Bu ayar etkinleştirildiğinde, ekstra parça düzgün şekilde eklenir](../images/meshfix_extensive_stitching_enabled.png)

Bu ayar, mesh düzgün bir şekilde su geçirmez değilse, Cura'nın boşlukları kapatmada daha iyi bir çaba göstermesine neden olur. Bu, iyi bir baskı olasılığını artırır, ancak dilimleme süresini artırır ve bazen yanlış yüzeylerin birbirine bağlanmasına neden olabilir.