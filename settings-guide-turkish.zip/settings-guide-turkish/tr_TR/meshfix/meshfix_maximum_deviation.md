Maksimum Sapma
====
Yüksek çözünürlüklü girişler başlangıçta daha iyi gibi görünse de, çoğu zaman yazıcı yüksek çözünürlüklü g-kodu ile iyi başa çıkamaz. Bu nedenle, Cura dilimleme sürecinde girişin çözünürlüğünü azaltır. Bu ayar, çözünürlüğü azaltmak için indirgenmiş yolun orijinal yoldan ne kadar sapabileceğini belirler.

<!--screenshot {
"image_path": "meshfix_maximum_resolution_0.05.png",
"models": [{"script": "cylinder.scad"}],
"camera_position": [40, -20, 116],
"settings": {
    "meshfix_maximum_resolution": 0.05
},
"colours": 64
}-->
<!--screenshot {
"image_path": "meshfix_maximum_resolution_1.png",
"models": [{"script": "cylinder.scad"}],
"camera_position": [40, -20, 116],
"settings": {
    "meshfix_maximum_resolution": 4,
    "meshfix_maximum_deviation": 0.5
},
"colours": 64
}-->
![Çözünürlük azaltılmadan önce](../images/meshfix_maximum_resolution_0.05.png)
![Çözünürlük azaltıldıktan sonra (aşırı durumda)](../images/meshfix_maximum_resolution_1.png)

Yazıcı, g-kodu yürütülürken işlemesi gerekir. G-kodu birçok küçük çizgi segmenti içeriyorsa, baskı kafası hareket boyunca o kadar hızlı ilerleyebilir ki, 3D yazıcının işlemcisi bu hıza yetişemez. Bu durumda, baskı kafası işlemcinin yetişmesi için ara sıra yavaşlayacak veya bir sonraki hareket komutunu beklemek zorunda kalacaktır. Bu, yüzeyin çok pürüzlü olmasına veya nozuldan çıkan akış hızının düzensiz hareketle tam olarak eşleşmemesi nedeniyle küçük kabarcıkların oluşmasına neden olabilir. Bazen daha düşük çözünürlük, daha iyi baskı kalitesiyle sonuçlanır.

Bu ayar, yeni, çözünürlüğü azaltılmış yolun orijinal yüksek çözünürlüklü yoldan ne kadar sapmasına izin verildiğini gösterir. Çizgiler, [Maksimum Çözünürlük](meshfix_maximum_resolution.md)'ten daha kısa olduklarında diğer çizgi segmentleriyle birleştirilmiş olarak kabul edilir, ancak bu kısayol, yolun bu ayarla belirtilen mesafeden daha fazla sapmasına neden olursa, çizgiler birleştirilmeyecektir.

Aynı katmandan her bir katmandan aynı köşelerin kaldırılacağı garanti edilmez, eğer köşeler hizalanırsa. Çözünürlük azaltma, katmanın şekillerinin köşelerini kaldırarak 2D olarak gerçekleştirilir, mesh'in köşelerini kaldırarak 3D olarak değil. Sonuç olarak, çözünürlüğü çok fazla azaltmak, genellikle açısal bir yüzey yerine düzensiz bir yüzeye yol açar.

Yapısal bütünlük için yolların bir çizgi genişliğinin yarısından fazla sapmasına izin verilmemesi şiddetle tavsiye edilir. Ancak yüzeyin pürüzsüz olması veya güzel görünmesi gerekiyorsa, bu ayar esasen yüzeydeki düzensizliklerin ne kadar derin olmasına izin verildiğini gösterir. Maksimum sapmanın çıplak gözle görülmeyecek kadar düşük olması gerekir.

Ancak, maksimum sapmanın çok fazla azaltılması, çözünürlük azaltmasını büyük ölçüde sınırlar. Sonuçta ortaya çıkan g-kodu iyi yazdırılmayabilir, çünkü CPU kısa hareket komutlarına yetişemez.