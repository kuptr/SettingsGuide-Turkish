Maksimum Hareket Çözünürlüğü
====
Model çok yüksek çözünürlüğe sahipse, Cura g-kodu komutlarının işlenmesi sırasında yazıcının işlemcisinin yetişebilmesi için çözünürlüğü azaltacaktır. Seyahat hareketlerinin maksimum çözünürlüğü, baskı sırasında kullanılan [Maksimum Çözünürlük](meshfix_maximum_resolution.md) ayrı olarak belirlenebilir.

Seyahat hareketleri baskı hareketlerinden çok daha hızlı gerçekleştirildiğinden, baskı kafası seyahat çizgi segmentlerinden diğer çizgi segmentlerinden çok daha hızlı geçer. CPU, nozula ayak uydurabilmek için bu çizgi segmentlerini çok daha hızlı işlemelidir. Bu nedenle, seyahat hareketlerinin çözünürlüğü, daha yavaş ekstrüzyon hareketlerinin çözünürlüğünden daha düşük olmalıdır.

Seyahat hareketleri sırasında hareketin çözünürlüğü, baskı kalitesi için genellikle önemli değildir. Ekstrüzyon yapılmadığından, yüzeyin bulanık veya açısal hale gelmesi söz konusu değildir. Bu nedenle, seyahat hareketlerinin çözünürlüğünün azaltılması baskı kalitesi üzerinde önemli bir etki yaratmaz.

Cura'nın seyahat hareketlerinin çoğu düz çizgilerdir. Bunlar en hızlı hareketlerdir ve en az titreşimi üretirler. Ancak, Cura çarpışmalardan kaçınmak için bir yüzeyin etrafında hareket ederken, bu yüzeyin çözünürlüğüne benzer bir çözünürlük izler. Sonuç olarak, bu ayar yalnızca [Tarama Modu](../travel/retraction_combing.md) etkinse gerçekten etkili olabilir.