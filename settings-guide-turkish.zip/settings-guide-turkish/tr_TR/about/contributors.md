Katkıda Bulunanlar
====
![Bu projenin bakımı Ghostkeeper tarafından yapılmaktadır.](../images/contributors/Ghostkeeper.png)

Programlama
----
![Ghostkeeper - Versiyon 1.1 ve sonrası](../images/contributors/Ghostkeeper.png)
![Alekseisasin - Versiyon 1.0](../images/contributors/Alekseisasin.png)

Maddeler
----
![Ghostkeeper - V2.0'daki tüm içeriğin ve o zamandan bu yana birçok makalenin yeniden yazılması](../images/contributors/Ghostkeeper.png)
![Ellecross - V1.0'daki içeriğin temeli](../images/contributors/Ellecross.jpg)
![Jeroen Stevens - V1.0'daki içeriğin temeli](../images/contributors/no_avatar.svg)
![Christerbeke - Uyarlanabilir Katman Yüksekliği ile ilgili makale](../images/contributors/Christerbeke.jpg)
![Laurent Lalliard - Küçük düzeltmeler](../images/contributors/5axes.png)
![Sophist - Küçük düzeltmeler](../images/contributors/Sophist.jpg)
![Yohan Pereira - Küçük düzeltmeler](../images/contributors/yohan-pereira.png)
![DigitalFrost - Küçük düzeltmeler](../images/contributors/DigitalFrost.jpg)

Çeviri
----
![Goodfeat - Rusca](../images/contributors/Goodfeat.png)
![Laurent Lalliard - Fransızce](../images/contributors/5axes.png)
![Vb138 - Çekce](../images/contributors/Vb138.png)
![SekIsBack - Almanca](../images/contributors/Sekisback.jpg)
![Kup - Türkçe](../images/contributors/Kup.png)