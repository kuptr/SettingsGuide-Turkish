Terminoloji
====
Bu sayfa, Cura tarafından kullanılan bazı endüstri terimlerini açıklar. Cura, terminoloji kullanımı konusunda her zaman en tutarlı olanı değildir, bu nedenle bazı terimler eşanlamlıdır.

* **Adaptive layers:** Adaptif katmanlar: Katman yüksekliğini baskı boyunca değiştirerek topolojinin görünürlüğünü azaltan ve yine de makul bir hızda baskı yapan bir teknik.
* **Aliasing:** Aliasing: Step motorlarının çözünürlük sınırının baskının dışında görülebildiği bir baskı hatası.
* **Anti-overhang mesh:** Destek engelleyici mesh: Modelin örtüştüğü herhangi bir çıkıntıyı desteklemek için destek oluşturulmasını engelleyecek bir model. "Destek engelleyici" ile eşanlamlıdır.
* **Bead:** Boncuk: Ekstrüder tarafından yerleştirildikten sonra oluşan malzeme ipliği. "Boncuk" terimi, filamentin katılaştıktan sonraki gerçek şeklini dikkate almanın önemli olduğu bilimde kullanılır. "Çizgi"ye benzer.
* **Blob:** Baloncuk/Lekeler: Baskının dış kısmında fazla malzemenin oluşturduğu bir nokta.
* **Bowden tube:** Teflon tüpü: Filamenti ekstrüder treninden yönlendirmek için kullanılan içi boş, esnek bir tüp.
* **Bridging:** Köprüleme: İki dinlenme noktası arasında düz çizgiler gererek havada asılı çizgileri yazdırma tekniği. Cura, köprüleme çizgilerinin parametrelerini ayarlayabilir ve köprüler oluşturmak için bazı çizgilerin yönünü ayarlayabilir.
* **Brim:** Kenar: Baskıya eklenen ve eteğe benzeyen, ancak malzemenin yapışması için daha fazla yüzey alanı sağlayarak baskının yapı plakasına daha iyi tutunmasını sağlayan bir malzeme kenarı.
* **Build plate:** Yapı plakası: Baskının yerleştirildiği ve inşa edildiği plaka. Bazı yapı plakaları, baskı devam ederken malzemenin daha iyi yapışmasını sağlamak için ısıtılır.
* **Build volume:** Yapı hacmi: Yazıcının malzeme ekstrüde edebileceği 3D alan.
* **Coasting:** Kıyı hattı: Ekstrüzyon yolunun son kısmının %0 akışla yazdırıldığı ve nozulun aşırı basıncını boşaltan bir teknik.
* **Combing:** Tarama: Seyahatler sırasında duvarların geçilmesini önleyerek baskının dış kısmında görünür bir iz oluşmasını engellemeye çalışan bir hareket.
* **Coordinate origin:** Koordinat merkezi: Bir nozulun [0, 0, 0] koordinatlarına hareket ettirilmesi istendiğinde yapı plakasındaki konumu.
* **CuraEngine:** CuraMakinesi: Cura'nın dilimleme sürecinin ağır işlerini yapmak için kullandığı bir program. 3D modelleri g-code'a dönüştürür.
* **Cutting mesh:** Kesme mesh: Yapı plakasında, hacminin gerçek baskı modelleriyle örtüşen kısmı için ayarları değiştirebilen bir model. Modelin kendisi yazdırılmaz, ancak diğer modellerin parçalarını keser ve ardından bu parçaların hangi ayarlarla veya ekstrüderle yazdırılacağını değiştirebilir.
* **Disallowed area:** Yasaklı alan: Bir modelin baskı için yerleştirilmesine izin verilmeyen yapı plakası üzerindeki bir konum. Örneğin, yatağı tutan klipslere, prime kulesine çarpabileceği veya baskınızın yardımcı parçalarının yapı hacminden çıkabileceği durumlar.
* **Draft shield:** Taslak kalkanı: Baskının etrafında sıcaklığı sabit tutan bir malzeme kabuğu.
* **Elephant's foot:** Fil ayağı: Baskının alt tarafının istenenden biraz daha geniş olduğu bir baskı hatası.
* **Extruder:** Ekstrüder: Besleyici, isteğe bağlı Bowden tüpü, ısı bölgesi, sıcak uç ve nozulu bir arada. Bazı yazıcılarda birden fazla ekstrüder veya ekstrüder treninin bazı parçalarından birden fazla bulunur. "Ekstrüder treni"nin kısaltmasıdır.
* **Extruder switch:** Ekstrüder değişimi: Genellikle aynı anda yalnızca bir ekstrüder aktiftir. Aktif ekstrüderi bir ekstrüderden diğerine değiştirdiğinde ekstrüder değişimi gerçekleşir.
* **Extruder train:** Ekstrüder treni: Besleyici, isteğe bağlı Bowden tüpü, ısı bölgesi, sıcak uç ve nozulu bir arada. Bazı yazıcılarda birden fazla ekstrüder treni veya ekstrüder treninin bazı parçalarından birden fazla bulunur.
* **Extrusion:** Ekstrüzyon: Filamenti ekstrüder treninden iterek malzemenin nozuldan çıkmasını ve baskıyı oluşturmak için doğru yere yerleştirilmesini sağlama eylemi.
* **Face:** Yüzey: 3D mesh'in düz bir yüzeyi. Üçgen meshlerle (Cura'nın işleyebildiği tek tür), tüm yüzeyler 3D uzayında üçgendir.
* **Fan:** Fan: Yazıcının herhangi bir fanı değil, özellikle malzeme ekstrüde edildikten hemen sonra baskıyı soğutan baskı kafasına bağlı fan(lar).
* **FDM printing:** FDM baskı: Fused Deposition Modelling. Belirli bir şekil oluşturmak için plastik hatların ekstrüde edilmesiyle yapılan bir tür 3D baskı. Bu, Cura'nın desteklediği tek 3D baskı tekniğidir. "FFF baskı" ile eşanlamlıdır.
* **Feeder:** Besleyici: Filamenti ekstrüzyon treninden iten veya çeken motor ve dişli kutusu.
* **Feedrate:** Besleme hızı: Filamentin ekstrüder trenine beslenme hızı.
* **FFF printing:** FFF baskı: Fused Filament Fabrication. Belirli bir şekil oluşturmak için plastik hatların ekstrüde edilmesiyle yapılan bir tür 3D baskı. Bu, Cura'nın desteklediği tek 3D baskı tekniğidir. "FDM baskı" ile eşanlamlıdır.
* **Filament:** Filament: 3D yazıcıya beslenen plastik ip. Makaralarda gelir. Ekstrüde edildikten sonra artık filament değil, sadece malzemedir.
* **Flow:** Akış: Malzemenin normal oranına göre ekstrüzyon oranı. %100'den fazla akış teorik olarak ayrılan hacme sığmayacak kadar fazla malzeme ekstrüde eder. %100'den az akış teorik olarak çok az malzeme ekstrüde eder.
* **Gantry:** Portal: Baskı kafasını yapı hacmi etrafında hareket ettiren mekanik çerçeve.
* **Gap filling:** Boşluk doldurma: Cura'nın baskıda küçük boşlukları çok küçük çizgi segmentleri kullanarak doldurmak için kullandığı bir teknik.
* **Gradual infill:** Kademeli dolgu: Hacmin alt kısımlarında malzeme miktarının azaltıldığı, ancak üst kısımlarda malzemenin üstünü düzgün bir şekilde desteklemek için yüksek tutulduğu bir teknik. Bu sadece malzeme için değil, destek için de kullanılır.
* **Hardness:** Sertlik: Bir baskının elastik deformasyon veya delmeye ne kadar direnebileceğinin ölçüsü.
* **Heater:** Isıtıcı: Filamenti 3D baskı için gereken sıcaklığa getiren ısıtma elemanı.
* **Heat zone:** Isı bölgesi: Filamentin nozula doğru ilerlerken ısındığı bölge. Isı bölgesinin başlangıcında filament oda sıcaklığındadır. Sonunda ise baskı sıcaklığındadır.
* **Hop:** Z sıçraması: Nozulun baskı üzerinde biraz boşluk bırakarak hareket etmesi için yukarı (+Z) hareket ettirildiği bir teknik. "Z hop" ile eşanlamlıdır.
* **Hot end:** Sıcak uç: Nozulu, ısıtma elemanını ve sıcaklık sensörünü içeren sıcak metal veya seramik parça.
* **Infill:** Dolgu: Bir baskının iç kısmında oluşturulan ve üst yüzeyi destekleyen ve baskıya ek dayanıklılık sağlayan yapı.
* **Infill mesh:** Dolgu mesh: "Kesme mesh"e (Cutting mesh) benzer, ancak yalnızca başka bir modelin dolgu hacmiyle örtüştüğü yerlerde geçerlidir. Bu, başka bir modelin dolgusu için ayarları ayarlayan bir modeldir.
* **Inner walls:** İç duvarlar: En dış duvar hariç tüm duvarlar. Bir katmanda yalnızca bir dış duvar bulunurken, herhangi bir sayıda iç duvar olabilir.
* **Inset:** İç boşluk: Poligonlar üzerinde daha küçük/daha ince bir poligon üreten ve konturunun orijinal poligonun konturundan belirli bir mesafede kalan bir işlem. Negatif mesafeli bir iç boşluk "offset" olarak adlandırılır.
* **Ironing:** Ütüleme: Üst yüzeyi ekstra pürüzsüz yapmak için üzerinden ek bir kez geçme tekniği.
* **Jerk:** Ani hız değişimi: Her hareketin başlangıcında uygulanan anlık hız değişiminin sınırı. Bu, fiziğin yaygın tanımı olan "sarsıntı"dan farklıdır! 3D yazıcılarda "jerk", yazıcı kafasının hızlanma veya yavaşlama sırasında aniden yön değiştirme hızını ifade eden bir terimdir. Genellikle "ani hız değişimi" olarak tanımlanabilir. Türkçede doğrudan bir karşılığı olmamakla birlikte, bazen "salınım" veya "darbesel hareket" gibi terimler kullanılır. Jerk ayarı, yazıcının hareketinin ne kadar pürüzsüz olacağını ve baskının kalitesini etkileyebilir.
* **Layer:** Katman: 3D baskı, ince malzeme katmanları halinde yapılır. Bu katmanlar belirli bir kalınlığa sahip 2D şekillerdir ve dikey olarak üst üste yerleştirildiğinde 3D bir baskı oluştururlar.
* **Layer shift:** Katman kayması: Bir katmanın yatay konumunun istemsizce kaydığı ve genellikle baskının geri kalanının da kaydığı bir baskı hatası.
* **Layer split:** Katman ayrılması: Katmanların yeterince iyi yapışmadığı ve açıldığı bir baskı hatası.
* **Line:** Çizgi (Line): Ekstrüder treninden yerleştirildikten sonra oluşan malzeme ipliği. Cura'da çizgiler, belirli bir genişlik, kalınlık (katman yüksekliği) ve uzunluğa sahip dikdörtgen bloklar olarak modellenir. "Boncuk (Bead)" ile benzer.
* **Line segment:** Çizgi segmenti: 3D baskı terimi "çizgi" ile karışıklığı önlemek için, matematiksel anlamda bir çizgi segmentine atıfta bulunurken, Cura her zaman belirli bir uzunluğa sahip düz geometrik bir çizgiyi belirtmek için tam terimi "çizgi segmenti" kullanır.
* **Material:** Malzeme: 3D baskınızın oluşturulduğu malzeme. Genellikle FFF baskısında bir termoplastiktir.
* **Mesh:** Mesh: Bir modeli oluşturan üçgenler koleksiyonu. Bazen "nesne" ve "model" ile eşanlamlı olarak kullanılsa da, genellikle yazdırmak isteyeceğiniz bir şeyden ziyade bir veri parçası bağlamında kullanılır.
* **Model:** Model: Cura'nın 3D sahnesine yüklenen bir 3D model (dilimlemeden önce). "Nesne" ile eşanlamlıdır.
* **Nozzle:** Nozul: Baskı malzemesinin ekstrüder treninden çıktığı açıklık.
* **Object:** Nesne: Cura'nın 3D sahnesine yüklenen bir 3D model (dilimlemeden önce). "Model" ile eşanlamlıdır.
* **Offset:** Offset (Ofset): Poligonlar üzerinde daha büyük/daha kalın bir poligon üreten ve konturunun orijinal poligonun konturundan belirli bir mesafede kalan bir işlem. Negatif mesafeli bir offset "inset" olarak adlandırılır.
* **One-at-a-time mode:** Bir seferde bir mod: Birden fazla nesneyi yazdırma modu, her nesne tamamlanmadan önce bir katman yazdırır, normalde ise bir katman tamamlanır, sonra diğer nesneye geçilir.
* **Ooze shield:** Sızma kalkanı: Baskının etrafında sızan malzemeyi yakalayan bir malzeme kabuğu.
* **Oozing:** Sızma: Nozuldan malzemenin istenmeyen şekilde sızması. Genellikle seyahat yolu boyunca bir malzeme ipi bırakır.
* **Outer wall:** Dış duvar: En dıştaki duvar. Her parça için katman başına yalnızca bir dış duvar vardır.
* **Overextrusion:** Aşırı ekstrüzyon: Sınırlı bir hacme çok fazla malzeme ekstrüde edilmesi, malzemenin istenmeyen yerlere taşmasına neden olur.
* **Overhang:** Çıkıntı: Baskının alt katmanlarındaki malzemelerle desteklenmeyen (veya tamamen desteklenmeyen) bir kısmı. Çıkıntı çok aşırı ise iyi bir baskı yapmak için destek veya köprüleme gereklidir.
* **Overpressure:** Aşırı basınç: Baskı sırasında, malzemenin tutarlı bir şekilde ekstrüde edilmesini sağlamak için nozul odası büyük bir basınçta tutulur.
* **Parking:** Park etme: Malzemenin soğuması için nozul baskıdan uzaklaştırılarak baskının bir anlığına durdurulması.
* **Part:** Parça: Tek bir katmanda sürekli bir şekil (poligon). Dilimlendiğinde, tek bir model belirli katmanlarda birden fazla parçaya bölünebilir.
* **Pattern:** Desen: Bir hacmi malzeme ile doldurma tekniği, ancak mutlaka %100 yoğunlukta değil. Cura, çizgiler, ızgara, konsantrik, tetrahedral gibi çeşitli desenler arasında seçim imkanı sunar.
* **Pillowing:** Kabarcık: Üst yüzeyin, altındaki dolgu çizgilerine dayanarak şişmesi veya kırılması.
* **Polygon:** Poligon: Bir dizi noktadan ve aralarındaki düz çizgi segmentlerinden oluşan bir 2D şekil veya kapalı döngü.
* **Prime blob:** Hazırlık kabarcığı: Bir ekstrüderi hazırlamak için baskının başında atılan malzeme kabarcığı.
* **Prime tower:** Hazırlık kulesi: Yazıcının nozullarını daha yüksek katmanlarda hazırlamasını sağlayan, baskının yanında oluşturulan bir yapı. Bir süre beklemede kaldıktan sonra ekstrüderi hazırlamak için birden fazla ekstrüderin kullanıldığı baskılarda kullanılır.
* **Priming:** Hazırlık: Filamentin nozul ucuna hizalanmasını ve nozul odasının düzgün bir şekilde doldurulup basınçlandırılmasını sağlamak için biraz malzeme püskürtme işlemi. Genellikle bir baskının başında veya ekstrüder değişiminden sonra yapılır.
* **Purging:** Püskürtme: Atık olarak biraz malzeme ekstrüde etme işlemi. Püskürtmenin yaygın bir nedeni "Priming"tır.
* **Raft:** Raft: Baskı plakası yapışmasını iyileştirmek için baskının altına yazdırılan ve daha sonra atılan katı bir plaka. Plaka, çok fazla yüzey alanına sahiptir ve iyi yapışan kalın çizgilerle yazdırılır, yapı plakasının düzlüğündeki düzensizlikleri yakalar. 3D baskı terimlerinden biridir ve Türkçe karşılığı "radye" olarak kullanılır. Radye, 3D yazıcıda genellikle baskı platformu üzerine destek sağlamak için yazdırılan düz bir tabaka veya ağ şeklinde yapıdır. Bu yapı, özellikle düşük yapışma özelliklerine sahip filamentlerle veya büyük ve karmaşık parçalarla çalışırken baskı kalitesini artırmaya yardımcı olur.
* **Retraction:** Geri çekme: Malzemenin nozul odasına geri çekilmesi için besleyiciyi kullanma işlemi. Genellikle temiz bir hareket sağlamak için malzemenin nozuldan akmasını geçici olarak durdurmak için yapılır.
* **Ringing:** Zil sesi: Yüzeyin düzensiz ekstrüzyon veya nozulun sallanması nedeniyle dalgalandığı bir baskı hatası. Genellikle keskin köşeleri çok hızlı yaparken olur.
* **Scar:** İz: Nozulun geçerken malzemeyi erittiği baskının dış kısmında bir hasar noktası.
* **Seam:** Dikiş: Kapalı bir döngünün başladığı ve durduğu yer. Bu nokta genellikle son baskıda görünür, bu nedenle görünürlüğünün az olduğu bir noktaya yerleştirmek istenir.
* **Shell:** Kabuk: Hem duvarlar hem de yüzey.
* **Skin:** Yüzey: Baskının üst ve alt tarafları. Bu kısımlar her zaman %100 yoğunlukta yazdırılır ve genellikle çizgi deseni kullanılır. "Üst/alt (top/bottom)" ile eşanlamlıdır.
* **Skirt:** Etek: Malzemeyi hazırlamak ve kullanıcıya yapı plakasının tamamen düz olup olmadığını görmek için ilk katmanda baskının etrafında çizilen bir kontur.
* **Slicing:** Dilimleme: Bir 3D modeli yazıcının yazdırması için talimatlara dönüştürme süreci. CuraEngine bağlamında, bu aynı zamanda modelin kesitlerini oluşturma süreci için de kullanılır, bu da tam dilimleme sürecinin aşamalarından biridir.
* **Spiralise mode:** Spiralize modu: Modellerin sadece dış hatlarını yazdırma modu, genellikle Z koordinatını katman boyunca kademeli olarak artırarak Z dikişini ortadan kaldırmak için modeli büyük bir spiral içinde yazdırır. Cura dışında bu, "vazo modu" olarak da bilinir.
* **Stand-by:** Bekleme: Birden fazla ekstrüderle baskı yaparken, genellikle aynı anda yalnızca bir ekstrüder aktiftir. Diğer ekstrüderler bekleme modunda olur.
* **Stitching:** Dikiş: Dilimleme sürecinin bir parçası. Bir grup üçgenin kesitlerini oluşturmak, her katmanda bir dizi çizgi segmenti ile sonuçlanır. Dikiş, bu çizgi segmentlerini poligonlara birleştirir ve katmanın içinin ne olduğunu belirler.
* **Strength:** Güç: Hareket direncinin çeşitli ölçülerini, çeşitli kuvvet türleri uygulandığında sertlik, rijitlik ve dayanıklılığı kapsayan bir terim.
* **Stringing:** İpliklenme (Stringing): Malzeme sızarken hareket ettiğinde, buna "ipliklenme" denilen ince malzeme iplikleri oluşur. Bu iplikler, bir hareketin uzunluğu boyunca tamamen uzanmazlar. Daha az aşırı bir formu "yığınlar (blobs)" ile sonuçlanır.
* **Support:** Destek: Baskı sırasında, malzemenin düşmesini veya çok fazla sallanmasını önlemek için baskıyı yerinde tutmak için gerekli olan, ancak baskıdan sonra kaldırılan bir parça.
* **Support blocker:** Destek engelleyici: Modelin örtüştüğü herhangi bir çıkıntıyı desteklemek için destek oluşturulmasını engelleyecek bir model. "Anti-overhang mesh" ile eşanlamlıdır.
* **Support floor:** Destek tabanı: Desteklerin modele dayandığı alt taraf. Bu destek parçası, isteğe bağlı olarak farklı ayarlarla yazdırılabilir. Destek yapı plakasına dayandığında destek tabanı olmaz.
* **Support infill:** Destek dolgusu: Desteğin ana bileşeni. Destek ara yüzü yoksa destek sadece destek dolgusundan oluşur.
* **Support interface:** Destek ara yüzü: Modelin desteğe dayandığı ve desteğin modele dayandığı destek tavanı ve tabanı. Destek yapı plakasına dayandığı alt taraf destek ara yüzü almaz.
* **Support mesh:** Destek mesh: Normal bir baskı olarak yazdırmak yerine destek yapısıyla doldurulan bir model. Desteğinizin şeklini özelleştirmek için kullanılabilir.
* **Support roof:** Destek tavanı: Modelin desteğe dayandığı üst taraf. Bu destek parçası, isteğe bağlı olarak farklı ayarlarla yazdırılabilir.
* **Support towers:** Destek kuleleri: Çok ince veya küçük baskı parçalarını destekleme tekniği. Parça, baskı sırasında desteğin devrilmemesi için aşağı doğru genişleyen bir kule ucuyla desteklenir.
* **Thermoplastic:** Termoplastik: Eriydiğinde yumuşayan bir plastik türü. FFF baskısı için yalnızca termoplastikler kullanılabilir.
* **Thickness:** Kalınlık: Dikey yönde (Z) bir yapının boyutu. "Genişlik (width)" ile karşılaştırın.
* **Top/bottom:** Üst/alt (Top/bottom): Baskının üst ve alt tarafları. Bu kısımlar her zaman %100 yoğunlukta yazdırılır ve genellikle çizgi deseni kullanılır. "Yüzey (skin)" ile eşanlamlıdır.
* **Top surface:** Üst yüzey: Üst yüzeyin en yüksek kısmı. Nadiren 1 katmandan fazla olan bu üst yüzey, daha fazla baskı süresi maliyeti olmadan daha yüksek kalite elde etmek için ayrı ayarlarla yazdırılabilir.
* **Topography:** Topografi: Sınırlı katman yüksekliğinin, neredeyse düz bir yüzeyi, katmanların sona erdiği yerlerde halkalarla coğrafi bir yükseklik haritasını andıran bir şeye dönüştürme etkisi.
* **Toughness:** Dayanıklılık: Bir baskının plastik deformasyona ne kadar direnebileceğinin bir ölçüsü.
* **Transition (of walls):** Duvarların geçişi: Farklı sayıda duvarın bir araya gelerek bazı kısımlarda farklı sayıda duvar kullanarak parçayı daha ince veya kalın yaptığı yer.
* **Travel (move):** Seyahat: Malzeme ekstrüde etmeden nozulu bir yerden bir yere hareket ettirme.
* **Underextrusion:** Yetersiz ekstrüzyon: Bir hacmi düzgün doldurmak veya güçlü ve sürekli boncuklar oluşturmak için yeterince malzeme ekstrüde edilmemesi.
* **Underpressure:** Düşük basınç: Geri çekildiğinde, nozul odası negatif basınçta tutulur, bu da malzemeyi içine çeker ve sızmayı önler.
* **Vase mode:** Vazo modu (Vase mode): Modellerin sadece dış hatlarını yazdırma modu, genellikle Z dikişini ortadan kaldırmak için Z koordinatını katman boyunca kademeli olarak artırarak. Cura her zaman bunu "spiralize mode" olarak adlandırır.
* **Walls:** Duvarlar: Baskının yan kısımları. Modelin etrafında yatay olarak dönerler.
* **Warping:** Bükülme: Malzemenin küçülmesi veya katılaşmadan önce malzemeye uygulanan iç gerilmeler nedeniyle baskının yazdırıldıktan sonra deformasyonu.
* **Width:** Genişlik (Width): Yatay yönde (X/Y) bir yapının boyutu. "Kalınlık (Thickness)" ile karşılaştırın.
* **Winding order:** Sarma sırası: Bir poligonu oluşturan noktaların sırası. Ya saat yönünde ya da saat yönünün tersinde. Cura'da, saat yönünün tersine sarma sırası pozitif bir şekli, saat yönünde sarma sırası ise bir deliği gösterir. Girdi 3D modelleri, dışarıdan bakıldığında saat yönünün tersine sarma sırasına sahip üçgenlere sahip olmalıdır.
* **Wiping:** Silme: Nozulu, nozul ucundaki sarkan sızan malzemeyi silmek için kasıtlı olarak daha önce yazdırılmış bir yapıyı geçirme tekniği, böylece bu malzemenin baskının dışına yerleştirilmesini önler.
* **Wire printing:** Tel baskı: Bir modeli sadece kabuğunun etrafında bir tel çerçeve yazdırarak baskı yapma tekniği. Oldukça deneysel.
* **Z seam:** Z dikişi (Z seam): Nozulun bir katmandan diğerine geçtiği dış duvarda görünen bir nokta. Genellikle yanlışlıkla sadece "dikiş (seam)" yerine kullanılır.
* **Z hop:** Z sıçraması (Z hop): Nozulun baskı üzerinde biraz boşluk bırakarak hareket etmesi için yukarı (+Z) hareket ettirildiği bir teknik. "Hop" ile eşanlamlıdır.