İlk Direk Salınımı (Jerk)
====
Bu ayar, ilk direk yazdırılırken nozülün köşelerden geçiş hızını belirler. Bu, baskının geri kalanından ayrı olarak yapılandırılabilir.

Jerk'i azaltmak, ilk direk yazdırılırken yazıcı içindeki titreşimleri azaltır. Bu, ilk direğin devrilme olasılığını azaltabilir.
