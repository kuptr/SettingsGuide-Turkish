Duvar Salınımı (Jerk'i)
====
Bu ayar, duvarları yazdırırken nozülün köşelerden geçiş hızını belirler. Bu, baskının geri kalanından ayrı olarak yapılandırılabilir.

Duvarları yazdırırken, yazıcı basılı nesneye göre titreşimlere çok duyarlıdır. Eğer yazıcı kafası basılı nesneye göre titreşirse, bu son baskıda halka izleri şeklinde görülebilir. Bu nedenle, duvarları baskının geri kalanından daha düşük bir jerk oranında yazdırmak faydalıdır.

Ancak bu, dış taraftaki köşelerin daha az keskin olmasına neden olabilir, çünkü nozül köşede daha fazla yavaşlar ve daha fazla malzeme bırakır. Bu etki, özellikle Bowden tarzı yazıcılarda besleyicinin tepki süresinin daha uzun olmasıyla daha belirgin hale gelir. Bu bir dengeleme işlemidir.