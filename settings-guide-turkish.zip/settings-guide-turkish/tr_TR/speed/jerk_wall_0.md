Dış Duvar Salınımı (Jerk'i)
====
Bu ayar, dış duvarı yazdırırken nozülün köşelerden geçiş hızını belirler. Bu, iç duvarlardan ayrı olarak yapılandırılabilir.

Dış duvarları yazdırırken, yazıcı titreşimlere çok duyarlıdır. Eğer yazıcı kafası basılı nesneye göre titreşirse, bu son baskıda hemen halka izleri şeklinde görülebilir. Bu nedenle, dış duvarları iç duvarlardan daha düşük bir jerk oranında yazdırmak faydalıdır.

Ancak bu, dış taraftaki köşelerin daha az keskin olmasına neden olabilir, çünkü nozül köşede daha fazla yavaşlar ve daha fazla malzeme bırakır. Bu etki, özellikle Bowden tarzı yazıcılarda besleyicinin tepki süresinin daha uzun olmasıyla daha belirgin hale gelir. Bu bir dengeleme işlemidir.