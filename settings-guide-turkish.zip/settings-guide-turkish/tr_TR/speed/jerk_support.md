Destek Salınımı
====
Bu ayar, destek yapıları yazdırılırken nozülün köşelerden geçiş hızını belirler. Bu, baskının geri kalanından ayrı olarak yapılandırılabilir.

Destekler için köşelerden dikkatlice geçmek önemli değildir. Desteklerin estetik olması gerekmez; sadece ayakta durmaları yeterlidir. Destekler yazdırılırken jerk oldukça yüksek ayarlanabilir. Genellikle bu, desteklerin daha güçlü ve çıkarılmasının daha kolay olmasını sağlar, çünkü ekstrüzyon hızı daha sabit olacaktır.

Ancak jerk'i çok fazla artırmak, katman kayması olasılığını artırır. Bu, motorların sınırlarını gerçekten zorlar.