Üst Yüzey İvmesi Değişimi
====
Bu ayar, üst yüzeyleri yazdırırken nozülün köşelerden geçiş hızını belirler. Bu, üst yüzeyin geri kalanından ayrı olarak yapılandırılabilir.

Bu baskı bölümü için jerk'i artırmak, nozülün komşu üst yüzey çizgileri arasındaki köşelerde durmamasını sağlar. Bu, çizgi genişliğinin genel olarak daha tutarlı olmasına izin verir. Bu etki, çizgi genişliğinin nozül çapından çok daha küçük olduğu durumlarda, üst yüzey için yaygın bir kullanım durumudur. Ancak jerk'i çok fazla artırmak, yapı platformunun titreşmesine ve düzensiz bir yüzey oluşturmasına neden olabilir. Hatta motorların adımlarını kaybetmesine yol açabilir, bu da katman kaymasına sebep olabilir.