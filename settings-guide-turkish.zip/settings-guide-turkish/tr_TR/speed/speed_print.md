Yazdırma Hızı
====
Bu ayar, modelin genel olarak hangi hızda basılacağını ayarlar.

Baskı hızları genellikle baskının farklı yapıları için ayrı ayrı ayarlanabilir, bu nedenle gerçek baskı hızı değişebilir. Bu ayar, diğer hızların oranına göre ayarlanmasını sağlar.

![Hazırlama aşamasında, baskı hızını görselleştiren bir renk şeması bulunmaktadır](../images/speed_difference.png)

Bu ayar, basılmış parça kalitesi ile baskı süresi arasındaki denge üzerinde büyük etkiye sahiptir. Baskı hızını artırmak, baskının süresini azaltacak ancak baskı kafasının titreşimini artıracaktır. Ayrıca, besleyicinin tempo tutmasını zorlaştırarak, baskının aşırı veya yetersiz ekstrüzyona daha duyarlı hale gelmesine neden olabilir.

Baskı hızını artırırken malzeme sıcaklığını da artırmak tavsiye edilir. Bu, malzemenin biraz daha akıcı hale gelmesini sağlar, bu da daha yüksek hızlarda daha kolay akmasını sağlar.

**Baskı hızını artırmak, baskının çok sayıda küçük detaya sahip olması durumunda büyük bir etkiye sahip olmayabilir. Bu durumda hızlanma ve jerk sınırlayıcı faktörler olabilir.**