İlk Direk İvmesi
====
Bu ayar, ısıtma kulesi baskısı sırasında nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Isıtma kulesi sırasında hızlanma, baskının geri kalanından farklı bir hızda ayarlanabilir.

Isıtma kulesini daha yüksek bir hızlanma oranında basmak, ekstrüzyonun biraz daha sabit olmasını sağlayarak daha iyi bir hazırlık sağlar. Ayrıca baskı süresinden tasarruf sağlar. Ancak, ısıtma kulesi çok yüksek olursa ve baskı sırasında yazıcı çok titreşirse, kule daha kolay devrilebilir.