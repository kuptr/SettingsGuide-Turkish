Dolgu Salınımı (Jerk)
====
Bu ayar, dolgu baskısı yapılırken nozülün köşelerden geçiş hızını belirler. Bu, baskının geri kalanından ayrı olarak yapılandırılabilir.

Infill genellikle dışarıdan görünmez, bu nedenle biraz daha fazla jerk ile basılabilir ve bununla birlikte baskı süresinden kazanç sağlanabilir. Yazıcı daha fazla titreşebilir, ancak bu genellikle gözle görülmez. Ancak nozül köşede biraz fazla hızlanabilir. Özellikle duvarlardan önce dolgu basılıyorsa, bu fazla hızlanma dolgu deseninin dışarıdan daha görünür olmasına neden olabilir.

Aksine, jerk'i azaltmak baskınızın daha güçlü olmasını sağlayabilir. Nozül, infillin duvarlarla temas ettiği köşelerde daha fazla zaman geçirir ve bu sayede orada daha geniş bir çizgi oluşturur. Bu daha geniş çizgi, infillin duvarlara daha iyi yapışmasını sağlar ve bu da parçanın genel sağlamlığını artırır.