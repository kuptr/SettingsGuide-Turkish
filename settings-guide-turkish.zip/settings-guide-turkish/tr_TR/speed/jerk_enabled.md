Salınım (Jerk) Kontrolünü Etkinleştir
====
Jerk, 3D yazıcının köşelerden geçerken nozülün hızını belirler. Eğer jerk kontrolü etkinse, Cura baskının çeşitli kısımlarında uygulanacak jerk miktarını belirler. Eğer devre dışı bırakılırsa, yazıcı firmware'i bir jerk değeri seçer. Yazıcı firmware'inin jerk değeri genellikle dilimleyiciye daha fazla kontrol sağlamak için yüksektir, ancak kendi donanımıyla ilgili Cura'dan daha fazla bilgiye sahip olabilir.

![Hız, ivme ve jerk arasındaki ilişki](../images/velocity_acceleration_jerk.svg)

**3D yazıcılar için jerk, fizikteki jerk ile aynı değildir.** "Jerk" terimi Marlin tarafından tanıtıldı. Yolu mükemmel şekilde takip etmeye çalışmanın içsel sorununu çözmek için tasarlandı. Teoride nozülün yoldan sapmamasına izin verilmediği için, nozül her köşede 0mm/s'ye hızlanması gerekecekti. Bu baskınızı bozabilir, çünkü 0mm/s'ye hızlanmak her köşede bir topak oluşturabilir. Köşeyi kısaltmak için eğri yapılmasına izin verilmiyor, ayrıca fazla hızlandırılamaz. Bunun yerine, Marlin her köşede hızın anlık olarak değişmesine izin verir. Bu hız değişiminin büyüklüğü "jerk" olarak adlandırılır.

Yani jerk, her hareketin köşesinde uygulanan maksimum anlık hız değişimidir.

Marlin gibi Marlin temelli olmayan firmware'ler (örneğin Sailfish firmware ailesi), jerk değişikliklerini görmezden gelecektir. Bu ayarın etkisi olmayacaktır.

Jerk'in matematiksel örneği
----
Örneğin, çok basit bir baskı alalım: İlk olarak 100mm sağa, sonra 100mm aşağı hareket edin. Baskı hızı 50mm/s olarak ayarlanmıştır. Hızlanma 1000mm/s^2 olarak ayarlanmıştır. Jerk ise 10mm/s olarak ayarlanmıştır. İşte ne olacak:
1. Baskının başlangıcında, Marlin yarısı jerk değerini alır, bu yüzden teorik olarak anında 5mm/s hıza hızlanacaktır.
2. 1000mm/s^2 hızlanmayla, 5mm/s'ten maksimum hız olan 50mm/s'ye hızlanması 0.045 saniye sürecektir. Bu süre içinde nozül 1.2375mm yol kat eder.
3. Nozül bir süre boyunca 50mm/s maksimum hızla ilerler.
4. Marlin köşeden ne kadar hızla geçebileceğini hesaplar: Nozül 90 derece bir köşe yapacak, önce sağa sonra aşağı gidecek. Bu hız değişimini sınırlamak için, sağa doğru cos(90/2) * (10/2)mm/s hızla girecek ve aşağı doğru çıkacak. Bu nedenle köşeden yaklaşık 7.07mm/s hızla geçecektir.
5. 50mm/s'ten 7.07mm/s hıza hızlanmak için 0.043 saniye sürecektir.
6. Köşe, anlık bir hız değişimi ile yapılır. [7.07, 0] ve [0, 7.07] vektörleri arasındaki farkın büyüklüğü tam olarak 10mm/s olduğundan, bu köşe anında yapılabilmektedir.
7. 7.07mm/s'den 50mm/s'ye hızlanmak için 0.043 saniye sürecektir.
8. Nozül bir süre boyunca yine 50mm/s maksimum hızla ilerler.
9. Baskının sonuna doğru, nozül 50mm/s'den 0mm/s'ye 0.05 saniyede hızdan kurtulacaktır