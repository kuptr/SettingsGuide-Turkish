İlk Katman Hareket Hızı
====
Bu ayar, ilk katmanın basılması sırasında yapılan seyahat hareketlerinin hızını ayarlar.

İlk katmanın baskı hızı, baskının geri kalan kısmından daha düşük olmalıdır, çünkü bu katmanda nozulun baskıyı yapı platformundan koparma olasılığı daha yüksektir.

İlk katmanda, baskı platformunun titreşimlerine karşı daha duyarlıdır. İlk katmanın seyahat hızını artırmak daha fazla titreşime neden olabilir. Bu da baskının yapı platformuna yapışma gücünü azaltır ve baskının başarısız olma olasılığını artırabilir.

Yine de, ilk katman sırasında seyahat hızı, baskı hızından daha yüksek olabilir, çünkü bu durumda eksik ekstrüzyon oluşmaz.