Dış Duvar Hızı
====
Bu ayar, dış duvarların basıldığı hızı normal baskı hızından veya iç duvarlardan ayrı olarak yapılandırmanıza olanak tanır.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Dış duvarlar bir baskının görsel kalitesinde en önemli faktördür, bu yüzden güzel görünmelidirler. Dış duvarların baskı hızı, bu duvarların ne kadar güzel görüneceğinde önemli bir faktördür. Bu nedenle dış duvarların çok yavaş basılması tavsiye edilir. Bu, yazıcıdaki titreşimleri azaltır, bu da sonuçta zil sesini azaltır. Ayrıca, yavaş baskı hızı asma katlarının kalitesini iyileştirir; çünkü yavaş baskı hızı fanların duvarları daha iyi soğutmasına izin verir, bu da havada daha fazla dayanıklılık sağlar.

Ancak dış duvar baskı hızı çok düşükse, çok büyük bir akış değişikliği riski vardır. Nozul aniden çok daha yavaş ekstrüde etmek zorunda kalırsa, nozul odasındaki basınç düşerken bir süre boyunca hala çok miktarda malzeme ekstrüde edecektir, bu da duvarın başlangıcında aşırı ekstrüzyona neden olabilir.

Dış duvarlar aynı zamanda baskı süresinin önemli bir bölümünü oluştururlar, bu nedenle bu duvarların daha yavaş basılması baskı süresini önemli ölçüde artırabilir.