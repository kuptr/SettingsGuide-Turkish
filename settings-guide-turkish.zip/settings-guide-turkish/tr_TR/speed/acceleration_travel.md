Hareket İvmesi
====
Bu ayar, nozülün yapı hacmi boyunca seyahat ederken farklı yönlere ne kadar hızlı hızlandığını kontrol eder. Seyahat sırasındaki hızlanma, malzeme ekstrüde edilirkenki hızlanmadan farklı bir oranda ayarlanabilir.

Seyahat hareketleri genellikle son derece hızlı ve oldukça uzun düz çizgilerdir. Bu, nozülün büyük hızlara ulaşmasına olanak tanır ve bu da hızlanmayı baskı süresinde önemli bir faktör haline getirir. Yazıcı bu hareketler sırasında malzeme ekstrüde etmediği için, yazıcının titreşimlerinin baskı üzerinde gerçek bir etkisi olmaz. Sonuç olarak, seyahat hızlanması baskı süresinden tasarruf etmek için oldukça yüksek olarak ayarlanmalıdır.

Ancak hızlanmayı çok yüksek ayarlamak, motorların bazı adımlarını kaybetmesine yol açabilir, bu da katman kaymalarına neden olabilir.