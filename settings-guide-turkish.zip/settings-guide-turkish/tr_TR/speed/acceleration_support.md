Destek İvmesi
====
Bu ayar, destek basılırken nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Destek sırasında hızlanma, baskının geri kalanından farklı bir hızda ayarlanabilir.

Hızlanma oranını artırmak, yazıcının destekleri toplamda daha hızlı basmasını sağlar, ancak daha dikkatsiz bir şekilde yapabilir. Bu, baskı süresini azaltırken, yazıcının destekleri devirmesi ve destek yapısını zayıflatması ihtimalini artırabilir. Genellikle destek, baskının geri kalanına kıyasla yüksek hızlanma ile basılır.