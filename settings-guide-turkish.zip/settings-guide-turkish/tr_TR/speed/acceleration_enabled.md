İvme Kontrolünü Etkinleştir
====
Bu ayar, baskı kafasının ne kadar hızlı hızlanması gerektiği konusunda Cura'nın kontrolü ele almasını sağlar. Bir araba gibi, baskı kafasının hızını değiştirebilmesi için hızlanması gerekir. Normalde yazıcı, baskı kafasının ne kadar hızlı yön değiştirmesi ve hızını değiştirmesi gerektiğine kendi karar verir, ancak bu ayar etkinleştirildiğinde, Cura bunun yerine karar verebilir ve bu, baskının her bir özelliği için farklı hızlanma oranlarına sahip olmanızı sağlar.

![Bir nozulu ileri geri hareket ettirirken zamanla (t) hızın (V) grafiği. Hızlanma, başlarken, dururken veya yön değiştirirken doğrunun eğimidir.](../images/velocity_acceleration_jerk.svg)

* Hızlanmayı artırmak, baskı kafasının istenen hıza daha hızlı ulaşmasını sağlar. Bu, özellikle küçük parçalar basarken baskıyı hızlandırır, ancak daha fazla titreşime de neden olur. Bu titreşimler boyutsal doğruluğu azaltır ve "çınlama" (ringing) etkisi yaratır.