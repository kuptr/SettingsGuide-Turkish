İç Duvar Salınımı (Jerk'i)
====
Bu ayar, iç duvarları yazdırırken nozülün köşelerden geçiş hızını belirler. Bu, dış duvarlardan ayrı olarak yapılandırılabilir.

İç duvarlar dışarıdan pek görünmez, yalnızca düz üst ve alt yüzlerde titreme pek sorun olmamakla birlikte. Dış duvar tarafından gizlenirler. Ancak [iç duvarlar dış duvarlardan önce](../shell/outer_inset_first.md) yazdırırsanız, iç duvarlardaki titreşimler bazı yerlerde dış duvarı iterek dış yüzeye halka izleri gibi yansımasına neden olabilir. Eğer dış duvar öncelikle yazdırılırsa, bu etki azalır. Ancak titreşen bir nozülün kısmen dış duvar üzerinden geçmesi dahi hafif bir halka izine neden olabilir.

Bu nedenle, iç duvar jerk değeri genellikle dış duvar jerk değerinden biraz daha fazladır, ancak genel baskının jerk değerinden daha azdır.