Destek Arayüz Salınımı
====
Bu ayar, destek arayüzü yazdırılırken nozülün köşelerden geçiş hızını belirler. Bu, destek parçasının ana kısmından ayrı olarak yapılandırılabilir.

Genellikle destek arayüzü, oldukça yüksek jerk değerleriyle yazdırılabilir çünkü arayüzde herhangi bir dalgalanma veya ekstrüzyon hızında tutarsızlık olup olmadığı önemli değildir. Ancak destek arayüzü, gerçek baskıya oldukça yakın yerleştirilir ve desteğin nesneye nasıl bağlanacağını belirler. Eğer arayüz titreşimler nedeniyle hatalı yazdırılırsa, destek baskıya çok iyi yapıştığı için iz bırakabilir veya destek ile model arasında çok fazla boşluk olduğunda kötü çıkıntılara neden olabilir. Bu nedenle, destek arayüzü sırasında jerk'i destek parçasının geri kalanına göre biraz daha düşük ayarlamak gerekebilir.