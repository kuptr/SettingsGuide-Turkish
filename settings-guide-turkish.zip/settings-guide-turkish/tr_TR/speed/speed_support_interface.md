Destek Arayüzü Hızı
====
Bu ayar, [Destek Arayüzünü Etkinleştir](../support/support_interface_enable.md), destek yapısının üst ve alt tarafının hangi hızda basılacağını ayarlar.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Daha yüksek bir hız, baskı süresinden tasarruf sağlayabilir.

Daha düşük bir hız, asma katlarda kaliteyi artırabilir. Çatıların daha doğru ve düzgün bir şekilde basılmasına neden olur. Sonuç olarak, çatının üstündeki yüzey de daha doğru olacaktır. Destek yapısının modelden çıkarılması da daha tutarlı olacaktır, bu da model üzerinde daha az iz bırakır.

Bu ayarın destek yapısının alt tarafı üzerindeki etkisi, malzemenin soğuma davranışına bağlıdır. Malzeme soğurken yapışmayı artırabilir veya azaltabilir.

Eğer destek modelle çok yakınsa, örneğin PVA veya diğer çözünür destek malzemeleri için, destek hızını artırmak nozulün modelin içine aşırı çıkmasına ve yüzeyi hafifçe bozmasına neden olabilir.