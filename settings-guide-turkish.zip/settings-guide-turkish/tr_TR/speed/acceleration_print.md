Yazdırma İvmesi
====
Baskı kafasının, istenen hıza ulaşmak için başlangıç, durma veya yön değiştirme sırasında ne kadar hızlı hızlanabileceğini belirler. Bir araba gibi, baskı kafasının hızını veya yönünü değiştirebilmesi için hızlanması gerekir.

![Bir nozulu ileri geri hareket ettirirken zamanla (t) hızın (V) grafiği. Hızlanma, başlarken, dururken veya yön değiştirirken doğrunun eğimidir.](../images/velocity_acceleration_jerk.svg)

Hızlanmayı artırmak, baskı kafasının istenen hıza ve yöne daha hızlı ulaşmasını sağlar. Bu, özellikle küçük parçaları basarken baskıyı hızlandırır, ancak daha fazla titreşime de neden olur. Bu titreşimler, boyutsal doğruluğu azaltır ve "çınlama" (ringing) etkisi yaratır.