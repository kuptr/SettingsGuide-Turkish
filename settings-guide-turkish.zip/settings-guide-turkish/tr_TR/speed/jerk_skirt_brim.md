Etek/Kenar İvmesi Değişimi
====
Bu ayar, etek veya kenar yazdırılırken nozülün köşelerden geçiş hızını belirler. Bu, ilk katmanın geri kalanından ayrı olarak yapılandırılabilir.

Nozül köşelerden geçerken baskı kafası sadece yatay olarak titreşmekle kalmaz, yapı platformu da dikey olarak titreşebilir. Bu titreşim, etek veya kenar ile yapı platformu arasındaki yapışmanın tutarlılığını azaltır. Etek veya kenar yazdırılırken jerk'in azaltılması, baskının yapı platformundan ayrılma olasılığını azaltabilir.

Bununla birlikte, etek ile yapı platformu arasındaki yapışma çok önemli değildir. Etek ayrılırsa, baskı muhtemelen yine de başarılı olacaktır. Ayrıca, etek veya kenar yazdırırken genellikle titreşime neden olabilecek çok keskin köşeler bulunmaz. Bu ayarı ayarlamanın etkisi çok küçük olacaktır.

Etek ve kenar her zaman ilk katmanın bir parçası olmasına rağmen, [İlk Katman Yazdırma Salınımı](jerk_print_layer_0.md) bunlar üzerinde etkili değildir. Bu ayar, İlk Katman Baskı Jerk'inin yerine geçer.