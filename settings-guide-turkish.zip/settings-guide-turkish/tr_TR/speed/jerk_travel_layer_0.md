İlk Katman Hareket Salınımı (Jerk'i)
====
Bu ayar, ilk katman sırasında yapı platformu üzerinde hareket ederken nozülün köşelerden geçiş hızını belirler. Bu, ilk katman ekstrüzyon hareketlerinden ayrı olarak yapılandırılabilir.

Seyahat hareketleri sırasında, baskı ile yapı platformu arasındaki yapışma titreşimlerden etkilenmez. Ancak yapı platformu çok fazla titreşirse, nozül baskıyı yapı platformundan koparabilir. Bu nedenle, ilk katmanın seyahat hareketleri sırasında jerk, ekstrüzyon hareketlerine göre biraz daha yüksek, ancak diğer katmanlardaki seyahat hareketlerine göre daha düşük ayarlanabilir.