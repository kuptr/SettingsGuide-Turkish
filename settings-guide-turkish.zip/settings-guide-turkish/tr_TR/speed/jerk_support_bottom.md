Destek Zemini Sarsıntısı (Jerk'i)
====
Bu ayar, destek tabanlarını yazdırırken nozülün köşelerden geçiş hızını belirler. Bu, destek tavanlarından ayrı olarak yapılandırılabilir.

Destek tavanı, hem iz bırakma hem de çıkıntı kalitesi için kritik öneme sahipken, destek tabanı sadece iz bırakmayı etkiler. Model destek tabanına değil, sadece desteğe oturduğu için çıkıntı kalitesi üzerinde bir etkisi yoktur. Bu nedenle, baskı süresinden tasarruf etmek için destek tabanını destek tavanına göre biraz daha az dikkatli yazdırabilirsiniz.