Hareket Salınımını (Jerk'ini) Etkinleştir
====
Bu ayar etkinleştirildiğinde, seyahat hareketleri kendi jerk oranlarına sahip olur. [Hareket Salınımı](jerk_travel.md) ayarı, seyahat hareketlerinin köşelerden geçiş hızını kontrol eder.

Seyahat hareketi sırasında jerk değeri, seyahat hareketinin sonunda yazdırılacak olan çizginin jerk değeri olacaktır. Örneğin, infill'e doğru hareket ediyorsa, seyahat hareketi sırasındaki jerk [Dolgu Salınımı](jerk_infill.md) olacaktır. Dış duvara doğru hareket ediyorsa, jerk [Dış Duvar Salınımı](jerk_wall_0.md) olacaktır. Bu şekilde, daha hassas yapılara diğer yapılardan daha dikkatli yaklaşılır.

Bu ayar varsayılan olarak etkindir ve seyahat sırasında jerk'i kontrol etmeyi sağlar. Bu, çoğu durumda iyidir, çünkü artan seyahat jerk'i zaman kazandırabilir, oysa bu kadar yüksek köşe hızları yazdırma sırasında kullanıldığında [ringing/çınlama](../troubleshooting/ringing.md) sorununa neden olur.

Ancak, bu ayarı devre dışı bırakmak isteyebileceğiniz iki neden vardır:

* Seyahat hareketleri için jerk oranını değiştirmek amacıyla, Cura jerk oranını çok sık değiştirir. Özellikle bazı infill desenlerinde ve duvarlardaki küçük detaylarda, ekstrüzyon ve seyahat arasında sık sık geçiş yapar. Firmware'in bu komutları işlemesi gerekir ve gerekli hesaplamalara ayak uyduramayabilir. Seyahat jerk'ini devre dışı bırakmak bu sorunu azaltır.
* Seyahat jerk'inin artırılması yazıcının çok titreşmesine neden olur. Bu titreşimler, seyahat hareketinin sonunda yazdırma başlamadan hemen önce tamamen durmayabilir. Bu da seyahat hareketinin sonunda ringing oluşmasına yol açabilir. Seyahat jerk'ini devre dışı bırakmak, nozülün baskının hassas yapılarına (örneğin dış duvar) daha az hassas yapılara (örneğin içdolgu) göre daha dikkatli yaklaşmasını sağlar.