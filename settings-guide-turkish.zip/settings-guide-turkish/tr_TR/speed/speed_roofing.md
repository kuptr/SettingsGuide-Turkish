Üst Yüzey Hızı
====
Bu ayar, üst yüzey deri katmanlarının basıldığı hızı ayarlar. Bu katmanlar, [Üst Yüzey Katmanları](../top_bottom/roofing_layer_count.md) ayarıyla yapılandırıldıysa geçerlidir.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Üst yüzey çok görünür olduğundan, bu alanın geri kalan deriye göre daha düşük bir hızda basılması ek zaman harcamaya değer olabilir. Bu, üst yüzeyin görsel kalitesini ve su geçirmezliğini artırır. Ancak bu hızı fazla düşürmek, üst yüzeyden geçiş yaparken büyük akış değişikliklerine neden olabilir.