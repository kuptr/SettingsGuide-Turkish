Duvar İvmesi
====
Bu ayar, duvarları yazdırırken nozülün farklı yönlere ne kadar hızlı hızlandığını kontrol eder. Duvarlar sırasındaki hızlanma, baskının geri kalanından farklı bir oranda ayarlanabilir.

Buradaki hızlanmayı ayarlamak, baskının boyutsal doğruluğunu büyük ölçüde etkiler. Yüksek hızlanma değerleri, yazıcı boyunca şok dalgalarına neden olur. Bu şok dalgaları, nozül veya yapı platformu titrediğinde baskıda görülebilir. Duvarlar dışarıdan çok görünür oldukları için, genellikle duvarların baskının geri kalanından daha düşük bir hızlanma oranıyla yazdırılması tercih edilir. Bununla birlikte, bu durum baskı süresinin artmasına yol açabilir.