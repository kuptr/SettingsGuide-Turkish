Dolgu İvmesi
====
Bu ayar, dolgu baskısı sırasında nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Dolgu sırasında hızlanma, baskının geri kalanından farklı bir hızda ayarlanabilir.

Dolgu içeride olduğu ve görünmediği için, dolgunun hızlanmasını ayarlamak baskının görsel kalitesi üzerinde düşük bir etkiye sahip olma eğilimindedir. Dolgu çizgileri genellikle yüksek hızda basılan uzun düz çizgilerden oluşur ve keskin köşelerle birleştirilir. Hızlanma, bu çizgilerin baskı süresi üzerinde büyük bir etkiye sahiptir. Bu nedenle, dolgu için hızlanma oranını, baskının geri kalanına göre biraz daha yüksek ayarlamak yaygındır.