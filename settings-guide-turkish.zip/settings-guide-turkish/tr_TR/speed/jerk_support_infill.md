Destek Dolgu İvmesi Değişimi
====
Bu ayar, ana destek parçasını yazdırırken nozülün köşelerden geçiş hızını belirler. Bu, destek arayüzünden ayrı olarak yapılandırılabilir.

Destek dolgusunun köşelerden dikkatlice geçmesi önemli değildir. Destek dolgusunun estetik olması gerekmez; sadece ayakta durması yeterlidir. Bu nedenle, jerk oldukça yüksek ayarlanabilir. Genellikle bu, destekleri daha güçlü ve çıkarılması daha kolay hale getirir, çünkü ekstrüzyon hızı daha sabit olacaktır.

Ancak jerk'i çok fazla artırmak, katman kayması olasılığını artırır. Bu, motorların sınırlarını gerçekten zorlar.