Dış Duvar İvmesi
====
Bu ayar, dış duvarları basarken nozülün farklı yönlere ne kadar hızlı hızlandığını kontrol eder. Dış duvarlar sırasında hızlanma, iç duvarlardan farklı bir oranda ayarlanabilir.

Buradaki hızlanmayı ayarlamak, baskının boyutsal doğruluğunu büyük ölçüde etkiler. Yüksek hızlanma oranları, yazıcı boyunca şok dalgalarına neden olabilir. Bu şok dalgaları, nozül veya yapı tablasının titreştiğinde baskıda görülebilir. Dış duvarlar dışarıdan çok görünür olduğu için, genellikle dış duvarların iç duvarlardan daha düşük bir hızlanma oranıyla basılması tercih edilir. Bununla birlikte, bu baskı süresinde bir artışa neden olabilir.