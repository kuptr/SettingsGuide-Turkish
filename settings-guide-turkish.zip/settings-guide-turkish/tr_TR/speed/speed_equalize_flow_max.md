Maximum Speed for Flow Equalization
====
Eğer [Equalize Filament Flow](speed_equalize_flow_enabled.md) ayarı etkinse, küçük boşluk doldurma tekniği, cilt ile eşit olacak şekilde akış hızını düzenler, hatta çizgiler çok daha ince olursa bile.

Bununla ilgili bir problem, çok ince çizgilerin sonuç olarak aşırı yüksek hızlara neden olabileceğidir. Bu tür hızlar, yazıcının ulaşamayacağı kayıp adımlara ve sonuç olarak bir katman kaymasına yol açabilir. Bu ayar, bu hızların üzerine bir maksimum koyar.

Küçük boşluklar genellikle doğası gereği küçük olduğundan, bu yüksek hızlarda çizilen çizgiler genellikle kısa olur. Bu, hızlanma sınırları nedeniyle, nozülün bu yüksek hızlara ulaşamayacağı anlamına gelir. Bu ayar genellikle, nozülün yazdıramayacağı kadar küçük iki duvar arasındaki uzun düz çatlakları dolduran küçük boşluk doldurma tekniklerinde etkilidir.