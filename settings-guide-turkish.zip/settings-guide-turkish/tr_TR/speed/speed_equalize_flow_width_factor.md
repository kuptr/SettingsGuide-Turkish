Akış Eşitleme Oranı
====
Bu özellik, yazıcınızın satır genişliğini ayarlamak için kullanacağı yöntemi değiştirmenizi sağlar: Nozuldan malzemenin akış hızını değiştirmek yerine yazıcı, nozulun hareket hızını değiştirir.

FFF (Fused Filament Fabrication) yazıcıları, malzemenin nozuldan çıkış hızını değiştirmede kötü bir üne sahiptir. Yazıcı, besleyici hızını değiştirdiğinde, bu değişikliğin gerçekten akış hızında bir değişime dönüşmesi birkaç saniye alabilir. Bu süre zarfında, baskı hızına bağlı olarak, akış hızının ayarlanması gereken noktadan milimetrelerce uzakta olabilir nozul. Bu durum, yazıcınızın besleyicisi nozul başlığından Bowden tüpü aracılığıyla uzakta ise daha da kötü olabilir.

Besleme hızını değiştirmek yerine yazıcı, baskı kafasının hareket hızını da değiştirebilir. Baskı kafası çok daha hızlı ivmelenebilir ve böylece çizgi genişliği üzerinde daha iyi kontrol sağlanabilir. Baskı kafası hızlandığında, akış hızı aynı kalırken aynı miktarda malzeme daha uzun bir mesafeye yayılır, bu da çizgi genişliğini azaltır. Baskı kafası yavaşladığında ise aynı miktarda malzeme daha küçük bir alanda toplanır, çizgi genişliğini artırır.

Bu ayar bir orandır. Bu oran akış hızını (%0) veya baskı hızını (%100) veya her ikisini birlikte değiştirebilir. Oran, akış hızını kalın çizgiler üretmek için azaltırken, bunu telafi etmek için daha fazla hızı azaltarak (%100'den daha fazla olabilir) artırabilir.

Bu oranı %100'e doğru artırmak, çizgi genişliğini değiştirmek için akış hızı yerine hızı kullanmanın etkilerini şu şekilde yapar:
* Çizgi genişliği daha doğru olabilir, baskının boyutsal doğruluğunu artırır.
* Akış hızı sabit kalır, bu da özellikle egzotik malzemelerle daha güvenilir bir baskı sağlar.
* Bazı yerlerde baskı kafası daha hızlı hareket eder, bu da yüzüklenmeye neden olabilir.

Bu ayar, ince parçaların ve keskin köşelerin genişliği ile ilgili olarak çizgi genişliğindeki değişikliklere uygulanır. Dolgu ve duvar için farklı çizgi genişlikleri gibi ayarlar nedeniyle akış hızındaki değişiklikler telafi edilmez. Köprüleme veya ütüleme gibi özellikler de telafi edilmez. Lineer Advance gibi benzer telafi özelliklerini uygulayan yazıcılar, bu ayar %100 olarak ayarlanmış olsa bile bunları kullanmaya devam etmelidir, çünkü bu ayarlar nedeniyle hala akış değişiklikleri olabilir.