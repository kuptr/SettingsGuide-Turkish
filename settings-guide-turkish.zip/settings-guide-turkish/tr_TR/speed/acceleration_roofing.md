Üst Yüzey İvmesi
====
Bu ayar, üst yüzey baskısı sırasında nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Üst yüzey sırasında hızlanma, cildin geri kalanından farklı bir hızda ayarlanabilir.

Üst yüzey sırasında hızlanmayı azaltmak, tüm üst yüzeyin ayarlanmasından daha az baskı süresi cezası ile daha iyi su geçirmezlik sağlayabilir.

Bu hızlanmayı azaltmak, yazıcıdaki titreşimleri de azaltır. 3D yazıcınızın yapı yapısına bağlı olarak, bu titreşimler baskı tablasının da titreşmesine neden olabilir ve bu da yüzeyin düzensiz olmasına yol açar. Bu hızlanmayı azaltmak bunu önleyebilir.