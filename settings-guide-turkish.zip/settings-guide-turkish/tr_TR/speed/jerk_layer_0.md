İlk Katman Salınımı (Jerk'i)
====
Bu ayar, ilk katmanın yazdırıldığı sırada nozülün köşelerden geçiş hızını belirler. Bu, diğer katmanlardan ayrı olarak yapılandırılabilir.

Keskin köşelerden yüksek hızlarda geçmek, sadece baskı kafasının yatay olarak titremesine neden olmaz. Aynı zamanda yapı platformunun dikey olarak titremesine de yol açabilir. Bu, yatak yapışmasını olumsuz etkiler. İlk katman sırasında köşelerden biraz daha dikkatlice geçmek, daha tutarlı bir yatak yapışması sağlar ancak baskı süresini uzatabilir.

Ek olarak, jerk'i azaltmak genellikle yazıcının keskin köşelerde daha fazla malzeme bırakmasını sağlar çünkü nozül, malzeme akışı azalırken yavaşlar ve malzeme akışı azalma gecikmesi vardır. Bu keskin köşeler, baskının çarpılmasından dolayı genellikle yapı platformundan ilk ayrılan yerlerdir. Bu köşelere ekstra malzeme bırakmak avantajlıdır, çünkü köşelerin daha iyi yapışmasını sağlar.

Baskının farklı yapıları genellikle farklı jerk değerlerine sahip olabilir. Infill, taban, dış ve iç duvarlar, destek ve prime tower için ayrı ayarlar bulunmaktadır. Bu ayar, tüm bu ayarların üzerine yazacaktır. Yalnızca [Etek/Kenar İvmesi Değişimi](jerk_skirt_brim.md) ayarı, bu jerk'i geçersiz kılabilir, çünkü etek ve kenar sadece ilk katmanda meydana gelir.