Hareket Salınımı (Jerk'i)
====
Bu ayar, nozül yapı hacmi boyunca hareket ederken köşelerden geçiş hızını belirler. Bu, nozül malzeme ekstrüzyonu yaparken ayarlanan hızdan ayrı olarak yapılandırılabilir.

Bu süre zarfında nozül malzeme ekstrüzyonu yapmadığı için, yazıcının titreşim yapması pek önemli değildir. Cura'yı [aHareket Sırasında Yazdırılan Bölümleri Atlama](../travel/travel_avoid_other_parts.md)'ya göre yapılandırdıysanız, yeterli bir [Hareket Atlama Mesafesi](../travel/travel_avoid_distance.md) bırakmak, nozülün biraz titreşse bile baskınıza çarpmasını önleyecektir. Bu nedenle, seyahat hareketleri sırasında baskı süresinden tasarruf etmek için jerk'i çok yüksek ayarlamak faydalıdır.

Ancak jerk'in çok yüksek ayarlanması, motorların adım atlamasına ve dolayısıyla katman kaymasına neden olabilir.