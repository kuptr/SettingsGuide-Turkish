Destek Hızı
====
Bu ayar, destek yapılarının hangi hızda basılacağını ayarlar.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Normalde destek yapıları çok hassas bir şekilde basılmaya ihtiyaç duymaz, bu nedenle baskıdan geri kalan kısımlardan daha yüksek bir hızda basmak güvenlidir. Bu, baskı süresinden tasarruf sağlayabilir.

Ancak hızı fazla artırmak, destek ve baskı arasında akış hızında farklılık yaratır. Bu durum, destekten baskıya geçişte aşırı ekstrüzyona ve baskıdan desteğe geçişte eksik ekstrüzyona neden olabilir.