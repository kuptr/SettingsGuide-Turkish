Etek/Kenar İvmesi
====
Bu ayar, skirt veya brim baskısı sırasında nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Skirt veya brim sırasında hızlanma, baskının geri kalanından farklı bir hızda ayarlanabilir. Skirt ve brim her zaman ilk katmana özgü olsa da, bu ayar [İlk Katman Yazdırma İvmesi](acceleration_print_layer_0.md) ayarını geçersiz kılar. Bunlar, genel olarak ilk katman ayarları değil, bu ayarla belirlenen hızlanma kullanılarak basılır.

Brim, baskı tablasına yapışma açısından çok önemlidir, bu yüzden brim baskısı sırasında hızlanma oranlarını azaltmak, baskı sırasında titreşimleri azaltabilir ve brim'in baskı tablasına yapışmasını iyileştirir, brim'in etkinliğini küçük bir baskı süresi maliyeti ile artırır.

Ancak hızlanmanın brim ve skirt üzerindeki etkisi genellikle son derece küçüktür, çünkü bunlar genellikle pürüzsüz eğrilere sahip çizgilerden oluşur. Hızlanma genellikle tamamen [Etek/Kenar İvmesi Değişimi](jerk_skirt_brim.md) ayarı tarafından kontrol edilir.