İlk Katman Yazdırma Hızı
====
Bu ayar, modelin alt katmanının hangi hızda basılacağını ayarlar.

Bu ayarı ayarlamak, ilk katmandaki ekstrüzyon hareketlerinin hızını ayarlayacaktır, ancak seyahat hareketlerini değil. Bunun için [İlk Katman Hareket Hızı](speed_travel_layer_0.md) ayarını ayarlayın. Duvarlar, dış kaplama ve destek normalde farklı hızlarda basılabilirken, ilk katman için bu mümkün değildir. Tümü bu ayarda belirtilen hızda basılacaktır. Varsayılan olarak, bu ayar [Etek/Kenar Hızı](skirt_brim_speed.md) ayarını etkiler, ancak ayrı olarak ayarlanabilir. [radyenin temel katman hızı](../platform_adhesion/raft_base_speed.md) etkilenmez.

İlk katman baskı hızını azaltmak, modelin yapı platformuna yapışmasını iyileştirir. Bunun nedeni, malzemenin daha uzun süre daha sıcak kalması ve daha uzun süre akabilmesidir. Bu, malzeme içindeki iç gerilimleri azaltır ve temas alanını artırır, her ikisi de yapışmayı artırır.