Equalize Filament Flow
====
Nozul üzerinden akım hızını ayarlamak biraz zaman alır. Baskı kafasının hızını ayarlamak daha hızlıdır. Bu ayarla, boşluk doldurma tekniği sırasında ekstrüzyon hızı yerine hareket hızı ayarlanır.

Hareket hızı, akım hızının eşit kalabilmesi için ayarlanır. Ancak, boşluk doldurma tekniği genellikle akışı kesen birçok seyahat hareketine sahiptir, bu nedenle genellikle pek fark yaratmaz.

Bu özelliği etkinleştirmenin dezavantajı, bazen çok hızlı ekstrüzyon hareketleri almanızdır. Bu titreşime neden olabilir. Ancak yine de, boşluk doldurma tekniği genellikle zaten birçok titreşim üretir, bu nedenle bu kısımda çok fazla fark yaratmaz.