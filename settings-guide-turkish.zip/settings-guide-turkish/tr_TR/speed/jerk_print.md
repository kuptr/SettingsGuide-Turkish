Yazdırma İvmesi Değişimi
====
Jerk, nozülün köşelerden geçiş hızını belirler. Yüksek jerk değerleriyle, nozül köşeye yaklaşırken daha az yavaşlamaz, bu da daha sabit bir hızda hareket etmesine ancak daha fazla titreşime yol açar.

**3D baskıda jerk, fizikteki jerk ile aynı değildir.** Bu terim Marlin tarafından tanıtılmıştır. Burada, yolu mükemmel bir şekilde takip etme çabasındaki temel sorunu çözmek için tasarlanmıştır. Nozülün teoride yoldan sapmasına izin verilmediği için, nozül her köşede 0mm/s'ye yavaşlaması gerekecekti. Bu, her köşede topaklanmaya neden olurdu. Köşeyi kısaltmak için eğri yapılmasına izin verilmediği gibi, aşırı hızlanma da mümkün değildir. Bunun yerine, Marlin her köşede hız vektöründe anlık bir değişikliğe izin verir. Bu hız vektöründeki değişikliğin büyüklüğüne "jerk" denir. Dolayısıyla jerk, hareketin her köşesinde uygulanan maksimum anlık hız değişimidir.

Jerk'in artırılması baskınıza bazı olumlu ve bazı olumsuz etkiler yapacaktır:
* Baskı süresi azalacaktır, çünkü nozül köşelerde daha az yavaşlar.
* Nozül köşelerde topaklanma yapmaz, çünkü nozül sabit bir hızda hareket eder ve malzeme akışı açıkta devam etmez.
* Yazıcı genellikle her köşe için daha fazla titreşir, çünkü baskı kafası teorik olarak sonsuz hızlanma ile anlık yönlendirme değişiklikleri yapmaya zorlanır. Bu titreşimler baskınızda dalgalanmalara, yüzük oluşumuna ve boyutsal doğruluğun azalmasına neden olabilir.
* Aşırı değerlerde, motorlar köşelerde bazı adımları kaybedebilir, bu da bir katman kaymasına yol açabilir.