Daha Yavaş Katman Sayısı
====
Bu ayar, daha yavaş basılan katman sayısını ayarlar. İlk katman yalnızca yavaş basılan katman değildir. Bu ayar, kaç katmanın daha yavaş basılacağını belirler. Bu katmanlar boyunca baskı hızı, normal baskı hızına doğru kademeli olarak artar.

![Baskı hızı kademeli olarak 50 mm/s'ye kadar artar](../images/speed_slowdown_layers.svg)

İlk katmandan başlayarak, hız duvarlar, dış kaplama, dolgu vb. için farklı hızlarda basılıyorsa, normal baskı hızına doğru lineer olarak artar (veya azalır).

Birden fazla katmanın normal baskı hızına geçiş yapması iki temel nedenle gereklidir. İlk olarak, ikinci ve üçüncü katmanlar hâlâ yapı platformuna yakın olduğundan, hızlı hareket edilmesi bu katmanların kolayca kopmasına neden olabilir. İkinci olarak, ilk katmanın baskı hızı ile normal baskı hızı arasındaki akış hızı farkı çok büyük olabilir, bu da büyük bir akış hızı değişikliğinin etkili olması zaman alabilir. Yavaş geçiş, büyük hız değişikliklerinde eksik ekstrüzyonu önler.

Ancak yavaş geçiş yapmak, toplamda baskının daha uzun sürmesine neden olabilir.