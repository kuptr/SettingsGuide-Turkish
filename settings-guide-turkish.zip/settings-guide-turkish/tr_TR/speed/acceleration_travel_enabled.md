Hareket İvmesini Etkinleştir
====
Bu ayar etkinleştirildiğinde, seyahat hareketleri kendi hızlanma oranlarına sahip olur. [Hareket İvmesi](acceleration_travel.md) ayarı, seyahat hareketleri sırasında hızlanmanın oranını kontrol eder.

Seyahat hareketi sırasında hızlanma değeri, seyahatin hedef noktasında basılacak olan çizginin değerini alır. Örneğin, dolguya doğru seyahat ederken, seyahat hareketi sırasındaki hızlanma [Dolgu İvmesi](acceleration_infill.md) olacaktır. Dış duvara doğru seyahat ederken, hızlanma [Dış Duvar İvmesi](acceleration_wall_0.md) olacaktır. Bu şekilde, diğer yapılar kadar hassas olan yapılar daha dikkatli bir şekilde yaklaşılır.

Bu ayar varsayılan olarak etkindir ve seyahat sırasında hızlanmanın kontrol edilmesine olanak tanır. Bu çoğu durum için iyidir çünkü artan seyahat hızlanması zaman kazandırabilir, ancak bu yüksek hızlanma doğrudan baskı sırasında [ringing/çınlama](../troubleshooting/ringing.md) olarak bilinen bir soruna yol açabilir.

Ancak bunu devre dışı bırakmak isteyebileceğiniz iki neden bulunmaktadır:

* Seyahat hareketleri için hızlanma oranını değiştirmek için, Cura hızlanmayı sık sık değiştirir. Özellikle dolgu desenlerinde ve duvarlardaki küçük detaylarda sık sık ekstrüzyon ve seyahat arasında geçiş yapılır. Bu komutların işlenmesi ve hesaplamaların yapılması için yazılım donanımının gereksinimlerini karşılayamayabilir. Seyahat hızlanmalarının devre dışı bırakılması bu sorunu azaltır.
* Seyahat hızlanmalarını artırmak, yazıcının çok titremesine neden olabilir. Bu titreşimler, baskıya başlamadan hemen önce seyahat hareketinin sonunda tam olarak durdurulamaz. Bu durum ayrıca seyahat hareketinin sonunda çınlamaya neden olabilir. Seyahat hızlanmasını devre dışı bırakmak, nozülün hassas yapıların (örneğin dış duvar gibi) yaklaşımını, dolgu gibi daha az hassas yapılarına göre daha dikkatli yapmasını sağlar (örneğin iç dolgu gibi).