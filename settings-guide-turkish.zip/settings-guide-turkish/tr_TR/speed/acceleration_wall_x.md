İç Duvar İvmesi
====
Bu ayar, nozülün iç duvarları yazdırırken farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. İç duvarlar sırasındaki hızlanma dış duvarlardan farklı bir hızda ayarlanabilir.

Buradaki hızlanmayı ayarlamak, baskının boyutsal doğruluğunu ve genel düzgünlüğünü etkiler. Yüksek hızlanma değerleri, yazıcı boyunca şok dalgalarına neden olur. Bu şok dalgaları, nozülün veya yapı platformunun titremesi şeklinde baskıda görülebilir. İç duvarlar dışarıdan görünmez, sadece üst ve alt kısımlarında fark edilebilirler, ancak iç duvarlar dış duvarlardan önce yazdırıldığında, dış duvarlar iç duvarların yanlışlıkla yazıldığı yerlere doğru daha fazla itilirler. Eğer dış duvarlar önce yazdırılmışsa, iç duvar hızlandırmasının etkisi daha az gözlemlenir, ancak nozül geçerken dış duvarların yeniden erimesiyle hala mevcuttur.

İç duvarların, baskı süresinden tasarruf etmek için genellikle dış duvarlardan daha yüksek bir hızlanma oranıyla yazdırılması yaygındır, ancak baskının geri kalanından daha düşük bir hızlanma oranıyla olması önerilir.