İlk Katman Yazdırma Salınımı (Jerk)
====
Bu ayar, ilk katman ekstrüde edilirken nozülün köşelerden geçiş hızını belirler. Bu, ilk katmanın seyahat hareketlerinden ayrı olarak yapılandırılabilir.

Jerk'i azaltmak, nozül malzeme akışı azaldığında yavaşladığı için keskin köşelere daha fazla malzeme bırakmasını sağlar. Bu keskin köşeler, baskının genellikle çarpılmasından dolayı yapı platformundan ilk olarak ayrılan yerlerdir. Bu köşelere ekstra malzeme bırakmak avantajlıdır, çünkü köşelerin daha iyi yapışmasını sağlar. Bu etki, ilk katmanın seyahat hareketleri sırasında mevcut değildir. Bu nedenle, ilk katmanın ekstrüzyonu sırasındaki jerk genellikle ilk katmanın seyahat hareketleri sırasındaki jerk'ten biraz daha düşüktür.

Baskının farklı yapıları genellikle farklı jerk değerlerine sahip olabilir. Infill, taban, dış ve iç duvarlar, destek ve prime tower için ayrı ayarlar bulunmaktadır. Bu ayar, tüm bu ayarların üzerine yazacaktır. Yalnızca [Etek/Kenar İvmesi Değişimi](jerk_skirt_brim.md) ayarı, bu jerk'i geçersiz kılabilir, çünkü etek ve kenar sadece ilk katmanda meydana gelir.