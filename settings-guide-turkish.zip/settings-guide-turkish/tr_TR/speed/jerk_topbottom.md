Üst/Alt Salınımı (Jerk)
====
Bu ayar, baskının üst ve alt yüzeylerini yazdırırken nozülün köşelerden geçiş hızını belirler. Bu, baskının geri kalanından ayrı olarak yapılandırılabilir.

Bu bölüm için jerk'i artırmak, nozülün bitişik yüzey çizgileri arasındaki köşelerde durmasını engeller. Bu, çizgi genişliğinin genel olarak daha tutarlı olmasını sağlar. Ancak jerk'i çok fazla artırmak, yapı platformunun titreşmesine ve düzensiz bir yüzey oluşmasına neden olabilir. Hatta motorların adımlarını kaybetmesine yol açabilir, bu da katman kaymasına sebep olabilir.