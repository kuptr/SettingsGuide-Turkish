İlk Direk Hızı
====
Bu ayar, prime kulesinin hangi hızda basılacağını yapılandırır.

Genellikle prime kulesini baskının geri kalanıyla benzer bir hızda basmak iyi bir tercihtir, böylece malzeme düzgün bir şekilde hazırlanır. Ancak prime kulesini daha yavaş basmak, özellikle akışkan malzemeler veya çok uzun baskılar için daha stabil hale getirebilir, bu da faydalı olabilir.