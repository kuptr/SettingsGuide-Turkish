İlk Katman Hızı
====
Bu ayar, modelin alt katmanının hangi hızda basılacağını ayarlar.

Normalde tüm ilk katman bu hızda basılır, ancak duvarlar, dış kaplama ve destek normalde ayrı hızlarda basılabilir. Ancak ilk katman için durum böyle değil! İlk katman için [İlk Katman Yazdırma Hızı](speed_print_layer_0.md) ve [İlk Katman Hareket Hızı](speed_travel_layer_0.md) ayrı ayrı ayarlanabilir. Ayrıca [Etek/Kenar Hızı](skirt_brim_speed.md) olarak bilinen baskının kenarları için kullanılan hız da ayarlanabilir. Varsayılan olarak, bu ayar tüm bu hızları etkiler. Ancak [radyenin temel katman hızı](../platform_adhesion/raft_base_speed.md) etkilenmez.

İlk katman hızını azaltmak, modelin yapı platformuna yapışmasını iyileştirir. Bunun nedeni, malzemenin daha uzun süre daha sıcak kalması ve daha uzun süre akabilmesidir. Bu, malzeme içindeki gerilimleri azaltır ve temas alanını artırır, her ikisi de yapışmayı artırır.