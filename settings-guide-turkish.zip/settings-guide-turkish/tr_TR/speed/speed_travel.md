Hareket Hızı
====
Bu ayar, baskı kafasının herhangi bir malzeme extrüde etmediği zamanlarda hareket ettiği hızı ayarlar.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Seyahat hızı genellikle diğer hız ayarlarından çok daha yüksektir. Seyahat hızını artırmanın bazı etkileri şunlardır:
* Daha yüksek bir seyahat hızı baskı süresini hafifçe azaltabilir.
* Filamentin malzemeden sızmasına neden olan zamanı azaltarak, genel olarak daha temiz bir parça elde edilmesini sağlar.
* Ancak hızı artırmak aynı zamanda yazıcının daha fazla titreşim yapmasına yol açar, bu da zil sesini artırır. Bu, Z sıçramaları ile azaltılabilir, ancak Z sıçramaları genellikle seyahat hızını artırarak sağlanabilecek zamandan daha fazla zaman alır.
* Hızı artırmak, baskınızın devrilme olasılığını artırır, özellikle [Tarama Modu](../travel/retraction_combing.md) devre dışı bırakılmışsa.
* Aşırı hızlara çıkıldığında, yazıcının motorları bazı adımları kaçırabilir, bu da bir katman kaymasına neden olabilir.

**Seyahat hızı, genellikle insanların varsaydığından daha az bir etkiye sahiptir. Bu, seyahat süresinin genellikle toplam baskı süresinin küçük bir kesimi olduğu ve yüksek hızlara ulaşmanın uzun zaman aldığı için, çoğunlukla ivme sınırları nedeniyle maksimum hızdan ziyade sınırlı olduğu için geçerlidir.**