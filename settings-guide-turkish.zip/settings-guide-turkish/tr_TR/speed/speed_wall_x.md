İç Duvar Hızı
====
Bu ayar, iç duvarların basıldığı hızı normal baskı hızından ve dış duvardan ayrı olarak yapılandırmanıza olanak tanır.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

İç duvarlar dış duvarlar kadar görsel kalite için önemli değildir. Ancak iç duvarlar, dış duvar malzemesinin dışarıya itilmesine neden olarak dış duvarların yerleşimini etkiler. Eğer [dış duvar iç duvarlardan sonra basılmıştır](../shell/outer_inset_first.md), dış duvar malzemesi dışarı itilir veya dış duvar önce basılırsa doğrudan dışarı itilir. Bu nedenle iç duvarları doğru bir şekilde basmak hala önemlidir, ancak zaman kazanmak için dış duvarlardan biraz daha hızlı basılabilirler.

İç duvarın hızını azaltmak, bu yapıyı basarken titreşimleri azaltır, bu da zil sesini azaltır. Ayrıca asma katları üzerinde iyileştirme sağlar; çünkü baskı kafasındaki fanlar, nozzle tarafından gerilirken malzemenin daha iyi soğuması için daha fazla zaman alır.

Ancak iç duvar baskı hızı çok düşükse, çok büyük bir akış değişikliği riski vardır. Nozul aniden çok daha yavaş ekstrüde etmek zorunda kalırsa, nozul odasındaki basınç düşerken bir süre boyunca hala çok miktarda malzeme ekstrüde edecektir, bu da duvarın başlangıcında aşırı ekstrüzyona neden olabilir.

İç duvarlar aynı zamanda baskı süresinin önemli bir bölümünü oluştururlar, bu nedenle iç duvarların daha yavaş basılması baskı süresini önemli ölçüde artırabilir.