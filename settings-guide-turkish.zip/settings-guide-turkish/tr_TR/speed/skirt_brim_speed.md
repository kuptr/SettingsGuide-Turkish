Etek/Kenar Hızı
====
Bu ayar, etek veya kenarlık hızını baskının geri kalanından ayrı olarak ayarlar.

Etek veya kenarlık genellikle yapının yapı platformuna daha iyi yapışması için oldukça yavaş bir şekilde yazdırılır. Daha yavaş yazdırmak (belirli bir noktaya kadar) genellikle yapışmayı artırır ancak daha uzun sürede yazdırma anlamına gelir.

Etek ve kenarlık ilk kat üzerinde yazdırılsa da, bu ayar [İlk Katman Yazdırma Hızı](speed_print_layer_0.md) ayarını geçersiz kılar.