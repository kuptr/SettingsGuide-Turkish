Dolgu Hızı
====
Bu özellik, dolgu malzemesinin normal baskı hızından ayrı olarak yapılandırılabileceği hızdır.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Dolgu görsel kalitesi genellikle önemli değildir, bu yüzden dolgu malzemesi zaman kazanmak için oldukça yüksek bir hızda basılabilir. Öte yandan, dolgu hızını artırmak duvarlara daha çok parçacık ulaşmasına neden olur, çünkü nozul duvarlara daha fazla yön değiştirir.

Ayrıca, akış değişikliğinin çok büyük olması tehlikesi vardır. Özellikle [Dolgu Katmanı Kalınlığı](../infill/infill_sparse_thickness.md) gibi ayarlarla birleştirildiğinde, dolgu için gereken akış hızı ile geri kalan baskı için gereken akış hızı arasındaki fark çok büyük olabilir. Nozul aracılığıyla akış hızını ayarlarken büyük bir gecikme vardır, bu nedenle dolgu malzemesi diğer kısımlara göre çok hızlı yapılırsa akış doğru olmayabilir.