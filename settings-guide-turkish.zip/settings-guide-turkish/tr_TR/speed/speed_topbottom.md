Üst/Alt Hız
====
Bu ayar, modelin üst ve alt tarafının hangi hızda basılacağını normal baskı hızından ayrı olarak yapılandırılmasını sağlar.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Eğer modelde herhangi bir asma varsa, genellikle üst ve alt tarafı yavaş basmak gereklidir. Asma yoksa, hızlı basmak önemli ölçüde baskı süresinden tasarruf sağlayabilir. Modelin üst ve alt tarafını yavaş basmak şu etkilere neden olur:
* Baskı süresini artırır, bazen ciddi şekilde. Üst ve alt yüzeyler uzun çizgilere sahip olduğundan, hız baskı süresi üzerinde en büyük etkiye sahip faktördür, ivme ve jerk'ten daha fazla etkilidir. Üst ve alt yüzeyler toplam baskı süresinin önemli bir kısmını oluşturabilir.
* Asma varsa, asma çok düz olduğunda asma kalitesini iyileştirir. Hâlâ dik eğimli olan asma üzerinde etkisi çok fazla olmaz, çünkü bu tür asmanın derisi o zaman gösterilmez. Asmayı daha yavaş basmak, filament ipliklerindeki gerilimi korur ve daha uzun süre soğumasına izin verir.
* Üst yüzey kalitesini iyileştirir. Aynı asma etkisi, üst yüzeyin dolgu üzerinde durduğu şekilde uygulanır.
* Yazıcı genellikle daha az titreşir. İnşa tablası daha az titreşirse, üst ve alt yüzeyler daha iyi görünür.

**Bu ayar, inşa tabanı yapışkanlığı üzerinde önemli bir etkiye sahip değildir. [İlk Katman Yazdırma Hızı](speed_print_layer_0.md) ilk birkaç katman için kullanılır.**