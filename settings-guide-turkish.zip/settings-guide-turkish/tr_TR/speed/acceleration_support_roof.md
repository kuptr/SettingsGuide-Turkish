Destek Çatısı İvmesi
====
Bu ayar, destek çatısı baskısı sırasında nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Destek çatısı sırasında hızlanma, destek tabanından farklı bir hızda ayarlanabilir.

Destek çatısı, doğru olmayan baskının daha hassas olmasına neden olabilir çünkü doğrudan aşağı sarkıntı kalitesini etkiler. Destek çatısını, destek tabanından daha düşük bir hızlanma oranına ayarlamak, benzer bir baskı süresi için daha iyi aşağı sarkıntı kalitesi sağlayabilir.