Destek Çatısı Sarsıntısı (Jerk'i)
====
Bu ayar, destek tavanları yazdırılırken nozülün köşelerden geçiş hızını belirler. Bu, destek tabanlarından ayrı olarak yapılandırılabilir.

Destek tavanı, modelin destek üzerinde durduğu yerdir ve güzel görünümlü çıkıntılar oluşturmak için önemlidir. Aynı zamanda destek, model üzerinde izler bırakabilir. Her iki faktör de destek tavanının yazdırılma doğruluğundan etkilenir. Destek tabanı için çıkıntı kalitesi önemli değildir, sadece iz bırakma önemlidir. Bu nedenle, destek tavanını tabana göre biraz daha dikkatli yazdırmak mantıklıdır.

Ancak jerk'i azaltmak her zaman daha iyi baskı anlamına gelmez. Jerk'in artırılması, daha sabit bir ekstrüzyon hızı sağlar. Özellikle besleyici uzun bir Bowden tüpünün arkasında olan yazıcılar için, ekstrüzyon hızını sabit tutmak, titreşimleri azaltmaktan daha önemli bir hedeftir.