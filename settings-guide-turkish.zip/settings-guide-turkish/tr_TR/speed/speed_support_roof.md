Destek Çatısı Hızı
====
Bu ayar, [Destek Arayüzünü Etkinleştir](../support/support_interface_enable.md), destek yapısının üst tarafının hangi hızda basılacağını ayarlar.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Daha yüksek bir hız, baskı süresinden tasarruf sağlayabilir, ancak asma katlarda kaliteyi düşürebilir. Baskı kafası daha fazla titreşim yapacağı için destek çatısı daha az doğru basılacak ve yüzeyi daha az düzgün olacaktır. Sonuç olarak, üzerindeki model daha az düzgün basılabilir, özellikle çözünür destek kullanıldığında ve model ile çok yakın basıldığında.