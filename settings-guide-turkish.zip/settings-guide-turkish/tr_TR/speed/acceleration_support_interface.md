Destek Arayüzü İvmesi
====
Bu ayar, destek arayüzü baskısı sırasında nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Destek arayüzü sırasında hızlanma, destekin geri kalanından farklı bir hızda ayarlanabilir.

Eğer yazıcı, destek arayüzü baskısı sırasında nozülün farklı yönlere hızlanması nedeniyle çok titreşiyorsa, arayüz modelin şekline çok doğru bir şekilde uymayabilir. Bu durum bazı yerlerde destek malzemesinin baskıya daha fazla yapışmasına neden olabilir, böylece baskıda iz veya çöküntü bırakabilir. Diğer yerlerde ise destek, modeli iyi desteklemeyebilir ve çirkin aşağı sarkıntılara neden olabilir. Hızlanmayı azaltmak, bu sorunla başa çıkmaya yardımcı olabilir, ancak baskı süresini artırır.