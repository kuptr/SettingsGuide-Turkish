Maksimum Z Hızı
====
Bu ayar, baskı sırasında yapılan tüm bina tablası hareketlerinin hızını değiştirir. Bu, tüm kat değişimlerini ve Z atlama hareketlerini içerir.

Normalde, bina tablası hareketlerinin hızı firmware tarafından belirlenir ve mümkün olduğunca hızlı hareket etmesine izin verir.

**[Spiral Dış Çevre](../blackmagic/magic_spiralize.md) bu ayar tarafından etkilenmez, hatta baskı sırasında bina tablasının sürekli olarak hareket etmesine neden olsa bile.**