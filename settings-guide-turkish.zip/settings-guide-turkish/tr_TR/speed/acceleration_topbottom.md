Üst/Alt İvme
====
Bu ayar, nesnenin üst ve alt yüzeylerini basılırken nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Üst ve alt yüzeyler sırasında hızlanma, baskının geri kalanından farklı bir hızda ayarlanabilir.

Diğer baskılara kıyasla hızlanma oranını artırmak bazı zaman tasarrufu sağlayabilir. Çünkü üst ve alt yüzeyler genellikle uzun düz çizgilerden oluşur ve nozül burada yüksek hızlara ulaşabilir. Ayrıca nozül, deri desenindeki tipik çizgilerle keskin köşeler yapmak zorundadır ki bu da yüksek hızlanma gerektirir. Ancak hızlanmayı artırmak yazıcının daha fazla titremesine neden olabilir. Bununla birlikte, üst ve alt yüzeylerin doğruluğu genellikle bir kısıtlama oluşturmaz çünkü bunlar duvarlar tarafından çevrilidir.