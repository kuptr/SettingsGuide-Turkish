Z Atlama Hızı
====
Bu ayar, Z Hop'ta dikey hareketlerin yapıldığı hareket hızını yapılandırır. Z Hop'un yatay hareketleri etkilenmez, çünkü bunlar [Hareket Hızı](speed_travel.md) tarafından yapılandırılır.

![Dikey hareket, Z Hop Hızı'nda gerçekleştirilir](../images/speed_z_hop.svg)

Z Hop Hızı aynı zamanda katlar arası seyahat hareketinin hızı olarak da kullanılır. Pratikte, bu hız çok az önem taşır çünkü tek bir kat kalınlığının hareketi çok kısa olduğundan genellikle hız, maksimum seyir hızı değil, ivmelenme tarafından sınırlanır.

Çoğu yazıcı için Z ekseni sağlam ancak yavaş bir şekilde yapılandırılmıştır. Z Hop Hızı'nın artırılması, Z hareketinin sınırlarını test eder, bu da Z motorunun bazı adımları atlamasına neden olabilir. Sonuç olarak, Z hop sonrasında nozülün farklı bir yüksekliğe sahip olması mümkündür. Bu hızı azaltmak, bunun olasılığını azaltır.

Öte yandan, daha yüksek bir Z Hop Hızı, nozülün basılmış yüzeyden daha hızlı uzaklaşmasını sağlar. Bu, blobların boyutunu azaltabilir.

Düşük Z ekseni ivme oranları nedeniyle, istenen Z Hop Hızı'nın genellikle çok yüksek Z Hop yüksekliği veya çok düşük hız olmadıkça ulaşılmadığını belirtmek önemlidir.