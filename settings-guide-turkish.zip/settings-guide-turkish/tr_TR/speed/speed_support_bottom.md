Destek Zemini Hızı
====
Bu ayar, [Destek Zeminini Etkinleştir](../support/support_bottom_enable.md), destek yapısının alt tarafının hangi hızda basılacağını ayarlar.

![Farklı hızlarda basılan çeşitli yapılar](../images/speed_difference.png)

Daha yüksek bir hız, baskı süresinden tasarruf sağlayabilir.

Bu ayarın etkisi büyük ölçüde koşullara bağlıdır. Özellikle hızlı soğuyan ve büyük [Destek Alt Mesafesi](../support/support_bottom_distance.md) olan bazı malzemelerle, daha yüksek bir hız destek ve model arasındaki yapışmayı artırabilir. Bu etki köprüleme ile benzerdir: Daha yüksek hızlarda, malzeme daha dikkatlice askıya alınmaz ve baskı kafasındaki fanlar tarafından soğutulmaya zaman bulamaz. Normalde istenmeyen bir durumdur çünkü destek modelin yüzeyinde daha belirgin izler bırakabilir.

Diğer malzemelerde ise, daha yüksek hız malzemenin yere daha sert bir şekilde yerleştirilmesini engeller ve malzemenin akışını sağlamaz. Bu etki yatak yapışmasına benzer. Daha yüksek hız, destek tabanlarının başlangıç ve sonunda akış hızındaki değişimin sınırlarına ulaşıncaya kadar avantajlıdır.

Destek tabanı modelle çok yakınsa, örneğin PVA veya diğer çözünür destek malzemeleri için, destek tabanı hızını artırmak nozulün modelin içine aşırı çıkmasına ve yüzeyi hafifçe bozmasına neden olabilir.