Destek Zemini İvmesi
====
Bu ayar, destek tabanı baskısı sırasında nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Destek tabanı sırasında hızlanma, destek çatısından farklı bir hızda ayarlanabilir.

Destek arayüzü için doğruluk, aşağı sarkıntı kalitesi için önemlidir ve destek modeline ne kadar iyi yapıştığı ve ne kadar iz bıraktığı da önemlidir, ancak destek tabanı için aşağı sarkıntı kalitesi bir sorun değildir. Baskı süresinden biraz tasarruf etmek için destek tabanı hızlanmasını destek çatısından biraz daha yüksek bırakmak avantajlı olabilir. Ancak hızlanmayı fazla artırmak ek iz bırakabilir ve üzerinde dinlenen desteğin stabilitesini tehlikeye atabilir.