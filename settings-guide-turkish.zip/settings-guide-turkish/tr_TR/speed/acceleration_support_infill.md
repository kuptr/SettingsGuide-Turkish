Destek Dolgusu İvmesi
====
Bu ayar, destek yapılarının ana kısmını baskılarken nozülün farklı yönlere ne kadar hızlı hızlanacağını kontrol eder. Destek dolgusu sırasında hızlanma, destek arayüzünden farklı bir hızda ayarlanabilir.

Hızlanma oranını artırmak, yazıcının destek yapılarını toplamda daha hızlı basmasını sağlar, ancak daha dikkatsiz bir şekilde yapabilir. Bu, baskı süresini azaltırken, yazıcının destekleri devirmesi ve destek yapısını zayıflatması ihtimalini artırabilir. Genellikle destek, baskının geri kalanına kıyasla daha yüksek bir hızlanma ile basılır.