Radyenin Orta Fan Hızı
====
Bu ayar, radyenin orta katmanlarını basarken fan hızını yapılandırır. Orta katmanları basarken fan hızı, taban ve üst katmanlardan ayrı olarak yapılandırılabilir.

![Orta katmanın radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Orta katmanlar için fan hızını ayrı ayrı yapılandırmak, fan hızını azaltmanın yatak yapışkanlığını artırabileceği ve sıklığı azaltabileceği için faydalıdır. Fan hızını artırmak, yüzeyin düzgünlüğünü artırabilir, ancak bu orta katmanlar için bir endişe kaynağı değildir. Bu nedenle, fan hızını üst katmanlardan biraz daha düşük ayarlamak faydalıdır.