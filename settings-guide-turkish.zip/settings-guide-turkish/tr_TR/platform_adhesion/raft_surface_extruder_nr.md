Radye Üst Ekstrüderi
====
Bu ayar, radyenin üst katmanlarını basmak için kullanılacak ekstrüderi seçer.

![Üst katmanların radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Üst katmanlar, orta katmanların üzerinde dinlenir ve gerçek baskı için bir yatak görevi görür. Orta katmana iyi yapışan bir malzeme kullanmak iyi bir fikirdir, ancak modelle yapışma [Radye Hava Boşluğu](raft_airgap.md) ayarı kullanılarak dikkatlice ayarlanmalıdır. Üst katmanlar için kullanılan malzeme modelle iyi yapışmazsa, yapışma aralığını azaltarak iyileştirilmelidir, aksi takdirde tersi yapılmalıdır. Modelin yapışması çok iyi olursa, baskıdan sonra çıkmaz, ancak yeterince iyi yapışmazsa baskı sırasında gevşeyebilir. 