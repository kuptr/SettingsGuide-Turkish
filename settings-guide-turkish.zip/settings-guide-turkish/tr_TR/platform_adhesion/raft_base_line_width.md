Radyenin Taban Hat Genişliği
====
Bu ayar, radyenin en alt katmanının çizildiği çizgilerin genişliğini yapılandırır.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Radyenin taban katmanının çizgileri çok kalın olmalıdır. Daha kalın çizgiler, malzemenin baskı tablasına çok sıkı itilmesine neden olur, bu da yapışmayı artırır. Çizgiler nozül boyutundan biraz daha geniş olabilir, ancak malzemenin küçük nozüllerle yanlara doğru ne kadar akabileceğinin bir sınırı vardır.