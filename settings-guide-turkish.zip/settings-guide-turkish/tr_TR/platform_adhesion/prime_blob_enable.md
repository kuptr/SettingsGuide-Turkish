İlk Damlayı Etkinleştir
====
Bu etkinleştirildiğinde, Cura, ekstruder ilk kullanılmadan hemen önce yazıcıya bir primleme komutu çıkarmasını sağlar. Yazıcı, yapıştırma plakasında küçük bir malzeme topağı oluşturarak primleme yapar.

Primleme, malzemenin düzgün bir şekilde akmasını sağlamak için yapılır. Prime blob etkinleştirilmezse, yazıcı başlangıçta eteği veya brim kullanılarak prim yapacaktır. Bu, eteğin ilk başta kullanılma nedenidir, ancak brim için bu brimin yapışma gücünü biraz azaltır.

Bu ayarın g-kodu üzerindeki etkisi, Cura'nın M280 komutunu belirli bir konuma yerleştirmesidir. **Şu anda, bu yalnızca Ultimaker 3 ve sonraki model yazıcılarında çalışır** çünkü bunlar M280 komutunu uygulayan tek yazıcılardır. Diğer yazıcılarda bu ayar görünmez olacaktır.