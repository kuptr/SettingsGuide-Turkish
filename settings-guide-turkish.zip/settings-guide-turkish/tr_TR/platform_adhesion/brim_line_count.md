Kenar Hattı Sayısı
====
Baskınızın tabanı etrafında çizilen kenarların sayısını kontrol eder.

![Bu kenar 8 çizgiye sahiptir.](../images/brim_width.svg)

Daha fazla kenar çizgisi, baskınızın yapım tablasına yapışmasını artırarak baskınızın yüzey alanını artırır. Ancak etkili baskı alanını azaltır.

**Bu ayar, [Kenar Genişliği](brim_width.md) ayarını geçersiz kılar.**