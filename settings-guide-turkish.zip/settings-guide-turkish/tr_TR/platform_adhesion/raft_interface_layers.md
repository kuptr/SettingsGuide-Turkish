Radye Orta Katmanları
====
Radyenin herhangi bir sayıda orta katmanı olabilir. Bu ayar, kaç orta katmanın basılacağını kontrol eder.

![Orta katmanın radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Daha fazla orta katmana sahip olmak, daha uzun süre basım yapılmasına neden olur, ancak radyenin sertliğini büyük ölçüde artırır ve modeli yapı platformunun ısısından daha iyi korur. Aynı etki [Radyenin Üst Katmanları](raft_surface_layers.md) artırılarak da elde edilebilir. Ancak üst katmanlar, güzel bir düzgün yüzey oluşturmak için ayarlanmıştır, bu da çok sayıda katman varsa basım süresini uzatabilir. Orta katmanların düzgün olması gerekmez, bu nedenle birçok orta katmana sahip olmanın basım süresi üzerinde büyük bir etkisi yoktur.