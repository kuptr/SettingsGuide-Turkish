Radye Üst Fan Hızı
====
Bu ayar, radyenin üst katmanlarını basarken fan hızını yapılandırır. Üst katmanları basarken fan hızı, taban ve orta katmanlardan ayrı olarak yapılandırılabilir.

![Üst katmanların radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Üst katmanlar için fan hızını ayrı ayrı yapılandırmak, fan hızının yatak yapışkanlığını büyük ölçüde etkilediği için faydalıdır, ancak bu, üst katmanlar için bir sorun değildir. Ancak, fan hızını artırmak radyenin üst yüzeyinin düzgünlüğünü artırır (bu, alt katmanlar için bir sorun değildir). Bu nedenle, üst yüzeylerin fan hızını, alt katmanların fan hızından biraz daha yüksek ayarlamak faydalıdır. Ancak fan hızını çok yüksek ayarlamak bazı malzemelerle çarpılmalara neden olabilir.