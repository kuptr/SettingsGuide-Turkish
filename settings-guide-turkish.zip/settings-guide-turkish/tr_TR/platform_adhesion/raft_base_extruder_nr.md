Radye Taban Ekstrüderi
====
Bu ayar, radyenin taban katmanı için kullanılacak ekstrüzyonu seçer.

![Radye tabanının radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Taban katmanı, build tablasının üstünde dinlenen katmandır. Build tablasına yeterli yapışmayı sağlamalıdır, bu nedenle bu amaç için build tablasına iyi yapışan ve küçülme yapmayan bir malzeme seçmek iyidir.