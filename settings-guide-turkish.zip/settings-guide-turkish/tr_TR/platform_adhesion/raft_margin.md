Ek Radye Boşluğu
====
Bu ayar, radyeyi modelden daha geniş yapar. Model etrafındaki ekstra kenarlığın genişliğini belirtir.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Bu ayarı artırmak, radye ile yapı platformu arasındaki yapışmayı büyük ölçüde artırır. Yalnızca radyenin yapışabileceği daha büyük bir alan bulunmakla kalmaz, aynı zamanda genişlemeler radyenin köşelerini de yumuşatır. Daha yumuşak köşelerle, çarpılmanın radye üzerindeki etkisi azalır. İkinci olarak, daha büyük bir radye, radyeyi modelden daha kolay ayırmanıza olanak tanır, çünkü radyeyi kavramak için bir alan bulunur.

Ancak, Radye Ekstra Kenarlık arttıkça, yapı platformunda daha fazla alan alacaktır. Radyeyi basmak için daha fazla malzeme ve zaman gerekecektir.