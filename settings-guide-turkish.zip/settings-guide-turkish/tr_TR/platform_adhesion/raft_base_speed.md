Radyenin Taban Yazdırma Hızı
====
Bu ayar, radyenin taban katmanının ne hızda basılacağını yapılandırır. Taban katmanının hızı, üst ve orta katmanların hızından ayrı olarak yapılandırılabilir.

![Radye içindeki taban katmanının konumu](../images/raft_dimensions_simplified.svg)

Taban katmanını daha yavaş basmak, malzemenin daha fazla akmasına izin verir. Bu, radye ile baskı tablası arasındaki temas alanını artırarak, radyenin baskı tablasına daha iyi yapışmasını sağlar. Malzemenin daha uzun süre sıcak kalması ayrıca plastikleri tavlama, iç stresi azaltma anlamına gelir. Her iki etki de çarpılma miktarını azaltır. Taban katmanı genellikle diğerlerinden daha yavaş basılır. Tabii ki, taban katmanının baskı hızını çok fazla azaltmak, baskının daha uzun sürmesine neden olur.

Radye kullanıldığında, [İlk Katman Yazdırma Hızı](../speed/speed_print_layer_0.md) modelin ilk katmanına uygulanır, radyenin ilk katmanına değil. Radye içindeki seyahat hareketleri, olağan [Hareket Hızı](../speed/speed_travel.md) sahip olacaktır.