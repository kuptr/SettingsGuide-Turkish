Radye Yazdırma İvmesi
====
Bu ayar, radyenin basılması sırasında yazıcı kafasının ivme oranını yapılandırır.

Genellikle radye uzun hat parçalarından oluştuğu için ivmeyi artırmak, baskı süresi üzerinde çok az etkisi olur. Ancak hatların sonundaki köşelerden geçerken ivmeyi artırmak biraz zaman kazandırır.

İvme oranını artırmak, radyenin basılması sırasında yazıcının daha fazla titreşmesine neden olur. Üst yüzey için, bu radyenin yüzeyini daha pürüzlü hale getirir. Diğer katmanlar için, bu, yapışma tablasına olan etkiyi daha fazla etkiler.