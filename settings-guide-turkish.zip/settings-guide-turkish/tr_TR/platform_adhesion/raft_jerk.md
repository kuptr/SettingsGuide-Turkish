Radye Yazdırma Salınımı
====
Bu ayar, radyeyi basarken nozülün köşelerden geçiş hızını yapılandırır.

Radye genellikle uzun çizgi segmentlerinden oluştuğu için, sarsıntı hızını artırmak genellikle baskı süresi üzerinde çok az etkiye sahiptir. Ancak sarsıntı hızını artırmak, çizgilerin sonundaki köşelerden geçerken biraz zaman kazandırır.

Sarsıntı hızını artırmak, yazıcının radyeyi basarken daha fazla titreşmesine neden olur. Üst yüzey için, bu radyenin yüzeyini daha pürüzlü hale getirir. Diğer katmanlar için ise, yapı platformuna olan yapışmayı daha fazla etkiler.