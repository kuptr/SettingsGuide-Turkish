Kenar, Desteği Değiştirir
====
Bu ayar etkinleştirildiğinde, kenar destek altındaki modeli takip etmeye devam eder, destek etrafından gitmez. Destek daha sonra bir sonraki katmanda kenarın üzerine basılacak. Ayrıca, destek etrafında hala bir kenar olacaktır.

<!--screenshot {
"image_path": "brim_replaces_support_disabled.png",
"models": [{"script": "castle.scad"}],
"camera_position": [0, 100, -136],
"settings": {
    "adhesion_type": "brim",
    "support_enable": true,
    "brim_replaces_support": false
},
"colours": 64
}-->
<!--screenshot {
"image_path": "brim_replaces_support_enabled.png",
"models": [{"script": "castle.scad"}],
"camera_position": [0, 100, -136],
"settings": {
    "adhesion_type": "brim",
    "support_enable": true,
    "brim_replaces_support": true
},
"colours": 64
}-->
![Devre dışı bırakıldığında, kenar destek etrafından geçer](../images/brim_replaces_support_disabled.png)
![Etkinleştirildiğinde, kenar destek altından geçer](../images/brim_replaces_support_enabled.png)

Bu ayarı etkinleştirmek, kenarın modeli daha iyi takip etmesini sağlar. Sonuç olarak, model yapı tablasına daha iyi yapıştırılır ve bu da çekmeyi önler.

Bazı durumlarda, bu destek parçaları için toplam kenar genişliğini azaltır. Ancak bu durumlarda, destek modelle yeterince yakın olduğundan, kenar modelinkine birleşir, bu nedenle yapışma sorunu neredeyse hiç olmaz.