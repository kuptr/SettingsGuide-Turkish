Yapım Tablası Yapıştırma Türleri
====
Yapım tablası yapışması için üç tür bulunmaktadır: etek, brim ve raft. Ayrıca, bunları "Hiçbiri" olarak ayarlayarak kolayca devre dışı bırakabilirsiniz.

<!--screenshot {
"image_path": "adhesion_type_skirt.png",
"models": [
    {
        "script": "stamp.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 128, 53],
"settings": {"adhesion_type": "skirt"},
"colours": 64
}-->
<!--screenshot {
"image_path": "adhesion_type_brim.png",
"models": [
    {
        "script": "stamp.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 128, 53],
"settings": {"adhesion_type": "brim"},
"colours": 64
}-->
<!--screenshot {
"image_path": "adhesion_type_raft.png",
"models": [
    {
        "script": "stamp.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 128, 53],
"settings": {"adhesion_type": "raft"},
"colours": 64
}-->
![Etek](../images/adhesion_type_skirt.png)
![Kenar](../images/adhesion_type_brim.png)
![Radye](../images/adhesion_type_raft.png)

Etek
----
Bir etek, baskınızın etrafında tek bir çizgi oluşturur. Doğrudan yapım tablası yapışmasına katkıda bulunmaz. Ancak diğer yapıştırma yöntemlerini kullanmak istemiyorsanız, bu yöntem hala iki işlevi yerine getirir:
* Baskınızın gerçek modelinizi yazdırmaya başlamadan önce, malzemenin düzgün akmasını sağlamak için nozülünüzü hazırlar.
* Yapım tablanızın düzgün seviyede olup olmadığını görmek için size bir referans sağlar.

Kenar
----
Kenar, modelinizin tabanı etrafında tek bir katman düz alan oluşturur. Amacı, baskınızın kenarlarını aşağıda tutmak ve baskı ve yapım tablası arasındaki temas alanını artırmaktır.
* Daha büyük yüzey alanı, baskınızın yapım tablasına daha iyi yapışmasını sağlar. Birkaç santimetreden daha büyük neredeyse tüm baskılar için kullanışlıdır.
* Bu kenar ayrıca, baskınızın kenarlarını aşağıda tutar. Soğurken çok fazla küçülen malzemeler (örneğin ABS gibi) baskı yaparken çok eğilme eğilimindedir. Yeterli genişlikte bir kenar, köşeleri yerinde tutarak bu eğilmeyi engelleyebilir.

Raft
----
Bir radye, model ile yapım tablası arasındaki kalın bir plakadır. Bu radye, baskınızı yapım tablasının ısısından korur. Ayrıca, yapım tablasına yapışmak için çok fazla yüzey alanı olacaktır. Baskı, bu raftın üstüne yerleştirilir, burada çok daha iyi yapışabilir. Ancak ince baskılarla dikkatli olun, çünkü baskıya zarar vermeden çıkarmak radyeyi çıkarmak zor olabilir.