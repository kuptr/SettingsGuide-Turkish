Radyenin Üst Hat Genişliği
====
Bu ayar, radyeninn üst katmanlarındaki çizgilerin ne kadar geniş olacağını belirtir.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Radye için düzgün bir yüzey oluşturmak amacıyla, üst katmanların çizgileri oldukça ince olmalı ve [Radyenin Üst Boşluğu](raft_surface_line_spacing.md) ayarı ile birbirine yakın yerleştirilmelidir. İnce çizgiler, baskının alt tarafını daha düzgün hale getiren daha pürüzsüz bir yüzey oluşturur ve radye ile baskı arasındaki yapışmayı iyileştirir.

Ancak, daha ince ve yakın aralıklı çizgiler basmak oldukça daha uzun sürer. Çizgileri çok ince yapmak ayrıca yetersiz ekstrüzyona neden olur, bu da radye ile model arasındaki yapışmayı zayıflatır.