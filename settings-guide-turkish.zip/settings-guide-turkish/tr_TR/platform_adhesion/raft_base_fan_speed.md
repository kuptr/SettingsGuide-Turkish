Radyenin Taban Fan Hızı
====
Bu ayar, radyenin taban katmanını yazdırırken fan hızını yapılandırır. Taban katmanını yazdırırken fan hızı, orta ve üst katmanlardan ayrı olarak yapılandırılabilir.

![Taban katmanının radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Taban katmanı için fan hızını ayrı ayrı yapılandırmak, fan hızını azaltmanın yatak yapışmasını artırabileceği ve eğilmeyi azaltabileceği için faydalıdır. Fan hızını artırmak, radyenin yüzeyinin pürüzsüzlüğünü artırabilir, ancak bu, taban katmanı için bir endişe kaynağı değildir. Bu nedenle, fan hızını üst katmanlardan biraz daha düşük ayarlamak faydalı olabilir.