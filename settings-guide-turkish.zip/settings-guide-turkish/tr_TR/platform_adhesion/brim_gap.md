Uç Mesafesi
====
Bu ayar, model ile kenar arasında bir boşluk oluşturur. Kenar çizgileri artık modele güvenli bir şekilde bitişik değildir.


<!--screenshot {
"image_path": "brim_gap.png",
"models": [
    {
        "script": "arrow.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [-22, 32, 133],
"settings": {
    "adhesion_type": "brim",
    "brim_gap": 1
},
"colours": 32
}-->
![Kenar, modele belirli bir mesafede kalır](../images/brim_gap.png)

Bu boşluğun amacı, kenarı modelden çıkarmayı kolaylaştırmaktır. Kenar çizgilerini gerçek modelden biraz uzakta (yaklaşık olarak yarım çizgi genişliğinde) yerleştirerek, kenar ile model arasındaki bağlantı bir katmandan daha zayıf hale gelir, bu da kenarı el ile koparmayı kolaylaştırır. Ayrıca, kenarın çıkarılmasından sonra kalan izi veya fil ayağını azaltacaktır. Bu özellikle kalın [İlk Katman Yüksekliği](../resolution/layer_height_0.md) durumunda etkilidir, çünkü kalın kenar o zaman çıkarılması daha zor olur.

Öte yandan, bu aynı zamanda modeli yapım tablasına yapıştırmak için kenarın etkinliğini azaltır. Daha ince bir temas alanıyla, kenar, modeli [eğrilme](../troubleshooting/warping.md) etkisine karşı aşağıya doğru tutmak için çok fazla kuvvet uygulayamaz.