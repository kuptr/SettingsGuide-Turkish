Radyenin Üst Boşluğu
====
Bu ayar, radyenin üst katmanlarındaki çizgiler arasındaki aralığı belirtir. Bu, [Dolgu Hattı Mesafesi](../infill/infill_line_distance.md) ayarına benzer bir şekilde yapılır.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Genellikle radyenin üst katmanları çok yoğundur, yani çizgiler birbirine oldukça yakın aralıklıdır. Daha yoğun bir üst katman, radyenin yüzeyini daha düzgün hale getirir. Bu, radyenin üzerinde basılan baskının alt tarafının da daha düzgün olmasını sağlar. Daha düzgün bir üst yüzey, model ile radye arasındaki yapışmayı da iyileştirir.