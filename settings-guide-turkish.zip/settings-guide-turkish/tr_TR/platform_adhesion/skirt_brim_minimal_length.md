Minimum Etek/Kenar Uzunluğu
====
Bu ayar, [Etek Hattı Sayısı](skirt_line_count.md) veya [Kenar Hattı Sayısı](brim_line_count.md) ayarları tarafından orijinal olarak istenenden daha fazla etek veya kenar çizgisi ekleyerek baskıya başlamadan önce nozülün yeterince hazırlanmasını sağlar. Bu ayardaki minimum uzunluğa, eklenen tüm etek veya kenar çizgilerinin toplam çevresi tarafından ulaşılmazsa, daha fazla kontur eklenecektir.

Bu ayarın amacı, baskıya başlamadan önce malzemenin yeterince hazırlanmasını sağlamaktır. Bu ayarın değeri, baskıya başlamadan önce nozülü hazırlamak için yeterli olacak şekilde ayarlanmalıdır.

**Yapı platformu etrafındaki yasak alanlar bu ayarı hesaba katamaz çünkü etkisi dilimleme işleminden önce bilinmemektedir. Bu ayar yüksek olduğunda yazıcınızın kenarına küçük nesneler yerleştirmek, yazıcının baskı hacminin dışına çıkmasına neden olabilir.**