Etek Hattı Sayısı
====
Bu ayar, etek için çizilecek kontürlerin sayısını yapılandırır.

Eteğin amaçlarından biri, nozülü hazırlamak ve malzemenin düzgün akmasını sağlamaktır. Çok küçük modellerde tek bir çizgi yeterli olmayabilir, bu nedenle eteği birden fazla çizgi ile çizmek için bu ayarı yapılandırabilirsiniz.

[Minimum Etek/Kenar Uzunluğu](skirt_brim_minimal_length.md) ayarını kullanmak, minimum miktarda hazırlanan malzemenin sağlanmasını garanti etmek için bu ayarı kullanmaktan daha güvenilirdir. Bu ayar sadece bir miktar daha anlaşılır olabilir.