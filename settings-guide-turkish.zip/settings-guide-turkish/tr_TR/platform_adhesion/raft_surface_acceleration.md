Radye Üst Yazdırma İvmesi
====
Bu ayar, radyenin üst katmanları basılırken baskı kafasının ivme oranını yapılandırır. Radyenin taban, orta ve üst katmanları için ivme ayrı ayrı yapılandırılabilir.

![Üst katmanların radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Radye genellikle uzun çizgi segmentlerinden oluştuğu için, ivmeyi artırma genellikle baskı süresi üzerinde çok az etkiye sahiptir. Ancak ivmeyi artırmak, çizgilerin sonundaki köşelerden geçerken biraz zaman kazandırır.

İvme oranının artırılması, radyeyi yazdırırken yazıcının daha fazla titreşmesine neden olur. Bu, radyenin üst yüzeyinin düzgünlüğünü kötüleştirir ve dolayısıyla radyeye oturan baskının alt yüzeyinin daha az düzgün olmasına yol açar.