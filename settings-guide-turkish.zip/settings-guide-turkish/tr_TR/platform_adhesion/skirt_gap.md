Etek Mesafesi
====
Bu ayar, model ile etek arasındaki mesafeyi ayarlar.

Bu, eteğin en yakın çizgisi ile model arasındaki mesafedir. Eğer etek birden fazla çizgiden oluşuyorsa, bu ek çizgiler modelden daha uzak bir mesafede yerleştirilecektir.

Yeterli mesafe korunarak, eteğin modele yapışması önlenir ve fil ayağı etkisi azaltılır.