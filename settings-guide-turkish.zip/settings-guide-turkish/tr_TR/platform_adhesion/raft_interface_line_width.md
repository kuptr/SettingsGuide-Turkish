Radyenin Orta Hat Genişliği
====
Bu ayar, radyenin orta katmanlarındaki çizgilerin genişliğini yapılandırır.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Daha geniş çizgiler, radyenin sertliğini artırır. Bazı malzemeler için, radyeyi çıkarmayı kolaylaştırır çünkü radyeyi eğmeniz gerekir. Ancak, diğer malzemeler için daha zorlaştırır, çünkü radyeyi çıkarmak için bükmeniz gerekir.