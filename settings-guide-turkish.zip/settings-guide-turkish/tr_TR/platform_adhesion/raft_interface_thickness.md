Radye Orta Kalınlığı
====
Bu ayar, radyenin orta katmanlarının dikey kalınlığını ayarlar. Bu sadece bir katmanın yüksekliğidir, bu nedenle orta katmanların toplam yüksekliği, bu ayarın [Radye Orta Katmanları](raft_interface_layers.md) ayarının değeriyle çarpılacaktır.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Daha kalın bir radye katmanı, radyeyi biraz daha sert hale getirme eğilimindedir. Bu, basım sırasında ve sonrasında radyenin eğilmesini önler. Basım sırasında radyenin çarpılmasını engellemek için radyenin sert olmasını istersiniz, bu da yapı platformuna yapışmayı kırar ve radyenin modelle birleşmesine neden olur. Basım sonrasında radyenin modelden daha kolay ayrılmasını istersiniz, bu nedenle radyenin esnek olmasını istersiniz. Bu ayar için dengeyi bulmak gereken önemli bir husustur.