Radyenin Orta Yazdırma İvmesi
====
<!--if cura_version<5.0:Bu ayar, radyenin orta katmanı basılırken yazıcı kafasının hızlanma oranını yapılandırır. Radyenin taban, orta ve üst katmanları için hızlanma bağımsız olarak yapılandırılabilir.-->
<!--if cura_version>=5.0-->Bu ayar, radyenin orta katmanları basılırken yazıcı kafasının hızlanma oranını yapılandırır. Radyenin taban, orta ve üst katmanları için hızlanma bağımsız olarak yapılandırılabilir.<!--endif-->

![Orta katmanın radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Genellikle radye uzun çizgi segmentlerinden oluştuğu için, hızlanmayı artırmak baskı süresi üzerinde çok az etkiye sahiptir. Ancak, hızlanmayı artırmak, çizgilerin uçlarında köşelere geçerken biraz zaman kazandırabilir.

Hızlanma oranını artırmak, radyenin orta <!--if cura_version<5.0:katmanı--><!--if cura_version>=5.0-->katmanları<!--endif--> basarken yazıcının daha fazla titreşim yapmasına neden olur. Bu, radyeyi baskı tablasından çekme riskini biraz artırır.