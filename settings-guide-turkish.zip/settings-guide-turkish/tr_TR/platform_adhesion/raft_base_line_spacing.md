Radyenin Taban Yazdırma Salınımı
====
Bu ayar, radyenin taban katmanındaki satırların arasındaki mesafeyi ayarlar. Bu, [Dolgu Hattı Mesafesi](../infill/infill_line_distance.md) ayarıyla benzer bir şekilde çalışır. Temel amaç, radyenin yapışma düzeyini ayarlamaktır.

![Radyede bulunan boyutlar](../images/raft_dimensions.svg)

Taban katmanındaki satırlar arasındaki mesafeyi azaltmak birkaç etkiye sahip olacaktır:
* Daha küçük bir mesafe, radyenin baskı tablasına yapışmasını artırır, çünkü radyenin yapışabileceği daha fazla yüzey olacaktır.
* Radye biraz daha sert olacaktır.
* Radyenin ilk katmanını yazdırmak daha uzun sürecektir. Bu katman çok yavaş bir şekilde yazdırılır, bu nedenle etki diğer radye katmanlarından daha büyüktür.