Radyenin Üst Katmanları
====
Bu, radyenin üst kısmındaki katman sayısıdır. Her zaman bir taban katmanı olacak, ancak [Radye Orta Katmanları](raft_interface_layers.md) ve üst katmanlar herhangi bir sayıda olabilir. Bu üst katmanlar genellikle çok yoğun olup, modelin basılacağı düzgün bir yüzey oluşturmak için tasarlanmıştır.

![Üst katmanların radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Daha fazla katman, modelin basılacağı daha düzgün bir yüzey oluşturur, çünkü seyrek dolu taban ve orta katmanlar geçiş yapmak zorundadır. Daha düzgün bir yüzey, baskınızın alt tarafının daha iyi görünmesini sağlar ve radye ile model arasındaki yapışmayı güçlendirir.

Ancak, daha fazla katman basmak da oldukça daha uzun süre alır.