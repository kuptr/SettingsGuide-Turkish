Radyenin Üst Katman Kalınlığı
====
Bu ayar, yüzey katmanlarının kalınlığını ayarlar. Bu sadece bir katmanın yüksekliğidir, bu nedenle yüzey katmanlarının toplam yüksekliği, bu ayarın [Radyenin Üst Katmanları](raft_surface_layers.md) ayarının değeriyle çarpılmasıyla elde edilir.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Küçük bir katman yüksekliği, radye üzerindeki soğutma etkisini artırma eğilimindedir. Bu, sarkmaları iyileştirir ve böylece radyenin düzgünlüğünü artırır. Daha düzgün bir radye, üzerine basılan baskının da daha düzgün olmasını sağlar ve radye ile nesne arasındaki yapışmayı iyileştirir. Ancak, katmanı çok ince yapmak yetersiz ekstrüzyona neden olur, bu da yapışma için faydalı değildir. Ayrıca, radyenin üst katmanı ile nesnenin alt katmanı arasında büyük bir akış hızı değişimi olacağını ve bu da nesnenin ilk katmanı basılırken bazı yetersiz ekstrüzyonlara neden olabileceğini göz önünde bulundurun.