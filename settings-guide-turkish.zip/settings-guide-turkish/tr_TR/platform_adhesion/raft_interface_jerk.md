Radyenin Orta Yazdırma Salınımı
====
Bu ayar, radyenin orta katmanlarını basılırken nozülün köşelerden geçiş hızını yapılandırır. Radyenin orta katmanları sırasında sarsıntı hızı, taban ve üst katmanlardan ayrı olarak yapılandırılabilir.

![Orta katmanın radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Radye genellikle uzun çizgi segmentlerinden oluştuğu için, sarsıntı hızını artırma genellikle baskı süresi üzerinde çok az etkiye sahiptir. Ancak çizgilerin sonunda köşelerden geçerken biraz zaman kazandırır.

Sarsıntı hızını artırmak, radyenin orta katmanlarını basarken yazıcının daha fazla titreşmesine neden olur. Bu, radyeyi yapı platformundan çekme riskini biraz artırır.