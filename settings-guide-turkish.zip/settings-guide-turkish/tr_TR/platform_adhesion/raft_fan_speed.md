Radye Fan Hızı
====
Bu ayar, radyenin basıldığı sırada soğutma fanlarının dönme hızını yapılandırır.

Fan hızını artırmak, malzemenin daha hızlı soğumasına neden olur. Bu, plastik içindeki iç gerilmelerin plastik sertleşmeden önce rahatlamasını engelleyebileceğinden sıklıkla sürmeyi tetikler. Ayrıca, malzemenin baskı tablası ile temas alanını artırmak için akışını artırmak yerine, radyenin baskı tablasına daha az yapışmasına neden olabilir. Ancak, artan fan hızıyla, hatlar orta ve üst katmanlarda daha iyi köprülenir, radyeniz için daha düzgün bir yüzey sağlar ve sonuç olarak baskınız için daha düzgün bir yüzey oluşturur.

Radye kullanıldığında, [ilk katmandaki fan hızı](../cooling/cool_fan_speed_0.md), modelin ilk katmanındaki fan hızını etkiler, radyenin ilk katmanını etkilemez.