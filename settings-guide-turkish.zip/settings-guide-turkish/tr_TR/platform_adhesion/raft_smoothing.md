Radye Düzeltme
====
Bu ayarla, radyenin iç köşeleri daha düzleştirilebilir. Ayarlanan yarıçap bir yayı belirtir. Belirtilen yay yarıçapından daha keskin olan tüm iç köşeler, belirtilen yay yarıçapına sahip olacak şekilde düzeltilir.

<!--screenshot {
"image_path": "raft_smoothing_0mm.png",
"models": [{"script": "question_stick_clip.scad"}],
"camera_position": [0, 97, 191],
"settings": {
    "adhesion_type": "raft",
    "raft_smoothing": 0
},
"layer": 509,
"colours": 64
}-->
<!--screenshot {
"image_path": "raft_smoothing_5mm.png",
"models": [{"script": "question_stick_clip.scad"}],
"camera_position": [0, 97, 191],
"settings": {
    "adhesion_type": "raft",
    "raft_smoothing": 5
},
"layer": 509,
"colours": 64
}-->
![Düzleştirme yok](../images/raft_smoothing_0mm.png)
![5mm yarıçap](../images/raft_smoothing_5mm.png)

Bu işlemin teknik terimi [morphological closing operation](https://en.wikipedia.org/wiki/Closing_\(morphology\))'udur. Belirtilen yarıçaptan daha küçük olan tüm delikler kapatılacaktır. En keskin iç köşeler artık daha keskin yapılmayacaktır.

Bu ayarın işlevi radyeyi daha sert hale getirmektir. Birden fazla parça ince bağlantılar aracılığıyla bağlandığında, raft bu yerlerde bükülebilir. Bu, onları daha az sert ve çarpılmaya karşı daha az dirençli hale getirir. Bu ayarı artırmak, ayrı parçaları daha iyi bağlı hale getirir, radyeyi daha güçlü hale getirir. Radyenin yüzey alanı daha büyük olacak, bu yüzden radye daha iyi yapışacak. Ayrıca, radyenin toplamda daha küçük bir çevresi olacak, bu da çarpılmanın başlayabileceği yerleri azaltacaktır. Toplamda, daha az çarpılma olmalıdır.

Ancak radyenin toplam hacmi de artacaktır. Bu daha fazla malzeme kullanır ve daha uzun süre basmak için alır, özellikle radye genellikle çok yavaş basılır.