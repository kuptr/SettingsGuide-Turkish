Radye Orta Ekstrüderi
====
Bu ayar, radyenin orta katmanları için kullanılacak ekstrüderi seçer.

![Orta katmanın radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Arayüz katmanları, taban katmanı ile üst katmanlar arasına gömülür. Üst katmanları desteklemek, ısıyı yapı platformundan uzak tutmak ve baz katmandan daha iyi bir yapısal dayanıklılık sağlamak için bir tampon bölgesi olarak işlev görür. Bu nedenle, taban ve üst katmanlardaki malzemelere iyi yapışan bir malzeme seçmek önemlidir.