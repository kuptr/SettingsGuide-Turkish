Radyenin Taban Yazdırma Salınımı
====
Bu ayar, radyenin taban katmanı yazdırılırken meme başının köşelerden geçme hızını yapılandırır. Radyenin taban katmanındaki titreşim hızı, orta ve üst katmanlardan ayrı olarak yapılandırılabilir.

![Taban katmanı radyenin içinde bulunduğu yerdir](../images/raft_dimensions_simplified.svg)

Genellikle radye uzun çizgi segmentlerinden oluştuğu için, titreşim hızını artırmak genellikle baskı süresi üzerinde çok az bir etkiye sahiptir. Ancak, çizgilerin sonunda köşelerden geçerken biraz zaman kazandırabilir.

Titreşim hızını artırmak, radyenin taban katmanını yazdırırken yazıcının daha fazla titreşmesine neden olur. Bu, radyenin yapıştırıcıdan çekilme riskini hafifçe artırır.