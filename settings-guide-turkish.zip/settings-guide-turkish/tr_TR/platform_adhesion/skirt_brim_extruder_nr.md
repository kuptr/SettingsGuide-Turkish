Etek/Kenar Ekstrüderi
====
Etek veya kenar basarken, bu ayar ana gövdenin hangi ekstruder ile basılacağını belirler.

Etek ve kenar, baskıda kullanılan her ekstruder için bir halka ile çevrelenir, bu da malzemenin hazır olmasını sağlar. Bu ayar, etek veya kenarın ilk kısmı için kullanılacak ekstruderi seçer.

Dikkat edilmesi gereken nokta, eğer yazıcı birden fazla ekstrudere sahipse ve ilk ekstruder baskının geri kalanında kullanılmıyorsa, bu ayar otomatik olarak kullanılan ekstruderlerden birine ayarlanmaz. Bu durumda, baskı sadece etek veya kenar için o ilk ekstruderi kullanacaktır. Bu, biraz zaman ve malzeme israfına yol açabilir veya baskının altına yanlış rengin yapışmasına neden olabilir.