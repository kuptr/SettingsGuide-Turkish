Extruder İlk X konumu
====
Bazı yazıcılar, özel bir g-code komutu (G280) kullanarak baskı işleminden önce ekstrüzyon sürecini hazırlayabilir. Bu ayar, [Extruder İlk Y konumu](extruder_prime_pos_y.md) ayarı ile birlikte bu hazırlamanın yapılacağı yeri tanımlar. Bu ayar X koordinatını belirler.

Bu koordinatlar, g-code koordinat sisteminde belirtilir ve Cura'nın nesnelerin yerleştirilmesini göstermek için kullandığı koordinat sisteminden farklıdır.

Cura, hazırlamanın yapılacağı yeri yapının üzerinde küçük bir daire ile belirtir. Orada hiçbir nesne yazdıramazsınız.
