Radyenin Taban Yazdırma İvmesi
====
Bu ayar, radye taban katmanı yazdırılırken baskı kafasının ivme oranını yapılandırır. Radye taban, orta ve üst katmanlarının ivmesi bağımsız olarak yapılandırılabilir.

![Radye taban katmanının konumu](../images/raft_dimensions_simplified.svg)

Radye genellikle uzun çizgi segmentlerinden oluştuğundan, ivmenin artırılması normalde baskı süresi üzerinde çok az etkiye sahiptir. Ancak, çizgilerin sonundaki köşelerden geçerken ivmenin artırılması biraz zaman tasarrufu sağlar.

İvme oranının artırılması, radye taban katmanı yazdırılırken yazıcının daha fazla titreşmesine neden olur. Bu, radyeyi yapı plakasından çekme riskini biraz artırır.