Radyenin Orta Yazdırma Hızı
====
Bu ayar, radyenin orta katmanlarının basıldığı hızı yapılandırır. Orta katmanların hızı, üst ve taban katmanların hızından ayrı ayrı yapılandırılabilir.

![Orta katmanın radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Orta katmanları daha yavaş basmak, malzemenin daha uzun süre sıcak kalmasını sağlar, bu da iç gerilmeleri azaltır. Bu, malzeme soğuduktan sonra çarpılma miktarını azaltır. Ancak daha yavaş basmak aynı zamanda daha fazla zaman alır.