Radye Yazdırma Hızı
====
Bu ayar, radyenin genel olarak ne hızda basılacağını belirler. Radyeyi basmak için kullanılacak gerçek hız, hızın taban, orta veya üst katmanlar için özelleştirilmiş olup olmadığına bağlı olarak farklı olabilir.

Radyeyi diğer baskılardan daha yavaş basmak genellikle faydalıdır. Daha yavaş basmak, plastiklerin daha fazla yumuşamasına izin verir çünkü daha uzun süre sıcak kalır, bu da çizgiler arasındaki iç gerilmeleri azaltır ve çarpılmayı azaltır. Daha uzun süre sıcak kalması nedeniyle, malzeme daha fazla akar ve yatakla temas alanını artırır, bu da yapışmayı artırır. Genel olarak, radyeniz daha sert, daha güçlü, daha güvenilir ve daha iyi yapışacaktır.

Ancak tabii ki radyeyi basmak daha uzun sürecektir.