Brim Only on Outside
====
Sadece dışarıda bulunan deliklerin çevresinde kenar oluşturur. Modelinizin taban katmanında delikleri varsa, bu ayar deliğin iç kısmında bir kenar oluşturulmasını önler.

<!--screenshot {
"image_path": "brim_outside_only_original.png",
"models": [{"script": "holes_in_panel.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "adhesion_type": "brim",
    "brim_line_count": 10,
    "brim_outside_only": false
},
"layer": 1,
"colours": 32
}-->
<!--screenshot {
"image_path": "brim_outside_only_enabled.png",
"models": [{"script": "holes_in_panel.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "adhesion_type": "brim",
    "brim_line_count": 10,
    "brim_outside_only": true
},
"layer": 1,
"colours": 32
}-->
![Heryerde kenar oluşturulur.](../images/brim_outside_only_original.png)
![Sadece dışarıda kenar oluşturulur](../images/brim_outside_only_enabled.png)

İç kısımdaki kenar genellikle baskı ve yapı tablası arasındaki yapışma gücüne çok az katkı sağlar ve küçülme önlemesinde etkisi yoktur. İç kısımdaki kenarı kaldırmak, baskı tamamlandıktan sonra zaman kazanmanızı sağlayabilir çünkü iç kısımdaki deliklerden kenarı çıkarmak zorunda kalmazsınız.

**Delik içinde başka bir nesne varsa, teknik sınırlamalar nedeniyle kenar kaldırılamaz.**