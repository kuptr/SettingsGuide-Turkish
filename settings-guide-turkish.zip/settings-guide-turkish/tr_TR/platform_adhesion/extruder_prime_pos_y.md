Extruder İlk Y konumu
====
Bazı yazıcılar, baskı işleminden önce ekstrüzyon sürecini hazırlamak için özel bir g-code komutu (G280) kullanabilir. Bu ayar, [Extruder İlk X konumu](extruder_prime_pos_x.md) ayarı ile birlikte bu hazırlamanın yapılacağı yeri tanımlar. Bu ayar Y koordinatını belirler.

Bu koordinatlar, g-code koordinat sisteminde belirtilir ve Cura'nın nesnelerin yerleştirilmesini göstermek için kullandığı koordinat sisteminden farklıdır.

Cura, hazırlamanın yapılacağı yeri yapının üzerinde küçük bir daire ile belirtir. Orada hiçbir nesne yazdıramazsınız.