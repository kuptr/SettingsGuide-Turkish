Radye Hava Boşluğu
====
Gerçek baskıdan radyenin çıkarılmasına izin vermek için model ile radye arasında bir boşluk bulunur. Bu, yazıcının radyenin üstüne objeyi hafifçe yerleştirmesini sağlar.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Boşluğu artırmak, radyenin daha kolay çıkarılmasını sağlar, ancak radyenin baskı sırasında kopma olasılığını da artırır; bu da baskınızı mahvedebilir. Radyeyi radyenin üstündeki modelle farklı bir modelle basıyorsanız, bu mesafeyi oldukça düşük tutmak tavsiye edilir; aksi takdirde baskınızın başarısız olma olasılığı yüksektir.