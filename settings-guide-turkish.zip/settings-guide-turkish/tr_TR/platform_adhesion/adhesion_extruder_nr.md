Yapı Levhası Yapıştırma Ekstruderi
====
Yapım tabanı yapışmayı artıran yapılar (örneğin, brim veya raft gibi) yazdırıyorsanız, bu ayar bu yapıların hangi ekstrüderle yazdırılacağını belirler.

* Yapım tablasına iyi yapışmayan bir malzeme ile yazdırıyorsanız, yapım tablasına iyi yapışan bir malzeme ile yazdırılmış bir raft kullanmak faydalı olabilir.
* Yazdırma işlemi için yalnızca bir ekstrüder kullanıyorsanız ve bu ilk ekstrüder değilse, bu ayar otomatik olarak modelinizle aynı ekstrüderi kullanacak şekilde ayarlanmaz. Baskınız hala birden fazla ekstrüder kullanır.

Etek veya brim kullanırken, [Etek/Kenar Ekstrüderi](skirt_brim_extruder_nr.md) bu ayarı tamamen geçersiz kılar, ancak varsayılan olarak aynı olmalıdır. Bir radye kullanırken, radyenin bireysel bileşenleri, [Raft Base Extruder](raft_base_extruder_nr.md), [Radye Taban Ekstrüderi](raft_interface_extruder_nr.md) ve [Radye Üst Ekstrüderi](raft_surface_extruder_nr.md) ile farklı ekstrüderlere atanabilir.