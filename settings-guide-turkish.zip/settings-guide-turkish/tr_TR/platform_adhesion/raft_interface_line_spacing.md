Radye Orta Boşluğu
====
Bu ayar, radyenin orta katmanlarında yan yana çizgiler arasındaki aralığı ayarlar. Bu, [Dolgu Hattı Mesafesi](../infill/infill_line_distance.md) ayarına benzer bir şekilde yapılır. Temel amaç, radyenin sertliğini ve üst katmanın ne kadar iyi desteklendiğini ayarlamaktır.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Çizgilerin arası uzak olursa, radyenin basım süresi azalır. Ayrıca, radyeyi daha kolay bükülebilir hale getirir, bu da onun daha kolay kırılmasını sağlar. Ancak, çizgiler çok uzak aralıklarla yerleştirilirse, radyenin üst katmanları iyi desteklenmez. Bu, radyenin yüzeyini düzensiz hale getirir, bu da radye ile model arasındaki yapışmayı azaltır, ancak modelin alt tarafını daha karmaşık hale getirir.