İlk Katman Z Çakışması
====
Bu ayar sadece bir radye ile baskı yaparken kullanılabilir. İlk kat hariç, modelin tüm katlarını aşağı çeker. Bu, ilk katı radye daha sıkı bir şekilde sıkıştırır.

![Radye'yi oluşturan boyutlar](../images/raft_dimensions.svg)

Bu ayarın amacı, radyedeki hava boşluğunu telafi etmektir. Ancak ilk kat radyeden uzaklaştıkça biraz daha soğumuş olacak ve radye fazla yapışmasını önleyecektir. Sonrasında, ikinci kat tarafından ilk kat radye bastırılacak ve baskı hala stabil olacaktır.
* Bindirmeyi arttırmak, radye daha güçlü yapışma sağlayabilir, bu da güvenilirliği artırır.
* Bu ayar, dikey yönde boyutsal doğruluğunuzu etkiler.
* Bu ayar, çok yüksek ayarlanırsa aşırı ekstrüzyona neden olabilir.