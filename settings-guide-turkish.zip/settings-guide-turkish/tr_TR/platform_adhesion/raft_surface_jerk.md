Radye Üst Yazdırma Salınımı
====
Bu ayar, radyenin üst katmanları basılırken baskı kafasının köşelerden geçiş hızını yapılandırır. Radyenin üst katmanlarında sarsıntı hızı, taban ve orta katmanlardan ayrı olarak yapılandırılabilir.

![Üst katmanların radye içindeki konumu](../images/raft_dimensions_simplified.svg)

Radye genellikle uzun çizgi segmentlerinden oluştuğu için, sarsıntı hızını artırma genellikle baskı süresi üzerinde çok az etkiye sahiptir. Ancak sarsıntı hızını artırmak, çizgilerin sonundaki köşelerden geçerken biraz zaman kazandırır.

Jerk (Salınım) oranının artırılması, radyeyi yazdırırken yazıcının daha fazla titreşmesine neden olur. Bu, radyenin üst yüzeyinin düzgünlüğünü kötüleştirir ve dolayısıyla radyeye oturan baskının alt yüzeyinin daha az düzgün olmasına yol açar.