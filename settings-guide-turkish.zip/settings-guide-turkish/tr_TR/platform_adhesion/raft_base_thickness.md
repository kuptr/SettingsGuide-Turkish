Radye Taban Kalınlığı
====
Bu ayar, radyenin en alt katmanının dikey kalınlığını ayarlar.

![Radye ile ilgili boyutlar](../images/raft_dimensions.svg)

Rafın ilk katmanının yüksekliğini artırmak, meme tarafından daha fazla kuvvetle ekstrüde edilmesine neden olur, [İlk Katman Yüksekliği](../resolution/layer_height_0.md) ayarıyla benzer şekilde. Bu, raft ile baskı tablası arasındaki yapışmayı artırır. Ayrıca, ekstra kalınlık, baskı tablasının tam olarak düz olmaması durumunda yükseklikteki herhangi bir değişkenliği yakalayabilir.