Kenar Genişliği
====
Bu ayar, kenarın genişliğini milimetre cinsinden ayarlar.

![Kenarın boyutları](../images/brim_width.svg)

Daha geniş bir brim, baskı plakasına yapışmayı artırarak baskınızın yüzey alanını artırır. Ancak, etkili baskı alanını azaltacaktır.