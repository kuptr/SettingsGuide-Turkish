Radye Üst Yazdırma Hızı
====
Bu ayar, radyenin üst katmanlarının basıldığı hızı yapılandırır. Üst katmanların hızı, orta ve taban katmanların hızından ayrı olarak yapılandırılabilir.

![Üst katmanların radye içinde nerede bulunduğu](../images/raft_dimensions_simplified.svg)

Üst katmanları daha yavaş basmak, malzemenin daha uzun süre sıcak kalmasını sağlar, bu da iç gerilmeleri ve çarpılmayı azaltır. Ayrıca, nozülün bitişik radye çizgilerini daha fazla ısıtmasına olanak tanır, bu da daha düzgün bir yüzey oluşturur. Bu, radye için daha düzgün bir yüzey ve dolayısıyla baskınız için de daha düzgün bir yüzey sağlar.

Bu, ek baskı süresi maliyetiyle gelir. Genellikle birden fazla üst katman bulunduğundan, hızın baskı süresi üzerindeki etkisi taban ve orta katmanlara göre daha büyüktür.