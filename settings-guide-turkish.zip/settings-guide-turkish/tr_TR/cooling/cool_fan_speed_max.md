Maksimum Fan Hızı
====
Katman minimum katman süresinde yazdırıldığında baskı kafasındaki fanların döneceği hız. Minimum katman süresinde, katmanı mümkün olduğunca hızlı soğutmak isteyeceksiniz ki yazıcı bir sonraki katmanı üzerine eklemeden önce katmanın soğuma süresi azalsın.

![Hangi fan hızı nerede kullanılıyor](../images/cool_fan_speed.svg)

Bir katmanın yazdırılması [Olağan/Maksimum Fan Hızı Sınırı](cool_min_layer_time_fan_speed_max.md) ve [Minimum Katman Süresi](cool_min_layer_time.md) ayarları arasında bir süre alıyorsa, fan hızı [Olağan Fan Hızı](cool_fan_speed_min.md) ile [Maksimum Fan Hızı](cool_fan_speed_max.md) arasında interpolasyon yapılacaktır. Minimum Katman Süresi'ne ulaşıldığında, Maksimum Fan Hızı na da ulaşılmış olacaktır. Bu şekilde, baskı mümkün olduğunca çabuk soğutulacak ve bir sonraki katmanın eklenmesinden önce hızla soğuması sağlanacaktır.