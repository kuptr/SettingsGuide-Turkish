Yazıcı Başlığını Kaldır
====
[Minimum Katman Süresi](cool_min_layer_time.md)'ne ulaşıldığında, bir sonraki katman eklenmeden önce önceki katmanın soğuması ve katılaşması için baskı kafası yavaşlar. Baskı kafası, [Minimum Hız](cool_min_speed.md)'a ulaşıldığı ana kadar yavaşlamaya devam eder.

Bu ayar etkinleştirildiğinde ve Minimum Katman Süresi'ni korumak için baskı kafası Minimum Hız'dan daha yavaş hareket etmesi gerektiğinde, baskı kafası katmanı yazdırdıktan sonra hafifçe yukarı hareket eder. Ardından Minimum Katman Süresi'ne ulaşana kadar bekler ve sonra bir sonraki katmana başlar.

Bu ayar devre dışı bırakıldığında, yazıcı bir sonraki katmana hemen devam eder. Minimum Katman Süresi'ni beklemez, bu nedenle katmanlar tamamen katılaşmamış katmanların üzerine yazdırılır.

![Minimum katman süresine ulaşıldığında başlık yukarı kalkabilir](../images/cool_fan_speed.svg)

Baskı kafası her zaman 3 mm yukarı hareket eder. Şu anda bunu yapılandırmak için bir ayar bulunmamaktadır.

Tavizler
----
Katmanın daha iyi soğumasına izin vermek için nozülü yavaşlatmanın bir tavizi vardır. Minimum Katman Süresi, baskı kafasının hareketini yavaşlatarak malzemenin soğuması için biraz zaman tanımak amacıyla tasarlanmıştır. Bu süre zarfında, fanlar maksimum güçte üfleyerek malzemeyi daha hızlı soğutmaya çalışır, ancak sıcak nozül de plastiğin üzerinde kalır. Çok küçük parçalar için, sıcak nozül fanların üflediğinden daha fazla ısıyı baskıya aktarabilir. Bu, plastiğin, minimum katman süresi olmasaydı daha fazla erimesine neden olur.

Kafayı Kaldır ile bu taviz çözülür. Belirli bir noktaya kadar yavaşlayabilir, ancak çok küçük katmanlar için sıcak nozül ısıyı baskıya daha fazla aktarmaması için yukarı hareket eder. Kafa, baskıya üfleyen fanların etkili olması için yeterince yakın tutulur.

Bunun dezavantajı, [Z Sıçraması Yüksekliği](../travel/retraction_hop.md) gerçekleştirmesidir, bu da bir miktar [sicimlenmeye](../troubleshooting/stringing.md) neden olur. Kafayı kaldırmak sarkma ve kabarcıklığı iyileştirebilir, ancak farklı bir tür karışıklık yaratır. Bir bıçakla biraz manuel işlem yaparak oluşan iplikleri temizleyebilirsiniz.