Olağan/Maksimum Fan Hızı Sınırı
====
Bu ayar, katmanın baskı süresini belirler; baskı süresi çok kısa olduğunda fan hızının [Maksimum Fan Hızı](cool_fan_speed_max.md) yönelmesine başlayacağı bir nokta. Bu süreden daha uzun süren katmanlar [Olağan Fan Hızı](cool_fan_speed_min.md) kullanırken, daha kısa süren katmanların fan hızı Olağan ve Maksimum Fan Hızı ayarları arasında, [Minimum Katman Süresi](cool_min_layer_time.md) boyunca Maksimum Fan Hızı'nda olacak şekilde ara değerlere interpolasyon yapılır.

![Hangi fan hızı nerede kullanılıyor](../images/cool_fan_speed.svg)

Bu eşik azaltıldığında (daha kısa katmanlara doğru), fanın daha sık bir şekilde normal fan hızında dönmesine neden olur. Bu eşik artırıldığında, fanın daha sık bir şekilde daha yüksek hızlarda dönmesine neden olur, hatta katmanlar çok küçük olmasa bile.

Minimum Katman Süresi ve bu Normal/Maksimum Fan Hızı Eşiği arasında bir mesafe tutmak iyidir. Eşik Minimum Katman Süresi'ne ayarlanırsa, katmanlar eşikten hafifçe aşağıda olursa fan aniden durur. Bu, fanın birdenbire hızlandığı keskin bir sınır olduğundan baskının yüzeyinde görünür bantlama oluşturur. Bunun yerine iki ayar arasında bir fark olduğunda, fan hızındaki değişim daha kademeli olur ve bantlama baskıda görünmez.