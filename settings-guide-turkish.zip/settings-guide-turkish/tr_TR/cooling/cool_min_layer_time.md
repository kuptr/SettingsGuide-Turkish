Minimum Katman Süresi
====
Minimum Katman Süresi, izin verilen en kısa katman baskı süresini yapılandırır. Yazıcı, bu süreden daha hızlı katmanlar yazmaya izin vermez.

Bu, önceki katmanın üzerine bir sonraki katmanın konulmadan önce önceki katmanın soğumasına izin vermek için gereklidir. Bu, önceki katmanın tamamen katılaştığından emin olur ve sarkmayı önler.

![Hangi fan hızı nerede kullanılıyor](../images/cool_fan_speed.svg)

Bu ayarın üç etkisi vardır:
* Bir katman, [Olağan/Maksimum Fan Hızı Sınırı](cool_min_layer_time_fan_speed_max.md) ayarının gösterdiği kadar hızlı yazdırılırsa, fan hızı [Maksimum Fan Hızı](cool_fan_speed_max.md)'na yönelir. Bir katman o kadar küçük olur ki yazdırmak için Minimum Katman Süresi'ne inerse, Maksimum Fan Hızı kullanılır. Fan hızı ikisi arasında interpolasyon yapılır.
* Bir katmanın yazdırılması Minimum Katman Süresi'nden daha az süre alacaksa, baskı hızı Minimum Katman Süresi kadar sürmesi için yavaşlatılır.
* Baskı kafası çok yavaşlanacaksa ([Minimum Hız](cool_min_speed.md) ayarından daha yavaş yazdırmak) baskı kafası bir katmanın sonunda bekler ve isteğe bağlı olarak kafayı biraz yukarı kaldırır.

Katmanın daha iyi soğumasına izin vermek için nozülü yavaşlatmanın bir tavizi vardır. Minimum Katman Süresi, malzemenin soğumasına biraz zaman vermek için baskı kafasının hareketini yavaşlatarak tasarlanmıştır. Bu süre zarfında, fanlar malzemeyi daha hızlı soğutmak için maksimum güçte üfler, ancak sıcak nozül de hala plastiğin üzerindedir. Çok küçük parçalar için, sıcak nozül fanların üflediğinden daha fazla ısıyı baskıya aktarabilir. Bu, malzemenin, minimum katman süresi olmaksızın daha fazla erimesine neden olur.

Eğer nispeten soğuk malzemeler yazdırıyorsanız veya baskı kafasındaki fanlar özellikle güçlüyse, malzeme sarkmayı azaltmak için daha yüksek bir Minimum Katman Süresi tolere edecektir. Minimum Katman Süresi çok yüksek ayarlanırsa, nozül daha sık yavaşlar ve bu da bazı yerlerde topaklanma ve sarkmalara neden olur.