Yüksekteki Olağan Fan Hızı
====
Fan hızı, baskının başlangıcında [İlk Fan Hızı](cool_fan_speed_0.md) ayarının değerinde başlayacaktır. Baskının ilk birkaç katmanı boyunca, bu ayarda belirtilen yüksekliğe ulaşana kadar fan hızı kademeli olarak [Olağan Fan Hızı](cool_fan_speed_min.md) değerine yükseltilecektir..

![Hangi fan hızı nerede kullanılıyor](../images/cool_fan_speed.svg)

Genellikle, Başlangıç Fan Hızı önemli ölçüde düşürülür çünkü ilk katmanın baskı sırasında sıcak kalması gerekir. Eğer ilk katman soğursa, malzemede [eğrilik](../troubleshooting/warping.md) başlar. Bu, ilk katmanın yapı plakasından ayrılmasına neden olur ve baskının başarısız olmasına yol açar. Ancak, ikinci katman çok hızlı soğursa, yine büzülür ve kayma sürtünmesiyle ilk katmanı yukarı çekerek baskının bükülmesine neden olur. Bu ayarın amacı, daha düşük bir fan hızıyla birden fazla katman yazdırmaya olanak tanımaktır. Bu şekilde, baskının bükülmesini engelleyerek yeterli sertliğe ulaşmasını sağlar.

İlk birkaç katman sırasında fan hızını basitçe azaltmak, fan hızında keskin bir değişiklik oluşturur ve bu da nihai baskının yüzey kalitesinde gözle görülür bir değişikliğe neden olur. Bu, bantlanma oluşturur. Bunun yerine, fan hızının kademeli olarak normal fan hızına doğru değiştirilmesi daha doğru bir yoldur.

* Bu ayarı artırmak [tablaya yapışmayı](../troubleshooting/bed_adhesion_problems.md)'yı iyileştirebilir.
* Yapı plakanız yüksek bir sıcaklığa ısıtılmışsa, [fil ayağı](../troubleshooting/elephants_foot.md)'nı veya sızmayı önlemek için bu ayarı azaltmanız gerekebilir.