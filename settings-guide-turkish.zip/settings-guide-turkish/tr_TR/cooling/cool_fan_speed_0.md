İlk Fan Hızı
====
Baskının başlangıcında, ilk birkaç katman boyunca baskı kafasındaki fanların döneceği hız. Fan hızı daha sonra yavaşça normal fan hızına geçecektir. [Katmandaki Olağan Fan Hızı](cool_fan_full_layer.md) ayarıyla belirtilen katman numarasında, fan hızı [Olağan Fan Hızı](cool_fan_speed_min.md) değerine ulaşmış olacaktır.

![Hangi fan hızı nerede kullanılıyor](../images/cool_fan_speed.svg)

Baskının başlangıcındaki fan hızı, baskının geri kalanına göre genellikle daha düşüktür. Bu, malzemenin daha yavaş soğumasını ve yapı plakasına daha fazla sarkmasını sağlar. Bu da yapı plakasına yapışmayı iyileştirir.