Yazdırma Soğutmayı Etkinleştir
====
Bu ayar, yazdırma sırasında baskı kafasındaki fanları etkinleştirir veya devre dışı bırakır. Fanlar, baskı sırasında malzemeyi soğutarak daha hızlı katılaşmasını sağlamak için kullanılır.

Düşük cam geçiş sıcaklığı aralığına sahip malzemeler, örneğin PLA, yazdırma sırasında soğutulmalıdır. Fanlar, ortamdan daha soğuk havayı nozülden yeni çıkmış sıcak malzemenin üzerine üfleyerek bunu sağlar. Aksi takdirde malzeme sıcaktan dolayı [sarkma](../troubleshooting/sagging.md)'ya başlar, bu da şekil bozukluklarına neden olur ve baskının tamamen başarısız olmasına yol açabilir. Malzemenin havada asılı kaldığı yerlerde, örneğin çıkıntıların olduğu yerlerde, sarkmayı durduracak bir şey olmadığı için malzemenin hemen soğutulması kritik önem taşır.

Daha yüksek cam geçiş sıcaklığı aralığına sahip malzemeler için, örneğin ABS, fanların açılması yine de önerilir, ancak baskının belirli bölümleri için daha düşük bir hızda çalışabilirler. Çoğu yazıcı, fan hızının hassas bir şekilde kontrol edilmesine olanak tanır, bu nedenle fanlar sadece açık/kapalı anahtarı gibi çalışmaz. Genellikle hassas [Fan Hızı](cool_fan_speed.md) kontrolü yapabilirsiniz..

Yalnızca çok yüksek cam geçiş sıcaklığına sahip malzemeler için fanları tamamen devre dışı bırakmalısınız. Fanlar etkinleştirilirse, bu ekstrüzyon problemlerine yol açabilir ve nihai baskıyı kırılgan hale getirebilir.