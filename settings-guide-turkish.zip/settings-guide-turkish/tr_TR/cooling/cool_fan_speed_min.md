Olağan Fan Hızı
====
Katman çok küçük olmadığı sürece baskı kafasındaki fanların döneceği hız. Bu, baskınızın çoğu için kullanılacak fan hızıdır, ancak katman küçükse katmanı daha hızlı soğutmak için fan hızı [Maksimum Fan Hızı](cool_fan_speed_max.md) değerine doğru artırılacaktır.

![Hangi fan hızı nerede kullanılıyor](../images/cool_fan_speed.svg)

* Daha yüksek hız daha iyi soğutma sağlar. Bu, sızmayı ve ipliklenmeyi azaltır.
* Daha yüksek hız daha iyi çıkıntılar oluşturur ve kabarcık etkisini azaltır.
* Daha düşük hız bazı malzemelerde bükülmeyi azaltır ve baskıyı daha güçlü hale getirir.

Fan hızı, düşük cam geçiş sıcaklığı aralığına sahip malzemeler, örneğin PLA, yazdırılırken neredeyse her zaman maksimum olmalıdır. Bu malzemelerin hızlı soğumasının neredeyse hiç olumsuz yanı yoktur, çünkü nozülün ısısı sıcaklığı cam geçiş aralığının üzerinde tutmaya yeterlidir.