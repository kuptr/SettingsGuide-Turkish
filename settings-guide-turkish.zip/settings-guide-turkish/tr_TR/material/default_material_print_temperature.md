Varsayılan Yazdırma Sıcaklığı
====
Bu ayar, malzeme için ideal olan baskı sıcaklığını tanımlar. Malzeme yöneticisinde baskı sıcaklığını değiştirmek aslında bu sıcaklığı değiştirir. Gerçek baskı sıcaklığı farklı kalite profilleri için hala değişebilir. Nadir malzemeler kullanmadıkça bu ayarı değiştirmeniz nadirdir.

Bu ayar, baskı işlemi sırasında çeşitli aşamalarda ekstrüzyon sıcaklıklarını tanımlayan diğer sıcaklık ayarlarına aktarılır.