Dikey Ölçekleme Faktörü Büzülme Telafisi
====
Bu ayar, dilimleme öncesinde modeli otomatik olarak dikey yönde ölçekler. Amaç, baskı oda sıcaklığına soğuduğunda meydana gelen herhangi bir büzülmeyi telafi etmektir. Baskıyı istenenden biraz daha büyük hale getirerek, nihai sonucun giriş modelinin orijinal boyutlarına daha doğru olmasını sağlayabilir. Bu ölçekleme faktörü yalnızca Z yönlüdür.

Dikey yönde ölçekleme, yatay yönlere göre daha az bir sorundur, çünkü dikey yönde daha az iç stres vardır. Dikey olarak basılan çizgiler olmadığından, baskıdan sonra meydana gelen büzülme neredeyse tamamen yatay olacaktır. Malzeme kendisi soğumaya bağlı olarak küçülür, ancak bu çok küçük bir etkidir, özellikle PLA ile.

%100'lük bir faktör herhangi bir ölçeklemeye neden olmaz. Polikarbonat gibi bazı yüksek sıcaklık malzemeleri için %100'den biraz daha fazla bir ölçekleme faktörü uygun olacaktır. %100'den daha az bir ölçekleme faktörü, bir köpük gibi soğurken büyüyen bir malzemeyi gösterir