Destek Akışı
====
Bu ayar, yalnızca destek için akış hızını ayarlar. Destek akış hızı, geri kalan baskının akış hızından ayrı olarak ayarlanabilir.

Destek sırasında akış hızını ayarlamak, ekstrüzyon hızı veya destek ile baskı arasındaki yapışma sorunlarını düzeltmek için geçici bir çözümdür. Aynı etki, [Destek Hattı Genişliği](../resolution/support_line_width.md) veya [Destek Hattı Mesafesi](../support/support_line_distance.md) ayarlanarak elde edilebilir, ancak akışı ayarlamak daha sezgisel olabilir.

Eğer destek sırasında yalnızca ekstrüzyon hızı veya mukavemet ile ilgili bir sorun varsa, [Destek Hızı](../speed/speed_support.md) ve [Yazdırma Sıcaklığı](material_print_temperature.md) ayarlarına bakmak daha iyidir. Belki de destek ile diğer yapılar arasındaki akış farkı yeterince iyi ekstrüzyon yapmamak için çok büyük. Destek akış hızı ile ilgili yaygın bir sorun, [Destek Şekli](../support/support_pattern.md) içinde çok fazla kesişmenin olmasıdır. Kesişmeyen bir desen seçmek, örneğin **Gyroid veya Zikzak**, işe yarayabilir.