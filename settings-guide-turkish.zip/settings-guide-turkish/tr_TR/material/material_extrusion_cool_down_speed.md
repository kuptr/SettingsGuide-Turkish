Ekstrüzyon Sırasında Soğuma Hızı Düzenleyici
====
[Auto Temperature/Otomatik Sıcaklık](../experimental/material_flow_dependent_temperature.md) etkinse, baskı sıcaklığı, ne kadar malzeme ekstrüde edildiğine bağlı olarak ayarlanır.

Malzeme nozül odasında ısındığında, bu ısıyı nozülden alır. Malzeme daha hızlı ekstrüde edildiğinde, nozülden daha fazla ısı alınır. Sıcaklık probu nozül ucunda tam olarak olmadığında, iyi bir PID kontrolcüsü olsa bile, malzeme ekstrüde edilirken nozülün boşta olduğundan biraz daha düşük bir sıcaklığa sahip olmasına neden olur.

Bu ayar, baskı sırasında nozülde ne kadar ısı kaybı olduğunu açıklar. Ekstrüzyonla kaybedilen ekstra ısı, g-koddan istenen baskı sıcaklığını artırarak telafi edilir. Ayarın değeri, nozül tasarımına, basılan malzemenin ısı kapasitesine ve ekstrüzyon hızına bağlıdır.