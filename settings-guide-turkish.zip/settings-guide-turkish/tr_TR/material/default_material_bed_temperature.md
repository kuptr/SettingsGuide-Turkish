Varsayılan Yapı Levhası Sıcaklığı
====
Bu ayar, malzeme için ideal olan baskı işlemi sırasında yapı plakası sıcaklığını tanımlar. Malzeme yöneticisinde yapı plakası sıcaklığını değiştirmek aslında bu ayarın değiştirilmesidir. Gerçek yapı plakası sıcaklığı farklı kalite profilleri için hala değişebilir. Nadir malzemeler kullanmadıkça bu ayarı değiştirmeniz nadirdir.

Bu ayar, olağan [Yapı Levhası Sıcaklığı](material_bed_temperature.md) ayarı ve [İlk Katman Yapı Levhası Sıcaklığı](material_bed_temperature_layer_0.md) ayarları için kullanılır.

Farklı malzemelerle baskı yaparken, yapı plakası sıcaklığı bu malzemelerin en yükseğine ayarlanır.