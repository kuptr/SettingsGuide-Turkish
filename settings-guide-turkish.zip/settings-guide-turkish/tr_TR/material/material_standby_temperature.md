Bekleme Sıcaklığı
====
Cura, çoklu nozullu yazıcıların ayrı sıcaklıklara sahip ayrı nozullara sahip olduğunu varsayar. Bir ekstruder meşgulken, diğer nozulların içindeki malzemenin bozulmasını ve sızıntıyı önlemek için düşük bir sıcaklıkta tutulması gerekir. Bu düşük sıcaklık, bekleme sıcaklığıdır.

![Mavi ekstruder baskı yaparken, kırmızı ekstruder bekleme sıcaklığına soğur](../images/temperature_regulation.svg)

İyi bir bekleme sıcaklığı, nozulu tıkayabilecek şekilde filamentin bozulmasını önlemek için yeterince düşük olmalıdır. Nozuldan malzemenin sızmasını önlemek için yeterince düşük olmalıdır. Ancak diğer ekstruderler işlerini bitirdiğinde hızlı bir şekilde baskıya devam etmek için yeterince yüksek olmalıdır.