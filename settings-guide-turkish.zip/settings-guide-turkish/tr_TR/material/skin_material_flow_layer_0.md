İlk Katman Alt Akışı
====
İlk katın akışı, [İlk Katman Akışı](material_flow_layer_0.md) ayarı ile değiştirilebilir, ancak bu ayar sadece ilk katın cildinin akışını değiştirerek ilk katın daha ince detayları üzerinde kontrol sağlar.

İlk katın bazı bölümleri diğerlerinden daha kolay yapı tablasından ayrılabilir. Baskının ilk satırları en tehlikelidir. Bu ayarı kullanarak, cildin akışını azaltarak orada aşırı ekstrüzyonu önleyebilirken, baskının duvarlarının akışını daha yüksek tutabilirsiniz.

İlk katın akışını çok yüksek tutmak, cildin kıvrılmasına neden olabilir, bu da baskının alt kısmında hoş olmayan bir etki yaratır ve baskının baskı sırasında yapı tablasından kopmasına neden olabilir. Duvarlar için bu kadar büyük bir sorun değildir. Bu akışı, [İlk Katman Dış Duvar Akışı](wall_0_material_flow_layer_0.md) ve [İlk Katman İç Duvar Akışı](wall_x_material_flow_layer_0.md) akışından daha düşük tutmak önerilir.