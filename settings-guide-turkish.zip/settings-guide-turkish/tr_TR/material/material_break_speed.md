Kopma Geri Çekme Hızı
====
Bazı yazıcılar için, bir filament değişimi için malzeme besleyicide düğümlenmeden temiz bir şekilde hareket etmesi gerekmektedir. Bu ayar, bunu temiz bir şekilde kırmak için prosedürün bir parçasını yapılandırır.

Bu ayar, malzemenin nozülde kalan topun sonunda filamenti koparmak için geri çekildiği hızı ayarlar. Nozülde kalan topun erimiş durumu nedeniyle dışarı çekilemez, ancak dışarı çekilen kısım ucunda ince bir iplik olmamalıdır, çünkü bu besleyicide sıkışabilir. Bu son geri çekme, filamenti kırar, ancak umarız önceki iki aşamanın yardımıyla temiz bir şekilde kırılır.

![İlk olarak, malzeme sızıntıyı durdurmak için geri çekilir](../images/filament_switch_anti_ooze.svg)
![İkinci olarak, filament yavaşça geri çekilir ve bu ipliği kırması kolay olan bir ince iplik çizilir ve bu ipliğin katılaşması sağlanır](../images/filament_switch_break_preparation.svg)
![Üçüncü olarak, filament daha da hızlı bir şekilde geri çekilir ve filament koparılır](../images/filament_switch_break.svg)

**Bu ayar şu anda Cura'nın arayüzünde hiç görünmez. Sadece profiller tarafından ayarlanabilir. Ayrıca, bu ayar dilimleme sırasında Cura tarafından kullanılmaz. Ancak, Cura'nın malzeme dosyası formatını anlayan yazıcılar, filament değiştirme prosedürlerini doğru şekilde yapılandırmak için bunu kullanabilir.** Bir son işlem betiği aracılığıyla baskıya `M600` komutu eklenebilir ve bu, bir filament değişimi tetikleyecektir.