Kristalli Malzeme
====
Malzemenin katılaşırken kristal yapılar oluşturup oluşturmadığını belirtir.

Bu sadece açıklayıcı bir ayar. Malzeme profilleri, malzemelerinin kristalin olup olmadığını belirtmek için bu ayarı ayarlayabilir, ancak kullanıcı bunu değiştiremez. Ancak, bir profil, ayar değerlerini belirlemek için bu özelliği kullanabilir. Bu, farklı malzemelerle aynı formüllerin kullanılmasına izin verir, bu da profil tasarımını kolaylaştırır ve belirli malzeme kombinasyonları için profillerin çalışmasını sağlar.

**Bu ayar hiçbir zaman arayüzde görünmez.**