Yazdırma Sıcaklığı
====
Bu, baskı sırasında nozulun sıcaklığına atıfta bulunur. Baskı sıcaklığı, malzemenin baskı sırasında nasıl davrandığını etkileyen en etkili ayarlardan biridir. Sıcaklıkta küçük bir farkın bile plastik akışı üzerinde büyük bir etkisi olabilir.

Her tür filamentin baskıda kullanılabileceği bir sıcaklık aralığı vardır. Bu genellikle filmin geldiği kutuda ve teknik veri tablosunda listelenir. Sıcaklığı arttırmak genellikle termoplastikleri daha akıcı hale getirir. Bu, yazıcının malzemeyi daha hızlı ekstrüde etmesine olanak tanır, çünkü iç sürtünme azalır. Büyük katman yükseklikleri, geniş hatlar, büyük akış veya büyük hızlarla baskı yaparken, sıcaklık aralığının daha yüksek uçunda olması gerekir. Ancak, daha sıcak baskı malzemenin soğumasını da zorlaştırır, bu da aşağıya sarkan kısımların daha fazla eğilmesine (daha fazla destek gerektirir) ve daha fazla sürünme oluşmasına neden olur.

Sıcaklığı çok yüksek ayarlamak, malzemenin baskı sırasında bozulmasına neden olur. Bu, nozulun tıkanmasına ve potansiyel olarak yazıcınızın zarar görmesine neden olabilir. Sıcaklığı çok düşük ayarlamak, besleyicinin malzemeye sürtmesine ve ekstrüzyonun durmasına neden olur.