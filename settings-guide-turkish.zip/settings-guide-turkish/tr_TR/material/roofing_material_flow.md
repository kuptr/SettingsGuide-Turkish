Üst Yüzeyin Dış Katman Akışı
====
Bu ayar, yalnızca üst yüzey için akış hızını ayarlar. Üst yüzeyin akış hızı, üst cildin geri kalan kısmının akış hızından ayrı olarak ayarlanabilir.

Üst yüzey sırasında akış hızını ayarlamak, ekstrüzyon hızı veya üst yüzeyin çok düzgün olmamasıyla ilgili sorunları düzeltmek için bir ara çözüm yöntemidir.

Yalnızca üst yüzeyin baskı sırasında ekstrüzyon hızıyla ilgili bir sorun varsa, nozuldan güvenilir bir akış elde etmek için [Yazdırma Sıcaklığı](material_print_temperature.md), [Üst Yüzey Hat Genişliği](../top_bottom/roofing_line_width.md) ve [Üst Yüzey Hızı](../speed/speed_roofing.md) kombinasyonuna bakmak daha iyidir.

Eğer üst yüzey pürüzsüz değilse, [Ütülemeyi Etkinleştir](../top_bottom/ironing_enabled.md) özelliği denemeye değerdir, ancak [Üst Yüzey Hat Genişliği](../top_bottom/roofing_line_width.md) ayarı, üst yüzeyin pürüzsüzlüğünü ayarlamak için daha etkili bir yol olabilir.