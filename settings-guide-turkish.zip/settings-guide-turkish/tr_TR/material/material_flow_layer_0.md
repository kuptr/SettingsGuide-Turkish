İlk Katman Akışı
====
Normal [Akış](material_flow.md) ayarı gibi, bu ayar nozuldan itilen malzemenin miktarını ayarlar, ancak bu sadece yapı platformuna dayanan katmanı etkiler.

Akışı doğrudan ayarlamak, aşağıya yerleştirilen malzemenin miktarını ayarlar. Normalde malzeme miktarı, Cura tarafından malzemenin doğru bir şekilde çizginin genişliği, yüksekliği ve uzunluğundaki boşluğu dolduracağı şekilde hesaplanır, ancak bu akış ayarlarıyla ayarlanabilir.

İlk kat için akışı artırmak, malzemenin yapı platformuna daha sıkı bir şekilde itilmesine neden olur. Bu, yapı platformuna yapışmayı artırır. Bu ayar ayrıca düzgün bir şekilde düzleştirilmemiş bir yatak için ayarlanabilir. Yatak çok yakınsa, akışı azaltmak istersiniz. Yatak çok uzaksa, akışı artırmak istersiniz. Ancak, mümkünse yatağı düzgün bir şekilde ayarlamak her zaman daha iyidir.