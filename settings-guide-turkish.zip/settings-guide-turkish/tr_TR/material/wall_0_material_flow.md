Dış Duvar Akışı
====
Bu ayar yalnızca dış duvar için akış hızını ayarlar. Dış duvarın akış hızı, iç duvarın akış hızından ayrı olarak ayarlanabilir.

Dış duvarda akış hızını ayarlamak, ekstrüzyon hızı veya boyutsal doğruluk sorunlarını gidermenin geçici bir yöntemidir. Aynı etki, [Dış Duvar Hattı Genişliği](../resolution/wall_line_width_0.md) ve [Dış Duvar İlavesi](../shell/wall_0_inset.md) ayarlarını ayarlayarak da elde edilebilir, ancak bu ayar başlangıçta ayarlamak için daha sezgisel bir yol olabilir.

Eğer dış duvarda yalnızca ekstrüzyon hızı ile ilgili bir sorun varsa, [Dış Duvar Hızı](../speed/speed_wall_0.md) ve [Yazdırma Sıcaklığı](material_print_temperature.md)'na bakmak daha iyidir. Belki malzeme nozuldan yeterince momentum alamıyor ve daha yüksek bir baskı hızı yardımcı olabilir. Belki çizgiler uygun şekilde ekstrüde edilmiyor. Belki malzeme çok soğuk veya çok sıcak.

Eğer boyutsal doğrulukta bir sorun varsa, [Dış Duvar Hattı Genişliği](../resolution/wall_line_width_0.md), [Yatay Büyüme](../shell/xy_offset.md)'ye ve [printing order](../shell/outer_inset_first.md) bakmak daha iyidir.