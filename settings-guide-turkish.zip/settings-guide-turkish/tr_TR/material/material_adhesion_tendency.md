Yapışma Eğilimi
====
Bu, yazdırmak için kullanılan malzemenin bir özelliğini tanımlayan betimsel bir ayar. Malzemenin kendisine ne kadar iyi yapışma eğiliminde olduğunu, özellikle katlar arası yapışma ne kadar güçlü olabilir, açıklar.

Şu anda bu ayarın tek etkisi, primer kulede hangi malzemenin kuleyi ayakta tutan güçlü dış kabuğu yazdırmak için kullanılacağını belirlemektir. En yüksek yapışma eğilimine sahip malzeme, primer kulenin en dış kabuğunu yazdırmak için kullanılacaktır.

**Bu ayarın bir birimi yoktur. Sadece göreceli bir özellik olması amaçlanmıştır.**