Son Yazdırma Sıcaklığı
====
Farklı bir ekstrüdere geçmeden hemen önce, nozülün Final Baskı Sıcaklığı'na hafifçe soğumasına izin verilecektir. Sonuç olarak, bu, ekstruder baskıyı tamamlamadan önce nozülün hafifçe önce soğumasına neden olur. Soğumaya başlaması beklenen an, nozül değişikliğinin gerçekleştiği noktada Tam Baskı Sıcaklığına tam olarak ulaşıldığında olur. Bundan sonra, beklemeye alma sıcaklığına doğru soğumaya devam edecektir.

![Soğumaya başlama anı (önsıcaklık) nozül değişikliği olduğunda Nozülün Final Baskı Sıcaklığına ulaşabileceği şekilde hesaplanır.](../images/temperature_regulation.svg)

Eğer Son Baskı Sıcaklığı normal baskı sıcaklığından biraz daha düşükse, diğer ekstrüder baskı yaparken bekleme durumunda beklerken nozülün oozlamayacağı kadar sızıntı yapmayacaktır.