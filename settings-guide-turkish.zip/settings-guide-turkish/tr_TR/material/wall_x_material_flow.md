İç Duvar Akışı
====
Bu ayar sadece iç duvarların akış hızını ayarlar. İç duvarların akış hızı, dış duvarın akış hızından ayrı olarak ayarlanabilir.

İç duvarlar sırasında akış hızını ayarlamak, ekstrüzyon hızı veya boyutsal doğruluk sorunlarını düzeltmek için geçici bir yöntemdir.

Eğer sadece iç duvarlar sırasında ekstrüzyon hızıyla ilgili bir sorun varsa, [İç Duvar Hızı](../speed/speed_wall_x.md) ve [Yazdırma Sıcaklığı](material_print_temperature.md)'na bakmak daha iyidir. Belki malzeme nozuldan yeterince momentum alamıyor ve daha yüksek bir baskı hızı yardımcı olabilir. Belki de [İç Duvar(lar) Hattı Genişliği](../resolution/wall_line_width_x.md) çok ince ve doğru bir şekilde ekstrüde edilemiyor. Belki de malzeme çok soğuk veya çok sıcak.

Boyutsal doğrulukla ilgili bir sorun varsa, [İç Duvar(lar) Hattı Genişliği](../resolution/wall_line_width_x.md), [Yatay Büyüme](../shell/xy_offset.md) ve [printing order](../shell/outer_inset_first.md) bakmak daha iyidir.