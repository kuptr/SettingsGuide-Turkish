Yüzey Enerjisi
====
Bu ayar, baskı malzemesi ile yüzey enerjisinin ne kadar güçlü olduğunu açıklar. Değiştirilmeyecek şekilde tasarlanmıştır, sadece kullanılan malzeme tarafından belirlenir.

Şu anda dilimleme tarafından aslında kullanılmamaktadır, ancak bazı yazıcı profilleri, bir başlangıç kulesi kullanılıp kullanılmayacağını belirlemek için bunu kullanır.

**Bu ayar, Cura'nın arayüzünde görünmez. Sadece profiller tarafından ayarlanabilir.**