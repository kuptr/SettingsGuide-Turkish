Yük Taşıma Çarpanı Yok
====
Bu ayar, filamentin, besleyici ile nozul odası arasında sıkıştırıldığında uzunluğundaki farkı ifade eder.

Filament nozuldan dışarı itiliyorsa, buna nozulun kendisi tarafından (daha küçük nozul açıklığından dolayı) ve nozul altındaki malzeme tarafından (basılan parça veya yatak olabilir) uygulanan bir karşı basınç vardır. Bu arada, besleyici diğer ucundan itiyor. Bu, filamenti besleyiciden nozula kadar olan yol boyunca sıkıştırır ve filamenti etkili olarak daha kısa hale getirir. Sonuç olarak, filamentin besleyiciden nozul ucuna getirilmesi, filamentin uygun bir baskı pozisyonuna getirilmesinden daha az hareket gerektirir.

Bu ayar, yazıcıya filamentin nozula getirilmesi için ne kadar ilerletilmesi gerektiğini söyler; çünkü besleyiciden nozula olan yolun ne kadar uzun olduğunu bilir. Bu ayrıca baskı için nozulu uygun bir basınç seviyesine getirmek için ne kadar malzeme primlenmesi gerektiğini belirlemeye de yardımcı olabilir.

TPU veya Polipropilen gibi daha kolay sıkışan malzemeler, PLA gibi sert malzemelere göre daha düşük bir faktöre sahip olacaktır.

**Bu ayar şu anda Cura'nın arayüzünde hiçbir zaman görünmez. Sadece profiller tarafından ayarlanabilir. Ayrıca, Cura dilimleme sırasında kullanılmaz. Ancak, Cura'nın malzeme dosya formatını anlayan yazıcılar, filamentin besleyici ile nozul arasında nasıl hareket edeceğini belirlemek için bunu kullanabilirler.**