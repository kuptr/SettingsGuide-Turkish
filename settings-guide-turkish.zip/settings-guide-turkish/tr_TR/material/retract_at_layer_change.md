Katman Değişimindeki Geri Çekme
====
Etkinleştirilirse, filament, bir sonraki katın yüksekliğine hareket ederken geri çekilir.

Bu, yüzeydeki Z dikişini azaltmak için kullanılabilir. Ancak, geri çekme mesafesi çok düşükse, etkili olacaktır. Geri çekme mesafesi yüksekse, geri çekmenin süresi malzemenin o kadar fazla sızmasına izin verecektir ki geri çekmeyi etkisiz hale getirir.