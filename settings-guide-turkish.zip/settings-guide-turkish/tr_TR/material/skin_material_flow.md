Üst/Alt Akış
====
Bu ayar, yalnızca üst ve alt için akış hızını ayarlar. Üst ve altın akış hızı, baskının geri kalan kısmının akış hızından ayrı olarak ayarlanabilir.

Üst ve alt sırasında akış hızını ayarlamak, ekstrüzyon hızı veya sızdırmaz olmama gibi sorunları düzeltmek için geçici bir yöntemdir.

Yalnızca üst tarafın baskısı sırasında ekstrüzyon hızıyla ilgili bir sorun varsa, [Dolgu Yoğunluğu](../infill/infill_sparse_density.md) ve [Dolgu Şekli](../infill/infill_pattern.md) veya belki de [Aşamalı Dolgu Basamakları](../infill/gradual_infill_steps.md)'na bakmak, üst tarafın geçmesi gereken mesafeyi azaltmak için daha iyidir. Yalnızca alt tarafın baskısı sırasında ekstrüzyon hızıyla ilgili bir sorun varsa, destek için [Destek Yoğunluğu](../support/support_infill_rate.md)'na, [Destek Şekli](../support/support_pattern.md)'ne ve [Kademeli Destek Dolgusu Aşamaları](../support/gradual_support_infill_steps.md)'na ye göz atın. İyi, tutarlı ekstrüzyon elde etmek için sıcaklık ve baskı hızı da önemli faktörlerdir.

Üst veya alt sızdırmaz değilse, sıcaklığı ayarlamak daha iyidir. Yastıklanma önlenmelidir, ancak sıcaklık çok düşükse ekstrüzyon eksikliği görebilirsiniz.