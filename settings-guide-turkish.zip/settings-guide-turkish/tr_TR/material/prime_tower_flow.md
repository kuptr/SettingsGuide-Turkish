İlk Direk Akışı
====
Başlangıç kulesinin akış hızı. Bu artırıldığında, daha fazla malzeme daha az bir alana itilir.

Bu ayarı artırmak, nozulun daha hızlı bir şekilde hazırlanmasını sağlar. Bu bazı zaman tasarrufu sağlayabilir. Ancak bunu fazla artırmak aşırı ekstrüzyona neden olabilir. Sonuç olarak, başlangıç kulesinde topaklar oluşabilir ve bu da kuleyi devirmesine neden olabilir.

Bu ayar, [İlk Direğin Minimum Hacmi](../dual/prime_tower_min_volume.md) ayarı için yeterli hacmi elde etmek için başlangıç kulesinin kaç çevreleyiciye ihtiyaç duyacağını hesaplarken dikkate alınır, bu nedenle akışı artırmak başlangıç kulesinin daha az çevreleyiciye sahip olmasına neden olur.