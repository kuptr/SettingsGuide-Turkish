Ölçekleme Faktörü Büzülme Telafisi
====
<!--if cura_version >= 4.8-->Bu ayar, modeli otomatik olarak dilimleme öncesinde etkili bir şekilde ölçekler. Amaç, baskı oda sıcaklığına soğuduğunda meydana gelen herhangi bir büzülmeyi telafi etmektir. Baskıyı istenenden biraz daha büyük hale getirerek, nihai sonucun giriş modelinin orijinal boyutlarına daha doğru olmasını sağlayabilir. Bu ölçekleme faktörü tüm boyutlara (X, Y ve Z) eşit olarak uygulanır.
Tüm sahne merkezinden ölçeklenir. Birden çok model bastırırken, tümü aynı köken noktasından ölçeklenir. Bu, bu modelleri son baskıda örtüşmeden çok yakın bir konuma yerleştirmenizi sağlar. Modellerin çarpışma alanları da ölçeklenir, böylece baskınızın nerede biteceğini tam olarak görebilirsiniz. Bu ayrıca modelleri sahnede, baskı veya yazıcı özelliklerinin, örneğin başlangıç kulesi veya yapı platformunun klipsleriyle çarpışabilecekleri konumlara yerleştirmenizi engelleyecektir.

%100'lük bir faktör herhangi bir ölçeklemeye neden olmaz. ABS veya polipropilen gibi birçok mühendislik malzemesi için %100'den biraz daha fazlası daha uygun olacaktır. %100'den daha az bir ölçekleme faktörü, bir köpük gibi soğurken büyüyen bir malzemeyi gösterir.

Sadece kimyasal veriler, bir malzemenin baskı sıcaklığı ile oda sıcaklığı arasındaki ne kadar küçüldüğünü tahmin etmek için yeterli değildir, çünkü baskı süreci de büzülmeyi etkiler. Bir çizgide ekstrüde edildiğinde, plastik çizginin uzunluğu boyunca gerilir ve o eksende daha fazla küçülür. Büzülme düzensizdir, ancak bu ayar tüm yönlere eşit bir ölçekleme faktörü uygular. Doğru sonuçlar için, ölçekleme faktörünü uygulamanız gereken en önemli eksende uygulamanız gerekir. En önemli boyut boyunca uzun, düz çizgiler varsa, ölçekleme faktörü daha büyük olmalıdır.

Ölçekleme faktörü %100,5'ten büyük ise ve büyük bir şey basıyorsanız, Cura, [eğilme](../troubleshooting/warping.md) yaşamaya başlayabileceğinize dair bir uyarı gösterecektir.<!--endif-->

<!--if cura_version < 4.8:Bu, modelin baskı sıcaklığından oda sıcaklığına soğurken ne kadar küçüldüğünü Cura'ya bildiren tanımlayıcı bir ayar.

Bu ayar şu anda dilimleme için kullanılmıyor. Şu anda, büzülme oranı %0,5'ten büyükse, büyük şeyler basılırken kullanıcıya bir uyarı göstermek için kullanılır.
-->
**TBu ayar, ayar listesinde görünmez. Sadece bir malzeme profili tarafından üzerine yazılacak dahili bir ayardır.**