İlk Yazdırma Sıcaklığı
====
Farklı ekstrüderler baskı yapıyorlarken bekleme durumundayken, nozül hafifçe daha düşük bir sıcaklıkta başlar. Ardından, baskı başladığında hemen normal baskı sıcaklığına ısıtılır.

![Ekstrüder değişimi, normal baskı sıcaklığından biraz daha düşük bir sıcaklıkta gerçekleşir](../images/temperature_regulation.svg)

Biraz daha düşük bir sıcaklıkta baskıyı yeniden başlatmak, nozül bekleme durumundayken oluşan sızıntı miktarını azaltır. Sonuçta, sızıntının çoğu nozül en yüksek sıcaklığında olduğunda gerçekleşir. Bu sıcaklığı düşürmek, aslında istenilen bir durumda gerçekleştiğinde sızıntının baskı sırasında olmasını sağlamak için baskının biraz daha düşük bir sıcaklıkta başlamasına neden olur.