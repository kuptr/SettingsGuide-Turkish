Kopma Hazırlığı Sıcaklığı
====
Bu, bir filament değişimi için malzemenin besleyici içinden temiz bir şekilde hareket etmesi için gereken prosedürün bir parçasını yapılandırır.

Bu ayar, malzeme ikinci pozisyona doğru çekilirken nozülün sıcaklığını ayarlar; malzemenin incelmesi için bir ince iplik haline gelmesi. Bu ince iplik, nozüldeki ısıtmalı bölgeden dışarıya uzanır, böylece soğuyabilir ve katılaşabilir. İnce, sert malzeme ipliği daha sonra geri çekmenin bir sonraki aşamasında kırılabilir.

![İlk olarak, malzeme sızıntıyı durdurmak için geri çekilir](../images/filament_switch_anti_ooze.svg)
![İkinci olarak, filament yavaşça geri çekilir ve bu ipliği kırması kolay olan bir ince iplik çizilir ve bu ipliğin katılaşması sağlanır](../images/filament_switch_break_preparation.svg)
![Üçüncü olarak, filament daha da hızlı bir şekilde geri çekilir ve filament koparılır](../images/filament_switch_break.svg)

**Bu ayar şu anda Cura'nın arayüzünde hiç görünmez. Sadece profiller tarafından ayarlanabilir. Ayrıca, bu ayar dilimleme sırasında Cura tarafından kullanılmaz. Ancak, Cura'nın malzeme dosyası formatını anlayan yazıcılar, filament değiştirme prosedürlerini doğru şekilde yapılandırmak için bunu kullanabilir.** Bir son işlem betiği aracılığıyla baskıya `M600` komutu eklenebilir ve bu, bir filament değişimi tetikleyecektir.