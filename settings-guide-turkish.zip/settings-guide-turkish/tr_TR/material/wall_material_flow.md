Duvar Akışı
====
Bu ayar yalnızca duvarlar için akış hızını ayarlar. Duvarların akış hızı, baskının geri kalanının akış hızından ayrı olarak ayarlanabilir.

Duvarlarda akış hızını ayarlamak, ekstrüzyon hızı veya boyutsal doğruluk sorunlarını gidermenin geçici bir yöntemidir.

Eğer duvarlarda yalnızca ekstrüzyon hızı ile ilgili bir sorun varsa,[Duvar Hızı](../speed/speed_wall.md)'larına ve [Yazdırma Sıcaklığı](material_print_temperature.md) bakmak daha iyidir. Belki malzeme nozuldan yeterince momentum alamıyor ve daha yüksek bir baskı hızı yardımcı olabilir. Belki [Duvar Hattı Genişliği](../resolution/wall_line_width.md) çok ince, uygun şekilde ekstrüde edilemiyor. Belki malzeme çok soğuk veya çok sıcak.

Eğer boyutsal doğrulukta bir sorun varsa, [Duvar Hattı Genişliği](../resolution/wall_line_width.md), [Yatay Büyüme](../shell/xy_offset.md)'ye ve [printing order](../shell/outer_inset_first.md)'na bakmak daha iyidir.