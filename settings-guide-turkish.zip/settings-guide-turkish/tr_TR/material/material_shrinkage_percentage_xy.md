Yatay Ölçekleme Faktörü Büzülme Telafisi
====
Bu ayar, dilimleme öncesinde modeli otomatik olarak yatay yönde ölçekler. Amaç, baskı oda sıcaklığına soğuduğunda meydana gelen herhangi bir büzülmeyi telafi etmektir. Baskıyı istenenden biraz daha büyük hale getirerek, nihai sonucun giriş modelinin orijinal boyutlarına daha doğru olmasını sağlayabilir. Bu ölçekleme faktörü yalnızca X ve Y yönlere uygulanır.

Yatay yöndeki ölçekleme daha önemlidir çünkü baskının iç streslerinin en büyük olduğu yöndür. Tipik olarak yatay büzülme, dikey büzülmeye göre daha büyüktür. Yatay olarak basılan çizgiler, çizgilerin dikey yönde olduğundan daha fazla yatay yönde daralmasına neden olur.

Tüm sahne merkezinden ölçeklenir. Birden çok model bastırırken, tümü aynı köken noktasından ölçeklenir. Bu, bu modelleri son baskıda örtüşmeden çok yakın bir konuma yerleştirmenizi sağlar. Modellerin çarpışma alanları da ölçeklenir, böylece baskınızın nerede biteceğini tam olarak görebilirsiniz. Bu ayrıca modelleri sahnede, baskı veya yazıcı özelliklerinin, örneğin başlangıç kulesi veya yapı platformunun klipsleriyle çarpışabilecekleri konumlara yerleştirmenizi engelleyecektir.

%100'lük bir faktör herhangi bir ölçeklemeye neden olmaz. ABS veya polipropilen gibi birçok mühendislik malzemesi için %100'den biraz daha fazlası daha uygun olacaktır. %100'den daha az bir ölçekleme faktörü, bir köpük gibi soğurken büyüyen bir malzemeyi gösterir.

Bir malzemenin baskı sıcaklığı ile oda sıcaklığı arasındaki ne kadar küçüldüğüne dair sadece kimyasal veriler bu ayar için iyi bir değeri öngörmek için yeterli değildir, çünkü baskı süreci de büzülmeyi etkiler. Bir çizgide ekstrüde edildiğinde, plastik çizginin uzunluğu boyunca gerilir ve o eksende daha fazla küçülür.