Temizleme Hızı
====
Eğer yazıcı belirli bir nozulden hangi filamentin geçeceğini değiştirmesi gerekiyorsa, nozül odasında hala kalan malzemeyi dışarı atması gerekir. Bu ayar, eski malzemeyi dışarı atmak için filamentin besleyici aracılığıyla ne kadar hızlı itildiğini belirler.

Bu yalnızca farklı bir tür malzemeye geçtikten sonra olan an için geçerlidir. Aynı tür malzeme tekrar yüklendiğinde (örneğin, önceki makara boşaldığı için), farklı bir [Filament Temizliği Bitiş Hızı](material_end_of_filament_purge_speed.md) kullanılır.

**Bu ayar şu anda Cura'nın arayüzünde hiçbir zaman görünmez. Sadece profiller tarafından ayarlanabilir. Ayrıca, Cura dilimleme sırasında kullanılmaz. Ancak, Cura'nın malzeme dosya formatını anlayan yazıcılar, filament değişim prosedürlerini doğru bir şekilde yapılandırmak için bunu kullanabilirler.** Bir son işleme betiği aracılığıyla, baskıya `M600` komutu eklenerek filament değişimi tetiklenebilir.