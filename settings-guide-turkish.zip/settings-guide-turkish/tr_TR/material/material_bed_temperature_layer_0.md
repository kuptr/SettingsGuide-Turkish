İlk Katman Yapı Levhası Sıcaklığı
====
Baskı yapılırken ilk katmanın basılması sırasında ısıtma tablaının farklı bir sıcaklığa ısıtılmasına neden olan bu ayar.

Baskı tablası, erimiş malzemenin ısısinin havalandırmalı havaya göre daha hızlı baskı tablasına transfer edilmesine izin verir, bu da malzemenin donma noktasından biraz daha uzun süre uzak tutulmasını sağlar, böylece katmanın küçülmesine ve eğilmesine neden olan bir sıcaklık şoku almaz.

**İlk katman tamamlandıktan sonra, tabla sıcaklığı normal tabla sıcaklığına ayarlanacaktır, ancak tablanın o sıcaklığa ulaşması biraz zaman alacaktır.**