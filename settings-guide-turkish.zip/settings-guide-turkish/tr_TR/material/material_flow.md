Akış
====
Akışı doğrudan ayarlamak, aşağıya yerleştirilen malzemenin miktarını ayarlar. Normalde malzeme miktarı, Cura tarafından malzemenin doğru bir şekilde çizginin genişliği, yüksekliği ve uzunluğundaki boşluğu dolduracağı şekilde hesaplanır, ancak bu akış ayarlarıyla ayarlanabilir.

Akışı ayarlamak için ana kullanım durumu, ekstrüzyon treninde bir hata telafi etmektir. Örneğin, nozül hafifçe tıkanmışsa, bu alt-ekstrüzyona neden olabilir. Akışı artırmak, umarız tıkanmış nozülde daha fazla malzeme itebilir, böylece doğru miktarda malzeme elde edilir. Bu ayrıca filament çapında kayma veya değişkenlik için telafi edebilir.

Genellikle, gerçek nedeni düzeltilen aşırı ekstrüzyon veya alt-ekstrüzyonu telafi etmek her zaman daha iyidir, ancak akışı ayarlamak kolay geçici bir çözüm olabilir.

**Çizgilerin daha geniş olmasını istiyorsanız, gerçek çizgi genişliği ayarını ayarlamak daha iyidir. Çizgi genişliğinin mutlaka nozül boyutuyla aynı olması gerekmez. Çizgi genişliğini ayarlamak ayrıca çizgiler arasındaki boşluğu da ayarlar, bu da aşırı ekstrüzyonu ve alt-ekstrüzyonu önler. Akışı ayarlamak boşluğu ayarlamaz.**