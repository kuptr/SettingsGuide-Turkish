İlk Katman Dış Duvar Akışı
====
Başlangıç katının akışı [İlk Katman Akışı](material_flow_layer_0.md) ayarı ile değiştirilebilir, ancak bu ayar yalnızca ilk katın dış duvarının akışını değiştirerek başlangıç katının daha ince detaylarını kontrol etmenizi sağlar.

Başlangıç katının bazı bölümleri diğerlerinden daha kolay yapışmaz. Baskının ilk çizgileri en tehlikelidir. Bu ayarı kullanarak, dış duvarın akışını artırarak onu daha iyi bir şekilde yapı tablasına tutturabilirsiniz. Bu, baskında brim olmadığında kullanışlıdır, çünkü dış duvar daha az yapışkanlık yüzey alanına sahip bir şekilde tek bir gevşek çizgi olarak yapı tablasında yazdırılır.

Sadece dış duvarın akış hızını değiştirerek, [Overextrusion / Aşırı ekstrüde](../troubleshooting/overextrusion.md) gibi yüksek akış hızı sorunlarından kaçınabilirsiniz.