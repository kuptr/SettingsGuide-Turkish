İlk Katman Yazdırma Sıcaklığı
====
Nozul, baskının geri kalan kısmı için ilk katmandan farklı bir sıcaklıkta baskı yapabilir.

Bu, yatak yapışkanlığını artırmak için faydalıdır. İlk katmanda malzeme biraz daha yüksek bir sıcaklıkta daha sıvı olacaktır. Bu, malzemenin daha ileri akmasına izin verir, baskının altında hava kabarcıklarını azaltır ve yapı platformuyla temas alanını artırır. Ayrıca, malzemenin biraz daha uzun süre ısıl işlem görmesine izin vererek şekil bozulmasını azaltır. Geri kalan baskı için daha yüksek bir sıcaklık istemezsiniz çünkü bu, aşağı sarkmalara ve sürünmelere neden olur.