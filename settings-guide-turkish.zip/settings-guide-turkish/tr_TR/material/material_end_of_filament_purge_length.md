Filament Temizliği Bitiş Uzunluğu
====
Bazı yazıcılar, malzeme tükendiğinde yeni bir makara otomatik olarak yüklenebilir. Böyle bir durumda, baskıya devam etmeden önce malzemeyi tekrar hazırlamaları gerekir. Bu ayar, yeni makarayı hazırlamak için kullanılan filamentin uzunluğunu belirler.

Bu yalnızca yeni malzeme önceki malzemeyle aynı olduğunda geçerlidir. Farklı bir malzemeye geçildiğinde, farklı [Temizleme Uzunluğu](material_flush_purge_length.md) kullanılır.

**Bu ayar şu anda Cura'nın arayüzünde hiçbir zaman görünmez. Sadece profiller tarafından ayarlanabilir. Ayrıca, Cura dilimleme sırasında kullanılmaz. Ancak, Cura'nın malzeme dosya formatını anlayan yazıcılar, yeni makaralara doğru bir şekilde geçmek için bunu kullanabilirler.**