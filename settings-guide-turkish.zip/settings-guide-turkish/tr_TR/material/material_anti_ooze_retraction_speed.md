Sızma Önleme Geri Çekme Hızı
====
Bazı yazıcılar için, bir filament değişimi için malzeme geri çekildiğinde, malzemenin çıtır çıtır kırılarak besleme mekanizmasından dolaşmadan geçirilmesi gerekmektedir. Bu ayar, malzemenin temizce kırılması prosedürünün bir kısmını yapılandırır.

Bu ayar, malzemenin sızıntı yapmasını durdurmak için ilk konuma doğru geri çekildiği hızı ayarlar. Malzeme bu noktada henüz kırılmamıştır. Amaç, sadece nozül odasındaki basıncı hızla azaltarak malzemeyi içeri çekmektir.

![İlk olarak, malzeme sızıntıyı durdurmak için bu ayara göre geri çekilir.](../images/filament_switch_anti_ooze.svg)
![İkinci olarak, filament, kırılması kolay ve katılaşmak üzere olan ince bir iplik çekmek için yavaşça geri çekilir](../images/filament_switch_break_preparation.svg)
![Üçüncü olarak, filament, filamentin kırılmasını sağlamak için daha fazla hızla geri çekilir](../images/filament_switch_break.svg)

**Bu ayar şu anda Cura'nın arayüzünde hiçbir zaman görünmez. Yalnızca profiller tarafından ayarlanabilir. Ayrıca, Cura dilimleme sırasında kullanılmaz. Ancak, Cura'nın malzeme dosyası biçimini anlayan yazıcılar, filament değiştirme prosedürlerini doğru şekilde yapılandırmak için bunu kullanabilirler.** Bir son işleme betiği aracılığıyla, baskıya filament değişimini tetikleyecek olan `M600` komutu eklenir.