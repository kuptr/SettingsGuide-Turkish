İlk Katman İç Duvar Akışı
====
İlk katın akışı [İlk Katman Akışı](material_flow_layer_0.md) ayarı ile değiştirilebilir, ancak bu ayar sadece ilk kat üzerindeki iç duvarların akışını değiştirerek ilk katın daha ince detaylarını kontrol etmeyi sağlar.

İlk katın bazı kısımları diğerlerine göre daha fazla yapışkan bir yapıya sahiptir. Baskının ilk çizgileri en tehlikelileridir. Bu ayar sayesinde iç duvarların akışını artırarak bunları yapıştırmayı ve yapı platformuna daha iyi yapışmasını sağlayabilirsiniz. Bu özellikle iç duvarları dış duvardan önce yazdırırken faydalıdır, çünkü o zaman ilk iç duvar dış duvara ve kenar şeridine yapışmadan önce tek bir, gevşek çizgi olarak yazdırılır.

Sadece iç duvarın akış hızını değiştirerek [Fil Ayağı](../troubleshooting/elephants_foot.md) gibi yüksek akış hızı sorunlarından kaçınılabilir.