Kopma Sıcaklığı
====
Bazı yazıcılar için, bir filament değişikliği için malzeme geri çekildiğinde, malzemenin besleyiciyi düğüm olmadan geçmesi için temiz bir şekilde kırılması gerekir. Bu ayar, filamenti temiz bir şekilde kırmak için prosedürün bir kısmını yapılandırır.

Bu ayar, filamentin koparılmadan önce soğuması gereken sıcaklığı ayarlar. Bu soğutma, ikinci ve üçüncü aşama arasında gerçekleşir (aşağıdaki resimlerde gösterildiği gibi). Amaç, filamentin sertleşmesine izin vermek ve yazıcının onu besleyiciye takılmadan temiz bir şekilde kırmasını sağlamaktır.

![İlk olarak, sızıntıyı durdurmak için malzeme geri çekilir](../images/filament_switch_anti_ooze.svg)
![İkincisi, filament ince bir iplik çekmek için yavaşça geri çekilir ve bu ipliği katılaştırır](../images/filament_switch_break_preparation.svg)
![Üçüncü olarak, filament hızla daha da geri çekilir ve kırılır](../images/filament_switch_break.svg)

**Bu ayar şu anda Cura'nın arayüzünde hiçbir zaman görünmez. Sadece profiller tarafından ayarlanabilir. Ayrıca, Cura dilimleme sırasında kullanılmaz. Ancak, Cura'nın malzeme dosya formatını anlayan yazıcılar, filament değişim prosedürlerini doğru şekilde yapılandırmak için bunu kullanabilirler.** Bir son işleme komut dosyası aracılığıyla, baskıda `M600` komutu eklenerek filament değişikliği tetiklenebilir.