Yapı Levhası Sıcaklığı
====
Bazı yazıcılar ısıtmalı bir baskı tablasına sahiptir. Bu ayar, baskı tablasının ne kadar sıcak olacağını belirler.

Baskı tablasını ısıtmak, malzemenin hafifçe akışkan ve yapışkan olmasını sağlar. Bazı malzemeler donduğunda kristaller oluşturur, bu da malzemenin donmasıyla önemli ölçüde küçülmesine neden olur. Isıtmalı tabla, malzemenin donma sıcaklığının hemen üzerinde tutularak bu küçülmenin önlenmesini ve sıvı plastik yapışkanlığının korunmasını sağlar. Bu, baskının baskı tablasına yapışmasını iyileştirmek için tasarlanmıştır.

Ancak, baskı tablası çok sıcak tutulursa, baskının baskı tablasına temas ettiği yerlerde çok akıcı olur. Bu, malzemenin biraz sarkmasına neden olur ve baskının alt tarafında [Fil ayağı](../troubleshooting/elephants_foot.md) oluşmasına sebep olur. Bu, [İlk Katmanın Yatay Genişlemesi](../shell/xy_offset_layer_0.md) ayarı ile telafi edilebilir, ancak boyutsal doğruluğu etkiler. Baskı tablasının ısıtılması ayrıca, baskı tablasında dinlenen malzeme ile modelde yukarıdaki malzeme arasında bir sıcaklık farkı oluşturur ve yukarıdaki malzeme küçüldüğünde [eğilme](../troubleshooting/warping.md) oluşturur.

Bu ayar 0 dereceye ayarlanmışsa, Cura baskı tablasının sıcaklığını değiştirmek için herhangi bir komut çıkarmaz, bu da bir baskı tablası yoksa donanımı karıştırabilir.

**Malzeme profili içinde baskı tablası sıcaklığını ayarlarsanız, bu, [Varsayılan Yapı Levhası Sıcaklığı](default_material_bed_temperature.md) ayarlar. Normalde Baskı Tablası Sıcaklığı, Varsayılan Baskı Tablası sıcaklığına eşit olacaktır, ancak bazen farklı bir kalite seçmek, baskı tablası sıcaklığında hafif ayarlamalar yapabilir. Bu Baskı Tablası Sıcaklığı ayarı, aslında baskı için kullanılan ayarlamadır.**