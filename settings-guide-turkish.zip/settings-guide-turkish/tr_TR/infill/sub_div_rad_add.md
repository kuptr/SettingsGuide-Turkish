Kübik Alt Bölüm Kalkanı
====
Bu ayar, baskının dayanıklılığını artırmak için Küp Alt Bölme dolgu deseninin iç kısmında biraz daha fazla dolgu azaltmaya başlar.

<!--screenshot {
"image_path": "sub_div_rad_add_small.png",
"models": [
    {
        "script": "cylinder.scad",
        "transformation": ["scale(3)"]
    }
],
"camera_position": [0, 0, 275],
"settings": {
    "infill_sparse_density": 70,
    "infill_pattern": "cubicsubdiv",
    "sub_div_rad_add": 0
},
"layer": 500,
"colours": 32
}-->
<!--screenshot {
"image_path": "sub_div_rad_add_large.png",
"models": [
    {
        "script": "cylinder.scad",
        "transformation": ["scale(3)"]
    }
],
"camera_position": [0, 0, 275],
"settings": {
    "infill_sparse_density": 70,
    "infill_pattern": "cubicsubdiv",
    "sub_div_rad_add": 5
},
"layer": 500,
"colours": 32
}-->
![Ek Kabuksuz Küp Alt Bölme](../images/sub_div_rad_add_small.png)
![5mm Ek Kabuk](../images/sub_div_rad_add_large.png)

Küp Alt Bölme, sekiz bitişik küp arasındaki sınırları kaldırarak çalışır, eğer küplerin hiçbiri dolgu hacminin sınırına dokunmuyorsa. Bu ayar, sınırları küpler arasından kaldırmaktan kaçınarak bu sınırı daha da içeri taşır.

Fiilen, bu, Küp Alt Bölme deseninin maksimum yoğunluğu daha sık çizmesine neden olur. Bu nesnenin dayanıklılığını artırırken, onu yazdırmak için gereken zaman ve malzeme miktarını artırır. Aşırı durumda, bu ayarı yeterince artırmak, Küp Alt Bölme deseninin basit Küp deseniyle aynı olmasına neden olacaktır.

Ayrıca, bunu negatif bir sayıya ayarlayabilirsiniz. Bu, küpler arasındaki sınırların daha sık kaldırılmasına neden olarak, etkili bir şekilde kenarlarda dolgu miktarını azaltır.