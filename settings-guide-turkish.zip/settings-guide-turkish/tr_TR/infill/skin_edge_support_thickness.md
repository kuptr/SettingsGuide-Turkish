Kaplamanın Kenar Desteği Kalınlığı
====
İçbükey şekiller yazdırılırken, dolgunun ortasında bir yerde sona eren bazı üst cilt olacaktır. Bu ayar, cildin kenarını desteklemek için dolgu içine ek bir çizgi ekler, böylece biraz daha az sarkar.

<!--screenshot {
"image_path": "skin_edge_support_thickness_0.png",
"models": [
    {
        "script": "stamp.scad",
        "transformation": ["scale(0.4)", "translateZ(-2.5)"]
    }
],
"camera_position": [-29, 29, -50],
"settings": {
    "infill_sparse_density": 10,
    "bottom_thickness": 0,
    "skin_edge_support_thickness": 0
},
"colours": 128
}-->
<!--screenshot {
"image_path": "skin_edge_support_thickness.png",
"models": [
    {
        "script": "stamp.scad",
        "transformation": ["scale(0.4)", "translateZ(-2.5)"]
    }
],
"camera_position": [-29, 29, -50],
"settings": {
    "infill_sparse_density": 10,
    "bottom_thickness": 0,
    "skin_edge_support_thickness": 1
},
"colours": 128
}-->
![Cildin kenarı, dolgu tarafından iyi desteklenmez](../images/skin_edge_support_thickness_0.png)
![Cildin kenarı altında dolgu boyunca bir çevre çizilir](../images/skin_edge_support_thickness.png)

Dolgudaki boşluklarda tek bir çizgi sarkmaya neden olabilir, bu nedenle çizgi, desteklenmesi gereken cildin kenarı altında birden fazla katman üzerine çizilebilir. Bu ayar, cildin kenarı altındaki çizginin dikey kalınlığını yapılandırır. Alternatif olarak, bu çizginin çizileceği cildin kenarı altındaki [Kaplamanın Kenar Desteği Katmanları](skin_edge_support_layers.md) doğrudan ayarlayabilirsiniz.

Bu kalınlığın artırılması genellikle baskı üzerinde şu etkilere sahip olacaktır:
* Cildin kenarı daha iyi desteklenecek ve cilt bir kenardan diğerine tamamen köprü kurduğu için daha düzgün bir üst taraf elde edilecektir..
* Yazdırmak biraz daha uzun sürebilir ve daha fazla malzeme kullanacaktır.

Dolgu oranı yüksekse, bu ayarın üst yüzeye neredeyse hiç etkisi olmaz ve dolguda [overextrusion/fazla ekstrüdere](../troubleshooting/overextrusion.md) neden olabilir. Bu durumda en iyi seçenek, 0mm olarak bırakmaktır.