Dolgu Desteği
====
Etkinleştirildiğinde, bu iç dolguyu destek olarak işlemeye başlar. İç dolgu yalnızca üst yüzeyi desteklemek için gerektiği yerde oluşturulacaktır. Modelin boş olduğu ve içinde destek oluşturduğu gibi davranır, ancak bu destek iç dolgu ayarları kullanılarak oluşturulur.

<!--screenshot {
"image_path": "infill_support_enabled_disabled.png",
"models": [{"script": "stamp.scad"}],
"camera_position": [0, 200, 30],
"settings": {
    "wall_line_count": 0,
    "infill_support_enabled": false
},
"colours": 64
}-->
<!--screenshot {
"image_path": "infill_support_angle_low.png",
"models": [{"script": "stamp.scad"}],
"camera_position": [0, 200, 30],
"settings": {
    "wall_line_count": 0,
    "infill_support_enabled": true,
    "infill_support_angle": 40
},
"colours": 64
}-->
![Normal iç dolgu](../images/infill_support_enabled_disabled.png)
![İç dolgu destek etkinleştirildiğinde](../images/infill_support_angle_low.png)

* Bu, çok az görsel maliyetle iç dolguda çok miktarda malzeme tasarrufu sağlar.
* Bu etkinleştirildiğinde, üst yüzeyler biraz daha fazla sarkabilir.
* Ancak, iç dolgunun yatay dayanıklılığı azalabilir. Çoğu durumda, eğer duvarlar dik bir eğime sahipse, duvarların arkasında iç dolgu olmayabilir.