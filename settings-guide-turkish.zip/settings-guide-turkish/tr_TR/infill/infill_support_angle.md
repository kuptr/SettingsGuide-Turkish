Dolum Çıkıntı Açısı
====
İç dolgu desteği kullanırken, bu ayar, desteklenmesi gereken yüzeyin minimum aşma açısını belirler. Bu, normal destek için kullanılan [Destek Çıkıntı Açısı](../support/support_angle.md) ayarına benzer.

<!--screenshot {
"image_path": "infill_support_angle_low.png",
"models": [{"script": "stamp.scad"}],
"camera_position": [0, 200, 30],
"settings": {
    "wall_line_count": 0,
    "infill_support_enabled": true,
    "infill_support_angle": 40
},
"colours": 64
}-->
<!--screenshot {
"image_path": "infill_support_angle_high.png",
"models": [{"script": "stamp.scad"}],
"camera_position": [0, 200, 30],
"settings": {
    "wall_line_count": 0,
    "infill_support_enabled": true,
    "infill_support_angle": 60
},
"colours": 64
}-->
![Düşük bir açı, daha fazla destek sağlar](../images/infill_support_angle_low.png)
![Yüksek bir açı, daha az destek sağlar](../images/infill_support_angle_high.png)

Bu açının artırılması, iç dolgunun üst yüzeyin daha azını desteklemesine neden olur. Bu, baskı süresi ve malzemeden tasarruf sağlar, ancak üst derinin biraz daha sarkmasına neden olur.
* 0° değeri, normal iç dolgu gibi davranır. Her şeyi destekler.
* 90° değeri, tüm iç dolgu malzemesini kaldırır.