Dolgu Çakışma Oranı
====
İç dolgu duvarlarla biraz örtüşüyorsa, duvarlara daha iyi yapışacak ve parçanın çok daha güçlü olmasına neden olacaktır. Bu ayar, iç dolgunun duvarlarla ne kadar örtüştüğünü, iç dolgu çizgi genişliğinin yüzdesi olarak kontrol eder.

![İç dolgu örtüşümü ve silme mesafesinin görselleştirilmesi](../images/infill_overlap.svg)

* Örtüşümü artırmak, iç dolgunun duvarlara daha iyi yapışmasını sağlar ve daha güçlü bir parça elde edilmesini sağlar.
* Ancak, aynı zamanda iç dolgunun duvarlardan daha fazla parlamasına ve baskının yüzeyinde bir desen oluşturmasına neden olur. Bu, görsel yüzey kalitesini azaltır.