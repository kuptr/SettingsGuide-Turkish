Dolgu Poligonlarını Bağla
====
İç dolgular kapalı döngülerden oluştuğunda, bu kapalı döngüler birleştirilerek tek bir döngü oluşturulabilir. Bu seçenek etkinleştirildiğinde, çokgenler bitişik olduğunda küçük bağlantılar yapılır.

Bu ayar yalnızca iç dolgunun bitişik döngülerden oluştuğu durumlarda kullanılabilir. Yani ya:
* [Dolgu Şekli](infill_pattern.md) İç dolgu deseni Çapraz veya 3D Çapraz olarak ayarlanmıştır.
* İç dolgu çizgileri [Dolgu Hattı Çoğaltıcı](infill_multiplier.md) ile çift bir sayıyla çarpılır.
* İç dolgunun etrafında en az 2 [Ekstra Dolgu Duvar Sayısı](infill_wall_line_count.md) bulunmaktadır.

<!--screenshot {
"image_path": "connect_infill_polygons_disabled.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "triangles",
    "infill_multiplier": 2,
    "zig_zaggify_infill": true,
    "connect_infill_polygons": false
},
"colours": 32
}-->
<!--screenshot {
"image_path": "connect_infill_polygons_enabled.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "triangles",
    "infill_multiplier": 2,
    "zig_zaggify_infill": true,
    "connect_infill_polygons": true
},
"colours": 32
}-->
![Çarpılmış iç dolgu çizgileri ile bu iç dolgu deseninde birçok döngü bulunmaktadır](../images/connect_infill_polygons_disabled.png)
![Bu ayar etkinleştirildiğinde döngüler birleştirilir](../images/connect_infill_polygons_enabled.png)

Bu işlevin amacı, seyahat hareketlerini önlemektir. Her bağlı dolgu parçası için nihai çizgi tek bir döngü olacaktır, böylece seyahat hareketleri olmayacaktır. Bu, esnek filamentlerle çalışmayı kolaylaştırır, çünkü bunlar geri çekilmeyi daha zor hale getirir ve nozuldan akarak en iyi sonucu verirler.

Bu döngüleri birleştirmek, iç dolguyu içsel olarak güçlendirebilir. Ancak, çokgenler birleştirildiğinde, baskı kafası genellikle birleşmeden hemen önce 180 derece dönüşler yapar. Bu dönüşler bazen birleşmeyi tamamen engelleyebilir. Bu bazı durumlarda iç dolgunun daha zayıf olmasına neden olabilir. Tümü, döngülerin modelinizin şekli boyunca nasıl eşleştiğine bağlıdır.