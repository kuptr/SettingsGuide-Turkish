Aşamalı Dolgu Basamakları
====
Kademeli dolgu, alt katmanlarda dolgu yoğunluğunu azaltarak, kullanılan dolgu miktarını azaltır. Bu, baskı süresinden ve malzeme kullanımından tasarruf sağlarken, yüzey kalitesini çok fazla azaltmaz. Görsel kalite için baskı yaparken dolgunun temel amacı, üst yüzeyi desteklemektir. Bu özellik, dolguyu sadece bu amaç için odaklar.

Bu ayar, dolgu yoğunluğunun ne kadar adımda azaltılacağını gösterir. Her adımda, dolgu yoğunluğu yarıya düşürülür. Örneğin, %20 dolgu yüzdesiyle başlayarak ve iki kademeli dolgu adımıyla, alt kısımların dolgu yoğunluğu sırasıyla %10 ve %5 olacaktır.

<!--screenshot {
"image_path": "gradual_infill_disabled.png",
"models": [{"script": "curved_top.scad"}],
"camera_position": [0, 137, -62],
"settings": {
    "wall_line_count": 0,
    "bottom_layers": 0,
    "gradual_infill_steps": 0
},
"colours": 16
}-->
<!--screenshot {
"image_path": "gradual_infill_step_height_large.png",
"models": [{"script": "curved_top.scad"}],
"camera_position": [0, 137, -62],
"settings": {
    "wall_line_count": 0,
    "bottom_layers": 0,
    "gradual_infill_steps": 3,
    "gradual_infill_step_height": 5
},
"colours": 16
}-->
![Normal dolgu](../images/gradual_infill_disabled.png)
![3 kademeli dolgu adımı](../images/gradual_infill_step_height_large.png)

**Önerilen Mod'da "Kademeli Dolgu" onay işareti bu ayarı 5 adıma ayarlar ve dolgu yoğunluğunu %90'a yükseltir. Bu, baskınızın üstünde çok yüksek bir yoğunluk (90%) ve baskınızın altında çok düşük bir yoğunluk (2.8%) oluşturur.**