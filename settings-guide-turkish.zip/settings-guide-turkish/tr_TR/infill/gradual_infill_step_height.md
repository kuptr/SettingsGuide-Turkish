Aşamalı Dolgu Basamak Yüksekliği
====
Kademeli dolgu kullanırken, dolgunun yoğunluğu üstten alta doğru birkaç adımda azalır. Her adımda, dolgu yoğunluğu yarıya düşürülür. Bu ayar, bu adımların yüksekliğini belirtir, dolgunun yarıya indirildiği iki nokta arasındaki mesafeyi gösterir.

<!--screenshot {
"image_path": "gradual_infill_step_height_small.png",
"models": [{"script": "curved_top.scad"}],
"camera_position": [0, 137, -62],
"settings": {
    "wall_line_count": 0,
    "bottom_layers": 0,
    "gradual_infill_steps": 3,
    "gradual_infill_step_height": 1.5
},
"colours": 16
}-->
<!--screenshot {
"image_path": "gradual_infill_step_height_large.png",
"models": [{"script": "curved_top.scad"}],
"camera_position": [0, 137, -62],
"settings": {
    "wall_line_count": 0,
    "bottom_layers": 0,
    "gradual_infill_steps": 3,
    "gradual_infill_step_height": 5
},
"colours": 16
}-->
![1.5 mm'lik Kademeli Dolgu Adım Yüksekliği](../images/gradual_infill_step_height_small.png)
![5 mm'lik Kademeli Dolgu Adım Yüksekliği](../images/gradual_infill_step_height_large.png)

Kademeli Dolgu doğası gereği dolgunun bir kısmını havada asar. Ancak bu genellikle otomatik olarak düzelir. İlk dolgu katmanı havada asılı kalır ve baskının yanlarına doğru uygun şekilde bağlanır. Üstüne yerleştirilen katmanlar önceki katmana birazcık dayanabilir, ancak hala ortada sarkar. Bu, katman katman daha iyi hale gelir.

* Düşük dolgu yoğunluğuna hızlı bir şekilde inmek için Kademeli Dolgu Adım Boyutunu azaltın. Bu, baskı süresinden ve malzeme kullanımından tasarruf sağlar.
* Dolgunun, dolgu yoğunluğundaki bir sonraki adımın gerçekleştiği zamana kadar kendini düzeltmek için yeterli alanı almayacağı durumda Kademeli Dolgu Adım Boyutunu artırın. Bu ayarın değerini artırmak, baskının daha güvenilir olmasını sağlar.