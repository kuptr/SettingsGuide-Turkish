Dolgu Sürme Mesafesi
====
Bu ayar, küçük bir seyahat hareketi ile nozulu iç dolgu hattının sonundan biraz daha ileri götürür. Bu küçük seyahat hareketinin amacı, malzemeyi yanındaki duvara silmektedir. Bu, iç dolgu hattını duvara daha iyi bir şekilde birleştirir.

![İç dolgu örtüşme ve silme mesafesinin görselleştirilmesi](../images/infill_overlap.svg)

Bu seyahat hareketi nesneyi daha güçlü hale getirirken, ana dezavantajı bu seyahat hareketinin duvarın içinden geçmesidir, bu da baskının dışındaki görünür bir iz bırakır. Aslında, bu, iç dolgu deseninin kabuğun daha fazla parlamasına neden olur.

Bu sadece iç dolgu hatlarının uçlarına uygulanır. Bağlı iç dolgu hatları kullanıldığında uçlar çok daha az olacaktır.