Dolgu Hattı Mesafesi
====
[Dolgu Yoğunluğu](infill_sparse_density.md) yüzde olarak ayarlamak yerine, bitişik iç dolgu çizgileri arasındaki mesafeyi ayarlayarak iç dolgu yoğunluğunu yapılandırmak da mümkündür. İç dolgu çizgileri arasındaki daha büyük bir mesafe, genel olarak daha düşük bir iç dolgu yoğunluğuna yol açacaktır.

İç Dolgu Çizgi Mesafesi, bu özelliğe farklı bir bakış açısı sunar. İç dolgu çizgileri arasındaki mesafe, üst yüzey çizgilerinin bir iç dolgu çizgisinden diğerine geçmek için kat etmeleri gereken mesafeyi gösterir. İç Dolgu Çizgi Mesafesini azaltmak, köprülenmiş mesafeyi azaltır ve üst yüzeylerin kalitesini artırır.

<!--screenshot {
"image_path": "infill_pattern_grid.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "grid"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "infill_sparse_density_low.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_sparse_density": 10
},
"colours": 64
}-->
![Çizgiler arasına 4 mm mesafe, %20 yoğunlukta sonuçlanır](../images/infill_pattern_grid.png)
![Çizgiler arasına 8 mm mesafe, %10 yoğunlukta sonuçlanır](../images/infill_sparse_density_low.png)

Normalde İç Dolgu Çizgi Mesafesi, istenen iç dolgu yoğunluğundan, seçilen iç dolgu desenine ve çizgi genişliğine bağlı olarak hesaplanır. İç Dolgu Çizgi Mesafesi önceliklidir.

İç dolgu yoğunluğunu artırmak (çizgi mesafesini azaltarak), baskınız üzerinde büyük bir etkiye sahiptir, yani:
* Baskınız daha güçlü olacaktır.
* Üst yüzey daha iyi desteklenecek ve daha pürüzsüz ve daha su geçirmez olacaktır.
* Yastıklanma azalır çünkü ısı bölgeleri daha küçük olacaktır.
* Baskınız daha fazla malzeme gerektirecek ve dolayısıyla daha ağır olacaktır.
* Baskı daha uzun sürecektir.