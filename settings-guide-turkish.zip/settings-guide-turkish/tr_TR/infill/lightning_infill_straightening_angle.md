Yıldırım Dolgu Düzleştirme Açısı
====
Bu ayar, Yıldırım iç dolgu deseninin iç kısımda ne kadar dik şekilde aşırı taşabileceğini belirler.

Yıldırım iç dolgu, baskının üst kısmını desteklemesi gereken yerlerde başlıkta adı geçen yıldırım benzeri zikzak çizgileri üretir, ancak bu çizgilerdeki keskin köşeler nedeniyle uzun süreli yazdırma sürelerine yol açar. Bu yüzden aşağıda, bu kaba çizgileri düzleştirmeye çalışır ve yazdırma süresini azaltmak için. Bu düzleştirme aşırı taşmalara neden olur. Ayar, izin verilen aşırı taşmanın ne kadar olduğunu belirler.

<!--screenshot {
"image_path": "lightning_infill_straightening_angle_40.png",
"models": [
    {
        "script": "cylinder.scad",
        "transformation": ["scaleZ(0.5)"]
    }
],
"camera_position": [36, 44, 19],
"settings": {
    "infill_pattern": "lightning",
    "wall_line_count": 0,
    "top_layers": 0,
    "lightning_infill_support_angle": 40,
    "lightning_infill_prune_angle": 10,
    "lightning_infill_straightening_angle": 40
},
"colours": 32
}-->
<!--screenshot {
"image_path": "lightning_infill_straightening_angle_10.png",
"models": [
    {
        "script": "cylinder.scad",
        "transformation": ["scaleZ(0.5)"]
    }
],
"camera_position": [36, 44, 19],
"settings": {
    "infill_pattern": "lightning",
    "wall_line_count": 0,
    "top_layers": 0,
    "lightning_infill_support_angle": 40,
    "lightning_infill_prune_angle": 10,
    "lightning_infill_straightening_angle": 10
},
"colours": 32
}-->
![40°'de, iç dolgu çizgileri hızla düz çizgilere dönüşür](../images/lightning_infill_straightening_angle_40.png)
![10°'de, iç dolguda artık dik aşırı taşmalar yoktur](../images/lightning_infill_straightening_angle_10.png)

Hızlı düzleştirme (artan aşırı taşma), yazdırma süresini biraz azaltır, ancak özellikle ince çizgi genişliği ile güvenilirliği azaltır. Eğer aşırı taşma çok dikse, bu bir katman bölünmesine neden olur. Bölünme baskının iç kısmında olacaktır ve genellikle bir sorun olmayacaktır, ancak bu kısmın iç dolgunun tamamen başarısız olmasına neden olabilir, bu da üst kısmın bir kısmının desteksiz kalmasına yol açar. Bu daha sonra üstte pürüzlü bir leke veya yastıklanma olarak görülebilir, veya en kötü durumda karışık plastik bir karmaşa olabilir.