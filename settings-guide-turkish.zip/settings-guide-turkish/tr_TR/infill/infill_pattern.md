Dolgu Şekli
====
İç dolgu deseni, nesnenin hacmini doldurmak için kullanılan bir yapıyı tanımlar. Her biri kendi avantajlarına sahip çeşitli desenler mevcuttur. Bazıları çok spesifik uygulamalar için özelleşmiştir.

<!--screenshot {
"image_path": "infill_pattern_grid.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "grid"
},
"colours": 64
}-->
Grid
----
![Izgara](../images/infill_pattern_grid.png)

Izgara iç dolgu deseni, iki dikey çizgi seti oluşturur. Bu, kareler desenini oluşturur.
* Dikey yönde en güçlü desendir.
* Çizgilerin iki yönünde oldukça güçlüdür.
* Diyagonal yönde o kadar güçlü değildir.
* Üst yüzeyi desteklemede çok iyidir. Yüzeyiniz çok düzgün görünecektir.

<!--screenshot {
"image_path": "infill_pattern_lines.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "lines"
},
"colours": 64
}-->
Çizgiler
----
![Çizgiler](../images/infill_pattern_lines.png)

Çizgiler deseni, paralel çizgiler oluşturur. Varsayılan olarak, çizgiler deseni, katmandan katmana dikey olarak yönünü değiştirir, bu da ilk bakışta ızgara desenine benzemenize neden olur. Ancak bu, [Dolgu Hattı Yönleri](infill_angles.md) ayarı ile değiştirilebilir.
<!--if cura_version<4.12:* The best pattern for a smooth top surface together with zigzag, since the distance between the lines is smallest.-->
* Dikey yönde zayıf olma eğilimindedir, çünkü katmanlar sadece küçük bağlanma noktalarına sahiptir.
* Çizgilerin yönlendirildiği bir yön dışında yatay yönde son derece zayıf olacaktır. Ancak o yönde bile kesme/kırılma kuvvetlerine karşı dayanıklı değildir, bu yüzden yük altında oldukça hızlı bir şekilde başarısız olur.

<!--screenshot {
"image_path": "infill_pattern_triangles.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "triangles"
},
"colours": 64
}-->
Üçgenler
----
![Üçgenler](../images/infill_pattern_triangles.png)

Üçgenler deseni, üç farklı yönde üç çizgi seti oluşturur. Bu, birlikte üçgenler desenini oluşturur.
* Kesme/kırılma kuvvetlerine karşı çok dayanıklıdır.
* Yatay her yönde yaklaşık olarak eşit güçtedir.
* Üst çizgiler oldukça uzun köprü kurmak zorunda kalır, düzgün bir üst yüzey elde etmek için birçok üst deri katmanı gerektirir.
* Akış, kesişimlerde önemli ölçüde kesintiye uğrar, bu da yüksek iç dolgu oranlarında nispeten düşük mukavemete yol açar.

<!--screenshot {
"image_path": "infill_pattern_trihexagon.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "trihexagon"
},
"colours": 64
}-->
Üçlü Altıgen
----
![Üçlü Altıgen](../images/infill_pattern_trihexagon.png)

Üçlü Altıgen deseni, üçgenler deseni gibi üç farklı yönde üç çizgi seti oluşturur, ancak hepsi aynı pozisyonda kesişmeyecek şekilde birbirinden offsetlidir.
* Yatay yönde en güçlü desendir.
* Yatay her yönde yaklaşık olarak eşit güçtedir.
* Kesme/kırılma kuvvetlerine karşı çok dayanıklıdır.
* Üst çizgiler çok uzun köprü kurmak zorundadır, düzgün bir üst yüzey elde etmek için birçok üst deri katmanı gerektirir.

<!--screenshot {
"image_path": "infill_pattern_cubic.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "cubic",
    "infill_sparse_density": 19
},
"colours": 64
}-->
Kübik
----
![Kübik](../images/infill_pattern_cubic.png)

Kübik desen, küpler oluşturur ve 3 boyutlu bir desendir. Küpler, köşeleri üzerinde duracak şekilde yönlendirilmiştir, bu da iç yüzeylerde aşırı eğimler olmadan baskıyı mümkün kılar.
* Her yönde, dikey yönde dahil, yaklaşık olarak eşit güçtedir.
* Her yönde oldukça güçlüdür.
* Uzun dikey sıcak hava ceplerini üretmediği için yastıklama etkisi azalır.

<!--screenshot {
"image_path": "infill_pattern_cubic_subdivision.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "cubicsubdiv",
    "infill_sparse_density": 50
},
"layer": 240,
"colours": 64
}-->
Kübik Alt Bölüm
----
![Kübik Alt Bölüm](../images/infill_pattern_cubic_subdivision.png)

Kübik alt bölüm deseni, küpler oluşturur ve 3 boyutlu bir desendir. Küpler, köşeleri üzerinde duracak şekilde yönlendirilmiştir, bu da iç yüzeylerde aşırı eğimler olmadan baskıyı mümkün kılar. Ancak, bu desen, hacmin iç kısımlarına doğru daha büyük küpler üretecek şekilde ayarlanmıştır, bu da malzemeden tasarruf sağlar. İç dolgu çizgilerini en az kullanışlı oldukları yerlerde bırakır.

Bu desen, istenenden daha düşük iç dolgu yoğunlukları üretebilir. Bu deseni kullanırken iç dolgu yoğunluğunu önemli ölçüde artırmak tavsiye edilir. Optimizasyon, yüksek iç dolgu oranlarında en iyi şekilde çalışır.

Algoritmik olarak, bu desen, tüm hacim etrafında büyük bir küp oluşturarak, sonra bu küpü herhangi bir duvara çarptığında 8 alt küpe bölecek şekilde üretilir. Bu işlem tekrarlanır, böylece duvarlara çarpan alt küpler tekrar tekrar bölünür. Bu işlem, iç dolgu çizgi mesafesi ulaşılana kadar tekrarlanır.
* Ağırlık ve baskı süresi açısından en güçlü desendir.
* Her yönde, dikey yönde dahil, yaklaşık olarak eşit güçtedir.
* İnce parçalarda iç dolgu yoğunlaşır.
* Uzun dikey sıcak hava ceplerini üretmediği için yastıklama etkisi azalır.
* Artan iç dolgu yoğunluğu kullanıldığında, iç dolgu duvarlardan pek parlamaz, bu da eşit baskı süresi için daha iyi bir yüzey kalitesi sağlar.
* Geri çekmeler gerektirir, bu da esnek veya akışkan malzemelerle iyi çalışmaz.
* Dilimlemek daha uzun sürer.

<!--screenshot {
"image_path": "infill_pattern_octet.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "tetrahedral",
    "infill_sparse_density": 21
},
"colours": 64
}-->
Octet
----
![Sekizli](../images/infill_pattern_octet.png)

Sekizli desen, düzenli dört yüzlüler ve küplerin bir kombinasyonunu oluşturur, 3 boyutlu bir desendir. Zaman zaman, birden fazla iç dolgu çizgisi birbirine bitişik yerleştirilir.
* Birden fazla paralel çizginin birbirine dokunduğu yerde güçlü bir iç çerçeve oluşturur. Yük, hızla bu iç çerçeveye dağılır.
* Yaklaşık bir santimetre kalınlığa sahip orta kalınlıktaki modellerde güçlüdür.
* Uzun dikey sıcak hava cepleri üretmediği için yastıklama etkisi azalır.
* Üst deri için çok uzun köprü mesafesi ile sonuçlanır, bu da üst yüzey kalitesini düşürür.

<!--screenshot {
"image_path": "infill_pattern_quarter_cubic.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "quarter_cubic",
    "infill_sparse_density": 21
},
"colours": 64
}-->
Çeyrek Kübik
----
![Çeyrek Kübik](../images/infill_pattern_quarter_cubic.png)

Çeyrek kübik desen, dört yüzlüler ve kesilmiş dört yüzlülerden oluşan 3 boyutlu bir tessellation (döşeme) oluşturur. Zaman zaman, birden fazla iç dolgu çizgisi birbirine bitişik yerleştirilir.
* Sekizli desene benzer şekilde, birden fazla paralel çizginin birbirine dokunduğu iki ayrık iç çerçeve oluşturur. Yük, hızla bu iç çerçeveye dağılır. Çerçeveler iki farklı yönde yönlendirilmiştir, bu da onları bireysel olarak daha zayıf yapar ancak yükün bu çerçevelere dağıtılma mesafesini azaltır.
* Birkaç milimetre kalınlığa sahip ince modellerde güçlüdür.
* Uzun dikey sıcak hava cepleri üretmediği için yastıklama etkisi azalır.
* Üst deri için çok uzun köprü mesafesi ile sonuçlanır, bu da üst yüzey kalitesini düşürür.

<!--screenshot {
"image_path": "infill_pattern_concentric.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "concentric"
},
"colours": 64
}-->
Eş merkezli
----
![Eş merkezli](../images/infill_pattern_concentric.png)

Eşmerkezli desen, duvarlara paralel halkalar oluşturur.
* %100 iç dolgu kullanıldığında en güçlü iç dolgu desenidir, çünkü sadece hiçbir çizgi kesişmez, aynı zamanda çizgiler yükü dağıtacak şekilde yönlendirilmiştir.
* Tüm yatay yönlerde çok zayıf ve eşit bir güç ile en esnek baskıları üretir.
* Dikey yönde yatay yönden daha güçlüdür.
* %100 iç dolgu yoğunluğunda, eşmerkezli halkaların bir noktada birleştiği yuvarlak şekilleri basarken malzeme ortada birikebilir, bu da baskının güvenilirliğini azaltır.
* Bazı şekillerde, bazı iç dolgu çizgileri havada asılı kalabilir, malzeme ve baskı süresi maliyeti için ek bir güç sağlamaz.
* %100 iç dolgu kullanılmadığında, bu yatay yönde en zayıf iç dolgu desenidir. Hiçbir güç eklemez.

<!--screenshot {
"image_path": "infill_pattern_zigzag.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "zigzag"
},
"colours": 64
}-->
Zik Zak
----
![Zik Zak](../images/infill_pattern_zigzag.png)

Zik Zak iç dolgu deseni, nozulun zikzak şeklinde çizgiler çizmesini sağlar. Bu, çizgiler gibidir ancak çizgiler, akış kesintilerini önleyen uzun bir çizgi halinde bağlanır.
* %100 iç dolgu kullanıldığında en güçlü ikinci desendir. Ancak, yuvarlak şekillerle eşmerkezli iç dolgudan daha güvenilir baskı yapar.
* Çizgiler arasındaki mesafe en küçük olduğundan, zigzag ile birlikte en düzgün üst yüzey için en iyi desendir.
* Katmanlar sadece küçük bağlanma noktalarına sahip olduğundan dikey yönde oldukça zayıf olma eğilimindedir.
* Çizgilerin yönlendirildiği bir yön dışında yatay yönde son derece zayıf olacaktır. Ancak o yönde bile kesme/kırılma kuvvetlerine karşı dayanıklı değildir, bu yüzden yük altında oldukça hızlı bir şekilde başarısız olur. 

<!--screenshot {
"image_path": "infill_pattern_cross.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "cross"
},
"colours": 64
}-->
Çapraz
----
![Çapraz](../images/infill_pattern_cross.png)

Çapraz iç dolgu deseni, hacmin içinde çarpı şeklinde görünen bir uzay doldurma eğrisi oluşturur.
* Tüm yatay yönlerde eşit şekilde yumuşaktır, bu da bu deseni yumuşak ve esnek nesneler basmak için kullanışlı hale getirir.
* Yatay yönde uzun düz çizgiler üretmez, bu da tüm çevre boyunca eşit şekilde yumuşak olmasını sağlar. Güçlü noktalar yoktur.
* Hiç geri çekme üretmez, bu da esnek malzemelerle baskıyı kolaylaştırır.
* Dikey yönde yatay yönden daha güçlü olacaktır.
* Dilimlemek uzun zaman alır.
* Tüm yatay yönlerde çok zayıf olacaktır.

<!--screenshot {
"image_path": "infill_pattern_cross_3d.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "cross_3d"
},
"colours": 64
}-->
Çapraz 3D
----
![Çapraz 3D](../images/infill_pattern_cross_3d.png)

Çapraz 3D iç dolgu deseni, hacmin içinde çarpı şeklinde görünen bir uzay doldurma eğrisi oluşturur. Bu desen, dikey yönde daha zayıf hale getirmek için Z ekseni boyunca dalgalanır.
* Yatay ve dikey tüm yönlerde yaklaşık olarak eşit şekilde yumuşaktır, bu da bu deseni yumuşak ve esnek nesneler basmak için en kullanışlı desen haline getirir.
* Uzun düz çizgiler üretmez, bu da tüm yüzey boyunca eşit şekilde yumuşak olmasını sağlar.
* Hiç geri çekme üretmez, bu da esnek malzemelerle baskıyı kolaylaştırır.
* Dilimlemek uzun zaman alır.
* Tüm yönlerde çok zayıf olacaktır. 

<!--screenshot {
"image_path": "infill_pattern_gyroid.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "gyroid"
},
"colours": 64
}-->
Gyroid
----
![Gyroid](../images/infill_pattern_gyroid.png)

Gyroid iç dolgu deseni, yönleri değiştiren dalgalı bir desen oluşturur.
* Tamamen sıvı geçişine izin veren bir hacim oluşturur, bu da çözünür malzemeler için kullanışlı bir desen yapar.
* Tüm yönlerde eşit şekilde güçlüdür ancak çok sert değildir. Bu, esnek malzemeler için kullanışlı hale getirir, ancak sonuç, Çapraz (3D) iç dolgu desenlerinden biraz daha sert ve daha az yumuşak olacaktır.
* Bu desende örtüşen çizgiler yoktur, bu da daha yüksek yüzey gerilimine sahip malzemelerle baskıyı daha kolay hale getirir ve iç dolguyu çok güvenilir ve tutarlı yapar.
* Kesme/kırılma kuvvetlerine karşı dayanıklıdır.
* Dilimlemek uzun zaman alır ve büyük G-kod dosyaları üretir. Bazı yazıcılar, saniye başına birçok G-kod komutunu takip etmekte zorlanabilir ve düşük baud hızlarında seri bağlantı üzerinden bu komutları takip etmek zor olabilir.

<!--screenshot {
"image_path": "infill_pattern_lightning.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "lightning"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "infill_pattern_lightning_side.png",
"models": [{"script": "three_cylinders.scad"}],
"camera_position": [148, 23, 126],
"settings": {
    "top_layers": 0,
    "wall_line_count": 0,
    "infill_pattern": "lightning",
    "infill_sparse_density": 30
},
"colours": 32
}-->
<!--if cura_version>=4.12-->
Yıldırım
----
![Yıldırım](../images/infill_pattern_lightning.png)
![Yıldırım deseni, yanlardan yukarı doğru inşa edilir](../images/infill_pattern_lightning_side.png)

Yıldırım iç dolgu deseni, yalnızca üst yüzeyi desteklemeyi amaçlayan düzensiz, minimal bir desendir. Belirtilen iç dolgu yoğunluğu, yalnızca iç dolgu hacminin üst tarafının hemen altında elde edilir.
* Yalnızca yüzeyin altına iç dolgu üreterek büyük miktarda zaman ve malzeme tasarrufu sağlar.
* İç dolgu yoğunluğunu artırmak, daha fazla zaman ve malzeme kullanmadan tüm desenler içinde en iyi üst yüzey kalitesini sağlar.
* Basitçe iç dolgu olmadığından, birçok yerde iç dolgunun duvarlardan parlamasını önler.
* Parçanın dayanıklılığına önemli bir katkıda bulunmaz.

<!--endif-->