Dolgu Ekstruderi
====
Bu ayar, iç dolgu malzemesini basmak için hangi ekstruderin kullanılacağını belirler. Bu ayar yalnızca birden fazla ekstruderi olan yazıcılar için kullanılabilir.

<!--screenshot {
"image_path": "infill_extruder_nr.png",
"models": [
    {
        "script": "gear.scad",
        "object_settings": {"extruder_nr": 3}
    }
],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_extruder_nr": 1
},
"colour_scheme": "material_colour",
"colours": 32
}-->
![Modelin kabuğu gümüş malzeme ile basılacak, ancak iç dolgu mavi malzeme ile basılacak](../images/infill_extruder_nr.png)

Yazıcınız her bir ekstruder takımı için farklı bir nozul kullanabiliyorsa, iç dolguyu daha büyük bir nozul boyutuyla basmak, baskı hızını ve dayanıklılığı artırırken kabuğun görsel kalitesini engellemeden sağlar.