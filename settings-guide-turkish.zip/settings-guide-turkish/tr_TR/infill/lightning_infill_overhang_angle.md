Yıldırım Dolgu Çıkıntı Açısı
====
Yıldırım iç dolgu, modelin iç kısmından sadece dışa taşan kısmın üst tarafını destekleyecektir. Bu ayar, modelin iç kısmından yıldırım tarafından iç kısımdan desteklenen aşma açısını belirler.

<!--screenshot {
"image_path": "lightning_infill_support_angle_30.png",
"models": [{"script": "half_sphere.scad"}],
"camera_position": [130, 87, 47],
"settings": {
    "infill_pattern": "lightning",
    "wall_line_count": 0,
    "top_layers": 0,
    "lightning_infill_support_angle": 30
},
"colours": 64
}-->
<!--screenshot {
"image_path": "lightning_infill_overhang_angle_70.png",
"models": [{"script": "half_sphere.scad"}],
"camera_position": [130, 87, 47],
"settings": {
    "infill_pattern": "lightning",
    "wall_line_count": 0,
    "top_layers": 0,
    "lightning_infill_support_angle": 30,
    "lightning_infill_overhang_angle": 70
},
"colours": 64
}-->
![30°'ye kadar olan aşma desteklenmemiştir](../images/lightning_infill_support_angle_30.png)
![70°'ye kadar desteklenmemiş olup, yalnızca kürenin çok üstü desteklenmiştir](../images/lightning_infill_overhang_angle_70.png)

Bu açıyı artırmak, oluşturulan iç dolgu miktarını azaltacaktır. Eğer çok dik bir aşma değilse, daha az üst yüzey desteklenecektir. Bu, zaman ve malzeme tasarrufu sağlar, ancak bazı yerlerde üst yüzeyin sarkmasına neden olabilir. Sonuç olarak, [yastıklanma](../troubleshooting/pillowing.md) veya genel olarak daha pürüzlü bir yüzey olabilir.

Ana ayar olan [Yıldırım Dolgu Destek Açısı](lightning_infill_support_angle.md)'nın aksine, bu ayar iç dolgu desenindeki aşma üzerinde etkili değildir.