Dolgu Hatlarını Bağlayın
====
Bu ayar, dolgunun duvarla veya dış kabukla buluştuğu yerlerde, dolgunun alan kenarını takip eden bir hat kullanarak dolgunun uçlarını birleştirir.

<!--screenshot {
"image_path": "infill_pattern_grid.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "grid"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "zig_zaggify_infill_enabled.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "grid",
    "zig_zaggify_infill": true
},
"colours": 64
}-->
![Bağlı dolgu hatları olmadan](../images/infill_pattern_grid.png)
![Bağlı dolgu hatları](../images/zig_zaggify_infill_enabled.png)

Bu, tüm dolgu desenini tek bir veya çok az hat haline getirir. Bunun tek bir hat haline getirilmesi her zaman mümkün olmayabilir. Bu hatın başlangıç noktası keyfidir, bu yüzden her kat için aynı olmayabilir, özellikle de dolgunun içerisinde bulunduğu şekil katmanlardan katmanlara farklı olduğunda.

Dolgunun birleştirilmesinin bazı faydaları, ancak bazı dezavantajları da vardır:
* Parçanız sonunda daha güçlü olacaktır, çünkü pratik olarak yarım bir çevre ekstra olacaktır.
* Yüzey alanının artması nedeniyle, dolgu duvarlara daha iyi yapışır, bu da parçayı daha güçlü hale getirir.
* Akış hızı daha sabit tutulacak, böylece dolgu malzemesini sorunsuz bir şekilde daha büyük hızda yazdırabilirsiniz. Bu özellikle uygun şekilde ekstrüde edilmesi zor malzemeler için önemlidir.
* Dolgunun yazdırılması sırasında önemli ölçüde daha az geri çekilme yapılacaktır, bu da malzemenin öğütülmesini engeller.
* Dolgunun [Dolgu Çakışma Oranı](infill_overlap.md) ayarının etkisi artar, çünkü dolgu hatlarının daha büyük bir kısmı duvarlarla çakışacak şekilde yapılır.
* Dolgunun yazdırılması daha fazla malzeme gerektirecektir.
* Genellikle dolgunun yazdırılması daha uzun sürecektir, çünkü seyahat hareketleri genellikle dolgu hatlarından daha hızlıdır.
* Dolgu genellikle duvarlardan daha fazla parlayacaktır, çünkü daha büyük bir kısmı duvarlara itilir.