Yıldırım Dolgu Destek Açısı
====
Yıldırım iç dolgu deseni, baskıyı sadece iç kısımdan desteklemek için tasarlanmıştır. Bu ayar, sadece destekleyeceği yüzeylerin maksimum aşma açısını belirlemez, aynı zamanda iç dolgunun kendisi içindeki içsel aşma açısını da belirler. Bu ayarı düşürmek, daha fazla iç dolgu oluşturur. Arttırmak ise iç dolgu miktarını azaltır.

Desen, baskının üst tarafını iç kısımdan destekler, ancak sadece bu açıdan daha fazla olan önemli ölçüde taşan üst tarafı. Desen ayrıca, dallanma ağacı yapısını oluşturmak için belirli bir açıda taşan uç noktalara sahiptir ve bu dallanma yapısının yanları belirli bölgelere daha fazla ulaşmak için bir iç açıya sahiptir. Taşmanın bu üç yönü de sırasıyla [Yıldırım Dolgu Çıkıntı Açısı](lightning_infill_overhang_angle.md), [Yıldırım Dolgu Budama Açısı](lightning_infill_prune_angle.md) ve [Yıldırım Dolgu Düzleştirme Açısı](lightning_infill_straightening_angle.md) ayarları ile ayrı ayrı kontrol edilebilir.

<!--screenshot {
"image_path": "lightning_infill_support_angle_30.png",
"models": [{"script": "half_sphere.scad"}],
"camera_position": [130, 87, 47],
"settings": {
    "infill_pattern": "lightning",
    "wall_line_count": 0,
    "top_layers": 0,
    "lightning_infill_support_angle": 30
},
"colours": 64
}-->
<!--screenshot {
"image_path": "lightning_infill_support_angle_60.png",
"models": [{"script": "half_sphere.scad"}],
"camera_position": [130, 87, 47],
"settings": {
    "infill_pattern": "lightning",
    "wall_line_count": 0,
    "top_layers": 0,
    "lightning_infill_support_angle": 60
},
"colours": 64
}-->
![Düşük bir taşma açısıyla, çok fazla destek gereklidir](../images/lightning_infill_support_angle_30.png)
![Yüksek bir taşma açısıyla, dik taşmalar izin verilird](../images/lightning_infill_support_angle_60.png)

Bu ayarı artırmak, gereken malzeme miktarını büyük ölçüde azaltacak ve yazdırma süresini azaltacaktır. Ancak bu sarkmaya neden olacaktır. Bu sarkma, modelin iç kısmındadır, bu nedenle hemen görülmez. Ancak [Üst Kalınlık](../top_bottom/top_thickness.md) yeterli değilse, [yastıklanma](../troubleshooting/pillowing.md)ya neden olabilir. İç dolgudaki iç açılar daha fazla taşmaya izin verildiğinden, iç dolgunun duvarlara daha yüksekte başlaması muhtemeldir.