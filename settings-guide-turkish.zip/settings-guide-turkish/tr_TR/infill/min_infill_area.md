Minimum Dolgu Alanı
====
Bu ayar, çok küçük parçaların dolgu deseni yerine cilt deseni ile doldurulmasına neden olur, böylece tamamen katı hale gelirler.

<!--screenshot {
"image_path": "min_infill_area_disabled.png",
"models": [{"script": "stature.scad"}],
"camera_position": [-64, 224, 82],
"settings": {
    "wall_line_count": 0,
    "min_infill_area": 0
},
"colours": 32
}-->
<!--screenshot {
"image_path": "min_infill_area_150.png",
"models": [{"script": "stature.scad"}],
"camera_position": [-64, 224, 82],
"settings": {
    "wall_line_count": 0,
    "min_infill_area": 150
},
"colours": 32
}-->
![0 olarak ayarlandığında, bu modelin ince ayakları dolgu ile dolar](../images/min_infill_area_disabled.png)
![150 olarak ayarlandığında, ayaklar cilt ile dolu olur](../images/min_infill_area_150.png)

Bazen, çok küçük boş alanlar doğru şekilde dolgu ile doldurulamaz, çünkü dolgu çizgileri o kadar kısa olur ki malzeme düzgün bir şekilde akamaz. Bu ayar, bunların cilt ile doldurulmasına neden olur, böylece daha güçlü hale gelirler ve cilt ile dolgu arasında bir sınırın oluşmasını önler.

Bu ayarı 0 olarak ayarlamak bu özelliği etkisiz hale getirir.