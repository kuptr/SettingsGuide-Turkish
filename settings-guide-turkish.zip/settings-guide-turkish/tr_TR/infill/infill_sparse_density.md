Dolgu Yoğunluğu
====
Bu ayar, baskı içindeki hacmin yoğunluğunu yapılandırır ve bu, son baskının gücü ve üst yüzey kalitesi üzerinde büyük bir faktördür. İç dolgu yoğunluğu ne kadar büyükse, iç dolgu çizgileri o kadar yakın yerleştirilir. %100'ün üzerinde yoğunluğa bile çıkabilirsiniz, ancak bu aşırı ekstrüzyona neden olur.

<!--screenshot {
"image_path": "infill_pattern_grid.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "grid"
},
"colours": 64
}-->
<!--screenshot {
"image_path": "infill_sparse_density_low.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_sparse_density": 10
},
"colours": 64
}-->
![20% Yoğunluk](../images/infill_pattern_grid.png)
![10% Yoğunluk](../images/infill_sparse_density_low.png)

Farklı yoğunluklar, farklı iç dolgu desenleri ile daha iyi çalışır. Birçok köşeye ve kesişime sahip iç dolgu desenleri, yüksek iç dolgu yoğunluklarında iyi çalışmaz. Köşeler, filament köşede sürüklendiğinden ve malzemenin yerleştirilmesi gereken köşenin dış kısmında hava cepleri oluşturduğundan sorun yaratır. Kesişimler daha da büyük bir sorundur, çünkü bir çizgi başka bir çizgiyi kestiğinde akışı kesilir ve bu da kesişim sonrasında yetersiz ekstrüzyona neden olur.

İç dolgu yoğunluğunu artırmak (çizgi mesafesini azaltarak), baskınız üzerinde büyük bir etkiye sahiptir, yani:
* Baskınız daha güçlü olacaktır.
* Üst yüzey daha iyi desteklenecek, daha pürüzsüz ve su geçirmez hale gelecektir.
* Yastıklanma azalır, çünkü ısı cepleri daha küçük olacaktır.
* Baskınız daha fazla malzeme gerektirecek ve bu nedenle daha ağır olacaktır.
* Baskı daha uzun sürecektir.