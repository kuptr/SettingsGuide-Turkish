Rastgele Boşluk Doldurma Başlat
====
Bu ayar etkinleştirildiğinde, yazıcının bir katmandaki iç dolguyu basmaya başlayacağı yer rastgele hale getirilir.

İç dolgu izinin başlangıcı, genellikle iç dolgunun geri kalanından biraz daha zayıftır. Bu, iç dolgu daha hızlı basıldığında, daha kalın çizgilerle veya daha büyük katman yüksekliğiyle olduğunda meydana gelir. Malzeme akışı aniden hızlanmak zorunda kaldığında, bu hemen gerçekleşmez, bu yüzden kısa bir süre için yetersiz ekstrüzyon olur. Bu, her katmanda aynı konumda gerçekleşirse, iç dolgu yapısını zayıflatır. Bu durumun gerçekleştiği yer en zayıf halka olacak ve çevresindeki iç dolgu daha fazla zorlanmaya maruz kalacaktır. Baskı bir kuvvete maruz kaldığında, kırılma olasılığı en yüksek yer burasıdır.

Normalde, iç dolgu, nozülün iç dolguyu başlattığında bulunduğu yere en yakın çizgi ile başlar, böylece seyahat süresi azaltılır. Bu ayar etkinleştirildiğinde, bu başlangıç konumu yerine rastgele hale getirilir. Bu, zayıf noktaların yayılmasını sağlar. Zincirde tek bir en zayıf halka olmayacak ve sonuç olarak iç dolgu daha güçlü olacaktır.

Ancak, bu durum seyahat süresini biraz artırır ve modelin içinde daha fazla sızıntıya yol açar, çünkü iç dolgunun başlangıç konumuna olan mesafe artık en aza indirilmemiştir.

**Başlangıç konumu rastgele yayılırken, yine de deterministiktir. Aynı dilimleme işlemi iki kez tekrarlandığında, aynı başlangıç konumları elde edilmelidir.**