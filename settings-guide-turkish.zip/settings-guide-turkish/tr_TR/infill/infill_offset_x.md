Dolgu X Kayması
====
Normalde iç dolgu desenleri, 3B modelin merkezine odaklanır. Bu ayar, [Dolgu Y Kayması](infill_offset_y.md) ile birlikte desenin merkezini kaydırmaya izin verir. Bu ayar, merkezin X koordinatını ayarlar.

<!--screenshot {
"image_path": "infill_offset_xy_0.png",
"models": [
    {
        "script": "hexagonal_prism.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 0, 90],
"settings": {
    "top_layers": 0,
    "infill_pattern": "triangles",
    "infill_offset_x": 0
},
"colours": 64
}-->
<!--screenshot {
"image_path": "infill_offset_x_2.png",
"models": [
    {
        "script": "hexagonal_prism.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 0, 90],
"settings": {
    "top_layers": 0,
    "infill_pattern": "triangles",
    "infill_offset_x": 2
},
"colours": 64
}-->
![İç dolgu merkezlenmiş](../images/infill_offset_xy_0.png)
![Sağa 2mm kaydırılmış hali](../images/infill_offset_x_2.png)

Düşük iç dolgu yoğunluğuyla baskı yaparken, bu ayarı kullanarak iç dolgu çizgilerinin bireysel olarak gücün en çok gerektiği yerde konumlandırılmasını sağlayabilirsiniz.