Dolgu Katmanı Kalınlığı
====
İç dolgunun katman yüksekliği, görsel kalite için önemli olmadığından, baskı süresini azaltmak için daha kalın katmanlar kullanabilirsiniz. Bu ayar, iç dolgu katmanlarının birleştirilmesini sağlar, iç dolgu katmanları birbirinin tam üstünde olduğu sürece. Bu durumda, bazı katmanlarda iç dolgu yazdırılmaz, ancak birleştirilen katmanların en yükseğinde daha fazla malzeme ekstrüzyonu yapılır.

Katman görünümünde, iç dolgu çizgileri çok daha genişmiş gibi görünecektir. Aslında yazdırıldığında, iç dolgu çizgileri yatay olarak yayılmak yerine daha fazla aşağı düşecektir.

<!--screenshot {
"image_path": "infill_sparse_thickness.png",
"models": [{"script": "cooking_utensil_hook.scad"}],
"camera_position": [6, 51, 27],
"camera_lookat": [0, 0, 7],
"settings": {
    "layer_height": 0.2,
    "wall_line_count": 0,
    "infill_pattern": "zigzag",
    "infill_sparse_thickness": 0.6
},
"layer": 19,
"colours": 64
}-->
![İç Dolgu Katman Kalınlığı, katman yüksekliğinin üç katı olarak ayarlanmıştır](../images/infill_sparse_thickness.png)

İç dolgu katman kalınlığı, normal katman yüksekliğinin katları olmalıdır. Eğer değilse, en yakın katman yüksekliğine yuvarlanacaktır.

* Bu ayarı çok fazla artırmamaya dikkat edin. İç dolguya geçerken ve iç dolgudan çıkarken, nozuldan geçen akış hızının önemli ölçüde hızlanması ve yavaşlaması gerekir. Bu durumda biraz gecikme olur, bu yüzden iç dolgu başında çok az ve sonunda çok fazla ekstrüzyon olacaktır
* Ara katmanlarda, çevresindeki katmanlarda iç dolgu olmadığı durumlarda daha düşük katman kalınlığı ile iç dolgu yazdırılmaya devam eder. Bu, eğimli duvarların yanında küçük iç dolgu çizgilerinin yazdırılmasına neden olabilir.