Duvarlardan Önce Dolgu
====
Bu, baskı sırasını etkiler. Bu ayar etkinleştirildiğinde, bir parçanın dolgu kısmı, o katmandaki duvarların üzerine basılmadan önce basılır.

<!--screenshot {
"image_path": "infill_before_walls_disabled.gif",
"models": [
    {
        "script": "cube.scad",
        "transformation": ["scale(0.25)"]
    }
],
"camera_position": [0, 0, 100],
"settings": {
    "top_layers": 0,
    "infill_before_walls": false
},
"layer": 162,
"line": [0, 1, 2, 3, 4, 7, 8, 9, 10, 12, 15, 18, 21, 24, 27],
"colours": 32,
"delay": 250
}-->
<!--screenshot {
"image_path": "infill_before_walls_enabled.gif",
"models": [
    {
        "script": "cube.scad",
        "transformation": ["scale(0.25)"]
    }
],
"camera_position": [0, 0, 100],
"settings": {
    "top_layers": 0,
    "infill_before_walls": true
},
"layer": 162,
"line": [0, 1, 4, 7, 10, 13, 16, 20, 21, 22, 23, 26, 27, 28, 29],
"colours": 32,
"delay": 250
}-->
![Ayar devre dışı bırakıldığı için duvarlar önce basılır](../images/infill_before_walls_disabled.gif)
![Ayar etkinleştirildiği için dolgu önce basılır](../images/infill_before_walls_enabled.gif)

Bu ayar, doğruluk ve dayanıklılık arasında bir denge sağlar:
* Duvarlar dolgudan önce basılırsa, duvarların bağlanacak hiçbir şeyi olmayabilir, bu da daha fazla sarkmalarına neden olabilir. Ancak, duvarlar önce katılaşacak ve dolgu tarafından itilmeyeceklerdir, bu da dolgunun duvarlardan sızmasını önler.
* Dolgu, duvarlardan önce basılırsa, duvarlar, dolgu duvarlara bağlı olduğu yerlerde itilecek, bu da duvarları daha az doğru hale getirir ve dolgunun yüzeye sızmasına ve dışarıdan görülebilen bir desen oluşturmasına neden olabilir. Ancak, dolgu, duvarlar basılırken duvarları daha iyi bir şekilde tutacaktır.