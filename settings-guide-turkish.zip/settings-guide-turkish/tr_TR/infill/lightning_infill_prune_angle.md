Yıldırım Dolgu Budama Açısı
====
Yıldırım iç dolgu deseni, baskının iç kısmında ağaç benzeri bir yapı oluşturur; küçük başlar ancak iç kısımdan desteklenmesi gereken baskının tüm parçalarına ulaşmak için dallanır. Bu ayar, ağacın dallarının uç noktalarında ne kadar ileriye taşınabileceğini gösterir.

<!--screenshot {
"image_path": "lightning_infill_prune_angle_40.png",
"models": [{"script": "half_sphere.scad"}],
"camera_position": [112, 15, 9],
"settings": {
    "infill_pattern": "lightning",
    "wall_line_count": 0,
    "top_layers": 0,
    "lightning_infill_support_angle": 40,
    "lightning_infill_prune_angle": 40
},
"colours": 32
}-->
<!--screenshot {
"image_path": "lightning_infill_prune_angle_70.png",
"models": [{"script": "half_sphere.scad"}],
"camera_position": [112, 15, 9],
"settings": {
    "infill_pattern": "lightning",
    "wall_line_count": 0,
    "top_layers": 0,
    "lightning_infill_support_angle": 40,
    "lightning_infill_prune_angle": 70
},
"colours": 32
}-->
![40°'de Yıldırım iç dolgu oldukça kararlıdır](../images/lightning_infill_prune_angle_40.png)
![70°'de dallar oldukça dik bir şekilde aşırıya taşar](../images/lightning_infill_prune_angle_70.png)

Budama açısını artırmak, iç dolgunun alt kısımda daha küçük başlamasına rağmen tüm üst yüzeye ulaşmasını sağlar. Birçok durumda, artık alttan başlamasına bile gerek olmayabilir, sadece yanlara tutunabilir. Bu açıyı artırmanın belirgin etkileri şunlardır:

* Baskı süresinde ve malzeme kullanımında azalma.
* Daha düzgün duvarlar, çünkü iç kısımdan duvarlara dokunan iç dolgu miktarı azalır.
* Biraz azalan dayanıklılık.
* Baskı başarısızlığı olasılığı artar. Eğer aşırıya taşma çok dikse, her bir çizginin sonunda önemli bir aşırı taşma olacaktır, bu da sarkabilir ve gevşeyebilir.

Uygulamada, budama açısı normal aşırıya taşma açılarından veya diğer Yıldırım iç dolgu aşırıya taşma açılarından daha yüksek olabilir. Çünkü çizgiler alttaki katmanda iyi desteklendiği için, biraz daha fazla aşırı taşma gerçekten bir sorun oluşturmaz.