Dolgu Hattı Yönleri
====
Dolgu çizgileri genellikle mümkün olduğunca 45 derece bir açıyla yönlendirilir. Bu açıda, hem X hem de Y motoru, yaygın Cartesian kiriş mekanizması olan bir yazıcıda, baskı kafasının maksimum ivmesini elde etmek için birlikte çalışır.

Bu ayarla, bu açıyı ayarlayabilirsiniz. Özel bir modeliniz için daha büyük bir dayanıklılık oluşturmak veya delta yazıcılar gibi belirli bir kiriş sistemi için daha büyük ivme elde etmek için özelleştirebilirsiniz.

<!--screenshot {
"image_path": "infill_pattern_lines.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "lines"
},
"colours": 32
}-->
<!--screenshot {
"image_path": "infill_angles_0_30.png",
"models": [{"script": "hexagonal_prism.scad"}],
"camera_position": [0, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_pattern": "lines",
    "infill_angles": [0, 30]
},
"colours": 32
}-->
![Varsayılan açıları olan 45 ve 135 derece ile dolgu çizgileri](../images/infill_pattern_lines.png)
![Özel açılar olan 0 ve 30 derece ile dolgu çizgileri](../images/infill_angles_0_30.png)

Bu ayarın değeri, parantez içindeki bir açı listesi olmalıdır. 0 derecelik bir açı, bir çizgiyi Y eksenine paralel olarak sonuçlandırır. Açı listesi katmanlar üzerinde sırayla uygulanır.
* Nihai baskı, dolgu çizgilerinin yönlerinde en güçlü olacaktır. Baskının belirli bir yönde belirli bir kuvvet taşımasını gerekiyorsa, dolgu çizgilerini o yöne doğru hizalamak faydalı olacaktır.
* Varsayılanı kullanmak için ayarı boş bir liste olarak bırakın.
* Varsayılan, iç dolgu desenine bağlıdır:
  * Çapraz ve Çapraz 3D iç dolgu desenleri için, varsayılan [22]'dir. Bu, çizgileri mümkün olan en fazla şekilde diyagonal hizalamaya çalışır.
  * Çizgi ve Zigzag iç dolgu desenleri için, varsayılan [45,135]'tir. Bu, hizalamanın katman katman iki diyagonal arasında değişmesine neden olur.
  * Diğer tüm desenler varsayılan olarak [45]'i kullanır. Bu, çizgileri mümkün olan en fazla şekilde diyagonal hizalamaya çalışır.