Ekstra Dolgu Duvar Sayısı
====
Bu ayar, iç dolgu alanlarının etrafına bir dizi kontur ekler. Bu, [Duvar Hattı Sayısı](../shell/wall_line_count.md)nı artırmakla benzerdir, ancak konturlar deri etrafına gitmez ve duvarlar deri ile iç dolgu arasında olacaktır. Aynı zamanda [Ek Dış Katman Duvar Sayısı](../top_bottom/skin_outline_count.md)na da benzerdir, ancak deri etrafında değil, iç dolgu etrafında eklenir.

Bu duvarlar, iç dolgu ayarlarıyla yazdırılır.

<!--screenshot {
"image_path": "infill_wall_line_count.png",
"models": [{"script": "hexasphericon.scad"}],
"camera_position": [0, 40, 136],
"settings": {
    "infill_wall_line_count": 2,
    "skin_outline_count": 0
},
"layer": 546,
"colours": 64
}-->
![İç dolgu etrafında iki ek duvar](../images/infill_wall_line_count.png)

Deri etrafında ek duvarlar eklemenin aksine, bu ayar modelin dayanıklılığını büyük ölçüde artırır ve deri üzerinden iç dolgu görünürlüğünü azaltır, ancak baskı süresini ve malzeme kullanımını artırır. Ek deri duvarları, zaten deri olarak yazdırılacak malzemenin yerine geçerken, bu ayar aslında malzeme ekler, eğer iç dolgu yoğunluğu zaten %100 değilse.

Bu, bütün baskının etrafına ekstra duvarlar eklemekle çok benzerdir. Ancak, ya iç dolgu etrafına ya da deri etrafına en az bir ek duvar eklemek iyi bir fikirdir, çünkü bu, deri çizgilerinin havada sona ermesini önler.