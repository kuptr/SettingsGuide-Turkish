Dolgu Hattı Çoğaltıcı
====
Bu ayar arttırıldığında, Cura daha fazla iç dolgu çizgisini doğrudan diğer iç dolgu çizgilerinin yanına yerleştirecektir.

<!--screenshot {
"image_path": "infill_multiplier.png",
"models": [{"script": "gear_knurled.scad"}],
"camera_position": [18, 0, 180],
"settings": {
    "top_layers": 0,
    "infill_multiplier": 3
},
"colours": 32
}-->
![Çarpan 3 olduğunda](../images/infill_multiplier.png)

Bu, iç dolgu yoğunluğunu [Dolgu Yoğunluğu](infill_sparse_density.md) ayarı belirttiğinden daha fazla artırır, ancak iç dolgu çizgilerini düzenli olarak aralıklı yerine, çizgiler doğrudan yan yana yerleştirilir. Sadece iç dolgu yoğunluğunu artırmaktan daha fazla, iç dolgu çünkü iç dolgu çizgileri ek sertlik için birbirlerine yaslanabilir.

Tek sayı çarpanı ayarlandığında, orijinal iç dolgu çizgileri yerinde kalır, ancak ek iç dolgu çizgileri iç dolgu deseninin deliklerinde döngü yapar. Çift sayı çarpanı ayarlandığında, orijinal iç dolgu çizgileri kaldırılır ve döngüler doğrudan yerlerine yerleştirilir.

Aynı çarpanla iç dolgu yoğunluğunu artırmanın alternatifiyle karşılaştırıldığında, bu baskınız üzerinde birkaç etkiye sahip olacaktır.
* İç dolgu genel olarak daha sert hale gelir, çünkü iç dolgu çizgileri kesme kuvvetleriyle karşılaştığında birbirlerine yaslanabilirler, iç dolgu çizgi genişliğini artırmakla benzerdir.
* İç dolgu, cilde daha fazla parlayacak şekilde daha fazla ortaya çıkar, yüzey kalitesini azaltır
* İç dolgu çizgileri arasındaki boşluklar daha büyüktür, çünkü çizgiler daha fazla bir araya toplanmıştır. Bu, cildin daha çok sarkmasına ve yastıklanmaya izin verir.

**Bu ayarın etkisi, iç dolgu yoğunluğu %100 veya daha yüksek olduğunda yoktur.**