Destek Zemin Hattı Yönleri
====
Destek tabanı genellikle üstteki destek ile ve alttaki model ile mümkün olduğunca dik açı yapacak şekilde yönlendirilir. Eğer üst yüzey hatları veya destek hatları özelleştirilmişse, destek tabanı çizgilerinin yönlendirmesini de özelleştirmek iyi bir fikirdir. Bu ayar size destek tabanı çizgi yönlerini özelleştirme imkanı sağlar.

<!--screenshot {
"image_path": "support_interface_angles_0.png",
"models": [
    {
        "script": "plug.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 36, 92],
"settings": {
    "support_enable": true,
    "support_interface_enable": true,
    "support_interface_pattern": "lines",
    "support_interface_angles": [0, 90]
},
"layer": 118,
"colours": 128
}-->
<!--screenshot {
"image_path": "support_interface_angles_45.png",
"models": [
    {
        "script": "plug.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [0, 36, 92],
"settings": {
    "support_enable": true,
    "support_interface_enable": true,
    "support_interface_pattern": "lines",
    "support_interface_angles": [45, 135]
},
"layer": 118,
"colours": 128
}-->
![Her iki yüzey de (taban ve tavan) 0° ve 90° açılı](../images/support_interface_angles_0.png)
![Her iki yüzey de (taban ve tavan) 45° ve 135° açılı](../images/support_interface_angles_45.png)

Bu ayar için birden fazla açı virgülle ayrılarak girilebilir. Cura bu açıları katmanlar boyunca sırayla kullanır.

Destek tabanı çizgileri, ideal olarak üzerlerinde dinlenecek model çizgilerine ve üzerlerinde dinlenecek destek çizgilerine dik olacak şekilde yönlendirilir. Onları dik yönlendirmek, bu çizgilerin köprü kurması gereken mesafeyi azaltır ve bu da sarkmayı azaltır ve desteklerin stabilitesini artırır.