Destek Alt Mesafesi
====
Bu ayar ile desteklerin model üzerinde oturduğu yerde, destek altı ile model arasındaki mesafeyi ayarlayabilirsiniz.

![Koyu mavi "model" ile, açık mavi "destek" arasındaki alt mesafe](../images/support_top_bottom_distance.svg)

Eğer destek sadece modelin üzerine basılırsa, çok sıkı yapışabilirler. Biraz mesafe bırakmak daha iyidir. Bu şekilde destekleri kırmak daha kolay olur ve baskınızda daha az iz bırakır. Ancak mesafeyi çok fazla artırmak desteklerin stabilitesini azaltabilir.

Eğer destek malzemeniz çözünebilir ise, bu mesafe çok düşük bırakılabilir. O zaman onu kırmak veya iz bırakmakla hiçbir sıkıntı yaşanmaz.