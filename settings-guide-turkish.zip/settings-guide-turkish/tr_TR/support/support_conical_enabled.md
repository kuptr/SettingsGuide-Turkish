Konik Desteği Etkinleştir
====
Bu ayar etkinleştirildiğinde, destek yapıları artık yan tarafları tamamen dikey olmayacak şekilde oluşturulur. Destek alt kısmına doğru konik bir şekil alacak, ya daha küçük ya da daha büyük olacaktır.

<!--screenshot {
"image_path": "support_conical_enabled.png",
"models": [
    {
        "script": "wide_overhang.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [91, -95, 19],
"settings": {
    "support_enable": true,
    "support_conical_enabled": true,
    "support_conical_angle": 30
},
"colours": 64
}-->
<!--screenshot {
"image_path": "support_conical_angle_neg10.png",
"models": [
    {
        "script": "wide_overhang.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [91, -95, 19],
"settings": {
    "support_enable": true,
    "support_conical_enabled": true,
    "support_conical_angle": -10
},
"colours": 64
}-->
![Destek alt kısmına doğru küçülür](../images/support_conical_enabled.png)
![Destek alt kısmına doğru büyür](../images/support_conical_angle_neg10.png)

Destek kendisi belirli bir [Konik Destek Açısı](support_conical_angle.md) ile eğilecektir. Negatif açılarla, destek alt kısmına doğru genişleyecek ve bu destekleri önemli ölçüde daha stabil hale getirecektir. Pozitif açılarla ise destek alt kısmına doğru küçülecek ve bu destek malzeme ve baskı süresinden büyük ölçüde tasarruf sağlar. Desteklerin stabilitesini korumak için destek için bir [Koni Desteğinin Minimum Genişliği](support_conical_min_width.md) de tanımlanabilir.

Konik destek, baskı süresi ile destek stabilitesi arasındaki en önemli denge parametresidir. Konik destek için iki ana kullanım alanı vardır:
* Malzeme ve baskı süresinden tasarruf etmek. Konik destek, özellikle büyük ve uzun baskılarda büyük miktarlarda destek malzemesi tasarrufu sağlayabilir ve bu sayede baskı süresinin yarısından fazlasını kısaltabilir.
* Negatif açı kullanarak destekleri daha stabil hale getirmek. Eğer baskınızın yukarılarda desteklenmesi gereken çok küçük özellikleri varsa, normalde bu desteklenmesi gereken çok uzun [Direkler](support_use_towers.md) oluşturur ve baskı sırasında devrilmeye meyillidir. Konik destek ile bu uzun, ince destek yapıları alt kısımlarda daha geniş hale getirilebilir, bu da ek stabilite sağlar. Ancak bu destekleri yazdırmak daha uzun sürecektir çünkü daha fazla malzeme gerektirir.

Eğer [Destek Yerleştirme](support_type.md) yalnızca inşa tabanına destek yerleştirmek olarak ayarlandığında, konik destek modelin diğer kısımlarının üzerinde bulunan yerlerde de modeli desteklemeyi sağlayabilir. Destek hala sadece inşa tabanına dayanacak olsa da, şekli sayesinde köşelerdeki aşağıya sarkan bölgelere ulaşabilir.

Bu özellik, [Ağaç Destek Yapısı](support_structure.md)'nın biraz daha basit ve aşırı olmayan bir versiyonudur. Ağaç destek, konik destekle aynı avantajlara sahiptir. Ancak Ağaç Destek, tamamen farklı bir algoritma kullanır ve destek yapılarının nasıl oluşturulacağı konusunda daha fazla özgürlüğe sahiptir, konik destek ise genellikle standart destek oluşturma algoritmasına daha sadık kalır. Bu nedenle, konik destekle kullanılan standart destek ayarlarının daha iyi çalışma eğiliminde olduğu, ağaç destek için ise ayarların önemli ölçüde ayarlanması gerektiği unutulmamalıdır. Ağaç destek, daha fazla malzeme ve baskı süresinden tasarruf sağlar ve baskı güvenilirliğini korur.