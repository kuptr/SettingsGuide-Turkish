Destek Kenar Hattı Sayısı
====
Bu ayar, destek kenarı için destek alanı içine çizilecek kontur sayısını ayarlar. Daha fazla çizgi ile kenar daha geniş olacaktır.

<!--screenshot {
"image_path": "support_brim_2mm.png",
"models": [{"script": "gazebo2.scad"}],
"camera_position": [-74, 38, -137],
"settings": {
    "support_enable": true,
    "support_use_towers": false,
    "support_brim_enable": true,
    "support_brim_width": 2
},
"colours": 64
}-->
<!--screenshot {
"image_path": "support_brim_4mm.png",
"models": [{"script": "gazebo2.scad"}],
"camera_position": [-74, 38, -137],
"settings": {
    "support_enable": true,
    "support_use_towers": false,
    "support_brim_enable": true,
    "support_brim_width": 4
},
"colours": 64
}-->
![5 kenar çizgisi](../images/support_brim_2mm.png)
![10 kenar çizgisi](../images/support_brim_4mm.png)

Daha fazla kenar çizgisi, desteklerin inşa tabanına yapışmasını artırır ve desteklerin sarkmasını azaltır. Sonuç olarak, destek daha sağlam duracak ve baskının güvenilirliği artacaktır.