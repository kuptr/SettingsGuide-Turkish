Koni Desteğinin Minimum Genişliği
====
Eğer konik destek etkinleştirilmiş ve destek yapısının daraltılmasına ayarlanmışsa, bu ayar destek yapısının konik destek tarafından daraltılacağı minimum genişliği belirler. Destek, üzerinde desteklenmesi gereken dışbükey alan zaten daha ince değilse daha da incelmez.

<!--screenshot {
"image_path": "support_conical_enabled.png",
"models": [
    {
        "script": "wide_overhang.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [91, -95, 19],
"settings": {
    "support_enable": true,
    "support_conical_enabled": true,
    "support_conical_angle": 30
},
"colours": 64
}-->
<!--screenshot {
"image_path": "support_conical_min_width_20.png",
"models": [
    {
        "script": "wide_overhang.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [91, -95, 19],
"settings": {
    "support_enable": true,
    "support_conical_enabled": true,
    "support_conical_angle": 30,
    "support_conical_min_width": 15
},
"colours": 64
}-->
![Minimum genişlik 5 mm'dir](../images/support_conical_enabled.png)
![Minimum genişlik 15 mm'dir](../images/support_conical_min_width_20.png)

Eğer çok miktarda destek, çok küçük bir destek sütununda dinleniyorsa, bu destek çok kolay devrilebilir. Minimum genişliği artırmak, koninin yerçekimini yapacağı destek sütununun taban genişliğini artırır. Bu, baskının güvenilirliğini artırır ancak ekstra malzeme maliyetine neden olur. Sonuç olarak, konik destek baskı süresini azaltmada daha az etkili olacaktır.