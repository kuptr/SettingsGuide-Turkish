Destek Zemini Ekstrüderi
====
Eğer yazıcınızda birden fazla ekstruder varsa, desteklerin model üzerinde oturduğu destekin alt tarafı, modelin destek üzerinde oturduğu tavanından farklı bir ekstruder ile basılabilir. Bu ayar, destek tabanı için hangi ekstruderin kullanılacağını seçmenize olanak tanır.

<!--screenshot {
"image_path": "support_bottom_extruder_nr.png",
"models": [
    {
        "script": "question_stick_clip.scad",
        "transformation": ["rotateY(90)"],
        "object_settings": {"extruder_nr": 1}
    }
],
"camera_position": [134, 134, 113],
"settings": {
    "support_enable": true,
    "support_interface_enable": true,
    "support_use_towers": false,
    "support_extruder_nr": 3,
    "support_bottom_extruder_nr": 2
},
"colour_scheme": "material_colour",
"colours": 64
}-->
![Destek tabanı kırmızı renkte basılırken, destek tavanı beyaz renktedir](../images/support_bottom_extruder_nr.png)

Bazı malzemeler, destek olarak kullanıldıklarında diğer malzemelere göre daha iyi asma özellikleri sağlar. Örneğin, yüzeye kimyasal olarak bağlanmadıkları için daha yakın bir şekilde basılabilirler veya su çözünür olabilirler. Ancak bu tür malzemeler genellikle pahalıdır ve daha uzun sürede basılırlar. Bu ayar, destek tabanını farklı bir ekstruder ile basmanıza olanak tanır. Bu şekilde, pahalı veya yavaş basılan malzemelerden tasarruf edebilirsiniz.

Destek tabanı, asma katlakların kalitesi için destek tavanından daha az önemlidir. Eğer pahalı bir malzeme tasarruflu kullanılacaksa, destek tabanı bu malzeme ile basılmak için uygun bir adaydır.