Destek Zeminini Etkinleştir
====
Destek tabanı, desteklerin model üzerinde oturduğu ara bir yapıdır. Destekleri model üzerinde desteklemek için kullanılır. Destek tabanı, destekler için daha stabil bir taban sağlamak veya destekleri baskıdan daha kolay çıkarılabilir hale getirmek için kullanılabilir, böylece baskınızda daha az iz bırakılır.

<!--screenshot {
"image_path": "support_bottom_enable.png",
"models": [{"script": "f3.scad"}],
"camera_position": [0, 134, 20],
"settings": {
    "support_enable": true,
    "support_bottom_enable": true
},
"colours": 64
}-->
![Destek tabanı, daha koyu bir mavi tonunda renklendirilmiştir](../images/support_bottom_enable.png)

Destek tabanı, daha stabil destek sağlamak veya modelden daha kolay çıkarılabilen farklı bir malzeme kullanarak daha yavaş bir şekilde basılabilir. Bu şekilde, tüm desteklerin bu malzeme veya ayarlarla basılması gerekmez, bu da çok zaman kazandırabilir.

**Destek tabanı, desteklerin baskı tablasında oturduğu yerde oluşturulmaz.**