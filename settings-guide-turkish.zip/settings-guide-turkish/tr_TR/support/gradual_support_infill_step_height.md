Aşamalı Destek Dolgusu Basamak Yüksekliği
====
Kademeli destek kullanılırken, destek yoğunluğu üstten alta doğru periyodik olarak azaltılır ve birkaç adımda halinde yarıya düşürülür. Bu ayar, destek yoğunluğunun yarıya düşürüldüğü iki nokta arasındaki mesafeyi belirtir.

<!--screenshot {
"image_path": "gradual_support_infill_step_height_1mm.png",
"models": [
    {
        "script": "stair.scad",
        "transformation": ["rotateY(-90)", "scaleZ(0.5)"]
    }
],
"camera_position": [49, 91, -38],
"settings": {
    "support_enable": true,
    "support_pattern": "grid",
    "support_wall_count": 0,
    "support_infill_rate": 50,
    "gradual_support_infill_steps": 3,
    "gradual_support_infill_step_height": 1
},
"colours": 64
}-->
<!--screenshot {
"image_path": "gradual_support_infill_step_height_3mm.png",
"models": [
    {
        "script": "stair.scad",
        "transformation": ["rotateY(-90)", "scaleZ(0.5)"]
    }
],
"camera_position": [49, 91, -38],
"settings": {
    "support_enable": true,
    "support_pattern": "grid",
    "support_wall_count": 0,
    "support_infill_rate": 50,
    "gradual_support_infill_steps": 3,
    "gradual_support_infill_step_height": 3
},
"colours": 64
}-->
![1mm adım yüksekliği](../images/gradual_support_infill_step_height_1mm.png)
![3mm adım yüksekliği](../images/gradual_support_infill_step_height_3mm.png)

Kademeli destek doğası gereği bazı destekleri havada asılı bırakır. Ancak bu genellikle otomatik olarak düzelir. Desteklerin ilk katmanı havada asılı kalacak ve sadece yan taraflara uygun şekilde bağlanacaktır. Üstündeki katmanlar bir önceki katmana birazcık temas edebilir ancak ortada sarkabilir. Bu durum katman katman iyileşir. Eğer kademeli destek adım yüksekliği yeterince büyükse, destek bir sonraki yoğunluk adımına kadar sağlam olur.

Kademeli Destek İç Dolgu Adım Yüksekliğini azaltmak, düşük destek yoğunluğuna hızlı bir şekilde inmeyi sağlar. Bu, baskı süresinden ve malzeme kullanımından tasarruf sağlar. Destek, destek yoğunluğunun bir sonraki adımında kendini tamir etmeye yeterli alan bulamazsa Kademeli Destek İç Dolgu Adım Yüksekliğini artırın. Bu ayarın değerini artırmak, baskının daha güvenilir olmasını sağlar.