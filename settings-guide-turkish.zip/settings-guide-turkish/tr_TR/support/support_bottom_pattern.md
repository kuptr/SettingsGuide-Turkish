Destek Zemini Deseni
====
Destek tabanının çizileceği desen, diğer destek kısımlarından farklı olabilir.

Destek tabanı, baskı sırasında desteklerin modelden ayrılmamasını sağlamak için model üzerinde iyi bir köprü oluşturmalıdır, ancak baskı tamamlandığında kolayca çıkarılabilir olmalıdır. Bu amaçla çaprazlama yapmayan desenleri seçmek faydalı olabilir, örneğin konsantrik veya zigzag. Bu desenler yapısal olarak çok güçlü olmasa da, genel destek sağlamlığına fazla etki etmez çünkü sadece destek tabanı etkilenir.