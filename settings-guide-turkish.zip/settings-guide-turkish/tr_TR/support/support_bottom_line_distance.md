Destek Zemini Çizgi Mesafesi
====
Bu ayar, desteklerin model üzerinde oturduğu destek tabanı desenindeki her iki ardışık çizgi arasındaki mesafeyi ayarlar.

Destek tabanındaki çizgiler arasındaki mesafeyi azaltmak, destek ile model arasındaki temas alanını artırarak daha iyi yapışmasını sağlar. Bu destekleri daha stabil hale getirebilir, ancak çıkarmayı da zorlaştırabilir. Kolay çıkarılabilen özel malzemeler, bu özellikten büyük fayda sağlayabilir, örneğin farklı büzülme oranlarına sahip malzemeler veya çözünebilir malzemeler.