Destek Zemini Yatay Büyüme
====
Bu ayar, destek tabanının diğer destek kısımlarına doğru tüm yatay yönlere doğru genişlemesine neden olur.

Bazı malzemeler, düşük akış hızlarında kötü bir şekilde ekstrüde olabilir veya başlamak için biraz zaman gerektirebilir. Destek malzemesinin küçük alanları, bu tür malzemelerle uyumlu olmayabilir. Bu ayar, bu alanları harfiyen daha büyük yaparak bu malzemelerin daha iyi ekstrüde edilmesi için daha fazla alan sağlayabilir.