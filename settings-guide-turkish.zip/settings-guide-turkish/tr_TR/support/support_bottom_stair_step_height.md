Destek Merdiveni Basamak Yüksekliği
====
Eğer [Destek Yerleştirme](support_type.md) "Her Yerde" olarak ayarlanmışsa, destek model üzerinde dinlenmeye izin verilir. Ancak modelin konturlarını tam olarak takip etmez. Bunun yerine, desteklerin alt tarafı merdiven basamağı şeklinde bir desen oluşturur. Bu şekilde, destek sadece modelle birkaç noktada bağlantı yapar.

Bu ayar, bu basamakların yüksekliğini belirler.

<!--screenshot {
"image_path": "support_bottom_stair_step_height.png",
"models": [{"script": "standing_ring.scad"}],
"camera_position": [0, 136, 10],
"camera_lookat": [0, 0, 10],
"settings": {
    "support_enable": true,
    "support_bottom_stair_step_height": 1
},
"colours": 64
}-->
![Destek altında oluşan merdiven basamakları](../images/support_bottom_stair_step_height.png)

Merdiven adım yüksekliği, modelin yüzeyinden olan mesafe olarak hesaplanır. Bu, [Destek Alt Mesafesi](support_bottom_distance.md) ayarında belirtilen dikey mesafe düşüldüğünde model ile destek arasındaki bağlantının artacağı anlamına gelir. Benzer şekilde, [Destek Zeminini Etkinleştir](support_bottom_enable.md) de merdiven basamaklarının etkisini azaltır.

[Destek Merdiveni Maksimum Basamak Genişliği](support_bottom_stair_step_width.md) ayarı, adımların genişliğini sınırlar. Eğer modelin yüzeyi o kadar sığsa ki küçük bir adım yüksekliği büyük bir adım genişliği anlamına geliyorsa, destek geri kalan adım yüksekliği için modelin yüzeyini takip eder.

Bu ayarın azaltılması, desteklerin alt yüzeyinin daha düz olmasına neden olur. Bu, destek ile model arasındaki yapışmayı artırır, destekleri çıkarmayı zorlaştırır ancak destekleri daha stabil hale getirir.