Destek Merdiveni Maksimum Basamak Genişliği
====
Epğer [Destek Yerleştirme](support_type.md) "Her Yerde" olarak ayarlanmışsa, destek model üzerinde dinlenmeye izin verilir. Ancak modelin konturlarını tam olarak takip etmez. Bunun yerine, desteklerin alt tarafı merdiven basamağı şeklinde bir desen oluşturur. Bu şekilde, destek sadece modelle birkaç noktada bağlantı yapar.

Bu ayar, bu basamakların maksimum genişliğini belirler. Basamak genellikle [Destek Merdiveni Basamak Yüksekliği](support_bottom_stair_step_height.md) değeri ile modelin yüzeyini takip eden bir genişlik alır. Ancak eğer bu genişlik çok fazlaysa, genişlik Destek Merdiven Adımı Maksimum Genişlik ile sınırlanır. Bu durumda, geri kalan adım yüksekliği için modelin yüzeyini takip eder.

<!--screenshot {
"image_path": "support_bottom_stair_step_width.png",
"models": [{"script": "standing_ring.scad"}],
"camera_position": [0, 136, 10],
"camera_lookat": [0, 0, 10],
"settings": {
    "support_enable": true,
    "support_bottom_stair_step_height": 1,
    "support_bottom_stair_step_width": 0.7
},
"colours": 64
}-->
![Genişliği sınırlı olan merdiven basamakları, desteklerin modeli takip etmesine neden olul](../images/support_bottom_stair_step_width.png)

Bu ayar normalde, destek hatlarının üstündeki stabiliteyi tehlikeye atmadan malzemenin köprülebileceği maksimum mesafeye ayarlanmalıdır. Ayarı düşürmek, desteklerin modeli daha sık takip etmesine ve destekleri daha stabil hale getirmesine neden olur. Ayarı artırmak, desteklerin Destek Merdiven Adımı Yüksekliği için belirtilen değere daha sık bağlanmasını sağlar ve destekleri modelden çıkarmayı kolaylaştırır.