Kademeli Destek Dolgusu Aşamaları
====
Kademeli destek, destek yoğunluğunu alt katlarda azaltarak destek malzemesinin kullanımını azaltır. Bu, baskı süresinden ve malzeme kullanımından tasarruf sağlarken, aşağıya doğru taşan kaliteyi fazla azaltmaz. Desteklerin temel amacı, asılı kalan alanları desteklemektir. Bu özellik destekleri yalnızca bu amaç için odaklar.

Bu ayar, destek yoğunluğunun kaç adımda azaltılacağını gösterir. Her adımda destek yoğunluğu yarıya düşer. Örneğin, %20 yoğunlukta başlayarak iki kademeli destek adımı ile alt kısımların destek yoğunluğu sırasıyla %10 ve %5 olur.

<!--screenshot {
"image_path": "gradual_support_infill_step_height_1mm.png",
"models": [
    {
        "script": "stair.scad",
        "transformation": ["rotateY(-90)", "scaleZ(0.5)"]
    }
],
"camera_position": [49, 91, -38],
"settings": {
    "support_enable": true,
    "support_pattern": "grid",
    "support_wall_count": 0,
    "support_infill_rate": 50,
    "gradual_support_infill_steps": 3,
    "gradual_support_infill_step_height": 1
},
"colours": 64
}-->
![Destek yoğunluğu 3 adımda azaltılır](../images/gradual_support_infill_step_height_1mm.png)

Adım sayısını artırmak, yoğunluğun daha da düşmesine yol açar, bu da daha az yoğunlukta destek sağlar. Bu malzeme ve baskı süresinden büyük ölçüde tasarruf sağlar, ancak destekleri zayıflatabilir.

Bazı destekler havada asılı kalabilir. Ancak çoğu destek deseni ile bu pratikte hızla kendini onarır, çünkü katmanlar alt katlarda bile düzgün bir şekilde inşa edilebilir. [Aşamalı Destek Dolgusu Basamak Yüksekliği](gradual_support_infill_step_height.md) ayarının amacı, katmanların bir sonraki kademeli destek adımı üstüne yığılmadan önce kendilerini tamir etmeleri için yeterli zaman sağlamaktır.

Bu ayar, en az bir [Duvar Hattı Sayısını Destekle](support_wall_count.md) ile birleştirildiğinde en etkili olur. Bu, destek çizgilerinin havada asılı kalmak yerine bir şeye tutunmasını sağlar.