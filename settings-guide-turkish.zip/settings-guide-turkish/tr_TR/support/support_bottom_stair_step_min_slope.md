Basamak Desteğinin Minimum Eğim Açısı
====
Bu ayar ile desteklerin çok alt kısmında merdiven basamağı oluşturulmasını, modelin eğiminin belirli bir açıya sahip olana kadar devre dışı bırakabilirsiniz.

<!--screenshot {
"image_path": "support_bottom_stair_step_min_slope_10.png",
"models": [{"script": "standing_ring.scad"}],
"camera_position": [0, 82, 10],
"camera_lookat": [0, 0, 10],
"settings": {
    "support_enable": true,
    "support_bottom_stair_step_height": 1,
    "support_bottom_stair_step_min_slope": 10
},
"layer": 250,
"colours": 64
}-->
<!--screenshot {
"image_path": "support_bottom_stair_step_min_slope_30.png",
"models": [{"script": "standing_ring.scad"}],
"camera_position": [0, 82, 10],
"camera_lookat": [0, 0, 10],
"settings": {
    "support_enable": true,
    "support_bottom_stair_step_height": 1,
    "support_bottom_stair_step_min_slope": 30
},
"layer": 250,
"colours": 64
}-->
![Merdiven basamakları 10° eğimine kadar devre dışı bırakılmış durumda](../images/support_bottom_stair_step_min_slope_10.png)
![Merdiven basamakları 30° eğimine kadar devre dışı bırakılmış durumda](../images/support_bottom_stair_step_min_slope_30.png)

Düz eğimlerde, desteklerin altındaki merdiven basamakları çok geniş olabilir. Bu genişlik [Destek Merdiveni Maksimum Basamak Genişliği](support_bottom_stair_step_width.md) ayarında belirtilenden daha fazla olamaz, ancak bu mesafe tüm taraflardan korunur, bu nedenle merdiven basamakları o kadar geniş olabilir ki destek için köprü kurulması gereken önemli bir mesafe oluşabilir. Eğer destek dinlendiği küçük bir vadi varsa, alt kısmın tamamen atlanmasına neden olabilir, bu da desteklerin sadece merdiven basamaklarının köşelerinde dinlenmesine yol açabilir.

Bu durumlar için, merdiven basamaklarını sadece daha dik eğimlerde oluşturacak şekilde sınırlayabilirsiniz. Bu ayar, bu yönden "dik" bir eğimi ne olarak kabul edeceğinizi belirler.

Bu ayarı artırmak, Cura'nın düz yüzeylerde merdiven basamakları oluşturmasını engelleyecektir. Bu destekleri daha sağlam hale getirecek, ancak çıkarmayı zorlaştıracaktır. Destekler, yüzeyde daha fazla iz bırakabilir. Azaltmak, desteklerin çıkarılmasını kolaylaştırır ve desteklerin dinlendiği yerde daha düzgün bir yüzey bırakır, ancak bazı durumlarda desteklerin uzun mesafelerde köprü kurmasına veya tamamen havada asılı görünmesine neden olabilir.

Güzel bir yüzey elde etmek için, bu ayarı 5° veya 10° gibi muhafazakar bir düşük açıda bırakmak en iyisidir. Desteklerin dinlendiği yüzeyin düz olmayan ancak çok sığ olmayan bir eğime sahip olduğunu fark ederseniz, katman görünümünü inceleyin ve desteklerin çok tehlikeli göründüğünü düşünüyorsanız açıyı artırın.