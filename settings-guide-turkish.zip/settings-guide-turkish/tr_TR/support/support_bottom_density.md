Destek Zemini Yoğunluğu
====
Bu ayar, destek tabanının model üzerine oturduğu yerde ne kadar yoğun olacağını belirtir.

Destek tabanının yoğunluğunu artırmak, destek ile model arasındaki temas alanını artırarak daha iyi yapışmasını sağlar. Bu destekleri daha stabil hale getirebilir, ancak çıkarmayı da zorlaştırabilir. Kolay çıkarma için özel olarak geliştirilmiş malzemeler, farklı büzülme oranlarına sahip malzemeler veya çözünebilir malzemeler gibi, bu özellikten büyük fayda sağlayabilir.