Konik Destek Açısı
====
Bu ayar, konik desteklerin ne açıda eğileceğini belirler.

<!--screenshot {
"image_path": "support_conical_enabled.png",
"models": [
    {
        "script": "wide_overhang.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [91, -95, 19],
"settings": {
    "support_enable": true,
    "support_conical_enabled": true,
    "support_conical_angle": 30
},
"colours": 64
}-->
<!--screenshot {
"image_path": "support_conical_angle_10.png",
"models": [
    {
        "script": "wide_overhang.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [91, -95, 19],
"settings": {
    "support_enable": true,
    "support_conical_enabled": true,
    "support_conical_angle": 10
},
"colours": 64
}-->
<!--screenshot {
"image_path": "support_conical_angle_neg10.png",
"models": [
    {
        "script": "wide_overhang.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [91, -95, 19],
"settings": {
    "support_enable": true,
    "support_conical_enabled": true,
    "support_conical_angle": -10
},
"colours": 64
}-->
![30 derece açı](../images/support_conical_enabled.png)
![10 derece açı](../images/support_conical_angle_10.png)
![-10 derece açı, tabanın daha geniş olmasına neden olur](../images/support_conical_angle_neg10.png)

Konik destek açısı, destek stabilitesi ile oluşturulan destek miktarı arasındaki temel dengeyi sağlar.

Büyük bir açı kullanmak, desteklerin büyük bir kısmı boyunca çok ince olmasını sağlar. Bu, destek malzemesi ve baskı süresinden büyük ölçüde tasarruf sağlar. Ancak çok fazla destek malzemesine ihtiyaç duyulduğunda, bu zaman ve malzeme tasarrufu sağlar, çünkü desteklerin yarısı dışarıda bırakılır. Ancak, destek alt kısımlarda çok ince hale geldiği için destek daha az stabil olabilir ve baskının başarısız olma olasılığını artırabilir. Bu durumu engellemek için [Koni Desteğinin Minimum Genişliği](support_conical_min_width.md)'ni artırabilirsiniz.

Negatif bir açı kullanmak, destekleri alt kısmına doğru daha geniş hale getirir, bir volkan şeklinde. Eğer baskınızın üst kısımlarında desteklenmesi gereken çok küçük özellikler varsa, normalde bu çok yüksek [Direkleri](support_use_towers.md) oluşturacak ve baskı sırasında devrilmeye meyilli olacaklardır. Negatif bir açı ile bu uzun, ince destek yapıları alt kısımlarda daha geniş hale getirilir. Bu, onlara ek bir stabilite sağlar. Ancak bu destekleri yazdırmak daha uzun sürecektir çünkü daha fazla malzeme gerektirir. Genellikle -5° civarında bir açı, en yüksek ve en ince destek yapılarına yeterli stabilite sağlar. Eğer malzemeniz seyahat hareketleri sırasında fazla akma eğilimindeyse, daha büyük bir negatif açı gerekebilir, çünkü destek üzerindeki pürüzler nedeniyle yapı daha fazla itilebilir.