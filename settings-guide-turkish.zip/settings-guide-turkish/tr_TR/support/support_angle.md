Destek Çıkıntı Açısı
====
Asma açısı, baskıyı desteklemek için ne kadar malzeme kullanılacağını etkiler. Bu açı, desteklenen minimum açıyı belirtir.

**Bu ayarın değerini azaltmak daha fazla destek oluşturur.**

<!--screenshot {
"image_path": "support_angle_low.png",
"models": [{"script": "duct.scad"}],
"camera_position": [136, 10, 10],
"camera_lookat": [0, 10, 10],
"settings": {
    "support_enable": true,
    "support_join_distance": 0.1,
    "support_angle": 40
},
"colours": 64
}-->
<!--screenshot {
"image_path": "support_angle_high.png",
"models": [{"script": "duct.scad"}],
"camera_position": [136, 10, 10],
"camera_lookat": [0, 10, 10],
"settings": {
    "support_enable": true,
    "support_join_distance": 0.1,
    "support_angle": 75
},
"colours": 64
}-->
<!--screenshot {
"image_path": "support_angle_prepare_mode.png",
"models": [{"script": "duct.scad"}],
"camera_position": [113, 77, 0],
"layer": -1
}-->
![Düşük bir asma açısı daha fazla destek oluşturur](../images/support_angle_low.png)
![Yüksek bir asma açısı daha az destek oluşturur](../images/support_angle_high.png)
![Desteklenen alanlar kırmızı renkte gösterilir](../images/support_angle_prepare_mode.png)

Bu ayarın azaltılması, yazıcının basılı parçanın daha fazlasını desteklemesini sağlar, hatta baskı sırasında çok dik olmayan yüzeyleri bile destekler. Eğer destek, desteklenmesi gerekmeyen parçaları destekliyorsa, baskı süresini ve malzeme kullanımını gereksiz yere artırabilir ve destek baskıya temas ettiği yerlerde izler bırakabilir.

Ancak destek asma açısını azaltmak bazen malzemenin çok fazla sarkmasını önlemek için gereklidir. Genellikle son parçanın boyutsal doğruluğunu artırır ve asma katlaklarının daha iyi görünmesini sağlar.

Destekle çalışırken, desteklerin Önizleme aşamasında nasıl göründüğünü görmek iyi bir fikirdir. Burada desteklerin nerede oluşturulacağını gerçekten görebilirsiniz. Bu ayarı ayarlamak, desteklerin tam olarak nerede oluşturulacağını filtrelemek için kullanabileceğiniz araçlardan biridir.