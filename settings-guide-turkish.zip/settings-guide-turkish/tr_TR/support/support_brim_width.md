Destek Kenar Genişliği
====
Bu ayar, destek kenarının genişliğini ayarlar. Daha geniş bir destek kenarı ile, daha fazla kontur destek alanı içinde çizilerek daha iyi yapışma sağlanır.

<!--screenshot {
"image_path": "support_brim_2mm.png",
"models": [{"script": "gazebo2.scad"}],
"camera_position": [-74, 38, -137],
"settings": {
    "support_enable": true,
    "support_use_towers": false,
    "support_brim_enable": true,
    "support_brim_width": 2
},
"colours": 64
}-->
<!--screenshot {
"image_path": "support_brim_4mm.png",
"models": [{"script": "gazebo2.scad"}],
"camera_position": [-74, 38, -137],
"settings": {
    "support_enable": true,
    "support_use_towers": false,
    "support_brim_enable": true,
    "support_brim_width": 4
},
"colours": 64
}-->
![2mm genişlik](../images/support_brim_2mm.png)
![4mm genişlik](../images/support_brim_4mm.png)

Daha geniş bir kenar, desteklerin inşa tabanına yapışmasını artırır ve desteklerin sarkmasını azaltır. Sonuç olarak, destek daha sağlam duracak ve baskının güvenilirliği artacaktır.