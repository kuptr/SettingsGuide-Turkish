Minimum Destek Bölgesi
====
Bu ayar, destek parçaları için izin verilen minimum boyutu belirler. Bir destek parçasının belirli bir katmanda bu ayarın değerinden daha az alanı varsa, destek o katmanda bırakılır.

<!--screenshot {
"image_path": "minimum_support_area_0.png",
"models": [{"script": "castle.scad"}],
"camera_position": [0, 190, 47],
"settings": {
    "support_enable": true,
    "minimum_support_area": 0
},
"colours": 64
}-->
<!--screenshot {
"image_path": "minimum_support_area_10.png",
"models": [{"script": "castle.scad"}],
"camera_position": [0, 190, 47],
"settings": {
    "support_enable": true,
    "minimum_support_area": 10
},
"colours": 64
}-->
![Alan üzerinde herhangi bir filtreleme yok (minimum alan 0'dır)](../images/minimum_support_area_0.png)
![Küçük destek parçaları dışarıda bırakılır](../images/minimum_support_area_10.png)

Bu ayar, ince destek sütunlarının devrilmeye meyilli olmasından dolayı var. Ayrıca genellikle destek olmadan basılabilen küçük özellikleri destekliyorlar gibi gözükür. Destek devrildiğinde, baskı üzerinde birçok pütür bırakılır. Bu nedenle, bu ince sütunları bırakmak daha iyi olabilir. Bu ayar, sütunun kesit alanına göre destekleri filtrelemenin bir yolunu sağlar.

Alanı artırmak, basılan destek miktarını azaltır, zaman ve malzeme kullanımını hafifçe azaltır. Daha da önemlisi, baskının güvenilirliğini artırır, çünkü destek sütunlarının devrilme olasılığı azalır. Ancak bu, baskıda küçük özellikler için destek sağlanmasını azaltacağı için, bu parçalar için asmaların kalitesini kötüleştirebilir.

Bazı şekiller için bu, üst kısmın alan eşiğinin altına düşmesi durumunda üst kısmın destekten çıkarılmasının hoş olmayan yan etkilerine yol açabilir, ancak alt kısım bunu yapmaz. Bu, normalde desteklenmesi gereken parçaların desteksiz kalmasına neden olabilir.

<!--screenshot {
"image_path": "minimum_support_area_problem.png",
"models": [{"script": "overhang_bridging_cooling.scad"}],
"camera_position": [117, 0, 15],
"settings": {
    "support_enable": true,
    "minimum_support_area": 50
},
"colours": 64
}-->
![Yayın ucunda, bu katmanlarda alan çok küçük olduğu için desteklenmez](../images/minimum_support_area_problem.png) 