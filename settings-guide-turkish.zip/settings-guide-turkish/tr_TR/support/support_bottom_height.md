Destek Zemini Kalınlığı
====
Bu ayar, desteklerin model üzerinde oturduğu destek tabanının kalınlığını belirler.

Daha kalın bir destek tabanı, destek tabanının etkinliğini artırır. Ana destek gövdesini modelden daha iyi ayıracak daha fazla malzeme olacaktır. Eğer destek tabanı, modelden kolayca ayrılan bir malzeme ile basılıyorsa, geri kalan desteklerin modelle temas etmesi ve iz bırakma olasılığı azalır.

Ancak daha kalın bir destek tabanı, daha fazla destek malzemesinin pahalı veya yavaş basılmasına neden olabilir. Bu da baskının tamamlanması daha uzun sürebilir veya daha pahalı malzemeler kullanılmasına yol açabilir.