Minimum Destek Zemini Bölgesi
====
Bu ayar, destek tabanının parçalarının çok küçükse bırakılmasına neden olur. Çok küçük alanlarda, normal destek baskı yapılır.

Bazı malzemeler yüksek akış hızlarında iyi bir şekilde ekstrüde edilir ve çalışmaya başlamak için biraz zaman gerektirir. Eğer bu tür malzemeler destek tabanı için kullanılıyorsa, küçük taban alanlarında pek etkili olmayabilirler. Onları bırakmak, ekstruder değiştirmek ve etrafı dolaşmak için zaman kazandırır ve yüzeydeki topaklanmaları önler. Bunun yerine Cura, normal destek çizecek ve böylece destek daha iyi desteklenebilir.