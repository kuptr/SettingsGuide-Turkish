Destek Kenarını Etkinleştir
====
Destek kenarı etkinleştirildiğinde, ilk katmanda destek alanı içine ek bir kenar çizilir.

<!--screenshot {
"image_path": "support_brim_4mm.png",
"models": [{"script": "gazebo2.scad"}],
"camera_position": [-74, 38, -137],
"settings": {
    "support_enable": true,
    "support_use_towers": false,
    "support_brim_enable": true,
    "support_brim_width": 4
},
"colours": 64
}-->
![Destek "Kenar"ı](../images/support_brim_4mm.png)

Destek kenarı, normal kenardan farklı olarak içeriye doğru çizilir. Eğer [Yapı Levhası Yapışma Türü](../platform_adhesion/adhesion_type.md) kenar olarak ayarlanmışsa, destek etrafında *dışında* başka bir kenar da çizilir.

Bu kenarın amacı, desteklerin inşa tabanına daha fazla yüzey alanında yapışmasını sağlamaktır. Bu, [Initial Layer Support Line Distance](support_initial_layer_line_distance.md) ayarını ayarlayarak da elde edilebilir, ancak bu özellikle destek alanının kenarında yapışmanın sürüdüğü yerde sarkmaları önlemek için daha etkilidir.

Destek kenarı, baskı süresini ve malzeme maliyetini biraz artırır, ancak sadece ilk katmanda olduğu için bu artış çok minimaldir. Bu kenar, destekleri önemli ölçüde daha güçlü yapar, bu nedenle zigzag destek deseni için çıkarması daha zor hale gelebilir.