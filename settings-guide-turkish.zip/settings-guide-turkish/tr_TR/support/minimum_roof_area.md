Minimum Destek Çatısı Bölgesi
====
Bu ayar, destek tavanının parçalarının çok küçükse bırakılmasına neden olur. Çok küçük alanlarda, normal destek baskı yapılır.

Bazı malzemeler yüksek akış hızlarında iyi bir şekilde ekstrüde edilir ve çalışmaya başlamak için biraz zaman gerektirir. Eğer bu tür malzemeler destek tavanı için kullanılıyorsa, küçük tavan alanlarında pek etkili olmayabilirler. Onları bırakmak, ekstruder değiştirmek ve etrafı dolaşmak için zaman kazandırır ve yüzeydeki topaklanmaları önler. Bunun yerine Cura, normal destek çizecek ve böylece model daha iyi desteklenebilir.