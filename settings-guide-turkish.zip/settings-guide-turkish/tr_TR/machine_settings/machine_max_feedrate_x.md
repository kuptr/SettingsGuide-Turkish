Maksimum X Hızı
====
Bu ayar, yazıcınızın X yönünde ulaşabileceği maksimum hızı gösterir.

Bu, [Yazdırma Hızı](../speed/speed_print.md) ve ilgili ayarları sınırlamak için kullanılır. Tüm eksenlerle aynı anda çapraz hareket ettiğinizde maksimum hızdan daha yüksek bir baskı hızı kullanamazsınız. Ayrıca, bir hareket çapraz hareket etmiyorsa ve sonra X eksisinde maksimum hıza ulaşıyorsa doğru zaman tahminlerini hesaplamak için kullanılır.

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez.**