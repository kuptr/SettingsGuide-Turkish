Etkinleştirilmiş Ekstruder Sayısı
====
Bu ayar, ön uçta kaç ekstrüderin şu anda etkin olduğunu saklar. Ekstrüderler, ekranın üst orta kısmındaki yapılandırma menüsünde bir onay kutusu ile etkinleştirilebilir veya devre dışı bırakılabilir.

Bu ayar, kullanıcı bir ekstrüderi etkinleştirdiğinde veya devre dışı bıraktığında Cura tarafından otomatik olarak ayarlanır. Ayar, kullanıcı veya profiller tarafından değiştirilmemeli veya ayarlar listesinde yer almamalıdır. Diğer ayarlar, uygun bir ayar değerini belirlemek veya çoklu ekstrüzyon ayarlarının gösterilip gösterilmeyeceğini belirlemek için bu ayarı kullanabilir.

**Bu bir makine ayarı olduğundan, bu ayar genellikle ayarlar listesinde görünmez.**