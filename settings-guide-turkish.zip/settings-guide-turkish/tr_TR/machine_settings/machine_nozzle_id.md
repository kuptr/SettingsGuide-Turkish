Nozül Kimliği
====
Bu, nozül profilleri tarafından özelleştirilmiş bir ayar olup, bu nozülün ne tür bir nozül olduğunu gösterir.

Bu ayarın değeri, [G-Code'un Griffin türü](machine_gcode_flavor.md) kullanıldığında g-code başlığına yazılır. Böylece yazıcı, g-code'un hangi nozül için olduğunu bilir ve kullanıcıya bu baskıyı başlatmadan önce nozülü değiştirmesi gerekebileceğini bildirebilir.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**