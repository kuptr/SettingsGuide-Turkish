Milimetre Başına Adım (Z)
====
Çoğu 3D yazıcı, baskı kafasını yapı hacmi etrafında hareket ettirmek için adım motorları kullanır. Bu motorlar adımlar halinde döner ve adımların iki konumu arasında kalmakta zorlanırlar. Adımlar, yazıcının çözünürlüğüdür. Bu ayar, bu çözünürlüğü belirtir: Motorun Z yönünde bir milimetre hareket sağlamak için kaç adım atması gerektiğini gösterir.

Bu, Z yönünde hareketi ayrı bir motorla kontrol etmeyen (delta tipi yazıcılar gibi) veya Z yönünde baskı kafasını veya yapı plakasını hareket ettirmek için adım motorları kullanmayan yazıcılar için geçerli değildir.

Bu ayar, Cura tarafından hiç kullanılmaz. Ancak, X3Gwriter eklentisi tarafından X3G dosyalarını doğru adım boyutlarıyla çıkarmak için kullanılır.

**Bu bir makine ayarı olduğundan, bu ayar normalde ayarlar listesinde görünmez.**