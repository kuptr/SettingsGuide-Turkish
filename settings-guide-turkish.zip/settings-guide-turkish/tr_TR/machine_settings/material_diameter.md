Çap
====
Bu ayar, nozüle beslenecek filamentin çapını tanımlar. Cura'nın ekstrüzyon oranını doğru hesaplaması ve geri çekme sayısını doğru sınırlaması için önemlidir.

Çoğu yazıcı, bir çizgi yazdırmak için yeterince ekstrüzyon yapmak üzere ekstrüzyon tekerleğinin ne kadar dönmesi gerektiğini belirten g-kodunu bekler. Doğru miktarda malzeme akışını sağlamak için bu filament çapı gereklidir. Yazıcının donanım yazılımı, ekstrüzyon miktarlarını hacimsel olarak yorumluyorsa, bu gereksizdir, ancak yine de belirli bir uzunluktaki filament üzerindeki geri çekme sayısını sınırlamak için filament çapını kullanacaktır.

Günümüzde çoğu yazıcı, 1.75 mm çapında filament kullanır. Diğer yaygın bir çap ise 2.85 mm'dir.

**Bir malzeme, filament çapı ekstrüder ile uyumlu ise yazıcıya uygun malzemeler listesinde görünecektir. Ekstrüderin kabul ettiği filamentleri öğrenmek için yazıcınızın Makine Ayarları paneline (ekstrüder sekmesinde) bakın.**