Malzeme Sıcaklıklarını Ekle
====
Bu ayar, dilimleme arka ucuna başlangıç g-kodundan önce baskının başlangıcı için nozül sıcaklık komutlarını yazıp yazmaması gerektiğini iletir. Bir dilimlemeye başlandığında otomatik olarak ayarlanır.

[G-code’u Başlat](machine_start_gcode.md) sırasında çoğu işlem için nozülün baskı için doğru sıcaklığa ulaşmış olması mantıklıdır. Yazıcı tanımlarını tasarlayanlar için işleri kolaylaştırmak adına, Cura başlangıç g-kodu yürütülmeden önce nozülü otomatik olarak ısıtır. Ancak, başlangıç g-kodu herhangi bir nozül sıcaklık ayarına referans içeriyorsa, nozül otomatik olarak ısıtılmayacaktır.

**Bu bir makine ayarı olduğundan, normalde ayarlar listesinde görünmez. Ayrıca değiştirilmesi de bir etki yaratmaz çünkü Cura tarafından otomatik olarak değiştirilecektir.**