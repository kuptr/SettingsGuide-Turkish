Maksimum Y İvmesi
====
Bu ayar, yazıcınızın motorunun ve çerçevesinin Y yönde işleyebileceği maksimum ivmeyi, yazıcının firmware'ine göre belirtir.

Bu ayar yalnızca doğru zaman tahminleri elde etmek için kullanılır. Cura tarafından belirlenen [Yazdırma İvmesi](../speed/acceleration_print.md) bir sınırı yoktur, ancak Cura, firmware'ninizin belirli bir eksen başına bir sınır belirlediğini varsayar. Y eksenindeki ivme bu ayarı aştığında, bu hareketlerin zaman tahminleri, firmware'ninizin ivmeyi sınırladığını varsayarak ayarlanır. Toplam ivme, birden fazla eksende aynı anda diyagonal olarak hızlanıldığında hala daha büyük olabilir.

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez.**