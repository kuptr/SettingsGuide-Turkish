Ekstruder İlk Z konumu
====
Eğer [İlk Damlayı Etkinleştir](../platform_adhesion/prime_blob_enable.md) etkin ise, bu ayar, başlatma topağının hareketinin başlayacağı Z koordinatını belirtir. Cura, başlatma topağı uygulanmadan önce o konuma hareket eder.

X ve Y koordinatının aksine, bu bir makine ayarıdır. Bunun nedeni, başlatma işleminin sabit bir Z koordinatına sahip olmasıdır. Başlatma topağı oluşturmak için nozulun yapı platformuna hareket etmesi ve belki biraz yukarı ve aşağı hareket etmesi gerekecektir. [Extruder İlk X konumu](../platform_adhesion/extruder_prime_pos_x.md) ve [Extruder İlk Y konumu](../platform_adhesion/extruder_prime_pos_y.md) normal ayarlarla seçilebilir; böylece, yapı platformunda yer sınırlıysa başlatma topağının konumunu değiştirebilirsiniz, ancak Z koordinatı değiştirilemez.

Bu ayarın değiştirdiği tek şey, Cura'nın başlatma topağı komutu uygulanmadan önce nozulu hareket ettirmesini istediği Z koordinatıdır.

**Bu bir makine ayarı olduğundan, bu ayar genellikle ayarlar listesinde görünmez.**