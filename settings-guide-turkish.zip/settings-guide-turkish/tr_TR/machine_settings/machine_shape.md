Yapı Levhası Şekli
====
Bu ayarla, yazıcınızda baskı hacminin aldığı şekli belirtebilirsiniz. İki seçenek vardır: dikdörtgen veya eliptik.

![Bir dikdörtgen yapı tablası](../images/machine_shape_rectangular.png)
![Bir eliptik yapı tablası](../images/machine_shape_elliptic.png)

Eliptik yapı hacimleri, delta tarzı 3D yazıcılarda yaygındır. Yapı tablası eliptik ise, yapı hacminin [Makine Genişliği](machine_width.md) ve [Makine Derinliği](machine_depth.md) elipsin iki yarıçapına uygulanır. Cura, nesneleri sadece elipsin içine yerleştirmeye izin verecektir, bu nedenle toplam yapı hacmi, aynı boyutlara sahip dikdörtgen bir yapı tablasına kıyasla daha küçük olacaktır.

**Bu ayar bir makine ayarıdır, bu nedenle normal ayar listesinde görünmeyecektir. Ayarları değiştirmek için tercihler ekranındaki yazıcı listesine gidip "Makine Ayarları" üzerine tıklamanız gerekmektedir.**