Makine Yüksekliği
====
Bu ayar, noz(z)ulların hareket edebileceği Z koordinatları arasındaki dikey aralığı belirtir. Temel olarak yazıcının kullanılabilir boyutudur.

Bu, yazıcınızın raf üzerindeki gerçek yüksekliği ile eşit değildir. Gerçek yazıcı aynı zamanda bir gantry veya bir kolu ve yapı hacmi etrafında bir tabana sahip olacaktır ve bu ölçüm bu boyutu içermez. Bu, sadece yapı hacminin boyutudur, nozülün hareket edebileceği koordinatlar.

![Yapı hacmi boyutları](../images/build_volume_dimensions.svg)

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez. Yükseklik, tercihler penceresinde eklenen yazıcıların listesinde bulunan yazıcı ayarları içinde değiştirilebilir.**