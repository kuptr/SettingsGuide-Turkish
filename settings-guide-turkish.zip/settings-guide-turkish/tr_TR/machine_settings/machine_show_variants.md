Makine Varyantlarını Göster
====
Cura 2.1'e kadar, bu ayar, bu yazıcıdan türetilen yazıcı tanımlarının, yazıcının ayrı bir açılır menüde varyantları olarak gösterilip gösterilmeyeceğini belirlerdi.

Cura 2.3'ten itibaren, bu ayarın artık herhangi bir etkisi yoktur.

**Bu bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görünmez.**