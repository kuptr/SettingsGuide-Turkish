Maksimum Hız E
====
Bu ayar, besleyicinizin filamenti hangi hızda hareket ettirebileceğini gösterir.

Bu, [Geri Çekme Hızı](../travel/retraction_speed.md) hızını sınırlamak için kullanılır. Besleyicinizin taşıyabileceğinden daha hızlı çekme yapamazsınız.

Ayrıca, besleyicinin hızı bir satırın ne kadar hızlı yazılabileceğinde bir sınırlayıcı faktör olabilirse, doğru zaman tahminlerini hesaplamak için kullanılır. Ancak gerçekte, besleyici genellikle plastik nozulunuzun içinde eritebileceği hızın ve yazıcınızın düzgün bir çizgi çizmek için hareket edebileceği hızın katlarında daha hızlı hareket eder, bu nedenle bu asla gerçekten bir sınırlayıcı faktör değildir.

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez.**