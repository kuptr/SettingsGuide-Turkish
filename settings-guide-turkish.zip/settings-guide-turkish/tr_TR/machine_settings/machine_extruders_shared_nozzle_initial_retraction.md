Paylaşılan Nozül İlk Geri Çekme
====
Eğer bir yazıcının ekstruderi [Ekstrüder Nozül Paylaşımı](machine_extruders_share_nozzle.md) yapılıyorsa, Cura tüm ekstruderlerin filamentinin nozul ucunda başladığını varsaymaz. Bu ayar, filamentin nozuldan ne kadar uzakta başladığını belirtir. Filament, baskı yapılırken ekstruder bekleme durumunda olduğunda, yazıcı hareketsizken filament daha uzak bir mesafede saklanmış olabileceği için [Nozül Anahtarı Geri Çekme Mesafesi](../dual/switch_extruder_retraction_amount.md)'nden farklı bir mesafede başlayabilir.

![Baskıdan önceki hareketsiz filament mesafesi](../images/machine_extruders_shared_nozzle_initial_retraction.svg)

Cura, ilk ekstruder değişiminde primleme prosedürüne başlamadan önce filamentin nozul ucunda olduğundan emin olmak için bunu kullanacaktır.