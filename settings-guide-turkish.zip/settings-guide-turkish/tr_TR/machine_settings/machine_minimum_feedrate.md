Minimum Besleme Hızı
====
3D yazıcılar için çoğu yazılımın türediği Marlin yazılımı, tüm hareketleri için bir minimum hızı vardır. Bu ayar, yazıcınızın yazılımı için bu minimum hızı belirtir.

Minimum hız, sıfıra bölme hatalarını önlemek için bir ayarlamadır. Yazılımın, motorlara doğru zamanlama ile sinyal göndermek için adım aralıklarını hesaplaması gerekir. Eğer motorun hızı 0 olmalı (yani durmalı) bu sonsuz bir zaman aralığı olur, ki bu yazılımın iyi ele alamayacağı bir durumdur. Ancak bu, yazıcının hiçbir motorunun gerçekte dönmediği durumlarda geçerlidir. Örneğin, X yönünde hareket ederken, Y eksenini kontrol eden motor hala dönmese de, adım motorlarının karmaşıklığı nedeniyle minimum besleme hızı burada uygulanmaz.

Cura, doğru zaman tahminleri üretmek için bu minimum besleme hızını kullanır. Bu, bir baskının başlangıcında veya bir mola sonrasında ivmelenirken ve bir baskının sonunda veya bir mola öncesi dururken yavaşlamada uygulanır.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**