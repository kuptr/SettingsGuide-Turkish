Nozül İzni Olmayan Alanlar
====
Bu ayar, aktif nozülün yapı plakasındaki herhangi bir alanın içine giremeyeceği alanları belirtir. Kullanıcı, bu alanlara veya yakınına hiçbir nesne yerleştiremez; aksi takdirde orada bir şeyin basılmasına (örneğin bir brim) neden olabilirler.

![Gri yama, yapı plakasındaki klipslerin etrafındaki yasaklı alanları gösterir](../images/machine_disallowed_areas.png)

Bu ayar yalnızca *aktif nozül* için geçerlidir, bu da demektir ki bu yasaklı alanların yanına nesneler yerleştirebilirsiniz, hatta bu diğer nozüllerin bu yasaklı alanların üzerinden hareket etmesine neden olabilir. Bu nedenle, bu ayar gerçekten yalnızca aktif olmayan nozülleri hareketsizken kaldırılan veya yapım hacmi dışına park edilen yazıcılar için kullanışlıdır. Olağan [İzin Verilmeyen Alanlar](machine_disallowed_areas.md) aykırı olarak, bu yasaklı alanlar nozüller arasındaki farka bağlı olarak hareket etmez.

Bu yasaklı alanlar, nozülün şeylere çarpmasını önlemek için gereklidir. Örneğin, yapı plakasında bazı klipsler veya bir etiket veya logo olabilir. Kullanıcı bu nesnelere çok yakın bir şekilde baskı almak isterse, nozül bu nesnelerle çarpışır. En iyi ihtimalle bir [katman kayması](../troubleshooting/layer_shift.md) elde edersiniz. En kötü ihtimalle nozülü veya çarpışan şeyi hasar alabilirsiniz.

Yasaklı alanlar, kullanıcıya oraya hiçbir nesne yerleştiremeyeceğini belirtmek için yapı plakasında gri bir gölge olarak çizilir. Bu gölgeler, brim veya skirtin ona çarpma olasılığını önlemek ve çeşitli diğer nedenlerle her yöne genişletilebilir. Ayrıca nozüllerin bir ofseti varsa hareket aralığını sınırlamak için yapı plakasında diğer gölgeler de bulunur.

**Bu bir makine ayarı olduğundan, bu ayar normalde ayarlar listesinde görünmez.**