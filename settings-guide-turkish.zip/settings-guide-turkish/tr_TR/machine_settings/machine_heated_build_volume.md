Yapı Hacmi Sıcaklığı Dengesi Mevcut
====
Bu ayar, yazıcının yapı hacmi sıcaklığını kontrol edip etmediğini açıklar.

Tüm 3D yazıcılar, nozüllerindeki ve yapı tablalarındaki ısıtıcılar aracılığıyla yapı hacimlerini belirli bir dereceye kadar ısıtırlar, ancak bazı yazıcılarda aktif ısıtma veya havalandırma sistemleri ve bir sıcaklık probu bulunur. Bu, yapı hacmi içindeki sıcaklığı kontrol etmelerini sağlar.

Bu ayar devre dışı bırakıldığında, [Yapı Disk Bölümü Sıcaklığı](../material/build_volume_temperature.md) ayarı arayüzden gizlenir. 

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez. Ancak, tercihler penceresinde eklenen yazıcıların listesinde bulunan yazıcı ayarları içinde bu ayar için bir onay kutusu bulunmaktadır.**