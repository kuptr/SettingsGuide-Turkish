Makine Derinliği
====
Bu ayar, nozulların hareket edebileceği Y koordinat aralığını gösterir. Temelde yazıcının kullanılabilir boyutunu belirtir.

Bu, yazıcınızın raf üzerindeki gerçek derinliği ile eşit değildir. Gerçek yazıcının imalat hacminin etrafında bir çerçeve veya kol olacaktır ve bu ölçüm bu boyutu içermez. Bu, yalnızca imalat hacminin boyutu, nozulun hareket edebileceği koordinatlardır.

![Baskı Nesne hacim boyutları](../images/build_volume_dimensions.svg)

Birden çok nozul dahilse, tüm nozullerin tam imalat hacmine ulaşamayabileceğini unutmayın. Bazı yazıcılarda, yazıcının farklı nozulleri birbirinden farklı yerlere yerleştirilmişse, bazı nozuller imalat hacminin bir tarafına kadar ulaşamayabilir. Bu ayar, tüm nozullerin ulaşabileceği hacimlerin birleşimini gösterir.

**Bu bir makine ayarı olduğundan, normal ayarlar listesinde normal olarak listelenmeyecektir. Derinlik, tercihler iletişim kutusundaki eklenen yazıcıların listesinde bulunan yazıcı ayarları ile değiştirilebilir.**