İzin Verilmeyen Alanlar
====
Bu ayar, baskı kafasının gitmesine izin verilmeyen yapı tabanındaki herhangi bir alana işaret eder. Kullanıcı, bu alanlara hiçbir nesne yerleştiremez veya bunların yakınına yerleştirmez; çünkü bu alanlarda bir şeyin basılmasına neden olabilirler (örneğin bir brim).

![Gri lekeler, yapı tabanındaki kelepçelerin etrafındaki yasaklanmış alanları belirtir](../images/machine_disallowed_areas.png)

Bu yasaklanmış alanlar, baskı kafasının çarpışmasını önlemek için gereklidir. Örneğin, baskı kafasının erişebileceği bir temizleme fırçası, bir değiştirme bölmesi veya iç yapı hacmi içinde biraz fazla çıkıntı yapan bir kamera olabilir. Kullanıcı bu nesnelerin çok yakınına basarsa, baskı kafası bunlarla çarpışır. En iyimser senaryoda bir [katman kayması](../troubleshooting/layer_shift.md) yaşanır. En kötü senaryoda ise baskı kafasını veya baskı kafasının çarpıştığı şeyi hasar görebilirsiniz.

Yasaklanmış alanlar, kullanıcıya bu alanlara hiçbir nesne yerleştiremeyeceğini belirten yapı tabanında gri bir gölge olarak çizilir. Bu gölgeler, brimi veya etrafındaki diğer nesnelerin çarpmasını önlemek ve çeşitli diğer nedenlerden dolayı her yönde genişletilebilir. Nozulların bir ofseti varsa, hareket aralığını sınırlamak için yapı tabanında başka gölgeler de olabilir.

Eğer yalnızca aktif nozul engellerle çarpışacaksa, benzer bir ayar olan [Nozül İzni Olmayan Alanlars](nozzle_disallowed_areas.md), nozulun ona çarpmasını önleyebilir ancak baskı kafasının üzerinden geçmesine izin verebilir.

**Bu bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görünmez.**