Makine Genişliği
====
Bu ayar, nozül(ler)in hareket edebileceği X koordinatları aralığını belirtir. Temel olarak yazıcının kullanılabilir boyutudur.

Bu, yazıcınızın raftaki gerçek genişliği ile eşit değildir. Gerçek yazıcı ayrıca yapı hacmi etrafında bir çerçeve veya kol içerir ve bu ölçüm bu boyutu içermez. Sadece nozülün hareket edebileceği yapı hacminin boyutudur.

![Yapı hacmi boyutları](../images/build_volume_dimensions.svg)

Birden fazla nozül söz konusu olduğunda, tüm nozüller yapı hacminin tamamına ulaşamayabilir. Bazı yazıcılar için, yazıcı birbirinden farklı konumlandırılmış nozüllere sahipse, bazı nozüller yapı hacminin bir tarafına tamamen ulaşamayabilir. Bu ayar, sadece tüm nozüllerin ulaşabileceği hacimlerin birleşimini belirtir.

**Bu bir makine ayarı olduğundan, normal ayarlar listesinde genellikle görünmez. Genişlik, tercihler diyaloğundaki eklenmiş yazıcılar listesinde bulunabilen yazıcı ayarları diyaloğunda değiştirilebilir.**