Makinenin Başlığı ve Fan Poligonu
====
Bu ayar, Cura'ya baskı kafanızın, üstten görüldüğünde şeklini belirtir. Bu, [Birer Birer](../blackmagic/print_sequence.md) baskı yaparken çarpışmaları önlemek için gereklidir.

![Baskı kafasının boyutları](../images/head_dimensions.svg)
![Üstten aşağıya bakıldığında, baskı kafasının şekli nozül konumuna göre belirlenir](../images/machine_head_with_fans_polygon.png)

Bu ayar, bir poligon oluşturan koordinat listesini içerir. Koordinatlar, kafanın "konumu"na göre göreceli olarak konumlandırılır, bu konumlara nozüller de göreceli olarak konumlandırılır.

Cura, bu bilgileri kullanarak tek tek modda baskı yaparken basılacak nesneler etrafında bir çarpışma alanı oluşturur. Bu çarpışma alanı, önceki olarak basılmış bir modelle çarpışmadan basılamayacak kadar yakın nesneleri yerleştirmenizi engeller. Ancak çarpışma alanı, baskı kafasının kendisi kadar bir şekle sahip değildir: Seyahat hareketleri sırasında çarpışmaları önlemek için baskı kafasının etrafında konveks bir kabuk oluşturulur. Ayrıca, simetrik olacak şekilde küçültülür. Örneğin, nozül baskı kafasının sol tarafına daha yakınsa (yukarıdaki resimde olduğu gibi), çarpışma alanı, daha önce basılmış nesnelere yakın başka bir nesne yerleştirilebilecek şekilde küçültülür. Bu nesnelerin basılma sırası daha sonra çarpışmalar olmadan basılabilmeleri için ayarlanır.

**Bu bir makine ayarı olduğu için, normal ayar listesinde genellikle listelenmez. Ancak baskı kafasının boyutu, tercihler penceresindeki eklenen yazıcılar listesinde bulunan yazıcı ayarları ile kaba bir şekilde belirtilebilir. Orada sadece baskı kafasının sol, sağ, üst ve alt kenarlarını belirtebilirsiniz.**