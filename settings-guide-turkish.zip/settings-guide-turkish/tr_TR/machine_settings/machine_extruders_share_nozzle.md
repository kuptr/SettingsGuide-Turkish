Ekstrüder Nozül Paylaşımı
====
Bu ayarla, yazıcınızın yalnızca tek bir nozulu olduğunu ve tüm filamentlerin bu aynı nozuldan geçirildiğini belirtebilirsiniz. Cura, böylece başlama g-strigindeki stratejisini değiştirir.

Normalde, Cura [G-code’u Başlat](machine_start_gcode.md) çalıştırıldıktan sonra, tüm ekstruderlerin filamentlerinin nozulun ucunda, baskı yapmaya hazır olduğunu varsayar. Ekstruderler bir nozulu paylaştığında, sadece bir filament aynı anda nozulun içinde olabileceğinden bu mümkün değildir. Normal bir primleme prosedürü yerine [İlk Damlayı Etkinleştir](../platform_adhesion/prime_blob_enable.md) veya ekstra etek çizgileri ile, nozulun tam ekstruder değişimi için primlenmesi gereklidir. Bu, etkinse [İlk Direği Etkinleştir](../dual/prime_tower_enable.md) içinde baskı yapmayı içerir.

Eğer tüm ekstruderler bir nozulu paylaşıyorsa, mantıklı olarak [Ekstrüderler Isıtıcıyı Paylaşır](machine_extruders_share_heater.md) düşünebilirsiniz. Ancak, Cura bunlar arasında doğrudan bir bağlantı yapmaz, bu yüzden eğer yazıcınız gerçekten tek bir nozul ve tüm ekstruderler için tek bir ısıtıcıya sahipse, her ikisini de etkinleştirdiğinizden emin olun.

**Bu bir makine ayarı olduğu için, genellikle normal ayar listesinde listelenmez. Ancak, tercihler iletişim kutusundaki eklenen yazıcıların listesinde bu ayar için bir onay kutusu bulunmaktadır.**