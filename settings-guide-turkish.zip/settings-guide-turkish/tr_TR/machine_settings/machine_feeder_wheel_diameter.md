Besleyici Çark Çapı
====
Bu ayar, besleyicide filamenti ileri geri hareket ettiren tekerleğin çapının ölçümüdür.

![Besleyici tekerlek genellikle en fazla kavrama yüzeyine sahip olan tekerlektir](../images/machine_feeder_wheel_diameter.svg)

Bu ayar hiçbir şekilde Cura tarafından kullanılmaz. Ancak, X3GWriter eklentisi, besleyiciyi doğru şekilde kontrol etmek için bu bilgiye ihtiyaç duyar. Filamenti doğru mesafede hareket ettirmek için besleyiciyi ne kadar hızlı hareket ettirmesi gerektiğini bilmelidir.

**Bu bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görünmez.**