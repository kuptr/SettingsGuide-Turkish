Nozül Sıcaklığı Kontrolünü Etkinleştir
====
Bu ayar devre dışı bırakıldığında, Cura g-code'a herhangi bir sıcaklık komutu çıktısı vermeyecek. Bunun yerine, Cura baskıdan önce nozülleri ısıtmayı yazıcı firmware'ine bırakacak.

Bu, [Isıtılmış Yapı Levhası İçerir](machine_heated_bed.md) ile benzer şekilde işlev görür. Bu ayar devre dışı bırakıldığında, [Yazdırma Sıcaklığı](../material/material_print_temperature.md) gibi sıcaklık kontrol ayarları kullanıcıya gösterilmeyecek.

Bunu geçici olarak devre dışı bırakmak, baskının kuru bir çalışmasını gerçekleştirmek için kullanılabilir. Bunun için ayrıca [Isıtılmış Yapı Levhası İçerir](machine_heated_bed.md) aktif değil ise, [Yapı Hacmi Sıcaklığı Dengesi Mevcut](machine_heated_build_volume.md) ve [Akış oranı](../material/material_flow.md) %0 olarak ayarlamanız gerekecektir.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**