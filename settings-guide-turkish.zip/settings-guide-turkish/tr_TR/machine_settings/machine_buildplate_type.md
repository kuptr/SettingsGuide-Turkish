Yapı Levhası Malzemesi
====
Bu ayarla, imalat platformunuzun hangi tür malzemeden yapıldığını belirtebilirsiniz. Şu anda iki seçenek bulunmaktadır: alüminyum veya cam.

Cura, bu bilgiyi Griffin g-kodu başlığında g-koduna iletmek dışında hiçbir işlem yapmaz. Bu sayede yazıcı, g-kodunun doğru imalat platformu için mi yoksa değil mi olduğunu bilebilir.

**Bu bir makine ayarı olduğundan, normal ayarlar listesinde normal olarak görüntülenmez.**