Fan Hızını 0 - 1 Arasında Ölçeklendir
====
Yazıcının fanlarının dönme hızını kontrol etmek için, Cura komutları g-code'a belirli bir hızı kontrol eden bir parametreyle koyar. Genellikle bu parametre 0 ile 255 arasında bir sayıdır. Ancak bazı yazıcılar 0 ile 1 arasındaki bir sayıyı da kabul eder ve farklı şekilde yorumlar. Bu ayar, Cura'nın fan hızlarını 0 ile 1 arasında bir sayı olarak yazmasını sağlar, 0 ile 255 arasında değil.

Pazardaki çeşitli yazıcılardaki firmware'lerin 3 tür davranışı vardır.
* Çoğu yazıcı, fan hızlarını yalnızca 0 ile 255 arasında bir sayı olarak kabul eder. Bu durumda bu ayar devre dışı bırakılmalıdır, aksi takdirde fan hiçbir zaman gerçekten dönmeyecektir.
* Bazı yazıcılar (özellikle RepRapFirmware) 0 ile 255 arasında sayıları kabul eder, ancak 1 veya daha düşükse, bunu 0 ile 1 arasında bir sayı olarak yorumlar. Bu durumda bu ayar etkinleştirilmelidir, aksi takdirde Cura'nın fan hızını yaklaşık olarak %0.4'e ayarlamaya çalıştığı nadir bir durum olabilir (255'ten 1), ancak yazıcı bunu %100 olarak ayarlar.
* Bazı yazıcılar yalnızca 0 ile 1 arasındaki sayıları kabul eder. Bu durumda bu ayar da etkinleştirilmelidir, aksi takdirde fan her zaman tamamen kapalı veya tamamen açık olur.