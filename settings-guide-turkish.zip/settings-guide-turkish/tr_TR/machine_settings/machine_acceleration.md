Varsayılan İvme
====
Bu ayar, Cura'nın [ivme kontrolünü](../speed/acceleration_enabled.md) sağlamadığı durumlarda yazıcınızın kullandığı hızlanmayı belirtir.

Cura'nın hızlanma oranlarını kontrol etmediği durumlarda baskı için doğru zaman tahminlerini elde etmek için kullanılır. Tüm baskı aynı hızlanma oranını kullanacaktır.

**Bu bir makine ayarı olduğundan, normal ayarlar listesinde normal olarak görüntülenmez.**