Makine Türü
====
Bu, kullandığınız yazıcı modelini tanımlayan açıklayıcı bir ayar.

Şu anda bu ayar, Griffin g-kodu türü için doğru meta verileri çıkarmak için kullanılır. Bu bilgiyi kullanarak, yazıcı, g-kodun hangi yazıcı modeli için optimize edildiğini bilebilir. Yazıcı, çeşitli tipteki yazıcılardan oluşan bir grupla bağlantı kurarsa, doğru tip yazıcının bu g-koduyla yazdırılmasına izin verebilir. Tercih edilen yazıcı mevcut değilse, kullanıcıya bu g-kodun bu yazıcı için tasarlanmadığı konusunda bir uyarı verebilir.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**