Portal Yüksekliği
====
Bu ayar, yapı platformu ile baskı kafasının asılı olduğu gantri sistemi arasındaki mesafeyi ölçer. Bu yükseklik, [Birer Birer](../blackmagic/print_sequence.md) yazdırırken bir tavana dönüşür, çünkü daha önce yazdırılan nesneler gantriye çarpabilir.

![Yazdırma kafası ölçüleri](../images/head_dimensions.svg)

Çoğu 3D yazıcı, baskı kafasının asılı olduğu bir çapraz kiriş veya ikiye sahiptir. Bu gantrinin şekli, Cura tarafından model olarak belirtilmez: iki çapraz kiriş, tek bir yönden gelen tek bir koldan veya baskı kafasının tek bir yönde hareket edebileceği bir çapraz kiriş olsun, Cura bu gantriyi tek tek yazdırırken sert bir tavan olarak görür. Modellerin hangi sırayla yazdırıldığına bakılmaksızın. Tek tek yazdırırken, yapı hacmi yüksekliği bu gantri yüksekliğine indirilir, böylece gantri yüksekliğinden daha yüksek modellerin izin verilmediği belirtilir.

Tek bir istisna, yapı platformunda yalnızca bir nesnenin yüklendiği durumdur. Bu nesne, gantri ile çarpışabilecek başka hiçbir şey olmadığından, gantri yüksekliğinden daha yüksek olabilir.

**Bu bir makine ayarı olduğundan, normal ayarlar listesinde normal olarak listelenmez. Gantri yüksekliği, tercihler iletişim kutusundaki eklenmiş yazıcılar listesinde bulunan yazıcı ayarları iletişim kutusunda değiştirilebilir.**