Isıtılmış Yapı Levhası İçerir
====
Bu ayar, yazıcının sıcaklık kontrolü yapabilen bir yapı tablasına sahip olup olmadığını belirtir. Bu tür yapı tablaları, baskı ve yapı tablası arasındaki yapışmayı iyileştirmek için birçok 3D yazıcıya takılmıştır.

Eğer yazıcının ısıtmalı bir yapı tablası yoksa, [Yapı Levhası Sıcaklığı](../material/material_bed_temperature.md) ayarı ve ilgili ayarlar kullanıcıya gösterilmeyecektir. Ayrıca, Cura yazıcıya herhangi bir yapı tablası sıcaklık komutu göndermeyecektir.

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez. Ancak, tercihler penceresinde eklenen yazıcıların listesinde bulunan yazıcı ayarları içinde bu ayar için bir onay kutusu bulunmaktadır.**