Soğuma hızı
====
Bu ayar, nozulun ısıtılmadığı zamanlarda ne kadar hızlı soğuduğunu Cura'ya söyler. Bu, nozul değiştirilmeden önce nozulun ön soğutulmasını ne zaman başlatacağını tahmin etmek için kullanılır.

![Nozullar, nozul değiştirilmeden önce önceden ısıtılmaya başlar](../images/temperature_regulation.svg)

Nozul değiştirilirken, Cura, aktif nozulu biraz daha az akıtarak beklerken nozulu ön soğutmaya başlar. Cura ayrıca, nozulun ne kadar soğuduğunu tahmin etmeye çalışırken ne kadar pasif olduğunu da tahmin etmeye çalışır. Bu şekilde, sonrasında ne kadar ısıtmaya ihtiyaç duyacağını bilir.

Nozulun, bu ayarın gösterdiğinden daha hızlı soğuduğu durumlarda, nozul aslında Cura'nın tahmin ettiğinden daha hızlı bir şekilde bekleme sıcaklığına ulaşır. Sonuç olarak, nozulu ısıtmak Cura'nın tahmin ettiğinden daha uzun sürebilir ve yazıcı, bu nozulun daha da ısıtılması için beklerken nozul değişiminde kalabilir.

Nozulun, bu ayarın gösterdiğinden daha yavaş soğuduğu durumlarda, Cura bir nozulu ön ısıtmak için bir komut gönderdiğinde nozul hala sıcak olabilir, bu da hızlı bir şekilde ısınmasına neden olur. Nozulun sıra gelene kadar bir süre baskı sıcaklığında olacak. Bu süre zarfında biraz sızabilir ve plastik biraz daha fazla bozulabilir.

Gerçek soğuma hızı, sabit bir hızda derece başına saniye cinsinden değildir. Daha olası olarak, mevcut nozul sıcaklığı ile baskı hacminin sıcaklığı arasındaki farka bağlı olacaktır. Bu nedenle, sıcakken daha hızlı soğur ve bekleme sıcaklığına yaklaştıkça daha yavaş soğur. Bunun ayarlanması için bu ayarı ayarlarken, [Son Yazdırma Sıcaklığı](../material/material_final_print_temperature.md)'ndan [Bekleme Sıcaklığı](../material/material_standby_temperature.md) soğuma süresini ölçerek dengelemeye çalışın. Bu, Cura'nın denemeye çalışacağı en önemli izdir. Küçük baskılar yaparken, nozulun daha sık sıcak kalması için soğutma hızını biraz artırabilirsiniz.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**