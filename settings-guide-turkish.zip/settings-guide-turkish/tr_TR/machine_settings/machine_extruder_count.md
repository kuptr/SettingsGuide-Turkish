Ekstrüder Sayısı
====
Bu ayar, bu yazıcının kaç ekstruderi olduğunu yapılandırır. Bazı yazıcılar, aynı baskı sırasında kullandıkları malzemeyi değiştirebilmek için birden fazla ekstrudere sahiptir.

Her bir ekstruder için, Cura ayrı bir sekme gösterecektir. Ayarlar genellikle ayrı ayrı ayarlanabilir, ancak bazı ayarlar ekstruder başına ayarlanamaz (örneğin, yapı hacmi sıcaklığı gibi). Ekstruder sayısı, ayrıca Cura'nın mevcut yazıcı için kullanılabilir ekstruder tanım dosyaları tarafından da sınırlıdır, çünkü Cura ayrıca bu ekstruderler hakkında daha fazla bilgiye ihtiyaç duyar, örneğin baskı kafasındaki göreli konumları gibi.

**Bu bir makine ayarı olduğu için, genellikle normal ayar listesinde listelenmez. Tercihler iletişim kutusundaki eklenen yazıcıların listesinde bulunan yazıcı ayarları iletişim kutusunda bir açılır widget bulunmaktadır.**