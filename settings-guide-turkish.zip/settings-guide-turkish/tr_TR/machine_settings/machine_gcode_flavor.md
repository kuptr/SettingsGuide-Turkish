G-code Türü
====
G-kodu, 3D yazıcılar gibi CNC makinelerine talimat iletişimi için standartlaştırılmış bir formattır, ancak her yazıcının desteklediği hangi g-kodlar olduğunda, başlangıç durumları ve bazen komutları nasıl yorumladıklarında hala bazı farklılıklar vardır. G-kodu lezzeti ile yazıcınızın hangi komut kümesini kabul ettiğini büyük ölçüde belirtebilirsiniz.

Bu g-kodu lezzetleri arasındaki fark genellikle oldukça küçüktür. En önemli komutlar, yani hareket etme ve nozulu ısıtma, genellikle aynıdır.

Doğru g-kodu lezzetini seçmek için, yazıcınızın firmware belgelerine başvurun. Hangi özelliklerin desteklendiğini ve hangilerinin desteklenmediğini size söylemelidir. İşte Cura'daki mevcut lezzetler ve farkları.

Marlin
----
Marlin, varsayılan g-kodu lezzeti olarak kabul edilir. Bu, en popüler 3D yazıcı firmware'i olan [Marlin firmware](https://marlinfw.org/) için tasarlanmıştır ve mevcut alternatif firmware'lerin çoğunun temelini oluşturur.

Marlin (Volumetric)
----
Bu, Marlin'in bir varyantıdır ve ekstrüzyon komutları, filament uzunlukları yerine kübik milimetre cinsinden ne kadar ekstrüde edildiğini belirtir. Bunlar dikkate değer değişikliklerdir:
* `G1` komutunun `E` parametresi, bu hareket sırasında beslenen plastik hacmi olan kübik milimetre cinsinden hesaplanır, filament uzunluğu yerine.
* G-kodun başındaki istatistikler de kullanılan filamenti kübik milimetre cinsinden belirtir.

RepRap
----
Bu, [RepRap project](https://reprap.org/wiki/RepRap) evrimleşen yazıcıları desteklemeye odaklanan bir lezzettir. Birkaç dikkate değer istisnası vardır:
* İlk kat sıcaklığını ayarlarken, bir ekstruder olsa bile her zaman ekstruder belirt.
* Baskıdan sonra her zaman göreli ekstrüzyona geri dön.
* Hareket hızlarını, baskı hızı ve seyahat hızı için sırasıyla `M204` komutunun `P` ve `T` parametreleri kullanılarak değiştirin, `S` parametresi yerine.
* Sarsıntıyı, `M566` komutunu kullanarak değiştirin, `M205` komutu yerine.

Ultimaker 2
----
Bu g-kodu lezzeti, Ultimaker 2 ailesi için tasarlanmıştır. Bu ailenin firmware'i, yazıcının malzemeyle ilgili ayarları dilimleyici yerine yazıcıyı kontrol etmesine izin vermesi gerektiği garip bir fikre sahipti. Bunlar istisnalarıdır:
* G-kodunda baskı sıcaklık komutları olmayacaktır.
* G-kodunda yapı platformu sıcaklık komutları olmayacaktır.
* G-kodunda yapı hacmi sıcaklık komutları olmayacaktır.
* Baskı başladığında, ilk nozul, baskı başladığında [İlk Katman Yazdırma Sıcaklığı](../material/material_print_temperature_layer_0.md)'na sahip olarak varsayılır.
* Baskı başladığında, yapı platformunun [İlk Katman Yapı Levhası Sıcaklığı](../material/material_bed_temperature_layer_0.md)'na sahip olduğu varsayılır.
* `G1` Komutunun `E` parametresi, bu hareket sırasında beslenen plastik hacmi olan kübik milimetre cinsinden hesaplanır, filament uzunluğu yerine.
* G-kodun başındaki istatistikler kullanılan filamenti kübik milimetre cinsinden belirtir.

Griffin
----
Bu, modern Ultimaker yazıcıları, Ultimaker 3 ve daha yenileri için g-kodu lezzetidir. Bu yazıcılar, g-kodu başlangıcında belirli bir formatta bir dizi meta veriye ihtiyaç duyarlar. Bu g-kodu lezzetindeki farklar şunlardır:
* G-kodu başında, baskının süresi, baskı işinin adı ve başlangıç sıcaklığı gibi meta verileri içeren büyük bir başlık bulunur.
* G-kodunda yapı hacmi sıcaklık komutları olmayacaktır.
* Baskı başladığında, ilk nozul [İlk Katman Yazdırma Sıcaklığı](../material/material_print_temperature_layer_0.md)'na sahip olarak varsayılır.
* Baskı başladığında, yapı platformu [İlk Katman Yapı Levhası Sıcaklığı](../material/material_bed_temperature_layer_0.md)'na sahip olduğu varsayılır.
* Yazıcının ilk ekstrüderde başlayacağı varsayılmaz, bu nedenle yazıcı, baskı başladığında bir `T` komutu kullanarak başlangıç ekstrüderine her zaman geçiş yapar.
* Her ekstrüder için bir `G280` komutuyla bir başlangıç bloğu yazdırılır, başlangıçta bir geri çekme yerine.

Makerbot
----
Bu, [Sailfish](https://www.sailfishfirmware.com/) tabanlı firmware için tasarlanmış bir g-kodu lezzetidir. Bu firmware, orijinal Makerbot yazıcılarının soyundan gelenlerde kullanılır. Bazı dikkate değer farklar şunlardır:
* Baskı sıcaklığını değiştirirken, bekleme yapmayan `M104` komutu kullanılır, bekleme yapmayan `M109` (sıcaklık ayarla ve bekle) desteklenmez. Ardından, bu sıcaklığa ulaşılana kadar bekleme yapması için `M116` kullanır.
* `G1` Ekstrüzyon komutunun `E` boyutu, baskı sırasında sıfırlanmaz. Diğer lezzetlerde bu parametre, her 10 metrelik filamentten sonra bir `G92 E0` komutu kullanılarak sıfırlanır, ancak bu lezzette yapılmaz.
* Ekstrüder değişimleri, `T` komutları yerine `M135` komutuyla gerçekleşir.
* Fan hızı çıktıya alınmaz. Fan tamamen açık veya tamamen kapalıdır. Cura, fan hızının %50 veya daha fazlasını istemesi durumunda yazıcıya fanı açması için komut verecektir.

Bits from Bytes
----
Bu, özel bir firmware'e sahip olan Bits from Bytes yazıcılarına yönelik bir g-kodu lezzetidir. Bu g-kodu lezzeti, diğerlerinden oldukça farklıdır. Cura'nın yapacağı değişiklikler şunlardır:
* Ekstrüzyon miktarları, `E` parametresi yerine besleyicinin RPM'si kullanılarak yazılır.
* Geri çekilmeler, etkin ekstrüdere bağlı olarak `M101` veya `M201` ile yazılır.
* Geri çekme hızı ayrı bir `M108` komutuyla yazılır.
* Seyahat hareketleri, `G1` komutunu `G0` ile değiştirmek yerine bir `M103` komutu ile belirtilir. `G0` komutları olmayacaktır.
* Yazıcı, otomatik geri çekme kullanmak üzere `M227` komutuyla ayarlanır.
* Cura, yalnızca bir yeni satır sembolü yerine, bir satır başı karakteri ile başlayan Windows tarzı yeni satırlar çıktılar.
* `G1` Ekstrüzyon komutunun `E` boyutu, baskı sırasında sıfırlanmaz. Diğer lezzetlerde bu parametre, her 10 metrelik filamentten sonra bir `G92 E0` komutu kullanılarak sıfırlanır, ancak bu lezzette yapılmaz.

Mach3
----
Bu, CNC freze makinelerinin g-kodu beklentilerine daha yakın kalan bir g-kodu lezzetidir. Tek dikkate değer fark şudur:
* Ekstrüzyon miktarları, `E`parametresi yerine `G1` komutunun `A` parametresi kullanılarak yazılır.

Repetier
----
Bu, Repetier tarafından üretilen 3D yazıcılar için tasarlanmış bir g-kodu lezzetidir. Repetier dilimleyicisinin çıktısını taklit eder. Bu g-kodu lezzetiyle ilgili dikkate değer farklar şunlardır:
* Firmware geri çekmeleri etkinleştirildiğinde, ekstrüder değişimi için geri çekilmeler, bunun bir ekstrüder değişimi için bir geri çekme olduğunu belirtmek için `G10 S1` kullanılır.
* Hızlanma değişiklikleri, `M204` yerine (sırasıyla baskı hızlanması ve seyahat hızlanması için) `M201` ve `M202` komutları kullanılarak yapılır.
* Jerk değişiklikleri, `M205` komutu yerine `M207` komutu kullanılarak yapılır.

**Bu bir makine ayarı olduğu için, normal ayar listesinde genellikle listelenmez. Ancak, bu ayar için bir seçim menüsü bulunur, bu menü tercihler ile eklenen yazıcılar listesinde bulunabilir.**