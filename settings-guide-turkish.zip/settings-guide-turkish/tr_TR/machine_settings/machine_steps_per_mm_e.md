Milimetre Başına Adım (E)
====
Çoğu 3D yazıcı, filamentin ileri ve geri hareket etmesini sağlamak için besleyicilerinde adım motorları kullanır. Bu motorlar adımlar halinde döner ve adımların iki konumu arasında kalmakta zorlanırlar. Adımlar, besleyicinin hassasiyetidir. Bu ayar, bu hassasiyeti belirtir: Motorun bir milimetre filament hareket ettirmek için kaç adım atması gerektiğini gösterir.

Bu, besleyicilerinde adım motorları kullanmayan yazıcılar için geçerli değildir. Cura, birden fazla besleyici varsa, besleyicilerin adım boyutlarının her ekstrüder için aynı olduğunu varsayar.

Bu ayar, Cura tarafından hiç kullanılmaz. Ancak, X3Gwriter eklentisi tarafından X3G dosyalarını doğru adım boyutlarıyla çıkarmak için kullanılır.

**Bu bir makine ayarı olduğundan, bu ayar normalde ayarlar listesinde görünmez.**