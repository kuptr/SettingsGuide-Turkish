Filament Park Mesafesi
====
Bu ayar, artık kullanılmayan filamenti nereye park edileceğini belirtmek için kullanılır. Birden fazla ekstruderle baskı yaparken, ekstruderlerden biri diğerinden daha yüksek bir yükseklikte baskı yapmaya gerek duymuyorsa, filament son kullanımından hemen sonra bir park konumuna yerleştirilirdi. Ancak artık bu yapılmıyor. Bunun yerine, filamenti [Nozül Anahtarı Geri Çekme Mesafesi](../dual/switch_extruder_retraction_amount.md)'ne çekecektir.

**Bu bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görünmez.**