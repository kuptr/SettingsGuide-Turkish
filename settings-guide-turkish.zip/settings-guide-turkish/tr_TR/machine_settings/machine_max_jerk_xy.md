Varsayılan X-Y Salınımı
====
Bu ayar, Cura'nın baskıda [Salınım Kontrolünü Etkinleştir](../speed/jerk_enabled.md) durumlarda yazıcınızın X ve Y yönleri için kullandığı salınım oranını gösterir.

Cura, firmware'ninizin X ve Y yönleri için aynı salınım oranını kullandığını varsayar, ancak bu salınım oranı Z yönü ve besleyici için farklı olabilir.

Bu, Cura'nın salınım oranlarını kontrol etmediği durumlar için doğru zaman tahminleri almak için kullanılır. Tüm baskı aynı salınım oranını kullanacaktır.

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez.**