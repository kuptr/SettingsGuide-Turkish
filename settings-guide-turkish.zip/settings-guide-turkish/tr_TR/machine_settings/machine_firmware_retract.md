Üretici Yazılımı Geri Çekme
====
Normalde, Cura, filamenti biraz geri çekmek için besleyicinin hareketini kontrol ederek bir geri çekme yapar. Bu ayar etkinleştirildiğinde, bunun yerine yazıcıya filamenti geri çekmesi için bir `G10` komutu yazacak veya geri çekmeyi iptal etmesi için bir `G11` komutu yazacaktır.

Firmware geri çekmelerini kullanmayı seçerek, yazıcının firmware'i filamentin ne kadar ve ne kadar hızlı geri çekileceğini kontrol eder. Yazıcı, Cura'dan daha fazla kendi geometrisi hakkında bilgiye sahip olabilir, bu nedenle filamentin nasıl geri çekileceğine daha iyi karar verebilir. Ancak, bu, Cura'nın artık bu geri çekmelerin kontrolünde olmadığı ve Cura'nın baskıyla ilgili daha fazla bilgiye sahip olduğu anlamına gelir. Temelde, dilimleyici ve firmware farklı bilgilere sahiptir ve bu ayar hangisinin seçim yapacağını belirler.

**Bu bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görünmez.**