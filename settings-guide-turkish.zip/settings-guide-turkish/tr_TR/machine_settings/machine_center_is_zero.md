Merkez Nokta
====
Bu ayar etkinleştirildiğinde, yazıcının 0,0 koordinatı imalat hacminin ortasına yerleştirilir, ön sol köşeye değil.

Bazı yazıcılarda, firmware 0,0 koordinatını imalat hacminin ortası olarak kabul eder. Bu, genellikle silindirik imalat hacimlerine sahip delta tarzı yazıcılarda yaygındır ve bunlar genellikle küpoidler yerine silindirik imalat hacimlerine sahiptir.

Yazıcının sıfır koordinatı merkezdeyse, o zaman son g-kodu negatif koordinatları da içerecek şekilde düzenlenir. Koordinat kökeni Cura'nın imalat hacminin ortasında olacaktır. Cura ayrıca üç renkli koordinat göstergesini merkezde gösterecektir. Ancak 3MF dosyalarının koordinatları hala 3MF dosya formatının bunu gerektirmesi nedeniyle yazıcının ön sol köşesindeki koordinat kökeni olarak ele alınacaktır.

**Bu bir makine ayarı olduğundan, normal ayarlar listesinde normal olarak görüntülenmez. Ancak bu ayarın onay kutusu, tercihler iletişim kutusundaki eklenen yazıcıların listesinde bulunabilir.**