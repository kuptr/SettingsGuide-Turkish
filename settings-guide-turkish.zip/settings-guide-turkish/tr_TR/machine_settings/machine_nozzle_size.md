Nozül Çapı
====
Bu ayar, malzemenin akışının gerçekleştiği nozül açıklığının çapını ölçer.

![Baskı kafası boyutları](../images/head_dimensions.svg)

Bu, diğer ayarların varsayılanlarını belirlemekte kullandığı önemli bir boyuttur. En önemlisi, [Hat Genişliği](../resolution/line_width.md) genellikle nozül boyutuna göre ayarlanır. Bazı yazıcı profilleri, katman yüksekliğini de genellikle nozül boyutuna bağlı olarak sınırlar, çünkü nozül boyutu malzemenin ne kadar hızlı ekstrüde edilebileceğinde en önemli faktördür.

<!--if cura_version < 5.0:The nozzle size is also used directly, for one detail: When filling [tiny gaps](../shell/fill_perimeter_gaps.md), line pieces further than two nozzle sizes away from each other are not merged together.-->

Fiziksel nozülü değiştirmiyorsanız, nozül boyutunu ayarlamayın. Bazı dilimleme yazılımları (bunlar arasında Cura 15.04 ve daha önceki sürümler de bulunur), "nozül boyutu" terimini baskının çizgilerinin ne kadar geniş olması gerektiği anlamında kullanır. Cura bunun için [Hat Genişliği](../resolution/line_width.md) ayarını kullanır.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez. Yazıcınızın mevcut nozüller için özel profillere sahipse, bunlardan seçim yapabilirsiniz. Aksi takdirde, nozül çapını tercihler iletişim kutusundaki (preferences dialogue) eklenen yazıcılar listesinde bulunan yazıcı ayarları iletişim kutusunda ayarlayabilirsiniz.**