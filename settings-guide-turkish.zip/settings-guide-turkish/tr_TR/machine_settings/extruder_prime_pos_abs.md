Mutlak Ekstruder İlk Konumu
====
Eğer [İlk Damlayı Etkinleştir](../platform_adhesion/prime_blob_enable.md) kullanılıyorsa, bu başlatma işleminin konumu bir [Extruder İlk X konumu](../platform_adhesion/extruder_prime_pos_x.md) ve [Extruder İlk Y konumu](../platform_adhesion/extruder_prime_pos_y.md) pozisyonu ile ayarlanabilir. Bu ayar, bu pozisyonun yapının üzerinde mi yoksa mevcut yazıcı pozisyonuna göre mi belirlendiğini belirler.

Bu ayar etkinleştirilmişse, X ve Y koordinatları her zaman bir yapının üzerinde belirli bir sabit konumu gösterir. Ekstruder, başlatma topağı oluşturmak için her zaman oraya hareket eder.

Bu ayar devre dışı bırakılmışsa, X ve Y koordinatları, nozulun o ekstrüdöre ilk geçişinde sahip olduğu konuma göre belirlenir. İlk ekstruder için bu, [0,0] koordinatı olacaktır. Diğer ekstruderler için, bu ekstrüdörün tanım dosyasında tanımlanan başlangıç konumu olacaktır. Bu başlangıç konumu da göreli olabilir.

Mutlak bir başlatma konumu kullanmanız şiddetle tavsiye edilir. Mutlak bir başlatma konumu, yapının diğer parçalarıyla çarpışmalardan uzak olduğundan emindir, çünkü bu yere nesneler yerleştiremezsiniz. Göreli bir başlatma konumu herhangi bir yerde bitirebilir ve sonuç olarak birinci katmanınızın üzerinde bir yere başlatma yapabilirsiniz. Göreli bir başlatma konumu kullanmak bazı seyahat zamanından tasarruf edebilir, ancak bu gerçekten riske değmez.

**Bu bir makine ayarı olduğundan, bu ayar genellikle ayarlar listesinde görünmez.**