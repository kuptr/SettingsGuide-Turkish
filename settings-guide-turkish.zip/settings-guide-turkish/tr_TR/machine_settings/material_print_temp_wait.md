Nozülün Isınmasını Bekle
====
İlk katman, [Yazdırma Sıcaklığı](../material/material_print_temperature.md) parçanın geri kalanından farklı bir [ozul sıcaklığına](../material/material_print_temperature_layer_0.md) sahip olabilir. Bu ayar etkinleştirildiğinde, yazıcı, baskıya devam etmeden önce o sıcaklığa ulaşılıncaya kadar bekler.

Isınma veya soğuma sürecinde uygun sıcaklığa ulaşılıncaya kadar bekleyecektir. Bu ayarın etiketi ısınma için bekleyeceğini söylese de, soğuma işlemi de aynı şekilde gerçekleşir. Nozül, [İlk Yazdırma Sıcaklığı](../material/material_initial_print_temperature.md), [Son Yazdırma Sıcaklığı](../material/material_final_print_temperature.md) veya [Bekleme Sıcaklığı](../material/material_standby_temperature.md) gibi diğer sıcaklık değişikliklerini beklemeyecektir. [Birer Birer](../blackmagic/print_sequence.md) ile baskı yapılıyorsa, nozül, bir sonraki nesneler için ilk katmana geri dönmek zorunda kaldığında ilk katman sıcaklığına ulaşılıncaya kadar bekleyecektir.

**Bu bir makine ayarı olduğundan, bu ayar normalde ayarlar listesinde görünmez.**