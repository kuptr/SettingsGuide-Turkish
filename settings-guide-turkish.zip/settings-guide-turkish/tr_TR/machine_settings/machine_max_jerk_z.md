Default Z Jerk
====
Bu ayar, Cura'nın baskıda [Salınım Kontrolünü Etkinleştir](../speed/jerk_enabled.md) durumlarda yazıcınızın Z yönü için kullandığı salınım oranını gösterir.

Bu, Cura'nın salınım oranlarını kontrol etmediği durumlar için doğru zaman tahminleri almak için kullanılır. Tüm baskı aynı salınım oranını kullanacaktır.

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez.**