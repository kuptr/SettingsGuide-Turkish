Isı Bölgesi Uzunluğu
====
Bu ayar, nozül ucundan ve filamentin ısınmaya başladığı nokta arasındaki mesafeyi ölçer.

Isı bölgesi, filamentin baskı sırasında konumlandırılması için "tehlike bölgesini" belirler. Nozül sıcakken ve filament bu ısı bölgesindeyken, filament erir ve bozulabilir. Bu ölçüm, bu nedenle [Nozül Anahtarı Geri Çekme Mesafesi](../dual/switch_extruder_retraction_amount.md) veya [Filament Park Mesafesi](machine_filament_park_distance.md) gibi uzun süreli geri çekilmeler için iyi bir başlangıç noktasıdır. Bazı profillerin geri çekilme uzunlukları, ısı bölgesi uzunluğuna bağlıdır.

**Bu bir makine ayarı olduğu için, bu ayar genellikle ayar listesinde görünmez.**