Z Kapaması Pozitif Yönde
====
Bu ayar, yazıcının ev konumuna getirildiğinde Z ekseni boyunca hangi yönde hareket edeceğini Cura'ya söyler. Bu ayar devre dışı bırakıldığında, Z ekseni için endstop'un yapı hacminin sıfır (veya negatif) koordinatında olduğunu varsayar. Ayar etkinleştirildiğinde, Z ekseni için endstop'un yazıcının maksimum Z koordinatında olduğunu varsayar. Yazıcı ev konumuna getirildiğinde, yazıcı kafasının nerede olduğunu bilmek için bu endstop'lara doğru hareket etmesi gerekecektir.

Bu ayar hiçbir şekilde Cura tarafından kullanılmaz. Ancak, X3GWriter eklentisi, X3G araç yolu dosyası yazılırken ev konumu g-kodu komutunu doğru şekilde uygulamak için bu ayarı kullanır.

**Bu bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görünmez.**