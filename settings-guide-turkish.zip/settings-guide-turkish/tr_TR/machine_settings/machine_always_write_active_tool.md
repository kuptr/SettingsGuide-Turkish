Her Zaman Aktif Aracı Yaz
====
Bu ayar, belirli bir araca ait bir araç parametresi içeren bazı g-kodu komutlarının yazıcı tarafından nasıl yorumlanacağını belirtir. Bazı g-kodu komutları, hangi ekstrüde uygulandığını belirtmek için bir parametre içerebilir. Bazı yazılımlar bu parametreyi, o araca geçip ardından g-kodu komutunu çalıştırmak olarak yorumlar, bazı yazılımlar ise bu parametreyi, g-kodu komutunu geçerli olan aracın farklı bir ekstrüde uygulanacak şekilde yapılması için bir komut olarak yorumlar.

3D baskıyla ilgili bu ayarın uygulandığı tek komutlar, nozul ısıtma komutları olan `M104` ve `M109` komutlarıdır. Birinci ekstrüder (`T0`) baskı yaparken aşağıdaki ısıtma komutu örneğini düşünün:

`M104 S210 T1`

Bu komutun iki olası yorumu vardır:
* Birinci ekstrüde devam ederken, ikinci ekstrüde 210°C'ye ısıtılmaya başlanır. Bu yorum, Marlin, Reprap, Sailfish ve bunların türetilmiş yazılım paketleri tarafından kabul edilen yorumdur.
* İlk olarak ikinci ekstrüde geçilir, ardından ikinci ekstrüde 210°C'ye ısıtılır. Bu yorum, Smoothieware ve türetilmiş yazılımları tarafından kabul edilen yorumdur.

Cura'nın sıcaklık düzenleme stratejisi nedeniyle, ikinci yorumu hiçbir zaman çalıştırması gerekmez. Yazıcı g-kodu komutunu ikinci şekilde yorumlarsa, Cura aşağıdaki g-kodu komutunu yazacaktır:

`M104 S210 T1`

`T0`

Temel olarak, yazıcının o komut nedeniyle ikinci ekstrüde geçeceğini bildiği için, baskıya devam etmek için ilk ekstrüde geri dönmesi gerekir.

**Bu bir makine ayarı olduğundan, normal ayarlar listesinde normal olarak görüntülenmez.**