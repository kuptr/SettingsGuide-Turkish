Yapı Levhasının Isınmasını Bekle
====
Bu ayar etkinleştirildiğinde, yazıcı yapı plakası sıcaklığı her değiştiğinde, yapı plakası sıcaklığına ulaşana kadar bekleyecektir.

Yapı plakası sıcaklığı genellikle sadece ilk katmandan sonra değiştirilir, eğer [İlk Katman Yapı Levhası Sıcaklığı](../material/material_bed_temperature_layer_0.md) normal [Yapı Levhası Sıcaklığı](../material/material_bed_temperature.md) ile farklıysa. [Birer Birer](../blackmagic/print_sequence.md) ile yazdırılırken, yapı plakası bir sonraki model için tekrar ilk katmanla başladığında da değiştirilir. Bu durumlarda, yazıcı yeni sıcaklığa ulaşana kadar baskıya devam etmeyecektir.

**Bu bir makine ayarı olduğundan, bu ayar normalde ayarlar listesinde görünmez.**