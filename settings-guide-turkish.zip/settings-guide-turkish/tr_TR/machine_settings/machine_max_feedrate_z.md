Maksimum Z Hızı
====
Bu ayar, yazıcınızın Z yönünde ulaşabileceği maksimum hızı gösterir.

Bu, [Z Atlama Hızı](../speed/speed_z_hop.md) sınırlamak için kullanılır. Yazıcınızın alabileceği maksimum hızdan daha yüksek bir Z atlama hızı kullanamazsınız.

**Bu bir makine ayarı olduğu için, bu ayar genellikle normal ayar listesinde listelenmez.**