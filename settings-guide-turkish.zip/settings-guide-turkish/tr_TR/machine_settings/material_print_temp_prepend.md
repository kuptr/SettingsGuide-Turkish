Yapı Levhası Sıcaklığını Ekle
====
Bu ayar, dilimleme arka ucuyla iletişim kurarak baskı işleminin başlangıcında başlangıç g-kodu öncesinde yapı plakası sıcaklık komutlarının yazılıp yazılmaması gerektiğini belirtir. Dilimleme işlemi başladığında otomatik olarak ayarlanır.

[G-code’u Başlat](machine_start_gcode.md) sırasında çoğu işlem için baskı için doğru sıcaklığa ulaşmış bir yapı plakasının olması mantıklıdır. Yazıcı tanımları tasarlamayı kolaylaştırmak için Cura, başlangıç g-kodu yürütülmeden önce yapı plakasını otomatik olarak ısıtır. Ancak, başlangıç g-kodu herhangi bir yapı plakası sıcaklık ayarı referansı içeriyorsa, artık yapı plakasını otomatik olarak ısıtmaz.

**Bu bir makine ayarı olduğundan, bu ayar normalde ayarlar listesinde görünmez. Değiştirmenin bir etkisi yoktur çünkü Cura tarafından otomatik olarak değiştirilecektir.**