Isınma Hızı
====
Bu ayar, yazıcınızın bu nozulu ne kadar hızlı ısıtabileceğini Cura'ya bildirir. Bu, nozulu değiştirmeden önce nozulu ne zaman ön-isitmeye başlayacağını tahmin etmek için kullanılır.

![Nozullar değiştirilmeden önce ön-ısınmaya başlar](../images/temperature_regulation.svg)

Nozulları değiştirirken, Cura, bir sonraki nozulu ihtiyacı olduğunda kullanılmak üzere önceden ısıtmaya başlar, böylece diğer ekstruder işini bitirdiğinde hazır olur. Bunu yapmak için, mevcut nozul sıcaklığı ile hedef nozul sıcaklığı arasındaki farkı alır ve bunu ısıtma hızına böler ve nozulu ön-ısıtmak için bir süre belirler.

Eğer nozul, bu ayarın gösterdiğinden daha hızlı ısınıyorsa, diğer ekstruder baskıyı bitirmeden önce nozul bir süre hedef sıcaklıkta olacaktır. Bu süre boyunca bir miktar malzeme akacaktır ve plastik nozulda biraz bozulabilir, bu da [underextrusion/düşük ekstrüdere](../troubleshooting/underextrusion.md) neden olabilir.

Eğer nozul, bu ayarın gösterdiğinden daha yavaş ısınıyorsa, yazıcı, nozulun baskı yapmak için istenen sıcaklığa ulaşana kadar ekstruder değişiminde beklemek zorunda kalacaktır. Bu ekstra bir süre gerektirecektir. Bunun dışında, önceki ekstruder de bu bekleme süresince son baskı sıcaklığında tutulacaktır, bu da daha fazla malzeme akmasına ve plastik nozulda bir kez daha bozulmasına neden olacaktır. Bu, dilimin sırasında Cura'nın beklediğinden daha fazla soğumasını önlemek için gereklidir, bu da Cura'nın beklediğinden daha büyük bir farka neden olacak ve böylece bir sonraki seferki beklemeyi daha da uzatacaktır. Bu, her katmanla birlikte tahmini daha da kötü hale getiren bir kaçış etkisine yol açacaktır, bu nedenle Cura, diğer nozulun sıcaklığına ulaşılana kadar önceki malzemeyi sıcak tutmak zorundadır.

Gerçek ısıtma hızı, sabit bir hız değildir, saniyedeki derece cinsinden bir orandır. Daha olası olarak, mevcut nozul sıcaklığı ile yapı inşaatı sıcaklığı arasındaki farka bağlı olacaktır. Bu nedenle, soğukken daha hızlı ısınacak ve hedef sıcaklığa yaklaştıkça daha yavaş ısınacaktır. Yazıcının PID regülatörü de bunun için büyük bir rol oynar. Çoğu regülatör, hedef sıcaklığa ulaşmadan hemen önce ısıtmanın yavaşladığından sıcaklığın aşırıya çıkmasını önlemek için yavaşlatır. Bunu ayarlarken, önemli olan, [Bekleme Sıcaklığı](../material/material_standby_temperature.md)'dan [İlk Yazdırma Sıcaklığı](../material/material_initial_print_temperature.md) ısıtmak için ne kadar süreceğini ölçmektir. Bu, Cura'nın tahmin etmeye çalışacağı en önemli izdir. Küçük baskılar yaparken, ısıtma hızını biraz düşürebilir ve bu, bekleme sıcaklığından değil, daha yüksek bir sıcaklıktan başlayacağı için ayarlamak için kullanılabilir.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**