Nozül Uzunluğu
====
Bu ayar, nozulun ucunun ve yazıcının ana gövdesinin arasındaki mesafeyi içerir.

![Baskı kafası boyutları](../images/head_dimensions.svg)

Bu ayar, Cura tarafından kullanılmaz, ancak profiller diğer ayarların değerlerini belirlemek için kullanabilir, örneğin [Wire Printing Connection Height/Tel Baskı Bağlantı Yüksekliği](../experimental/wireframe_height.md).

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**