Dış Nozül Çapı
====
Bu ayar, nozül ucunun en ince noktasındaki dış çapını tanımlar, alt kısmında.

![Baskı kafası boyutları](../images/head_dimensions.svg)

Diğer ayarlar, bu değeri otomatik olarak bazı varsayılanları ayarlamak için kullanabilir, örneğin ütüleme çizgileri arasındaki boşluğu.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**