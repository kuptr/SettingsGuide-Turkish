Minimum Sürede Bekleme Sıcaklığı
====
Bu ayar, stand-by modunda olma süresinin minimum süresini yapılandırır. Nozul, bu ayarın altında bir süre boyunca stand-by modunda olacaksa, soğutulmaz ve bunun yerine [Son Yazdırma Sıcaklığı](../material/material_final_print_temperature.md) sabitlenir.

Nozulunuzun bir PID regülatörü vardır, bu regülatör nozulu ısıtmak için kullanılan gücü ne kadar düzenleyeceğini düzenler ve doğru sıcaklıklara ulaşmak için. Nozulun hızlı bir şekilde soğutulup ve ısıtılmasına ilişkin büyük sıcaklık farkları ile komutlandığında, PID regülatörü genellikle ne kadar ısı gerektiğini yanlış tahmin eder. Bu, gerçek nozul sıcaklığında geniş dalgalanmalara neden olur. Bu ayar ile, nozulun çok kısa bir süre için pasif durumda olduğunda [Bekleme Sıcaklığı](../material/material_standby_temperature.md) gitmesini önleyebilirsiniz.

Bu ayarın optimal değeri PID regülatörünüzün ayarına bağlıdır. Bazı regülatörler hızlı hedef sıcaklık değişikliklerini diğerlerinden daha iyi yönetir ve bunlar kısa bir stand-by süresini daha iyi yönetebilir. Bu ayarı düşürmek, malzemenin nozul içinde bozulmasını önlemeye yardımcı olabilir.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**