Nozül Açısı
====
Bu ayar, nozul ucunun açısını derece cinsinden içerir. Daha düşük bir açı, ucu çok keskin olduğu anlamına gelir. Daha yüksek bir açı, ucu kısayken anlamına gelir.

![Baskı kafası boyutları](../images/head_dimensions.svg)

Bu açı, [wire printing/tel baskı](../experimental/wireframe_enabled.md) kullanırken bitişik kirişler arasındaki boşluğu belirlemek için kullanılır. Nozul çok kısayken, nozulun diğer kirişlere çarpmasını önlemek için dikey kirişlerin çok uzak aralıklarla yerleştirilmesi gerekir.

**Bu, bir makine ayarı olduğu için, bu ayar genellikle ayarlar listesinde görüntülenmez.**