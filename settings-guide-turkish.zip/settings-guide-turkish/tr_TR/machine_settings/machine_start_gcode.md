G-code’u Başlat
====
Bu ayarla, her baskının başlangıcında yürütülecek biraz g-kodu yazılabilir. Bu g-kodu kullanılarak, yazıcı baskıya hazır hale getirilebilir.

Başlangıç g-kodunda genellikle yürütülen bazı örnekler şunlardır:
* Nozulu(ları) hazırlama.
* Yapı tablasını ısıtma.
* Nozulu(ları) ısıtma.
* Doğru ekstrüzyonun seçildiğinden emin olma.
* Fanları, ivmeleri veya titremeleri yapılandırma.
* Otomatik yatak düzleme.
* Doğrusal ileri ayarı yapılandırma.

[RepRap Wiki](https://reprap.org/wiki/G-code)'ye başvurarak mevcut G-kodlarının nispeten kapsamlı bir listesi bulunabilir.

References to settings
----
Başlangıç g-kodunu düzenlerken, diğer ayarların değerlerine başvurabilirsiniz. Bu belirli bir sözdizimini kullanır. Ayarlar, *anahtarları* ile başvurulur. Bu anahtar, Cura'da iç isimdir. Kullanıcı arayüzünde görünmez. Tüm anahtarların tam listesi için, Cura'nın kaynak kodundaki [bu belgeye](https://github.com/Ultimaker/Cura/blob/master/resources/definitions/fdmprinter.def.json) başvurun.

Bir genel ayarın değerini almak için kullanılan sözdizimi şu şekildedir:

`{setting_key}`

Yani, ayarın anahtarını süslü parantez içine yazın. Bu, bir ayarın genel değerini alır. Ancak birçok ayar, her bir ekstruder için farklı olabilir. Bunlar şu şekilde başvurulmalıdır:

`{setting_key, #}`

Burada `#` sembolünün yerine ayarın alınacağı ekstrüder numarasını yazmalısınız. Ekstrüderler 0'dan başlayarak sayılır. Genel ayarlar da bir ekstrüder belirterek alınabilir, ancak bunlar tüm ekstrüderler için aynı olacaktır. Ekstrüder numarasını belirtmeden ekstrüder özel sıcaklık almayı denediğinizde, devre dışı bırakılmış ilk ekstrüderin değerini alırsınız.

Bu referansları örneğin doğru sıcaklığa ön-ısıtmak veya ivmeleri ayarlamak için kullanabilirsiniz. İşte bazı örnekler:

`M104 S{material_print_temperature_layer_0, 0} ;pre-heat`

`M140 S{material_bed_temperature_layer_0} ;heat bed`

`M204 P{acceleration_print, 0} T{acceleration_travel, 0}`

`M205 X{jerk_print, 0}`

Hızlarla dikkatli olun. G-kodu genellikle besleme hızını *dakikada* milimetre cinsinden kabul ederken, ayarlar *saniyede* milimetre cinsinden listelenir. Şu anda doğru besleme hızını seçmenin bir yolu yoktur. Bu referanslarda hesaplama yapmak imkansızdır.

Diğer bilgiler
----
Ayarlara başvurularla aynı sözdizimi aracılığıyla bazı yardımcı bilgiler de mevcuttur:

* `{time}` dilimlendiği günün geçerli yerel saati.
* `{date}` dilimlendiği tarih.
* `{day}` dilimlendiği haftanın günü.
* `{initial_extruder_nr}` baskının hangi ekstrüderle başlayacağına işaret eder.
<!--if cura_version>=4.12-->
* `{material_id}` etkin malzemenin benzersiz tanımlayıcısı. Diğer ayarlar gibi ekstrüderi belirtin.
* `{material_name}` etkin malzemenin adı. Genellikle bu malzemenin satıldığı bir web sitesinde gördüğünüz isimdir.
* `{material_type}` etkin olan malzemenin sınıfı, örneğin PLA veya ABS.
* `{material_brand}` etkin malzemenin üreticisi.
* `{print_time}` baskının tahmini süresi (ISO-8601 biçiminde düzenlenmiştir).
* `{filament_amount}` her bir ekstrüder için kullanılan filamentin uzunluğu, metre cinsinden. Bu, kare parantezlerle çevrili bir liste olarak biçimlendirilir.
* `{filament_weight}` her bir ekstrüder için kullanılan filamentin ağırlığı, gram cinsinden, kare parantezlerle biçimlendirilmiştir. Makaradaki ağırlık bilinmiyorsa, bu 0 olacaktır.
* `{filament_cost}` her bir ekstrüder için kullanılan filamentin maliyeti. Maliyet birimi, tercihlerdeki malzeme yönetimi sayfasında listelenenle aynıdır. Bilinmiyorsa, bu 0 olacaktır.
<!--endif-->

Başlangıç g-kodu öncesinde ısıtma
----
Cura, başlangıç g-kodunuz başlamadan önce ısıtma komutları otomatik olarak verecektir. Bu sayede başlangıç g-kodunuzun nozulun ısıtılması gerektiğini düşünmesine gerek kalmaz. Nozulu hemen hazırlamaya başlayabilirsiniz. Başlangıç g-kodunuz herhangi bir sıcaklık referansı içeriyorsa (nozul veya taban için), bu (nozul veya taban için) devre dışı bırakılacaktır.

**Bu ayar bir makine ayarıdır, bu yüzden normal ayarlar listesinde görünmeyecektir. Tercihler ekranındaki yazıcılar listesine giderek "Makine Ayarları"na tıklayarak değiştirilebilir.**