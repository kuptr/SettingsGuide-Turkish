Ekstruder Ofseti
====
Bu ayar, Cura'nın baskı kafasının mı yoksa nozülün mü hareket etmesi için koordinatlar yazması gerektiğine karar verir.

Yazıcınızda sadece tek bir nozül varsa, yazıcınızın koordinat sistemi büyük olasılıkla nozülünüzle hizalanmıştır. Bu, [50,50] konumuna hareket etmenin aslında nozül ucunu o konuma taşıdığı anlamına gelir. Ancak, yazıcınızda birden fazla nozül varsa ve bu nozüller baskı kafasında yan yana yer alıyorsa, bu durum önemlidir.

Bazı yazıcılar, hangi nozülün etkin olduğuna bakılmaksızın baskı kafasını aynı konuma hareket ettirir. G-kodu yazıcıya [50,50] konumuna hareket etmesini emredebilirken, etkin olan nozülün ucu örneğin ilk nozülün 18 mm sağında olduğundan [68,50] konumuna taşınabilir. Bu durumda, bu ayar etkinleştirilmelidir.

Diğer yazıcılar ise baskı kafasının pozisyonunu otomatik olarak ayarlayarak etkin nozülün g-kodunda belirtilen konuma taşınmasını sağlar. Bu, g-kodu yazıcıya [50,50] konumuna hareket etmesini emrederse, etkin olan ekstruderin o konuma hareket edeceği anlamına gelir. Baskı kafası, etkin ekstruderi o konuma yerleştirmek için biraz yana hareket eder. Yazıcınız bu şekilde davranıyorsa, bu ayar devre dışı bırakılmalıdır.

**Bu bir makine ayarı olduğundan, bu ayar normalde ayarlar listesinde görünmez.**