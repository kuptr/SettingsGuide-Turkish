G-code’u Sonlandır
====
Bu ayarla, her baskının tam sonunda yürütülecek biraz g-kodu yazılabilir. Bu g-kodu kullanılarak, yazıcı bileşenleri kapatılabilir ve baskı işleminden sonra temizlik yapılabilir.

Genellikle bitiş g-kodunda yürütülen yaygın şeyler şunlardır:

* Malzemenin geri çekilmesi.
* Nozulların soğutulması.
* Yapı tabanının soğutulması.
* Fanların kapatılması.

Kullanılabilir g-kodlarının nispeten kapsamlı bir listesi için [RepRap Wiki](https://reprap.org/wiki/G-code)'ye başvurabilirsiniz.

Ayarlara referanslar
----
Bitiş g-kodunu düzenlerken, diğer ayarların değerlerine atıfta bulunabilirsiniz. Bu belirli bir sözdizimi kullanır. Ayarlar, *anahtarlarına* göre belirtilir. Bu anahtar, Cura'da dahili bir isimdir. Kullanıcı arayüzünde görünmez. Tüm anahtarların tam listesi için, Cura'nın kaynak kodundaki [bu belgeye](https://github.com/Ultimaker/Cura/blob/master/resources/definitions/fdmprinter.def.json) bakabilirsiniz.

Bir genel ayarın değerini almak için kullanılan sözdizimi şu şekildedir:

`{setting_key}`

Başka bir deyişle, ayarın anahtarını süslü parantez içine yazın. Bu, bir ayarın genel değerini alacaktır. Ancak, birçok ayar her bir ekstruder için farklı olabilir. Bunlar şu şekilde belirtilmelidir:

`{setting_key, #}`

Burada, ayarın değerini almak için `#` sembolünün yerine ekstruder numarasını yazmalısınız. Ekstruderler 0'dan başlayarak sayılır. Genel ayarlar da bir ekstruder belirterek alınabilir, ancak tüm ekstruderler için aynı olacaktır. Ekstruder numarası belirtilmeden ekstruder özel sıcaklık almak istediğinizde, devre dışı bırakılmamış ilk ekstruder için değeri alırsınız.

Bu referansları, örneğin bir bekleme sıcaklığına soğutma veya yazıcının varsayılan ivme ve jerk'ini geri yüklemek için kullanabilirsiniz. İşte bazı örnekler:

`M104 T0 S{material_standby_temperature, 0} ;stand-by for the next print`

`M104 T1 S{material_standby_temperature, 1}`

`M204 P{machine_acceleration} T{machine_acceleration}`

Hızlarla dikkatli olun. G-kodu genellikle besleme hızını *dakika* başına milimetre cinsinden kabul ederken, ayarlar milimetre başına *saniye* cinsinden listelenir. Şu anda doğru besleme hızını seçmenin bir yolu yoktur. Bu referanslarda hesaplama yapmak imkansızdır.

Diğer bilgiler
----
Ayarlara referanslarla aynı sözdizimiyle, bazı yardımcı bilgiler de mevcuttur:

* `{time}` o an dilimlendiği günün yerel saatine işaret eder.
* `{date}` dilimlendiği tarihe işaret eder.
* `{day}` dilimlendiği haftanın gününe işaret eder.
* `{initial_extruder_nr}` baskının hangi ekstruderle başlayacağına işaret eder.
* `{material_id}` aktif malzemenin benzersiz bir tanımlayıcısına işaret eder. Diğer ayarlar gibi ekstruder belirtiniz.
* `{material_name}` aktif malzemenin adına işaret eder. Genellikle o malzemeyi satan bir web sitesinde göreceğiniz adıdır.
* `{material_type}` aktif olan malzemenin sınıfına işaret eder, örneğin PLA veya ABS.
* `{material_brand}` aktif malzemenin üreticisine işaret eder.

**Bu ayar bir makine ayarıdır, bu nedenle normal ayar listesinde görünmez. "Makine Ayarları"na gitmek için tercihler ekranındaki yazıcı listesine gidip "Makine Ayarları"na tıklamanız gerekir.**