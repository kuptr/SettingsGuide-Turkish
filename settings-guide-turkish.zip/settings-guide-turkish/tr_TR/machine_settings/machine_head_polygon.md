Machine Başlığı Poligonu
====
Bu ayar, şu anda [Makinenin Başlığı ve Fan Poligonu](machine_head_with_fans_polygon.md)  olarak kullanılan ayarla aynı şekilde kullanılan bir ayardı. Bu ayar, [Birer Birer](../blackmagic/print_sequence.md) baskı yapılırken nesneler etrafında çarpışma alanını belirlemek için kullanılıyordu.

![Baskı kafasının boyutları](../images/head_dimensions.svg)

Ancak daha sonraki sürümlerde, fanların da baskı kafasının geri kalanı kadar çarpışabileceği açık hale geldi. Bu ayar, Cura 4.5'te sonunda kaldırıldı, daha önce birçok sürümde etkili bir şekilde kullanılmamış olsa da. Şu anki Cura sürümünüzde bu ayarın hiçbir etkisi yoktur.

**Bu bir makine ayarı olduğu için, bu ayar genellikle ayar listesinde görünmez.**