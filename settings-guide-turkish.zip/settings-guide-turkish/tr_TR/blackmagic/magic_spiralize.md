Spiralize Dış Çevre
====
Spiralize Dış Kontur, bir hile.

Katman katman baskı yaparken, nozül normalde bir katmandan diğerine hareket etmelidir. Bu hareket, nozülün yüzeye neredeyse sabit durması için bir anlık bir zaman bırakır ve buna Z dikişi denir. Bu ayarın amacı bunu önlemek ve daha fazlasını yapmaktır. Baskı sürecini birçok yönüyle büyük ölçüde basitleştirir.

Model spiralize edilirken, model herhangi bir dolgu veya üst almayacaktır. Yalnızca bir duvar ve bir taban alır. Önemli olan şudur ki, [Helezon Şeklinde Düzeltme](smooth_spiralized_contours.md) etkinleştirildiğinde, nozülün yüksekliği bir katman boyunca kademeli olarak artar. Bu şekilde, modelin konturunu takip eden bir spiral oluşturulur. Nozül, bir sonraki katmana kademeli olarak hareket ettiği için bir katmandan diğerine geçerken hiçbir hareket olmaz.

Spiralize modu birçok dilimleme yazılımında yaygındır. Bazen "vazo modu" olarak da bilinir, çünkü vazoları yazdırmak için iyi bir yoldur. Diğer bazı özellikler şunları içerir:
* Çok hızlı baskılar yapar.
* Yüzey çok düz olur. [Helezon Şeklinde Düzeltme](smooth_spiralized_contours.md) etkinleştirildiğinde, bir sonraki katmana geçerken hareket ettiği yerde artık bir [Z Dikişi](../troubleshooting/seam.md) olmaz.
* Çok güçlü olmayacaktır. Model çok büyükse, ince duvar nedeniyle [katman ayrılması](../troubleshooting/layer_splitting.md) gerçekleşebilir.
* Dikişi kaldırmak baskıyı su geçirmez hale getirmeye yardımcı olurken, büyük bir boyuta sahipse baskının su geçirmez olmasını sağlamak zordur. Bunun için en az 2 duvara sahip olmak tavsiye edilir. Dış konturu spiralize etmek bu durumda imkansızdır.

**Spiralize, yatay yüzeylerin çok olduğu baskılarla iyi çalışmaz. Asla askıları işlemez ve üst yüzeyler yazdırmaz, bu nedenle hiçbir şey yatay bir yüzeye dayanamaz. Ayrıca, bir katmanda birden fazla parça olduğunda da iyi çalışmaz.**