Helezon Şeklinde Düzeltme
====
Eğer [Spiral Dış Çevre](magic_spiralize.md) etkinleştirilmişse, bu ayar Spiralize modunun en belirgin özelliğini etkinleştirir veya devre dışı bırakır: Her katmanı birbirini takip eden aralıklarla değil, katman boyunca yükseklik kademeli olarak artar.

Spiralize modu, çoğu katman için yalnızca duvarların basılmasına neden olduğundan, tek bir konturun bir spiral şeklinde oluşması, adını Spiralize özelliğine verir. Baskının ilk ve son katmanları, aşırı ekstrüzyonu önlemek ve doğru yüksekliği elde etmek için akış oranı kademeli olarak azaltılır.

Çünkü Spiralize modu, baskı katmanı boyunca nozulu yavaşça bir sonraki katman yüksekliğine taşır, artık nozulun bir sonraki katmana geçtiği yerde hiç bir dikiş olmayacaktır. Bu etkili bir şekilde Z dikişini kaldırır.

Öte yandan, katman yarı yükseklik kadar yukarı veya aşağı hareket ettirilir. Bu daha az hassastır. Baskıda ince detaylarda bulanık bir etki yapabilir.

Bu ayar, bir katmanda basılacak birden fazla kontur varsa dikişleri kaldırmak için etkili değildir. Hala nozulun bir sonraki basılı parçaya gitmek için konturun sonunda ekstrüzyonu durdurması gerekir. Bu dikiş bırakır.

**Bu etki, katman görünümünde, renderleme sınırlamaları nedeniyle görünmez.**