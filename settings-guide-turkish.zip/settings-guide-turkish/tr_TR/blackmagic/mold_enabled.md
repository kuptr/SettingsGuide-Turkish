Kalıp
====
Bu özellik, modelin kendisini yazdırmak yerine, modelin negatifini oluşturacak şekilde yazıcıyı bir kalıp oluşturmaya yönlendirirsiniz, böylece farklı bir malzeme dökerek modelinizi oluşturabilirsiniz. Bu kalıbın, döküm yapmak için uygulanabilir ve FFF baskı ile yazdırılabilir birkaç özelliği vardır. Bu, [Hızlı Döküm](https://en.wikipedia.org/wiki/Rapid_casting) işlemine olanak tanır.

<!--screenshot {
"image_path": "mold_enabled_shell.png",
"models": [{"script": "stature.scad"}],
"camera_position": [-78, 160, 228],
"layer": -1
}-->
<!--screenshot {
"image_path": "mold_enabled_mould.png",
"models": [{"script": "stature.scad"}],
"camera_position": [-78, 160, 228],
"settings": {
    "mold_enabled": "True"
},
"colours": 32
}-->
![Bir döküm yapmak istediğiniz model](../images/mold_enabled_shell.png)
![Bu model için kalıp](../images/mold_enabled_mould.png)

Cura'nın kalıp oluşturma işlemi, döküm yapmak istediğiniz tam şekilde bir boşluk oluşturur. Bu boşluğun etrafında, [Minimum Kalıp Genişliği](mold_width.md) ayarıyla yapılandırılabilen belirli bir genişlikte bir kabuk oluşturulur. Kalıbın üstünde ve altında, [Kalıp Çatı Yüksekliği](mold_roof_height.md) ayarıyla yapılandırılabilen belirli bir yükseklikte bir cilt oluşturulur. Ancak bu cilt, döküm malzemesini içine dökebilmeniz için modelin en üstünde oluşturulmaz. Ayrıca modelin en altında da oluşturulmaz. Döküm yapılırken inşa tablasında kalması amaçlanmıştır.

Kalıbınızı Tasarlama
----
Cura'nın kalıp oluşturma işlemi mükemmel değildir. Birkaç eksik nokta bulunmaktadır. Bunları düzeltmek için bazı ipuçları şunlardır.
* Cura, modelinizdeki tüm yerel maksimumlar için döküm yolları oluşturmaz. Döküm yolu gerektiren her noktaya dikey çubuklar eklemeniz gerekir.
* Cura, malzemenizin soğurken küçülmesi durumunda ekstra malzeme dökülmesine izin vermez. Malzemeniz çok küçülüyorsa, en yüksek noktasına bile ekstra döküm yolları eklemeniz gerekir.
* Cura'nın kalıbı her zaman bir parçadır. Birçok şekil için bu, kalıbın çıkarılması için yok edilmesi gerektiği anlamına gelir. Kalıplar, basit bir güçle, içindeki malzeme buna izin veriyorsa ısınarak veya suya çözünen PVA gibi bir malzeme kullanılarak yok edilebilir.
* Cura, kalıbı güçlendirmek için çubuklar veya teller yerleştirmenize izin vermez. Bunun için, Cura'nın boşluklar bırakacağı ekstra çubuklar ekleyin ve ardından çubuğu veya tel yerleştirin.
* Kalıbınızdaki alt geçitler uyarı verilmeden oluşturulur. Dökümünüzün doğru şekilde akması ve havanın dışarı çıkması için malzemenin oraya doğru akmasını sağlamak ve kalıbın katılaştıktan sonra dökümü çıkarmak için bazı döküm yolları veya diğer kanallar kullanmanız gerekir. Ayrıca, kalıbınızın katılaştıktan sonra dökümü çıkarmak için yok edilmesi gerekebileceğini unutmayın.

Kalıbın Basılacağı Malzemeler
----
İdeal kalıp özellikleri:
* çok sert
* yüksek sıcaklıklara dayanıklı
* kimyasal olarak inert olmalı, böylece döküm malzemenize bağlanmaz
* küçülme yapmamalı

Ayrıca, bazı kalıpların modeli çıkarmak için yok edilmesi gerekebilir. Bu durumda, kırılgan bir malzeme veya su veya diğer kimyasallar kullanılarak çözülebilen bir malzeme olan PVA gibi bir malzeme seçilebilir.

Döküm Yapmak İçin Kullanılan Malzemeler
----
Bir kalıbı dökmek için birçok farklı malzeme vardır. Bazıları 3B baskı ile oluşturulan kalıplarla daha uyumludur. İşte işe yarayabilecek bazı malzeme örnekleri:
* **Silikon**. Silikon, plastiklere bağlanmadığı için çıkarılması kolaydır. Silikon ayrıca çok esnektir ve bu, alt geçitler için uygundur. Dahası, silikonlar termoset ve ısıya dayanıklıdır, bu nedenle katılaştıktan sonra kalıbı eritmeyi düşünebilirsiniz. Ancak silikon dökmek için özel bir ekipmana ihtiyaç vardır. Özellikle, silikondan gaz kabarcıklarını pompalamak için bir vakum odası gereklidir.
* **Kum**. Kum, bir şeyin negatifini oluşturmak için endüstri standardıdır çünkü çok ısıya dayanıklıdır ancak dökülmeden önce ısıtılması gerekmez. Kalıbı döktükten sonra, beton veya yapıştırıcı ile bağlayarak parçalanmasını önleyebilirsiniz. Daha sonra daha ısıya dayanıklı bir malzemeden daha fazla negatif çıkarabilirsiniz.
* **Stucko**. Kum gibi, ancak genellikle daha ince tanelidir. Bu, bağlayıcının zaten malzemede bulunması avantajına sahiptir, bu yüzden bağlamaya ihtiyaç yoktur. Ancak sonuç olarak daha kırılgan bir sonuç ortaya çıkabilir.
* **Balmumu**. Özel mumlar veya figürler yapmak için, bir modeli balmumunda dökebilirsiniz. Balmumunun düşük erime sıcaklığı vardır, bu nedenle kalıbı eritmez. Ayrıca, plastiklere bağlanmaz, bu da kalıptan çıkarmayı kolaylaştırır. Balmumu çok esnektir ve kalıptan çıkarıldıktan sonra kolayca değiştirilebilir. Bir özel mum yaparken, katılaşmadan önce bir fitil eklemeyi unutmayın.
* **Çikolata**, özel bir özel ikram veya hediye olarak. Çikolatayı dökmek için, erime noktasının hemen üzerinde eritin, sonra kalıba dökün, hafifçe titreştirerek hava kabarcıklarını çıkarın ve hemen dondurucuya koyun. Hatta kalıbı, ısıyı daha hızlı çıkarmak için dondurucudaki soğuk su banyosuna koyabilirsiniz. Beş dakika sonra, çikolatayı dikkatlice kalıptan çıkarın.

FFF baskı sadece termoplastiklerle çalışabilir. Termoplastikler, yüksek sıcaklıklarda yumuşak hale gelen plastiklerdir. Bu, döküm sırasında sıcak olan döküm malzemeleri ile uyumlu değildir. Genel olarak 3B baskılı kalıplarla uyumsuz olan bazı malzemeler:
* **Metaller**, dökmek için plastiklerin erime noktasının üzerinde ısıtılması gerektiğinden, kalıbınızı eritecek ısı kütlesine sahiptir.
* **Plastikler** Kalıbın yapıldığı plastikle bağlanabilen plastikler uygun değildir. Bu, kalıbı modelden ayıramamanıza neden olabilir. Kalıbın içine bir miktar kalıp salımı püskürtmek çözüm olabilir, ancak malzeme çok benzerse yine de kalıcı olarak kalıba yapışabilir.
* **Katılaşma Sonrası Büzülme** Katılaşmadan sonra fazla miktarda büzülen malzemeler uygun değildir. Katılaşmadan önce büzülen malzemeler, yeterince uzun dökme kanalları olduğunda sorun teşkil etmez.
* **Epoxy Reçine** Reçine soğukken kalıba döküldüğünde, iki bileşenin kimyasal reaksiyonu, plastik erime noktasını aşacak kadar yeterli ısı açığa çıkarır. Ayrıca, epoksi plastiklere yapışma eğilimindedir.

3D baskı ile doğrudan uyumlu olmayan bir malzemede bir nesne oluşturmanız gerekiyorsa, çoklu döküm aşamalarıyla çalışmanız gerekir. Her aşama, önceki aşamanın negatifini oluşturur. Örneğin, nesnenizin şeklini normal olarak (bu ayarı devre dışı bırakarak) yazdırabilir, ardından kalıbı alçı banyosuna koyarak bir negatif oluşturabilirsiniz. Alçı, çok daha ısıya dayanıklı olduğu için, bronz gibi daha yüksek ısıda eriyen veya plastiklere bağlanan malzemeler kullanabilirsiniz.

Döküm Süreci
----
3D baskılı bir kalıpla döküm, diğer herhangi bir kalıpla aynıdır ve büyük ölçüde kullanılan malzemelere bağlı olacaktır. Ancak 3D baskılı kalıplarla ilgili dikkat edilmesi gereken birkaç nokta vardır.

Kalıbınızı basmak için kullandığınız termoplastiğin ısı kapasitesi düşüktür ve genellikle düşük bir cam geçiş sıcaklığına sahiptir. Bu, kalıbın dökümden sonra çabuk bir şekilde soğumasının önemli olduğu anlamına gelir. Malzeme çok yavaş soğursa, kalıp yumuşayabilir. Bu, kalıbın sonuçtan çıkarılmasını zorlaştırır. Dökümden sonra kalıbın ayırt edici şeklini korumak için, döküldükten sonra bir buz banyosuna daldırabilirsiniz.

3D baskılı kalıplar, katmanlar arasındaki sınırlar nedeniyle yanları boyunca daha fazla çıkıntıya sahiptir. Bunlar, kalıbı dökümden ayırmayı zorlaştırır. Kalıb ile döküntü arasına bir ayırıcı madde kullanıyorsanız, bu boşlukları doldurabilecek bir şey kullanın. İnce yağlayıcılar yeterli değildir. Daha uygun arayüz katmanları arasında balmumu veya daha kalın yağlayıcılar bulunur.