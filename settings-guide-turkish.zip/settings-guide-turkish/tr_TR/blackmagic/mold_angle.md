Kalıp Açısı
====
[Çıkıntıyı Yazdırılabilir Yap](../experimental/conical_overhang_enabled.md) özelliğine benzer şekilde, bu ayar kalıpların şeklini değiştirir ve destek olmadan yazdırılabilir hale getirir. Yalnızca kalıbın dış şekli değiştirilir, bu nedenle döküm şekliniz etkilenmez.

<!--screenshot {
"image_path": "mold_angle.png",
"models": [
    {
        "script": "star_podium.scad",
        "transformation": ["mirrorZ"]
    }
],
"camera_position": [81, 129, 45],
"settings": {
    "mold_enabled": "True"
},
"colours": 48
}-->
![40 derecelik bir açı, bu kalıbın alt tarafının herhangi bir destek gerektirmeden yazdırılmasına olanak tanır](../images/mold_angle.png)

Bu açıyı azaltmak, aşırı asılı kısımların yoğunluğunu azaltır. Bu, baskının daha güvenilir olmasını sağlar. Ancak baskının tabanını daha geniş yapar, bu da baskının süresini önemli ölçüde artırır ve kullanılacak malzemenin miktarını artırır.

Bazı şekiller için, kalıbın dış şeklini değiştirmek baskıyı düzgün şekilde yazdırmak için yeterli olmayabilir. Hala destek gerekebilir. Benzer bir etkiyi [Konik Desteği Etkinleştir](../support/support_conical_enabled.md) özelliğini etkinleştirerek elde edebilirsiniz.

<!--screenshot {
"image_path": "mold_needs_support.png",
"models": [{"script": "basic_overhang.scad"}],
"camera_position": [20, 183, 97],
"settings": {
    "mold_enabled": "True"
},
"colours": 32
}-->
![Bu kalıp hala destek gerektiriyor](../images/mold_needs_support.png)