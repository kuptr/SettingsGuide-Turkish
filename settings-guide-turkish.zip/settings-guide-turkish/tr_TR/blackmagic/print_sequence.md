Yazdırma Dizisi
====
Yapı levhasına birden fazla model yerleştirildiğinde, bu seçenek bu nesnelerin katmanlarının hangi sırayla yazdırılacağını belirler. İki seçenek vardır.

Hepsi Aynı Anda
----
Tüm nesneler aynı anda yazdırılacak, yani katmanlar tüm nesneler için aynı anda alttan üste doğru yazdırılacaktır. Bir nesnenin her bir katmanını yazdırmadan önce diğer nesnelere geçecektir.

Bu iki önemli avantaja sahiptir:
* Önceki katmanın soğuması için daha fazla zaman alır, bu da küçük nesneleri yazdırırken daha iyi kaliteye yol açar.
* Baskı için tam yapı hacmi kullanılabilir.

Bir Tane Yalnızca
----
Nesneler sırayla yazdırılacaktır, yani bir nesnenin tüm katmanları yazdırılır ve ardından bir sonraki nesneyi yazdırmak için yapı levhasına geri dönülür.

Bu modun temel avantajları şunlardır:
* Baskı herhangi bir nedenden dolayı başarısız olursa, başarısızlık öncesinde tamamlanan tüm nesneler tamamen kullanılabilir durumdadır.
* Nesneler arasında gidip gelmek için daha az seyahat hareketi gereklidir. Bu, bazı baskı süresi kazandırır ve nozülün nesneye giriş ve çıkış yaptığı yerlerdeki yara izi sayısını azaltır.

Ancak, bu mod bazı çatışmaları önlemek için bazı kısıtlamalarla gelir.
* Yazıcınızın kiriş yüksekliğinden daha uzun olan nesneleri yazdıramazsınız. Kiriş yüksekliği, yazıcınızın Makine Ayarları iletişim kutusunda ayarlanabilir. Bu kiriş yüksekliği, nozül ucunun ve baskı kafasını taşıyan sistemin arasındaki dikey mesafeyi belirtir. Bu kısıtlamanın nedeni, baskı kafasının ikinci nesneyi yazdırmak için yapı levhasına inmesi gerektiğidir. Bu, ikinci nesne yazdırılırken birinci nesnenin kiriş tarafından vurulabileceği anlamına gelir. Teoride, en son yazdırılan nesnenin kirişten daha yüksek olmasına izin verilebilir, ancak basitlik açısından Cura yine de izin vermez.
* Nesneler arasındaki mesafe, baskı kafasının önceki olarak yazdırılan modellere çarpmasını önlemek için daha uzak olmalıdır.
* Nesnelerin yazdırılacağı sıra sabittir ve nesnelerin daha yakın bir şekilde yazdırılmasına izin verecek şekilde optimize edilmiştir. Baskı kafanız simetrik değilse, bu, yapı levhasında çok fazla alan tasarrufu sağlayabilir.

**Tek ekstrüzyonlu yazıcıda Yalnızca Bir Tane Yalnızca kullanılabilir. Çoklu ekstrüzyonlu bir yazıcı kullanıyorsanız, bu ayarın görünmesi için tüm ekstrüzyonları devre dışı bırakmanız gerekir.**