Yüzey Modu
====
Normalde, Cura, ağınızın tüm üçgenlerinin kesitlerini oluşturur. Bu çizgi segmentleri, döngüler oluşturmak için bir araya dikilir. Kapatılmamış olan herhangi bir döngü atılır.

Bu ayar, bu kapatılmamış döngülerle ne yapılacağını kontrol eder. "Normal" olarak ayarlanırsa, atılırlar. "Yüzey" olarak ayarlandığında, tüm kesitler çizgi olarak yazdırılır. "Her İkisi de" olarak ayarlandığında, kapalı döngüler normal olarak yazdırılır, ancak kapatılmamış olanlar ek duvarlar olarak ayrıca yazdırılır.

<!--screenshot {
"image_path": "magic_mesh_surface_mode_normal.png",
"models": [{"script": "extra_surface.py"}],
"camera_position": [66, 129, 124],
"settings": {
    "magic_mesh_surface_mode": "normal"
},
"colours": 32
}-->
<!--screenshot {
"image_path": "magic_mesh_surface_mode_surface.png",
"models": [{"script": "extra_surface.py"}],
"camera_position": [66, 129, 124],
"settings": {
    "magic_mesh_surface_mode": "surface"
},
"colours": 32
}-->
<!--screenshot {
"image_path": "magic_mesh_surface_mode_both.png",
"models": [{"script": "extra_surface.py"}],
"camera_position": [66, 129, 124],
"settings": {
    "magic_mesh_surface_mode": "both"
},
"colours": 32
}-->
![Normal mod, sağdaki tek kapatılmamış yüzeyi dışarıda bırakır](../images/magic_mesh_surface_mode_normal.png)
![Yüzey modu, yüzeyleri kapalı hacimler olarak işlemeksizin yalnızca yazdırır](../images/magic_mesh_surface_mode_surface.png)
![Her iki hacmi ve sağdaki ek kapatılmamış yüzeyi yazdırmak](../images/magic_mesh_surface_mode_both.png)

Ek olarak yazdırılan yüzeyler yalnızca dikey yüzeyleri tek çizgi olarak içerir. Yatay yüzeyler için doldurma tekniği yoktur, çünkü yüzeyler kapatılmamış çokgenler değildir. İç kısmı olmadığı için doldurulamazlar; bu nedenle üst kısımlar, altlar, dolgu veya destekler olamaz. Sadece tek çizgiler.

Ek yüzeyler, dış duvar yazdırma hızından, çizgi genişliğinden vb. etkilenerek dış duvarlar gibi yazdırılacaktır. Ayrıca, bu yüzeyler, modelin iç kısmına hizalamak yerine, yüzeyin tam ortasına hassas bir şekilde hizalanmış bir çizgi kullanarak yazdırılır. Bu, yüzeyin iç tarafının hangi tarafının modelin iç kısmı olduğu belirsiz olduğu için, yüzeyin her iki tarafında da yarım çizgi genişliğiyle uzanır. Baskınız boyutsal olarak doğru olmayacaktır. Yukarıdaki ekran görüntüsünde olduğu gibi, ek yüzey, normal, katı bir yüzeye hizalandığında ve eksik duvarları tamamlamak için "Her İkisi de" seçeneğini kullanıyorsanız, katmanlar uygun şekilde hizalanmaz.

**Normal hacimleri ve ek yüzeyleri birlikte yazdırırken, dikkate almanız gereken, hacimlerin dış duvarının tamamen hacim içinde olacağıdır. Ek yüzeyler, çizginin yüzeyin ortasında hizalandığı ve çizginin genişliğinin her iki tarafında da yarısı kadar olduğu şekilde yazdırılır. Bir ek yüzey, yukarıdaki resimlerde olduğu gibi, kapalı bir hacmin yüzeyine hizalandığında, yüzey yarım bir çizgi genişliği kadar kaydırılır. Sonuçta, ek yüzeyin iç kısmı hareket edecek bir iç kısmı yoktur.**