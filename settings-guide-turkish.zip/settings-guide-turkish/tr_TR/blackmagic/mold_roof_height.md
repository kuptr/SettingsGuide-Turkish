Kalıp Çatı Yüksekliği
====
Bu ayar, kalıbınızın üst ve alt kısımlarının ne kadar kalın olacağını belirler. Bu sadece dikey kalınlıktır. Yatay kalınlık, [Minimum Kalıp Genişliği](mold_width.md) ayarı tarafından belirlenir.

Modelinizin en üst noktasında yatay bir kısım olmayacak, böylece malzemeyi dökebilirsiniz. Modelin altında yatay bir kısım da olmayacak çünkü baskı tablası kendiliğinden kalıbı kapatarak işlev görür. Modelin altında yatay bir parça isteniyorsa, bunun için raft kullanılabilir.

Daha kalın üst ve alt kısımlar, kalıbınızı daha sağlam ve büzülme karşısında daha dirençli hale getirir. Ancak daha fazla malzeme alır ve daha uzun sürede baskı alır.