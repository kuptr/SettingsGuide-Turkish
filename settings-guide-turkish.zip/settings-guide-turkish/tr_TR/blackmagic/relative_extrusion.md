Bağıl Ekstrüzyon
====
Cura, nesnenizi g-code'da yazdırmak için yazıcıya yönlendirmeler yazıyor. Bu yönlendirmeler, baskı kafasını belirli konumlara taşır ve besleyiciyi devreye sokar. Cura genellikle baskı kafasının hareket edeceği koordinatları ve besleyicinin dönüşünü mutlak koordinatlar olarak kaydeder. Ancak bu ayar etkinleştirildiğinde, besleyici için koordinatlar göreceli olarak kaydedilir.

Bu devre dışı bırakıldığında (yani mutlak ekstrüzyon), baskıya başlamadan önce filamentin pozisyonu sıfır koordinat olarak kabul edilir. Filamentin pozisyonu, dosya boyunca daha fazla malzeme ekstrüde edildikçe artar ve filament baskının başlangıç noktasından giderek daha fazla uzaklaşır.

Ancak bu etkinleştirildiğinde, g-code'daki her ayrı satırın ekstrüzyonu, önceki satırın pozisyonuna göre göreceli olarak yazılır. Her satır, yalnızca o belirli satır için ekstrüde edilen malzeme miktarını içerir.

Göreli ekstrüzyon, oluşturulduktan sonra g-code'yu düzenlemeyi kolaylaştırır. Orta kısıma ekstra malzeme eklenmesi gerekiyorsa (hat segmentleri eklemek veya çıkarmak veya akış oranlarını ayarlamak için), yeni ekstrüzyon sadece düzenlenen kısımda yazılır. Mutlak ekstrüzyon kullanılıyorsa, sonraki tüm komutların doğru olduğundan emin olmak için besleyicinin pozisyonu `G92` kullanılarak sıfırlanmalıdır.

Ancak g-code'un işlenmesi sırasında herhangi bir yuvarlama hatası tanıtılırsa (Cura'da, donanım yazılımında veya hareket sırasında) mutlak ekstrüzyon, bir sonraki satırda bunu otomatik olarak düzeltecektir. Göreli ekstrüzyonda, bu çok küçük olsa da aşırı ekstrüzyona veya eksik ekstrüzyona yol açar.

Her yazıcı yazılımı, ilgili ekstrüzyonu desteklemeyebilir.

**Mutlak ekstrüzyon kullanıldığında, Cura, donanım yazılımında kayan nokta yuvarlama hatalarını önlemek için her 10 metrede bir filament pozisyonunu sıfırlar.**