Minimal Kalıp Genişliği
====
Bu ayar, kalıbın duvarlarının ne kadar kalın olacağını belirler. Bu sadece yatay yöndür. Dikey yönlendirme, [Kalıp Çatı Yüksekliği](mold_roof_height.md) ayarı tarafından belirlenecektir.

Daha kalın bir duvarın baskı alması, kalıbın daha sert hale gelmesine ve bu da döküm malzemesinin büzülmesine karşı daha dirençli hale gelmesine neden olur. Ancak, daha fazla malzeme alır ve daha uzun sürede baskı alır. Kalıp çok ince yapılırsa, tamamen duvarlarla doldurulması yararlı olur. Bu, dış duvarların iç sertliğe daha fazla katkıda bulunmasını sağlar. İç duvarların sertliği, büzülmeye karşı en çok etkili olan şeydir.