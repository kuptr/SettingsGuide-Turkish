Hat Genişliği
====
Bu, yazıcının yerleştireceği çizgilerin yatay genişliğidir. Normalde, nozül açıklığının çapı, çizgilerinizin ne kadar geniş olacağını belirler, ancak daha az veya daha fazla malzeme çıkartarak, yazıcı çizgilerin ne kadar geniş olacağını biraz değiştirebilir.

<!--screenshot {
"image_path": "line_width_small.png",
"models": [{"script": "holes_cutout.scad"}],
"camera_position": [17, 39, 61],
"settings": {"line_width": 0.2},
"colours": 64
}-->
<!--screenshot {
"image_path": "line_width_large.png",
"models": [{"script": "holes_cutout.scad"}],
"camera_position": [17, 39, 61],
"settings": {"line_width": 0.6},
"colours": 32
}-->
![Çok ince çizgiler](../images/line_width_small.png)
![Çok geniş çizgiler](../images/line_width_large.png)

Çizgi genişliğini azaltmak, yazıcının daha fazla detay yazdırmasına olanak tanır. Özellikle ince parçaların yazdırılmasına da olanak tanır. Çizgi genişliği, baskınızda en etkili ayarlardan biridir. İşte bazı etkileri:
* Daha ince çizgiler yazdırmak, daha ince parçaların yazdırılmasına izin verir, çünkü en ince kısımlara bile bir çizgi sığabilir.
* Çizgi genişliğini baskınızın kalınlığının düz katlarına ayarlamak, nesneyi daha güçlü hale getirir ve malzemenin daha iyi akmasını sağlar.
* Daha küçük bir çizgi genişliği, üst yüzeyinizin daha düzgün görünmesini sağlar.
* Nozül boyutunuzdan biraz daha küçük çizgiler yazdırmak, mukavemeti artırır. Nozül, bir sonraki çizginin hafifçe önceki çizginin üzerinden geçtiği sırada yan yana çizgileri birleştirebilir.
* Çizgi genişliği fazla olan çizgilerin yazdırılması, malzeme yetersiz çıkartma ile sonuçlanır. Yazıcı, çizginin istenilen genişliğini dolduracak kadar fazla malzeme çıkartmaya çalışacaktır. Bu malzeme, nereye akarsa oraya akacaktır. Ancak, bir noktada, geri basınç o kadar büyük hale gelir ki malzeme artık çok geniş çizgilerin yanlarına kadar tam olarak akamaz. Bu, çizgiler arasında boşluklar bırakır.
* Çizgi genişliği fazla olan çizgilerin yazdırılması, malzeme yetersiz çıkartma ile sonuçlanır. Malzeme nozülün içinden yeterince hızlı akamazsa, malzemenin yüzey gerilimi küçük damlacıklar halinde birikmesine neden olur, bu da çıkartmanın düzensiz olmasına ve damlacıklar arasında boşluk bırakmasına neden olur.
* Daha ince çizgiler yazdırmak, baskı süresini önemli ölçüde artırır.

Çizgi genişliğini nozül boyutunun %60'ından azaltmak veya %150'in üzerine çıkartmak önerilmez. Her ikisi de yeterli miktarda malzeme çıkartmayabilir.

<!--if cura_version>=5.0-->İnce parçalarda, çizgi genişliği yerel parça genişliğine sığacak şekilde otomatik olarak ayarlanır. Parçanın genişliğinin çizgi genişliğinin bir katı olduğundan emin olmaya gerek yoktur. [Wall Transitioning Threshold Angle](../shell/wall_transition_angle.md) , keskin köşelerde çizgi genişliğinin otomatik olarak nasıl ayarlandığını belirler. [Minimum Wall Line Width](../shell/min_wall_line_width.md) her yönde ne kadar ayarlanabileceğini belirler.<!--endif-->

<!--if cura_version<5.0:
Hat genişliklerini yeterli duvarlara uyarlama
----
İnce ancak güçlü olması gereken mekanik parçaları yazdırırken, parçanızın temiz bir çizgi genişliği katı olmadığında düzenli olarak karşılaşacaksınız. Eğer temiz bir katı değilse, Cura genellikle [Compensate Wall Overlaps](../shell/travel_compensate_overlapping_walls_enabled.md) ayarı nedeniyle bazı çizgilerin akışını azaltır. Bu, nozül üzerinden akış hızını değiştirir ve görsel kaliteye zarar verir. Eğer çizgi genişliğinin temiz bir katıysa ancak düz bir sayı değilse, duvarlardan biri 0'a düşer.

Düzgün çizgilerle temiz konturlar oluşturmak, baskının daha güçlü ve daha iyi görünmesini sağlar. Herhangi bir uzman Cura kullanıcısının temel becerilerinden biri, istenen sayıda konturun baskıyı dolduracak şekilde çizgi genişliğini ayarlayabilmesidir.

![Varsayılan çizgi genişliği, konturların uymadığı ve bazı çizgilerin diğerlerinden daha kalın olduğu durum](../images/line_width_fit_bad.png)
![Çizgi genişliğini azaltmak, uyumlu hale getirir](../images/line_width_fit_good_small.png)
![Çizgi genişliğini artırmak da çalışır](../images/line_width_fit_good_large.png)
-->
Akışı sabit tutmak
----
FDM yazıcılarında büyük akış dalgalanmaları bazen sorun olabilir. Nozül odası bir miktar malzemeyi basınç altında tutar, bu da nozüldeki gerçek akış hızının gecikmesine neden olur. Akış hızının artması veya azalması bir süre alır. Filamenti beslemek için Bowden sistemi kullanan yazıcılar ayrıca Bowden tüpünde yaylanma içerir, bu da etkiyi çok daha kötüleştirir. Bu nedenle, daha yüksek bir akış hızına geçişte azaltma ve daha düşük bir akış hızına geçişte artırma yaşarsınız. Bu nedenle, akış hızını mümkün olduğunca sabit tutmak iyi bir fikirdir.

Çizgi genişliği akış hızını büyük ölçüde etkiler. Çizgi genişliklerini birbirine yakın ve nozül boyutuna yakın tutmanız önerilir. Çizgi genişliğini önemli ölçüde ayarlarken, akış hızını daha sabit tutmak için baskı hızını da ayarlamayı düşünebilirsiniz. Bu, baskınızın boyutsal doğruluğunu artırır.