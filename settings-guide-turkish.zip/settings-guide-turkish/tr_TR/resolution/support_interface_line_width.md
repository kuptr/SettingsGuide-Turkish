Destek Arayüz Hattı Genişliği
====
Destek arayüzü çizgilerinin genişlikleri, geri kalan destek çizgilerinden ayrı olarak yapılandırılabilir.

<!--screenshot {
"image_path": "support_roof_line_width.png",
"models": [
    {
        "script": "trash_bin_lid.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [-47, 79, 110],
"settings": {
    "support_enable": true,
    "support_roof_enable": true,
    "support_roof_line_width": 0.8
},
"layer": 192,
"colours": 64
}-->
![Destek arayüzü çizgileri, geri kalan destek çizgilerinden daha geniştir](../images/support_roof_line_width.png)

Destek arayüzünü biraz daha ince çizgilerle yazdırmak, desteklediği asılı yüzeyin kalitesi için genellikle avantajlıdır, yalnızca üstteki düzgün bir yüzeyin olması nedeniyle. Ancak, bu destek arayüzü ile model arasındaki yapışmayı artırmaz, bu nedenle destek çıkarmak daha zor olmayacaktır.

Benzer şekilde, destek zemini daha düzgün yapışır, destek model üzerinde dinlendiği yerlerde iz bırakmayı azaltırken destek daha zayıf hale gelmez.

Ancak, arayüz çizgilerini çok ince yazdırmak düzensiz ekstrüzyona neden olabilir, bu da arayüzün destek etkisini azaltır, daha kötü bir asılı kalite ve daha az stabil destek sağlar. Ayrıca, nozzle aracılığıyla akış hızında büyük bir değişiklik oluşturabilir, bu da destek arayüzünü yazdırmaya başladığında aşırı ekstrüzyona ve destek arayüzünden sonraki baskıyı azaltmaya neden olabilir.