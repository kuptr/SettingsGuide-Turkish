Dış Duvar Hattı Genişliği
====
Dış duvarın çizgi genişliği, iç duvarlardan ayrı olarak ayarlanabilir. Bu ayar, dış duvar çizgisinin ne kadar geniş olacağını gösterir.

<!--screenshot {
"image_path": "wall_line_width_0.png",
"models": [{"script": "hive.scad"}],
"camera_position": [-31, -31, 147],
"settings": {
    "wall_line_count": 2,
    "wall_line_width_0": 0.8
},
"colours": 64
}-->
![Dış duvarın konturu geri kalanlardan çok daha geniştir](../images/wall_line_width_0.png)

Dış duvarı nozul çapından biraz daha küçük bir çizgi genişliğine indirmek, dayanıklılık için faydalı olduğu bilinmektedir. Nozul biraz daha az malzeme çıkaracak ancak açıklığı yan iç duvarla örtüşecektir. Bu, malzemenin önceki konulmuş duvar tarafından uygun konumuna itilmesine neden olur. Ancak bu aynı zamanda plastiğin iç içe duvarlara daha iyi yapışmasını sağlar. Bu, dış duvarın iç duvarlara daha iyi bir şekilde yapışmasını sağlar, böylece dayanıklılıklarını birleştirir. Bu, duvarların dayanıklılığını büyük ölçüde artırır.

Dış duvar çizgi genişliğini azaltmak aynı zamanda nozulun daha ince detaylar yazdırmasına izin verir, çünkü daha ince çizgi küçük detaylara daha iyi uyacaktır.

Dış duvar çizgi genişliğini artırmak, baskı süresini azaltabilir. Daha az iç duvar ile benzer kalınlıkta bir duvar elde edebilirsiniz. Dayanıklılık hala biraz azalacaktır çünkü dış duvar, iç duvarlara o kadar iyi yapışmayacaktır.

<!--if cura_version>=5.0-->İnce parçalarda, çizgi genişliği yerel genişliğe uyacak şekilde otomatik olarak ayarlanır. Parçanın genişliğinin çizgi genişliğinin bir katı olması gerekmez. [Wall Transitioning Threshold Angle](../shell/wall_transition_angle.md), çizgi genişliğinin keskin köşelerde otomatik olarak nerede ayarlanacağını belirler. [Minimum Wall Line Width](../shell/min_wall_line_width.md) bunların her bir yönde ne kadar ayarlanabileceğini belirler.<!--endif-->

<!--if cura_version<5.0:
Çizgileri Uygun yapma
----
İnce parçaları yazdırırken, duvar çizgi genişliği ayarlarını doğru ve güçlü parçalar elde etmek için önemli bir araç olarak kullanmak önemlidir. Cura yalnızca tam konturlar çizecektir, bu nedenle bir kontur uymazsa duvarlarda bir boşluk oluşur ve bu parçanın dayanıklılığını ve doğruluğunu büyük ölçüde etkiler.

Cura, duvarlar arasındaki bu tür boşlukları doldurmaya çalışırken [Fill Gaps Between Walls](../shell/fill_perimeter_gaps.md) etkinleştirilmişse, ancak bu teknik rastgele şekiller için ideal değildir ve genellikle çok fazla baskı zamanı alır. İki duvar örtüştüğünde, [Compensate Wall Overlaps](../shell/travel_compensate_overlapping_walls_enabled.md) özelliği, parçanın boyut olarak doğru olmasını sağlamak için duvar çizgi genişliğini azaltır, ancak bu akış değişiklikleri nedeniyle baskının kalitesini ve dayanıklılığını da azaltır.

İdeal bir uyum için, parçanın tam olarak duvar çizgi genişliğinin bir katı olmasını istersiniz, böylece duvarlar parçanın içinde tam olarak uyar. Parçanız ne kadar geniş olduğunu biliyorsanız, duvarların genişliğini ayarlayarak bu kolayca yapılabilir. Öncelikle, çizgilerin hala makul bir genişliğe sahip olmasını sağlayacak kadar kaç kontur sığdırmak istediğinizi görürsünüz. Ardından, çizgilerin uygun şekilde sığmasını sağlamak için duvar çizgi genişliğini ne kadar ayarlamamız gerektiğini görebilirsiniz. Unutmayın ki [Outer Wall Line Width](wall_line_width_0.md) ve [Inner Wall Line Width](wall_line_width_x.md) ayarlarını ayrı ayrı ayarlayabilirsiniz. Duvar çizgi genişliğini değiştirmenin etkisini öngörmek için her tür duvarın kaç kez çizileceğini dikkatlice sayın.

Duvar çizgilerini uygun şekilde uydurmak, uzman 3D yazıcı operatörlerini diğerlerinden ayıran önemli bir beceridir. Biraz pratik gerektirir.-->