Üst/Alt Hat Genişliği
====
Üst ve altın her çizgisinin genişliği. Bir çizginin genişliği, gereğinden fazla veya az malzeme sıkarak nozül boyutundan farklı olabilir. Daha fazla malzeme sıkılırsa, plastik yan taraflara doğru akar, çizgi daha kalın olur. Daha az malzeme sıkılırsa, malzemenin yüzey gerilimi malzemeyi nozül yolunun merkez çizgisine çekme eğilimindedir.

<!--screenshot {
"image_path": "skin_line_width.png",
"models": [
    {
        "script": "flipper_grip.scad",
        "transformation": ["scale(0.6)"]
    }
],
"camera_position": [0, 37, 107],
"settings": {"skin_line_width": 0.8},
"layer": 300,
"colours": 64
}-->
![Cilt çizgileri, geri kalanından önemli ölçüde daha geniştir](../images/skin_line_width.png)

Cilt çizgilerini genişletmek, nesnenin üst ve alt yüzeylerini yazdırmak için daha az çizgiye ihtiyaç duyulacağı için baskı zamanını azaltmanın kolay bir yoludur. Ancak bunu çok fazla artırmak büyük ekstrüzyon dalgalanmalarına neden olabilir. Bu, cilt yazdırılırken underextrusion'a ve sonraki işlemler sırasında overextrusion'a neden olur, çünkü nozüldeki akış yeterince hızlı ayarlanamaz. Cilt çizgi genişliğini artırmak ayrıca yüzeyde deliklerin oluşma şansını artırır, bu da hoş olmayan bir görünüme sahiptir ve su geçirmez olmasını engeller.

Cilt çizgilerinin genişliğini azaltmak daha güzel bir üst yüzey üretme eğilimindedir, ancak baskı süresinin büyük maliyeti vardır. Genellikle [Ütülemeyi Etkinleştir](../top_bottom/ironing_enabled.md) gibi farklı bir teknik kullanmak veya yalnızca [Üst Yüzey Hat Genişliği](../top_bottom/roofing_line_width.md) ayarını düzenlemek daha etkilidir.