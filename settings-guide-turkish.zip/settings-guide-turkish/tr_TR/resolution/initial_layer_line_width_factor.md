İlk Katman Hat Genişliği
====
Bu, başlangıç katmanındaki çizgileri belirli bir oranda daha geniş veya daha ince yapar.

<!--screenshot {
"image_path": "initial_layer_line_width_factor.png",
"models": [{"script": "hex_foot.scad"}],
"camera_position": [0, 92, 122],
"settings": {
    "adhesion_type": "brim",
    "initial_layer_line_width_factor": 200
},
"colours": 32
}-->
![Başlangıç katmanındaki çizgiler, geri kalanından iki kat daha geniştir](../images/initial_layer_line_width_factor.png)

Bu ayarın amacı, yapı platformuna yapışmayı iyileştirmektir. Daha geniş çizgileri basabilmek için, nozülün daha fazla malzeme ekstrüde etmesi ve bu malzemenin daha geniş dışarıya akması gerekir. Bu, nozülün malzemeyi yapı platformuna daha sıkı bir şekilde bastırmasına neden olur, bu da filamentin yapı platformuna yapışmasını artırır.
* Çizgiler sadece daha geniş veya daha ince olmayacak, aynı faktörle daha uzağa veya daha yakına yerleştirileceklerdir, bu yüzden aşırı ekstrüzyon veya yetersiz ekstrüzyon oluşturmayacaktır.
* Bu ayar tüm çizgi genişliklerini etkiler; deri, duvarlar, yapışma, destek, başlangıç kulesi vb. Aynı oranda daha geniş veya daha ince yapılacaklardır.