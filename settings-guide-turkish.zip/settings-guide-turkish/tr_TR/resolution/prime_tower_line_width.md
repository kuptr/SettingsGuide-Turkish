İlk Direk Hattı Genişliği
====
Bu ayar, başlangıç kulesinin çizildiği hatların genişliğini belirler.

<!--screenshot {
"image_path": "prime_tower_line_width.png",
"models": [
    {"script": "cube.scad"},
    {
        "script": "cube.scad",
        "object_settings": {"extruder_nr": 1},
        "transformation": ["translateX(40)"]
    }
],
"camera_position": [475, -419, 131],
"camera_lookat": [475, -465, 20],
"settings": {
    "prime_tower_enable": true,
    "[1]prime_tower_line_width": 0.8
},
"colour_scheme": "material_colour",
"colours": 64
}-->
![Mavi malzemenin çizgi genişliği, sarı malzemeden daha büyüktür](../images/prime_tower_line_width.png)

Daha kalın bir çizgi genişliği seçmek, başlangıç kulesinin bazen daha hızlı yazdırılmasına neden olabilir. Bir kontur tarafından çıkarılan hacim yeterince büyükse, çizgi genişliğini artırmak başka bir döngünün gereksiz hale gelmesine neden olur. Ancak çizgi genişliğini çok fazla artırmak, başlangıç kulesini yetersiz malzeme hızlı bir şekilde çıkarılamadığı için daha zayıf yapabilir.