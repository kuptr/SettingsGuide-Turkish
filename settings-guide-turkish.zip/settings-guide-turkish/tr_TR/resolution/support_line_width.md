Destek Hattı Genişliği
====
Destek çiziminde kullanılan çizgilerin genişliği, baskının geri kalan çizgi genişliğinden farklı olabilir.

<!--screenshot {
"image_path": "support_line_width.png",
"models": [
    {
        "script": "clamp.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [28, 57, 90],
"settings": {
    "support_enable": true,
    "support_line_width": 0.8
},
"layer": 350,
"colours": 128
}-->
![Destek çizgileri, geri kalan çizgilere kıyasla daha geniştir](../images/support_line_width.png)

Destek genellikle hassas bir şekilde yazdırılması gerekmediğinden, biraz zaman kazanmak için daha geniş bir çizgi genişliğiyle yazdırılabilir, bu da destek sağlamlığını tehlikeye atmadan yapılabilecek bir değişikliktir. Ancak, aynı yoğunluğa ulaşmak için destek çizgileri arasında daha fazla mesafe bırakılacaktır. Bu, baskınızın asılı yüzeylerinin kalitesini düşürebilir.