Destek Zemini Çizgi Genişliği
====
Bu ayar, destek altının çizgilerinin genişliğini ayarlar.

<!--screenshot {
"image_path": "support_bottom_line_width.png",
"models": [
    {
        "script": "gutter_lift.scad",
        "transformation": ["mirrorZ", "scale(0.5)"]
    }
],
"camera_position": [-45, 0, 104],
"camera_lookat": [0, 0, 3],
"settings": {
    "support_enable": true,
    "support_bottom_enable": true,
    "support_bottom_line_width": 0.8
},
"layer": 65,
"colours": 64
}-->
![Destek zemini (daha koyu mavi), geri kalan destekten daha geniş çizgilerle yazdırılır](../images/support_bottom_line_width.png)

Daha ince çizgilerin yazdırılması, desteklerin model üzerinde oturduğu yerlerdeki yapışmayı azaltma eğilimindedir. Ancak bu aynı zamanda yapışmayı daha sabit ve güvenilir hale getirir. Genel olarak, desteklerin çıkarılması daha kolay olan ve nesnede daha az iz bırakan destekler için tercih edilir. Elbette, daha ince çizgilerin yazdırılması daha fazla baskı zamanı alır.