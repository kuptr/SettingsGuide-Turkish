Dolgu Hattı Genişliği
====
Her iç dolgu çizgisinin genişliği. Bir çizginin genişliği, nozül boyutundan farklı olabilir, sadece gereğinden fazla veya az malzeme ekstrüde edilerek. Daha fazla malzeme ekstrüde edilirse, plastik yanlara doğru akar, çizgi daha kalın hale gelir. Daha az malzeme ekstrüde edilirse, malzemenin yüzey gerilimi malzemeyi nozül yolunun merkez çizgisine doğru çeker.

<!--screenshot {
"image_path": "infill_line_width.png",
"models": [{"script": "material_calibration.scad"}],
"camera_position": [35, 92, 122],
"settings": {"infill_line_width": 1},
"layer": 111,
"colours": 64
}-->
![İç dolgu çizgileri, geri kalanından önemli ölçüde daha geniştir](../images/infill_line_width.png)

İç dolgu çizgilerini daha geniş yapmak, baskınızı daha güçlü yapabilir ve baskı süresini de azaltabilir. Ancak, bunu çok fazla arttırmak büyük ekstrüzyon dalgalanmalarına neden olabilir. Bu, iç dolgu basılırken yetersiz ekstrüzyona ve iç dolgu sonrası basılırken fazla ekstrüzyona neden olur, çünkü nozül aracılığıyla akış yeterince hızlı ayarlanamaz.

**Gerçek iç dolgu çizgileri, [Dolgu Katmanı Kalınlığı](../infill/infill_sparse_thickness.md) ayarını ayarladıysanız, bu ayarda belirttiğiniz rakamdan daha geniş çıkabilir.**