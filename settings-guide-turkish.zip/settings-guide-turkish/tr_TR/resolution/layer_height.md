Katman Yüksekliği
====
3D yazıcı, katmanlar halinde plastik yerleştirir. Katman yüksekliği, bu katmanların kalınlığıdır ve milimetre cinsinden ölçülür. Son baskınızın görsel kalitesi ve baskı süresi üzerinde en önemli etkiye sahip olan faktördür.

<!--screenshot {
"image_path": "layer_height_0.1.png",
"models": [{"script": "plunger_stop.scad"}],
"camera_position": [25, 100, 50],
"settings": {"layer_height": 0.1},
"colours": 32
}-->
<!--screenshot {
"image_path": "layer_height_0.3.png",
"models": [{"script": "plunger_stop.scad"}],
"camera_position": [25, 100, 50],
"settings": {"layer_height": 0.3},
"colours": 32
}-->
![0.1mm katman yüksekliği](../images/layer_height_0.1.png)
![0.3mm katman yüksekliği](../images/layer_height_0.3.png)

Katman yüksekliği, genel kalite ve buna karşılık baskı süresini etkileyen en önemli ayarlar arasındadır. Bunlar sadece bazı etkilerdir:
* Daha ince katmanlar, baskının görsel kalitesini artırır. Katmanlar daha ince olduğu için, katmanın kenarlarında merdiven basamağı etkisi azalır. Ayrıca, katmanlar birbirine daha yakın olacak ve bu nedenle katmanlar arasındaki kırışıklıklar daha küçük olacak, bunun sonucunda daha pürüzsüz bir bitiş elde edilir.
* Daha ince katmanlar, yazıcının baskınızın üst ve alt yüzeylerinde daha fazla detay üretmesine izin verir.
* Daha kalın katmanlar, baskıyı belirli bir noktaya kadar daha güçlü hale getirir. Katmanlar arasında daha az sınır olacaktır, ki bu genellikle zayıf bir noktadır. Daha kalın katmanlar ayrıca çok fazla kaymayacaklardır.
* Daha kalın katmanlar, baskı süresini azaltır, çünkü nozülün yapması gereken yatay hareketler azalır.

Katman yüksekliği vs. profiller
----
Birçok ayar katman yüksekliğine bağlıdır. Katman yüksekliği, malzemenin nozul aracılığıyla akış hızını önemli ölçüde etkilediğinden, baskı sürecinin birçok parametresi değişir. Bu oldukça karmaşıktır. Örneğin, katman yüksekliğini arttırdığınızda, ek ısı kaybı oranını dengelemek için baskı sıcaklığını biraz artırmak gerekebilir. Sıcaklık daha sonra malzemenin akıcılığını etkiler, bu da köşelerinizin ne kadar keskin olacağını ve ne tür bir soğutma gerektiğini etkiler ve benzeri. Yazıcınız için kullanılabilir olan önceden oluşturulmuş bir kalite profiliyle başlamanız her zaman iyidir ve bu profillerden biri, istediğiniz katman yüksekliğine yakın bir katman yüksekliğine sahip olacaktır.

Özel Mod'da istediğiniz katman yüksekliğini seçebilirsiniz, ancak önceden oluşturulmuş profiller de çeşitli katman yüksekliklerine sahiptir. Önerilen Mod'da, bir kaydırıcı kullanarak veya Özel Mod'da açılır menü öğesini kullanarak farklı katman yüksekliklerine sahip profiller arasından seçim yapabilirsiniz. Bu profiller ayrıca katman yüksekliğine bağlı bazı parametreleri değiştirir, bu nedenle bu şekilde daha iyi bir kalite elde edebilirsiniz.

Ek notlar
----
Çok düşük katman yüksekliklerinde, yazıcınızın Z ekseni çözünürlük sınırına ulaşabilir. Yazıcınızın Z ekseni adım büyüklüğünü kontrol edin ve katman yüksekliğinin bunun bir katı olmasını sağlayın. Eğer düzgün eşleşmiyorsa, bazı katmanlar diğerlerinden daha kalın olacak ve bu da çizgilerde bantlanmaya neden olacaktır.

**Unutmayın ki katman yüksekliği ayarı, baskının ilk katmanı veya raft katmanları için geçerli değildir; bunlar ayrı bir şekilde katman yüksekliğini ayarlamak için kendi ayarlarına sahiptir. Adaptif katmanlar kullanıldığında, bu katman yüksekliği ayarı bir başlangıç ​​noktası olarak kullanılacaktır ancak gerçek katman yüksekliği bazı değişkenlik gösterecektir.**