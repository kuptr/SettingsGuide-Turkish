İlk Katman Yüksekliği
====
Bu ayar, baskınızın ilk katmanının kalınlığını tanımlar. Başlangıç katmanı, genellikle yapı platformuyla daha güçlü bir yapışma oluşturmak için geri kalanından daha kalın bir şekilde basılır. Bu ayarla, başlangıç katmanının kalınlığı, geri kalan baskının çözünürlüğünü azaltmadan artırılabilir.

<!--screenshot {
"image_path": "layer_height_0.png",
"models": [
    {
        "script": "rolling_blind_spacer.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [39, 28, 5],
"settings": {"layer_height_0": 0.3},
"colours": 32
}-->
![Başlangıç katmanı, geri kalan katmanlardan daha kalındır](../images/layer_height_0.png)

Başlangıç katmanının kalınlığını arttırmak, nozülün aynı mesafe boyunca daha fazla malzeme ekstrüde etmesine neden olur. Bu ekstra kuvvet gerektirir, çünkü malzeme yanlara doğru yayılır ve tam çizgi genişliğini doldurur. Bu ekstra kuvvet, malzemenin yapı platformuna daha iyi yapışmasını sağlar. Ek olarak, daha kalın katman, düz yüzeydeki düzensizlikleri yakalar. Eğer yapı platformu hafifçe eğilmişse, değişkenlik ilk katmanın kalınlığı tarafından absorbe edilecek, aksi takdirde nozül ikinci katmanda bunu kazıyabilir.

Çok kalın bir başlangıç katmanına sahip olmak, ilk katmanın daha fazla sarkmasına neden olur, bu da fil ayağına yol açar. [İlk Katmanın Yatay Genişlemesi](../shell/xy_offset_layer_0.md) ayarı, bunu küçük bir negatif değer vererek önleyebilir.