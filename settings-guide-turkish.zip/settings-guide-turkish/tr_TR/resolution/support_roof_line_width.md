Destek Çatısı Çizgi Genişliği
====
Destek tavanı çizgilerinin genişlikleri, geri kalan destek çizgilerinin genişliklerinden ayrı olarak yapılandırılabilir.

<!--screenshot {
"image_path": "support_roof_line_width.png",
"models": [
    {
        "script": "trash_bin_lid.scad",
        "transformation": ["scale(0.5)"]
    }
],
"camera_position": [-47, 79, 110],
"settings": {
    "support_enable": true,
    "support_roof_enable": true,
    "support_roof_line_width": 0.8
},
"layer": 192,
"colours": 64
}-->
![Destek tavanı çizgileri, geri kalan destek çizgilerinden daha geniştir](../images/support_roof_line_width.png)

Destek tavanını biraz daha ince çizgilerle yazdırmak, sadece destek arayüzünün üzerinde daha düzgün bir üst yüzeye sahip olması nedeniyle genellikle asılı yüzeyin kalitesi açısından avantajlıdır. Ancak bu, destek arayüzü ile model arasındaki yapışkanlığı artırmaz, bu nedenle destek çıkarmak daha zor olmayacaktır.

Ancak, tavan çizgilerini çok ince yazdırmak, düzensiz ekstrüzyona neden olabilir, bu da tavanın destek etkisini azaltarak daha kötü bir asılı kaliteye yol açabilir. Ayrıca, destek tavanını yazdırmaya başladığında fazla ekstrüzyon ve destek tavanından sonra ne gelirse onu yazdırmaya başladığında yetersiz ekstrüzyon gibi nozulda akış hızında büyük bir değişikliğe neden olabilir.