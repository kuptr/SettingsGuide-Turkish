Etek/Kenar Hattı Genişliği
====
Bu ayar, tek bir etek veya kenar çizgisinin genişliğini yapılandırır (hangisi etkinse).

Bir kenar kullanırken, hafifçe artırılmış bir çizgi genişliği, kenarın ve yapım tablasının yapışkanlığını artırır. Bunun nedeni, nozülün malzemeyi daha fazla kuvvetle sıkmasıdır, böylece kenar daha sıkı bir şekilde yapım tablasına bastırılır. Kenarın hoş görünmesine gerek yoktur, bu yüzden kenar çizgi genişliğinin mümkün olduğunca yüksek olması faydalıdır.

Eteği kullanırken, çizgi genişliğini artırmak daha fazla malzeme kullanmasına neden olur. Ancak iyi bir önceden doldurma için kısa bir sürede kullanılmasına izin verir, bu nedenle küçük nesneler için daha az etek çizgisi gereklidir.

**Eteğin ve kenarın çizgi genişliği ayrıca [İlk Katman Hat Genişliği](initial_layer_line_width_factor.md) ayarından da etkilenir.**