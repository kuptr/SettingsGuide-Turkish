Duvar Hattı Genişliği
====
Duvarlar için hat genişliği, baskının geri kalanından ayrı olarak ayarlanabilir. Bu ayar, bireysel duvar hatlarının ne kadar geniş olacağını belirtir.

<!--screenshot {
"image_path": "wall_line_width.png",
"models": [{"script": "hive.scad"}],
"camera_position": [-31, -31, 147],
"settings": {
    "wall_line_count": 2,
    "wall_line_width": 0.8
},
"colours": 64
}-->
![Duvarlar için hatlar geri kalanından çok daha geniştir](../images/wall_line_width.png)

Duvarları nozül boyutunun biraz altında bir hat genişliğine indirmenin güç için faydalı olduğu bilinmektedir. Nozül biraz daha az malzeme çıkaracak ancak açıklığı bitişik duvar hatlarıyla örtüşecektir. Bu, malzemenin daha önce yerleştirilen duvar tarafından uygun konumuna itilmesine neden olur. Ancak bu aynı zamanda plastik parçaların bitişik duvarlara daha iyi kaynaşmasına da neden olur. Bu duvarların birbirine daha iyi kaynamasını sağlar, böylece güçlerini birleştirebilirler. Bu, duvarların dayanıklılığını büyük ölçüde artırır.

Duvar hat genişliğini azaltmak aynı zamanda nozülün daha ince detayları basmasına olanak tanır. Özellikle [Dış Duvar Hattı Genişliği](wall_line_width_0.md) bu özellik için önemlidir.

Duvar hat genişliğini artırmak baskı süresini azaltabilir. Benzer dayanıklılığa sahip parçalar elde etmek için daha az duvar hattına ihtiyacınız olacaktır. Ancak bitişik duvarlar birbirine o kadar fazla kaynamayacağı için dayanıklılık biraz azalacaktır.

İnce parçalarda, hat genişliği otomatik olarak oradaki parçanın yerel genişliğine uyacak şekilde ayarlanır. Parçanın genişliğinin hat genişliğinin bir katı olması gerektiğini sağlamak için herhangi bir gereklilik yoktur. [Duvar Geçişi Eşik Açısı](../shell/wall_transition_angle.md), hat genişliğinin keskin köşelerde otomatik olarak nasıl ayarlandığını belirler. [Minimum Duvar Hattı Genişliği](../shell/min_wall_line_width.md), her yönde ne kadar ayarlanabileceklerini belirler.